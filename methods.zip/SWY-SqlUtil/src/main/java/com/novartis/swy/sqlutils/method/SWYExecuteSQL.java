package com.novartis.swy.sqlutils.method;

import java.util.Locale;
import com.documentum.fc.client.IDfModule;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.utils.QueryUtils;
import com.emc.common.java.utils.ArgumentParser;
import com.emc.d2.api.methods.D2Method;
import com.emc.d2.api.methods.D2methodBean;
import com.emc.d2.api.methods.ID2Method;

/**
 * D2 doesnt allow to execute SQL from D2 Life cycle, So SWYExecuteSQL D2 method
 * will allow to execute update or insert or delete SQL statements
 *
 * @author patilk
 *
 */
public class SWYExecuteSQL implements ID2Method, IDfModule {

	public final static String ARG_QUERY_STRING = "-query";

	/**
	 * execute method is default method getting called
	 * @param idfsession Session Passed to the Method
	 * @param idfsysobject ObjectID of selected Object
	 * @param local User Locale
	 * @param argumentParser Arguments passed from D2 Application
	 * @return D2MethodBean d2method bean with success or failure message
	 * @throws Exception
	 */
	@Override
	public D2methodBean execute(IDfSession idfsession, IDfSysObject idfsysobject, Locale locale,
			ArgumentParser argumentparser) throws Exception {
		
		try {
			DfLogger.debug(this, "--------------------------------------------------------------------------", null,
					null);
			DfLogger.debug(this, "Executing D2 method {0} - arguments: {1}",
					new String[] { getClass().getName(), argumentparser.toString() }, null);

			String queryString = argumentparser.getStringArgument(ARG_QUERY_STRING, "");
			DfLogger.debug(this, "Query passed as argument: {0}", new String[] { queryString }, null);
			if (queryString == null || queryString.length() == 0) {
				throw new DfException("Missing argument: -query");
			}

			QueryUtils.execSQLQuery(queryString, idfsession);

			DfLogger.debug(this, "--------------------------------------------------------------------------", null,
					null);
			return new D2methodBean(D2Method.RETURN_SUCCESS_STR, null);

		} catch (Exception exception) {
			DfLogger.error(this, exception.getMessage(), null, exception);
			return new D2methodBean(D2Method.RETURN_FATAL_STR, exception.getMessage());
		}

	}

}
