package com.novartis.swy.notification.method;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Locale;
import javax.mail.internet.InternetAddress;

import com.documentum.d2.model.D2Dictionary;
import com.documentum.fc.client.IDfModule;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfId;
import com.documentum.utils.AttributeExpression;
import com.documentum.utils.QueryUtils;
import com.documentum.utils.StringUtils;
import com.emc.common.java.javamail.MailMessage;
import com.emc.common.java.javamail.MailSender;
import com.emc.common.java.utils.ArgumentParser;
import com.emc.common.java.utils.ArrayUtil;
import com.emc.d2.api.config.mail.D2MailConfig;
import com.emc.d2.api.config.mail.ID2MailConfig;
import com.emc.d2.api.methods.D2Method;
import com.emc.d2.api.methods.D2methodBean;
import com.emc.d2.api.methods.ID2Method;

/**
 * D2 server method that Sends Notification for certain artifact documents when
 * they are finalized in the system
 * <p>
 * <strong>Method-specific arguments:</strong>
 * <ul>
 * <li><strong>-id</strong> -
 * <p style="text-indent :5em;">
 * R_OBJECT_ID of the document<strong>(Mandatory)</strong>.
 * </p>
 * </li>
 * <li><strong>-if</strong> -
 * <p style="text-indent :5em;">
 * Pre condition will be evaluated<strong>(optional)</strong>.
 * </p>
 * </li>
 * <li><strong>-dictionary</strong> -
 * <p style="text-indent :5em;">
 * Artifact Dictionary name to refer<strong>(Mandatory)</strong>.
 * </p>
 * </li>
 * <li><strong>-key</strong> -
 * <p style="text-indent :5em;">
 * key value to be searched in Artifact
 * dictionary/taxonomy<strong>(Mandatory)</strong>.
 * </p>
 * </li>
 * <li><strong>-alias</strong> -
 * <p style="text-indent :5em;">
 * Default is "notify_list". if passed the key will be searched in the
 * alias<strong>(Optional)</strong>.
 * </p>
 * </li>
 * <li><strong>-separator</strong> -
 * <p style="text-indent :5em;">
 * Default is ;. if passed the notify_list will be separated using this param
 * value<strong>(Optional)</strong>.
 * </p>
 * </li>
 * </ul>
 * 
 * @author kpatil
 **/

public class SWYArtifactNotification implements ID2Method, IDfModule {
	private IDfId doc_obj_id = null;
	private String d2_url = null;
	private String dictionaryName = null;
	private String seperator = ";";
	private String key = null;
	private String preCondition = null;
	private String aliasName = null;

	@Override
	public D2methodBean execute(IDfSession session, IDfSysObject sysObj, Locale locale,
			ArgumentParser paramArgumentParser) throws Exception {

		doc_obj_id = paramArgumentParser.getIdArgument(ISWYArtifactNotificationConstants.PARAMETER_ID, null);
		dictionaryName = paramArgumentParser.getStringArgument(ISWYArtifactNotificationConstants.PARAMETER_DIC_NAME,
				null);
		seperator = paramArgumentParser.getStringArgument(ISWYArtifactNotificationConstants.PARAMETER_SEPERATOR, ";");
		key = paramArgumentParser.getStringArgument(ISWYArtifactNotificationConstants.PARAMETER_KEY, null);
		preCondition = paramArgumentParser.getStringArgument(ISWYArtifactNotificationConstants.PARAMETER_PRECOND, null);
		aliasName = paramArgumentParser.getStringArgument(ISWYArtifactNotificationConstants.PARAMETER_ALIAS_NAME,
				ISWYArtifactNotificationConstants.ALIAS_NAME);
		DfLogger.debug(this,
				"***********************************************SWY Artifact Notification***********************************************************************",
				null, null);
		DfLogger.info(this, "[INFO]: **SWYArtifactNotification** Object ID :" + doc_obj_id.getId().toString(), null,
				null);
		DfLogger.info(this, "[INFO]: **SWYArtifactNotification** Dictionary Name:" + dictionaryName, null, null);

		if (doc_obj_id.isNull() || !doc_obj_id.isObjectId()) {
			throw new IllegalArgumentException("[Illegal Argument Exception] : -id parameter can't be null");
		} else if (StringUtils.isNullOrEmpty(dictionaryName))

		{
			throw new IllegalArgumentException("[Illegal Argument Exception] : -dictionary parameter can't be null");
		} else if (StringUtils.isNullOrEmpty(key)) {
			throw new IllegalArgumentException("[Illegal Argument Exception] : -key parameter can't be null");
		}
		IDfSysObject docObject = (IDfSysObject) session.getObject(doc_obj_id);
		if (!QueryUtils.checkObjectConditionExpression(docObject, preCondition, session)) {
			DfLogger.info(this, "Preconditions not satisfied for {0} \"{1}\" ({2}) - exiting",
					new String[] { docObject.getTypeName(), docObject.getObjectName(), preCondition }, null);

			return new D2methodBean(D2Method.RETURN_SUCCESS_STR, null);
		}

		String resultType = null;

		String email_ids = D2Dictionary.getAliasValue(dictionaryName, key, aliasName, session, docObject,
				session.getLoginUserName(), true, true);
		if (StringUtils.isNullOrEmpty(email_ids)) {
			resultType = "Notification not Required";
			return new D2methodBean(D2Method.RETURN_SUCCESS_STR, resultType);
		} else {
			String[] emailList = email_ids.split(seperator);

			String mailSubject = D2Dictionary.getAliasValue(ISWYArtifactNotificationConstants.NOTIFCICATION_DICTIONARY,
					ISWYArtifactNotificationConstants.KEY_PREFIX + docObject.getString("domain"), "subject", session,
					docObject, session.getLoginUserName(), true, true);
			String mailBody = D2Dictionary.getAliasValue(ISWYArtifactNotificationConstants.NOTIFCICATION_DICTIONARY,
					ISWYArtifactNotificationConstants.KEY_PREFIX + docObject.getString("domain"), "message", session,
					docObject, session.getLoginUserName(), true, true);

			if (!StringUtils.isNullOrEmpty(mailSubject) && !StringUtils.isNullOrEmpty(mailBody)) {
				mailSubject = AttributeExpression.resolve(mailSubject, docObject, session.getLoginUserName());
				mailBody = AttributeExpression.resolve(mailBody, docObject, session.getLoginUserName());
				if (mailBody.contains("d2_url_param")) {
					String d2UrlQuery = "SELECT alias_value FROM d2_dictionary_value where dictionary_name='System Parameters' and object_name='d2_url' AND is_enabled=True ";
					d2_url = QueryUtils.getAllQueryResultsAsStrings(d2UrlQuery, session)[1];
					d2_url = d2_url + "/?docbase=" + session.getDocbaseName() + "&locateId="
							+ docObject.getObjectId().toString();
					mailBody = mailBody.replace("d2_url_param", d2_url);
				}
				if (mailBody.contains("effective_date_param"))
					mailBody = mailBody.replace("effective_date_param",
							docObject.getTime("r_modify_date").asString("mm/dd/yyyy"));
				ID2MailConfig mailConfig = D2MailConfig.getInstance(session);
				MailSender mailSender = mailConfig.getMailSender();
				DfLogger.debug(this, "[Artifact  Notification] : Invoking send email for Doc Id--" + doc_obj_id + "",
						null, null);
				DfLogger.debug(this, "[Artifact  Notification] : Mail Subject" + mailSubject, null, null);
				DfLogger.debug(this, "[Artifact  Notification] : Mail Body" + mailBody, null, null);
				sendMessage(mailSender, mailSubject, mailBody, new ArrayList<String>(Arrays.asList(emailList)), null,
						mailConfig.getFromInternetAddress(), session);
				resultType = " Artifact Email Sent for object id " + doc_obj_id + " ";

			} else {
				DfLogger.info(this, "[Mail Subject/Body not found in dictionary]", null, null);
				return new D2methodBean(D2Method.RETURN_SUCCESS_STR, null);
			}

		}
		return new D2methodBean(D2Method.RETURN_SUCCESS_STR, resultType);
	}

	private void sendMessage(MailSender mailSender, String mailSubject, String mailBody, ArrayList<String> addressTo,
			ArrayList<String> addressCC, InternetAddress addressFrom, IDfSession session) throws DfException {
		// Send message

		DfLogger.debug(this, "-------Sending Email With Details:------", null, null);
		DfLogger.debug(this, "Email Sent To User Names" + ArrayUtil.join(addressTo, ";"), null, null);

		MailMessage msg = new MailMessage();
		msg.setFrom(addressFrom);

		try {

			msg.setTo(addressTo);

			if (addressCC != null) {
				DfLogger.debug(this, "Email Sent CC User Names :" + ArrayUtil.join(addressCC, ";"), null, null);

				msg.setCc((InternetAddress[]) addressCC.toArray());
			}
			DfLogger.debug(this, "Email Sent with Subject : " + mailSubject, null, null);
			DfLogger.debug(this, "Email Sent with Body : " + mailBody, null, null);

			msg.setSubject(mailSubject);
			msg.setContent(mailBody, true);
	
			mailSender.sendMessage(msg);
			// DfLogger.debug(this, "Send mail To : {}", addressTo, null);
			// LOG.info("Send mail To : {}", addressTo);

		} catch (Exception e) {
			DfLogger.error(this, "-----Error sending Email------" + getClass() + ":sendMessage", null, e);
		}
	}

}
