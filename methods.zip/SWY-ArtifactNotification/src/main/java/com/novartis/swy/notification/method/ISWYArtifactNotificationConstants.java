package com.novartis.swy.notification.method;


public interface ISWYArtifactNotificationConstants {
	
	public static final String PARAMETER_ID = "-id";
	public static final String PARAMETER_DIC_NAME = "-dictionary";
	public static final String PARAMETER_SEPERATOR = "-separator";
	public static final String PARAMETER_KEY = "-key";
	public static final String ALIAS_NAME = "notify_list";
	public static final String MSG_SUBJECT = "MSG_SUBJECT";
	public static final String MSG_BODY = "MSG_BODY";
	public static final String PARAMETER_PRECOND = "-if";
	public static final String PARAMETER_ALIAS_NAME = "-alias";
	public static final String NOTIFCICATION_DICTIONARY = "CMN-DIC-SecRF User Notification";
	public static final String KEY_PREFIX = "ARTIFACT_NOTIFICATION_";
	

}
