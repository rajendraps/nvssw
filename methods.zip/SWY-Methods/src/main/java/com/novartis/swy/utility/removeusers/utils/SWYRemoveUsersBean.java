package com.novartis.swy.utility.removeusers.utils;

import java.io.Serializable;
import java.util.ArrayList;

public class SWYRemoveUsersBean implements Serializable
{
	private String tarObjectId=null;
	private String srcObjectId=null;
	private ArrayList<String> action=new ArrayList<String>();
	private ArrayList<String> srcAttr=new ArrayList<String>();
	private ArrayList<String> tarAttr=new ArrayList<String>();
	
	private ArrayList<String[]> srcAttrValue=new ArrayList<String[]>();
	
	
	public ArrayList<String[]> getSourceAttrValue()
	{
		return srcAttrValue;
	}
	
	public void setSourceAttrValue(String[] srcAttrVal)
	{
		srcAttrValue.add(srcAttrVal);
	}
	
	
	public ArrayList<String> getAction()
	{
		return action;
	}
	
	public void setAction(String actionName)
	{
		action.add(actionName);
	}
	
	public ArrayList<String> getSourceAttribute()
	{
		return srcAttr;
	}
	
	public void setSourceAttribute(String sAttrName)
	{
		srcAttr.add(sAttrName);
	}
	
	public ArrayList<String> getTargetAttribute()
	{
		return tarAttr;
	}
	
	public void setTargetAttribute(String tAttrName)
	{
		tarAttr.add(tAttrName);
	}
	
	
	
	
	public String getTargetObjectId()
	{
		return tarObjectId;
	}
	
	public void setTargetObjectId(String objId)
	{
		tarObjectId=objId;
	}
	
	
	public String getSourceObjectId()
	{
		return srcObjectId;
	}
	
	
	public void setSourceObjectId(String objId)
	{
		srcObjectId=objId;
	}
}