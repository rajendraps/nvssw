package com.novartis.swy.security.utils;

public interface ISWYApplySECRFConstants {
	// Documentum method name to use for distributed placeholder generation.
	
	
	final public static String DEFAULT_SEPARATOR="~";
	final public static String COMMA_SEPARATOR=",";
	
	//final public static String DCTM_DATE_ATTR_FORMAT="mm/dd/yyyy hh:mi:ss" ;	
	final public static String DCTM_DATE_ATTR_FORMAT="mm/dd/yyyy hh:mi:ss a";
	final public static String ORACLE_DATE_ATTR_FORMAT="yyyy/mm/dd hh24:mi:ss";
	final public static String DQL_DATE_ATTR_YYYYMMDDHHMISS_FORMAT=	"yyyy/mm/dd hh:mi:ss";
	final public static String DM_METHOD_NAME = "SWYApplySecRF";
	
	final public static String ROLES_DICTIONARY="CMN-DIC-Security Registration Roles";
	final public static String D2_CORE_METHOD_CLASS = "com.emc.d2.api.methods.D2CoreMethod";
	final public static String SRF_TYPE="swy_sec_registration_form";
	final public static String CONTROLLED_DOC_TYPE="cd_controlled_doc";
	final public static String TMF_DOC_TYPE="cd_clinical_tmf_doc";
	final public static String CLINICAL_DOC_TYPE="cd_clinical";
	final public static String TMF_DOMAIN="Clinical TMF";
	final public static String SECURITY_MODE="swy_secrf_mode";
	final public static String AUTOMATIC="Automatic";
	final public static String MANUAL="Manual";
	final public static String DEFAULT="Default";
	//final public static String FROM_CONTROLLED_DOC="FROM_CONTROLLED_DOC_LIFECYCLE";

	final public static String ALL_AVAILABLE_SRFS_ATTR_NAME="swy_sel_security_rest_forms";
	final public static String SRF_ATTR_NAME="swy_security_rest_form";

	final public static String CONFIDENTIALITY_ATTR_NAME="swy_confidentiality";
	final public static String RESTRICTED_CONFIDENTIALITY_VALUE="RSTD";
	final public static String BUO_CONFIDENTIALITY_VALUEE="BUO";
	final public static String SRF_STATUS_ACTIVE_VALUE="Active";
	final public static String SRF_STATUS_INACTIVE_VALUE="Inactive";
	final public static String SECURITY_APPLICATION_MODE_ATTR_NAME="swy_secrf_application_mode"; 


	final public static String CREATOR_NAME_ATTR="r_creator_name";
	final public static String AUTHORS_NAME_ATTR="authors";

	/**
	 * Date April 18, 2017 :: Version 2.0 ::::
	 */
	final public static String DOC_ARTIFACT_NAME_ATTR="artifact_name";
	final public static String DOC_R_OBJECT_ID_ATTR="r_object_id";
	final public static String SEPARATOR=";";
	final public static String EMPTY_NON_EMPTY_ATTR_VAL_SEPARATOR="AND";
	final public static String NON_EMPTY_ATTR_VAL_SEPARATOR="=";

	final public static String DIVISIONS_ATTR_NAME="swy_divisions";
	final public static String SRF_DIVISION_ATTR_NAME="swy_division";
	final public static String SRF_ARTIFACT_NAME_ATTR="swy_filter_artifact_abv";
	final public static String SRF_IS_CROSS_DOMAIN_ATTR_NAME="swy_is_cross_domain";
	final public static String SRF_R_OBJECT_ID_ATTR="r_object_id";
	final public static String SRF_DOMAIN_ATTR_NAME="domain";
	final public static String TMP_SRF_EMPTY_ATTR_LIST_ATTR="swy_filter_empty_attr_list";
	final public static String TMP_SRF_NON_EMPTY_ATTR_LIST_ATTR="swy_filter_attr_value_list";	
	final public static String SRF_FILTER_ATTR_DICTIOANRY_NAME="CMN-DIC-Security Registration Form Filter";	
	final public static String SRF_FILTER_VALUE_LOOKUP_ATTR="Attributes";
	final public static String DOCUMENT_DOMAINS_DIC="Document Domains";
	final public static String DOCUMENT_DOMAINS_DIC_OBJ_TYPE_ALIAS="cd_object_type";
	final public static String DOCUMENT_TMF_UNIQUE_DIC="TMF Unique Artifact Names 3.0";
	final public static String C_LINE_DOMAINS="Safety,Clinical,Clinical TMF";


	final public static String DOC_SECRF_CONFLICTING_ATTR="swy_conflicting_secrf";
	final public static String DOC_SECRF_CONFLICT_STATUS="Conflict";
	final public static String DOC_SECRF_NON_CONFLICT_STATUS="Non-Conflict";
	
	final public static String DOC_CONFLICT_REMARKS="Restriction conflict must be resolved by Security Manager";
	final public static String DOC_SECRF_RSTD_REMARKS="Restricted by SecRF %s";
	final public static String DOC_SECRF_NOT_FOUND_REMARKS="Secrf not found for restricted document";
	final public static String DOC_FORCED_UNBLIND_ATTR="swy_is_forced_unblind";
	final public static String DOC_MIG_OBJ_ID_ATTR="mig_r_object_id";
	
	final public static String MAIL_OBJECT_MSGS_DICTIONARY="CMN-DIC-SecRF User Notification";
	final public static String MAIL_OBJECT_MSGS_TEMPLATE1_KEY="SecRF_EXISTING_ALL";
	final public static String MAIL_OBJECT_MSGS_TEMPLATE2_KEY="SecRF_EXISTING_ACTION_REQUIRED";
	final public static String MAIL_OBJECT_MSGS_TEMPLATE3_KEY="SecRF_NEW_CONFLICTED";
	final public static String MAIL_OBJECT_MSGS_TEMPLATE4_KEY="SecRF_NEW_CONFLICTED_MANAGER_ONLY";
	final public static String MAIL_OBJECT_MSGS_TEMPLATE5_KEY="SecRF_NEW_NON_CONFLICTED";
	final public static String MAIL_OBJECT_MSGS_TEMPLATE6_KEY="MANUAL_SECRF_NOT_FOUND";
	
	final public static String MAIL_OBJECT_NOTIFICATION_METHOD_NAME="SWYSecRFEmailNotificationAsynchMethod"; 
	final public static String MAIL_OBJECT_CREATE_PATH="/dmadmin";
	final public static String MAIL_OBJECT_TYPE="swy_secrf_mail_notification";
	final public static String MAIL_OBJECT_TYPE_ATTR_01="swy_doc_object_id";
	final public static String MAIL_OBJECT_TYPE_ATTR_02="swy_doc_security_status";
	final public static String MAIL_OBJECT_TYPE_ATTR_03="swy_comment";
	final public static String MAIL_OBJECT_TYPE_ATTR_04="swy_form_managers";
	final public static String MAIL_OBJECT_TYPE_ATTR_05="swy_new_authors";
	final public static String MAIL_OBJECT_TYPE_ATTR_06="swy_previous_authors";
	final public static String MAIL_OBJECT_TYPE_ATTR_07="swy_is_workflow_aborted";
	
	final public static String SUCCESS_STATUS="Success";
	final public static String FAILED_STATUS="Failed";

	final public static String APPEND_FORM_MANAGERS_TO_ATTR="doc_coordinators";
	final public static String RETRIEVE_FORM_MANAGERS_RECORD_ATTR="form_managers";
	final public static String RETRIEVE_AUTHORS_RECORD_ATTR="authors";
	
	final public static String SECRF_STATS_INFO_TEXT_ALL_AFFECTED_DOC="Number of Affected Documents"; 	// Max char. lenght must be 255 char
	final public static String SECRF_STATS_INFO_TEXT_CONFLICTED_DOC="Number of Conflicted Documents";	// Max char. length must be 255 char
	final public static String SECRF_STATS_INFO_TEXT_WF_ABORTED_DOC="Number of Documents in Workflow";  // Max character length must be 255 char
	final public static String SECRF_STATS_INFO_TEXT_QC_ABORTED_DOC="Number of Documents in QC";  // Max character length must be 255 char
	final public static String SECRF_STATS_INFO_TEXT_CHECKED_OUT_DOC="Number of Checked Out Documents";  // Max character length must be 255 char
	
	final public static String WF_ABORT_WF_METHOD_NAME="CDFWorkflowManagerMethod";
	final public static String WF_ABORT_LC_TRANSITIONSTATE="(Abort WF)";
	final public static String DOC_IS_IN_WF_ATTR_NAME="wf_is_in_workflow";
	final public static String SYS_CURRENT_VERSION_LABEL="CURRENT";
	
	final public static String[] ATTR_TO_BE_UPDATE_ON_VERSION_OBJ= new String[]{"authors","readers","reviewers","approvers","qo_approvers","review_notif_recipients",
			"doc_coordinators","format_reviewers","auditors","swy_sel_security_rest_forms","swy_security_rest_form","swy_secrf_application_mode","swy_applicable_secrf_count","swy_conflicting_secrf",
			"swy_declassification_date","swy_confidentiality","swy_data_privacy","swy_security_filters","qc_group","qc_user","external_authors","external_approvers","external_auditors",
			"external_doc_coordinators","external_readers","external_reviewers"};
	
	//final public static String SRF_ATTR_LIST_TO_RETRIEVED_BASED_ON_DIVISION="r_object_id,swy_filter_attr_value_list,swy_filter_empty_attr_list";
	final public static String TMF_QC_USER_ATTR="qc_user";
	final public static String TMF_QC_USER_DEFAULT_VAL="none";
	final public static String TMF_QC_GROUP_ATTR="qc_group";
}
