package com.novartis.swy.tmf.methods;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;

import com.documentum.cdf.d2.D2Integrator;
import com.documentum.fc.client.IDfModule;
import com.documentum.fc.client.IDfRelation;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.client.IDfTypedObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfId;
import com.documentum.utils.QueryUtils;
import com.documentum.utils.StringUtils;
import com.emc.common.dctm.objects.DfDocbaseConstantsEx;
import com.emc.common.java.utils.ArgumentParser;
import com.emc.d2.api.methods.D2Method;
import com.emc.d2.api.methods.D2methodBean;
import com.emc.d2.api.methods.ID2Method;

/**
 * D2 Server method that updates creates reference links for Clinical and Safety
 * documents to Trial Registration Forms
 * <p>
 * Method Args :
 * <ul>
 * <li>-id object ID of selected document</li>
 * <li>-force remove all the links and recreate them from scratch</li>
 * 
 * </ul>
 *
 */
public class SWYCreateStudyLinks implements ID2Method, IDfModule {
	private static final String TYPE_DM_RELATION = "dm_relation";
	private static final String ARG_FORCE_NEW = "-force";
	private static final String ARG_SELECTED_OBJECT_ID = "-id";
	private static final String ATTR_LIST_OF_STUDIES = "swy_referenced_studies";
	private static final int MAX_LENGTH_IN_CLAUSE_D2_CORE = 500;
	private static final String REL_DESCRIPTION = "Document Referencing";
	private static final String REL_RELATE = "swy_doc_ref";
	private static final String REFERENCE_CLINICAL_PREFIX_NAME = "[CLINICAL]";
	private static final String REFERENCE_SAFETY_PREFIX_NAME = "[SAFETY]";
	private static final String ATTR_IS_PLACEHOLDER = "is_placeholder";
	private static final String TYPE_CLINICAL = "cd_clinical";
	private static final String TYPE_SAFETY = "cd_safety";

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.emc.d2.api.methods.ID2Method#execute(com.documentum.fc.client.IDfSession,
	 * com.documentum.fc.client.IDfSysObject, java.util.Locale,
	 * com.emc.common.java.utils.ArgumentParser)
	 */
	@Override
	public D2methodBean execute(IDfSession session, IDfSysObject job, Locale locale, ArgumentParser argumentParser)
			throws Exception {
		try {
			// The "-id" argument is passed automatically by D2, and specifies
			// the selected object ID:
			IDfId targetObjectId = argumentParser.getIdArgument(ARG_SELECTED_OBJECT_ID, null);

			if ((targetObjectId == null) || targetObjectId.isNull()) {
				throw new DfException("Missing argument: -id");
			}

			boolean force = argumentParser.getBooleanArgument(ARG_FORCE_NEW, false);
			IDfSysObject targetObject = (IDfSysObject) session.getObject(targetObjectId);

			if (targetObject == null) {
				throw new DfException(
						"Invalid argument: -id " + targetObjectId.getId() + " - the specified object does not exist.");
			}
			String objectType = targetObject.getTypeName();

			if (targetObject.getBoolean(ATTR_IS_PLACEHOLDER)) {
				DfLogger.info(this, "Placeholder passed - do nothing", null, null);
				return new D2methodBean(D2Method.RETURN_SUCCESS_STR, targetObjectId.getId());
			}

			// Custom method args can also be passed in a D2 "Apply Method" lifecycle
			// action:
			// String myMethodArg = argumentParser.getStringArgument("-my_method_arg",
			// "defaultValue");
			create(session, targetObject, targetObjectId, objectType, force);

			return new D2methodBean(D2Method.RETURN_SUCCESS_STR, targetObjectId.getId());
		} catch (Exception e) {
			DfLogger.error(this, e.getMessage(), null, e);
			return new D2methodBean(D2Method.RETURN_FATAL_STR, e.getMessage());
		}
	}

	/**
	 * Get a list of references that are needed
	 * 
	 * @param session
	 *            Session to do work
	 * @param parentId
	 *            Id of parent (product document)
	 * @return Map of trial IDs that need references
	 * @throws DfException
	 */
	private HashMap<String, String[]> getNeededReferences(IDfSession session, IDfId parentId, String objectType)
			throws DfException {
		HashMap<String, String[]> list = new HashMap<>();
		String dql = "select clinical_trial_id from cd_clinical_trial_info where clinical_trial_id in (select "
				+ ATTR_LIST_OF_STUDIES + " from " + objectType + " (all) where r_object_id = '" + parentId.getId()
				+ "')";

		DfLogger.debug(this, "needed references dql: " + dql, null, null);

		try {
			String[] trialIds = QueryUtils.getAllQueryResultsAsStrings(dql, session);
			for (String trial_id : trialIds) {
				list.put(trial_id, new String[] { trial_id });
			}
		} catch (DfException e) {
			DfLogger.error(this, "Error in getNeededReferences for {0} ", new String[] { parentId.toString() }, e);
		}
		return list;
	}

	/**
	 * delete the references that are no longer needed
	 * 
	 * @param session
	 *            session to do work
	 * @param parentId
	 *            id of product document
	 * @return map of references to delete
	 * 
	 *         this is an overload - optional last parameter of this study - set to
	 *         null
	 * 
	 * @throws DfException
	 */
	private HashMap<String, String[]> processReferenceDeletions(IDfSession session, IDfId parentId, String objectType)
			throws DfException {
		return processReferenceDeletions(session, parentId, null, objectType);
	}

	/**
	 * delete the references that are no longer needed
	 * 
	 * @param session
	 *            session to do work
	 * @param parentId
	 *            id of product document
	 * @param thisStudy
	 *            String array representing a single study that needs the reference
	 * @return map of references to delete
	 * 
	 *         this is an overload - optional last parameter of this study - set to
	 *         null
	 * 
	 * @throws DfException
	 */
	private HashMap<String, String[]> processReferenceDeletions(IDfSession session, IDfId parentId, String[] thisStudy,
			String objectType) throws DfException {
		HashMap<String, String[]> neededReferences = getNeededReferences(session, parentId, objectType);

		if (thisStudy != null) {
			// add the passed study to the list of needed references
			neededReferences.put(thisStudy[0], thisStudy);
		}

		StringBuilder list = new StringBuilder();
		String dql = "select r_object_id from cd_common_ref_model where r_object_id in ("
				+ "select child_id from dm_relation where relation_name = '" + REL_RELATE + "' " + "and parent_id = '"
				+ parentId + "')";
		DfLogger.debug(this, "process reference deletion dql: " + dql, null, null);

		try {
			IDfTypedObject[] objects = QueryUtils.getAllQueryResults(dql, session);

			for (IDfTypedObject object : objects) {

				if (list.length() > 0) {
					list.append(",");
				}
				list.append("'" + object.getValueAt(0).toString() + "'");
			}

			if (list.length() > 0) {// delete the references
				dql = "DELETE dm_relation objects where relation_name =" + StringUtils.quote(REL_RELATE)
						+ " and parent_id ='" + parentId + "'";
				QueryUtils.execQuery(dql, session);
				switch (objectType) {
				case TYPE_CLINICAL:
					dql = "DELETE cd_clinical_tmf_doc objects where r_object_id in (" + list + ")";
					break;
				case TYPE_SAFETY:
					dql = "DELETE cd_safety objects where r_object_id in (" + list + ")";
					break;
				default:
					throw new IllegalArgumentException("Object Type invalid");
				}
				QueryUtils.execQuery(dql, session);
			}
		} catch (DfException e) {
			DfLogger.error(this, "Error in processReferenceDeletions for {0} ", new String[] { parentId.toString() },
					e);
		}

		return neededReferences;
	}

	/**
	 * Create Clinical or Safety Document References
	 * 
	 * @param session
	 *            IDfsession
	 * @param obj
	 *            Selected object
	 * @param docId
	 *            Object Id
	 * @param objectType
	 *            Selected Object type
	 * @param force
	 * @throws Exception
	 */
	public void create(IDfSession session, IDfSysObject obj, IDfId docId, String objectType, boolean force)
			throws Exception {

		switch (objectType) {
		case TYPE_CLINICAL:
			createClinical(session, obj, docId, force);
			break;
		case TYPE_SAFETY:
			createSafety(session, obj, docId, force);
			break;
		default:
			throw new IllegalArgumentException("Object Type invalid");
		}
	}

	/**
	 * Create clinical references
	 * 
	 * @param session
	 * @param obj
	 * @param docId
	 * @param force
	 * @throws Exception
	 */
	public void createClinical(IDfSession session, IDfSysObject obj, IDfId docId, boolean force) throws Exception {
		try {

			if (force) { // remove all references
				String dql = "delete cd_common_ref_model objects where r_object_id in (select child_id from dm_relation where relation_name = "
						+ StringUtils.quote(REL_RELATE) + " " + "and parent_id = '" + docId + "')";
				QueryUtils.execQuery(dql, session);
				DfLogger.info(SWYCreateStudyLinks.class.getName(),
						"Force is indicated - deleting all references for id {0} ", new String[] { docId.toString() },
						null);
			}

			// delete the relationships and the references that are not in the list
			HashMap<String, String[]> toCreate = processReferenceDeletions(session, docId, TYPE_CLINICAL);
			// create the references needed
			updateReferencesForClinical(session, obj, toCreate);

		} catch (DfException e) {
			DfLogger.error(this, "Error in create for {0} ", new String[] { docId.toString() }, e);
		}
	}

	/**
	 * Create Safety references
	 * 
	 * @param session
	 * @param obj
	 * @param docId
	 * @param force
	 * @throws Exception
	 */
	public void createSafety(IDfSession session, IDfSysObject obj, IDfId docId, boolean force) throws Exception {
		try {

			if (force) { // remove all references
				String dql = "delete cd_common_ref_model objects where r_object_id in (select child_id from dm_relation where relation_name = "
						+ StringUtils.quote(REL_RELATE) + " " + "and parent_id = '" + docId + "')";
				QueryUtils.execQuery(dql, session);
				DfLogger.info(SWYCreateStudyLinks.class.getName(),
						"Force is indicated - deleting all references for id {0} ", new String[] { docId.toString() },
						null);
			}

			// delete the relationships and the references that are not in the list
			HashMap<String, String[]> toCreate = processReferenceDeletions(session, docId, TYPE_SAFETY);
			// create the references needed
			updateReferencesForSafety(session, obj, toCreate);

		} catch (DfException e) {
			DfLogger.error(this, "Error in create for {0} ", new String[] { docId.toString() }, e);
		}
	}

	/**
	 * Create the new references that are needed for Clinical
	 * 
	 * @param session
	 *            session to do work
	 * @param obj
	 *            product document
	 * @param toCreate
	 *            map of study information for creating references
	 * @throws Exception
	 */

	private void updateReferencesForClinical(IDfSession session, IDfSysObject obj, HashMap<String, String[]> toCreate)
			throws Exception {
		Iterator<String[]> iCreate = toCreate.values().iterator();
		StringBuilder inQueryFilter = new StringBuilder();
		IDfId docId = obj.getObjectId();
		while (iCreate.hasNext()) {
			String[] info = iCreate.next();
			DfLogger.info(this, "Creating reference here for {0}", new String[] { info[0] }, null);
			obj.removeAll(ATTR_LIST_OF_STUDIES);
			obj.setBoolean(ATTR_IS_PLACEHOLDER, false);
			obj.setString(DfDocbaseConstantsEx.A_STATUS, "REFERENCE");
			obj.setOwnerName(obj.getOwnerName());
			// maybe here is where we add code to set the dynamic groups for the product
			// object
			IDfId newObjId = obj.saveAsNew(true);

			IDfSysObject newObj = (IDfSysObject) session.getObject(newObjId);
			String query = "delete dm_relation object where parent_id = '" + newObjId.getId() + "'";
			QueryUtils.execQuery(query, session);

			String dql = "change cd_clinical objects to cd_clinical_tmf_doc_ref where r_object_id = '"
					+ newObjId.getId() + "'";
			QueryUtils.execQuery(dql, session);
			IDfRelation rel = (IDfRelation) session.newObject(TYPE_DM_RELATION);
			rel.setChildId(newObjId);
			rel.setParentId(docId);
			rel.setRelationName(REL_RELATE);
			rel.setChildLabel(newObj.getVersionLabel(0));
			rel.setDescription(REL_DESCRIPTION);
			rel.save();

			if (inQueryFilter.length() != 0) {
				inQueryFilter.append(",");
			}

			inQueryFilter.append("'" + newObj.getObjectId().getId() + "'");

			if (inQueryFilter.length() > MAX_LENGTH_IN_CLAUSE_D2_CORE) // need to do an interim D2 Core call. This was
																		// done from when we
																		// passed the string and were facing limits on
																		// length.
			{
				doD2Core(session, inQueryFilter, TYPE_CLINICAL);
				DfLogger.debug(this, "Ran Interim D2 Core", null, null);
				inQueryFilter.setLength(0);
			}
		}

		if (inQueryFilter.length() > 0) // we have some docs that need D2
		{
			doD2Core(session, inQueryFilter, TYPE_CLINICAL);
		}

		// regardless - we need to rename all the references to match the object's
		// name - just with a reference prefix (can't concat country/site info )
		String dql = "update cd_clinical_tmf_doc objects set object_name = '" + REFERENCE_CLINICAL_PREFIX_NAME
				+ obj.getObjectName().replace("'", "''").replace("\\", "\\\\") + "[" + obj.getVersionLabel(0) + "]"
				+ "' where r_object_id in (select child_id from dm_relation where relation_name = "
				+ StringUtils.quote(REL_RELATE) + " and parent_id = '" + docId + "')";
		QueryUtils.execQuery(dql, session);
	}

	/**
	 * Update references for safety
	 * @param session
	 * @param obj
	 * @param toCreate
	 * @throws Exception
	 */
	private void updateReferencesForSafety(IDfSession session, IDfSysObject obj, HashMap<String, String[]> toCreate)
			throws Exception {
		Iterator<String[]> iCreate = toCreate.values().iterator();
		StringBuilder inQueryFilter = new StringBuilder();
		IDfId docId = obj.getObjectId();
		while (iCreate.hasNext()) {
			String[] info = iCreate.next();
			DfLogger.info(this, "Creating reference here for {0}", new String[] { info[0] }, null);
			obj.removeAll(ATTR_LIST_OF_STUDIES);
			obj.setBoolean(ATTR_IS_PLACEHOLDER, false);
			obj.setString(DfDocbaseConstantsEx.A_STATUS, "REFERENCE");
			obj.setOwnerName(obj.getOwnerName());
			obj.setRepeatingString(ATTR_LIST_OF_STUDIES, 0, info[0].toString());

			IDfId newObjId = obj.saveAsNew(true);

			IDfSysObject newObj = (IDfSysObject) session.getObject(newObjId);
			String query = "delete dm_relation object where parent_id = '" + newObjId.getId() + "'";
			QueryUtils.execQuery(query, session);

			String dql = "change cd_safety objects to swy_safety_ref where r_object_id = '" + newObjId.getId() + "'";
			QueryUtils.execQuery(dql, session);
			IDfRelation rel = (IDfRelation) session.newObject(TYPE_DM_RELATION);
			rel.setChildId(newObjId);
			rel.setParentId(docId);
			rel.setRelationName(REL_RELATE);
			rel.setChildLabel(newObj.getVersionLabel(0));
			rel.setDescription(REL_DESCRIPTION);
			rel.save();

			if (inQueryFilter.length() != 0) {
				inQueryFilter.append(",");
			}

			inQueryFilter.append("'" + newObj.getObjectId().getId() + "'");

			if (inQueryFilter.length() > MAX_LENGTH_IN_CLAUSE_D2_CORE) // need to do an interim D2 Core call. This was
																		// done from when we
																		// passed the string and were facing limits on
																		// length.
			{
				doD2Core(session, inQueryFilter, TYPE_SAFETY);
				DfLogger.debug(this, "Ran Interim D2 Core", null, null);
				inQueryFilter.setLength(0);
			}
		}

		if (inQueryFilter.length() > 0) // we have some docs that need D2
		{
			doD2Core(session, inQueryFilter, TYPE_SAFETY);
		}

		// regardless - we need to rename all the references to match the object's
		// name - just with a reference prefix (can't concat country/site info )
		String dql = "update swy_safety_ref objects set object_name = '" + REFERENCE_SAFETY_PREFIX_NAME
				+ obj.getObjectName().replace("'", "''").replace("\\", "\\\\") + "[" + obj.getVersionLabel(0) + "]"
				+ "' where r_object_id in (select child_id from dm_relation where relation_name = "
				+ StringUtils.quote(REL_RELATE) + " and parent_id = '" + docId + "')";
		QueryUtils.execQuery(dql, session);
	}

	/**
	 * Call the D2 Configs for the set of documents created
	 * 
	 * @param session
	 *            session to do work
	 * @param inQueryFilter
	 *            CDL of document ids
	 * @throws Exception
	 */
	private void doD2Core(IDfSession session, StringBuilder inQueryFilter, String objectType) throws DfException {
		boolean runAutoName = false; // we are just going to get the name from the parent object
		String dql = "select r_object_id from " + objectType + " where r_object_id in (" + inQueryFilter + ")";
		DfLogger.debug(this, "DQL = {0}", new String[] { dql }, null);
		D2Integrator.applyD2Configurations(session, dql, false, runAutoName, true, true, false, false);
	}
}
