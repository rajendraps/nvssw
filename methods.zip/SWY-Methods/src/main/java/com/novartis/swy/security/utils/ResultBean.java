package com.novartis.swy.security.utils;

import java.io.Serializable;
import java.util.Map;

import com.documentum.fc.common.DfLogger;

public class ResultBean implements Serializable 
{
	private boolean isMailObjNeeded=false;
	private boolean isWorkflowAborted=false;
	private String object_id=null;
	private String process_msg=null;
	private String process_status=null;	//Failed or Success
	private String[] mail_object_template_name=null;
	private String mail_object_remarks=null;
	private String mail_object_doc_conflict_status=null;	// Conflict, Non-Conflict
	private String[] mail_object_doc_previous_authors=null;
	private String[] mail_object_doc_new_authors=null;
	private String[] mail_object_doc_form_mgrs=null;
	private String[] applicable_secrfs=null;
	private boolean isDocChkoutCancelled=false;
	private boolean isDocAffectedWithSecRF=false;
	
	private boolean isReCheckinReq=false;
	
	private Map<java.lang.String,java.lang.String[]> chkOutInfoMap=null;
	
	
	public ResultBean()
	{
		DfLogger.debug(this,"ResultBean() ::: Constructor :::",null,null);
	}
	
	public String[] getApplicableSecRFs()
	{
		return this.applicable_secrfs;
	}
	
	public void setApplicableSecRFs(String[] secrfs)
	{
		this.applicable_secrfs=secrfs;
	}
	
	public String[] getDocFormManagers()
	{
		return this.mail_object_doc_form_mgrs;
	}
	
	public void setDocFormManagers(String[] docFormMgrs)
	{
		this.mail_object_doc_form_mgrs=docFormMgrs;
	}
	
	public String[] getDocNewAuthors()
	{
		return this.mail_object_doc_new_authors;
	}
	
	public void setDocNewAuthors(String[] docNewAuthors)
	{
		this.mail_object_doc_new_authors=docNewAuthors;
	}
	
	public String[] getDocPreviousAuthors()
	{
		return this.mail_object_doc_previous_authors;
	}
	
	public void setDocPreviousAuthors(String[] docPreviousAuthors)
	{
		this.mail_object_doc_previous_authors=docPreviousAuthors;
	}
	
	public String getDocConflictStatus()
	{
		return this.mail_object_doc_conflict_status;
	}
	
	public void setDocConflictStatus(String mailObjDocConflictStatus)
	{
		this.mail_object_doc_conflict_status=mailObjDocConflictStatus;
	}
	
	public String getRemarks()
	{
		return this.mail_object_remarks;
	}
	
	public void setRemarks(String mailObjRemarks)
	{
		this.mail_object_remarks=mailObjRemarks;
	}
	
	public String[] getTemplateName()
	{
		return this.mail_object_template_name;
	}
	
	public void setTemplateName(String[] mailObjTemplateName)
	{
		this.mail_object_template_name=mailObjTemplateName;
	}
	
	public String getProcessStatus()
	{
		return this.process_status;
	}
	
	public void setProcessStatus(String processStatus)
	{
		this.process_status=processStatus;
	}
	
	public String getProcessMsg()
	{
		return this.process_msg;
	}
	
	public void setProcessMsg(String processMsg)
	{
		this.process_msg=processMsg;
	}
	
	public String getObjectId()
	{
		return this.object_id;
	}
	
	public void setObjectId(String objectid)
	{
		this.object_id=objectid;
	}
	
	public boolean isMailObjectNeeded()
	{
		return this.isMailObjNeeded;
	}
	
	public void setMailObjectNeeded(boolean isMailObjectNeeded)
	{
		this.isMailObjNeeded=isMailObjectNeeded;
	}
	
	public boolean isWorkflowAborted()
	{
		return this.isWorkflowAborted;
	}
	
	public void setWorkflowAborted(boolean isWFAborted)
	{
		this.isWorkflowAborted=isWFAborted;
	}
	
	public boolean isDocCheckoutCancelled()
	{
		return this.isDocChkoutCancelled;
	}
	
	public void setDocCheckoutCancelled(boolean isDocChkoutCancel)
	{
		this.isDocChkoutCancelled=isDocChkoutCancel;
	}
	
	public boolean isDocAffectedDueToSecRF()
	{
		return this.isDocAffectedWithSecRF;
	}	
	public void setDocAffectedDueToSecRF(boolean isDocAffectedDueToSecRF)
	{
		this.isDocAffectedWithSecRF=isDocAffectedDueToSecRF;
	}	
	
	public boolean isReCheckinRequired()
	{
		return this.isReCheckinReq;
	}
	public void setIsReCheckinRequired(boolean isReChkInReqd)
	{
		this.isReCheckinReq=isReChkInReqd;
	}
	
	public void setCheckoutInfo(Map<java.lang.String,java.lang.String[]> chkOutCollMap)
	{
		this.chkOutInfoMap=chkOutCollMap;
	}
	public Map<java.lang.String,java.lang.String[]> getCheckoutInfo()
	{
		return this.chkOutInfoMap;
	}
}
