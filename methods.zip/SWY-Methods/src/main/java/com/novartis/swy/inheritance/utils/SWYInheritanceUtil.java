package com.novartis.swy.inheritance.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfList;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.DfTime;
import com.documentum.fc.common.IDfList;
import com.documentum.ls.audit.AuditTrailItem;
import com.documentum.utils.QueryUtils;
import com.emc.common.java.utils.ArgumentParser;
import com.emc.d2.api.methods.D2Method;

public class SWYInheritanceUtil {


	public void applyChangesToDocAllVersions(String docObjId, IDfSession session,ArrayList<String> tarAttrList, boolean isAuditNeeded, String arg_auditEvent,String arg_auditEventMsg) 
	{
		HashMap<String, String> attrCurrValMap=new HashMap<String, String>();
		HashMap<String, String> attrNewValMap=new HashMap<String, String>();

		try {

			IDfSysObject sysObject	=(IDfSysObject)session.getObject(new DfId(docObjId));
			Vector<String> objIdsVector=getPreviousVersionsIds(docObjId,session);
			int versionCount=objIdsVector.size();
			DfLogger.debug(this, "Processing Object Id ["+docObjId+"] No of Versions ["+versionCount+"] and Ids["+objIdsVector.toString()+"]" , null, null);

			if(versionCount>0)
			{
				if(isAuditNeeded)
				{
					for(int i=0;i<versionCount;i++)
					{
						String tmoPVerObjId=objIdsVector.get(i);
						String auditAttrList=generateAttributesAuditEntry(tmoPVerObjId,session,tarAttrList);

						attrCurrValMap.put(tmoPVerObjId, auditAttrList);
					}

				}

				String[] get_single_multi_attr=new String[tarAttrList.size()];
				tarAttrList.toArray(get_single_multi_attr); 

				ArrayList<String> singleAttrList=new ArrayList<String>(); 
				ArrayList<String> multiAttrList=new ArrayList<String>();


				for(int i=0;i<get_single_multi_attr.length;i++)
				{
					String attr_name=get_single_multi_attr[i];
					if(sysObject.hasAttr(attr_name))
					{
						if(sysObject.isAttrRepeating(attr_name))
						{
							multiAttrList.add(attr_name);
						}
						else
						{
							singleAttrList.add(attr_name);
						}
					}
				}

				int versionUpdateResult=0;	
				boolean isUpdateVersionPerformed=false;
				
				/**
				 * Start : Added on June 12, 2020
				 */
				if ((multiAttrList.size()>0 || singleAttrList.size() >0) && versionCount>0)
				{
					disableObjectsImmutability(true,session,docObjId,versionCount, objIdsVector);
				}
				/**
				 * End : Added on June 12, 2020
				 */
//==============
				Map<String,Map<java.lang.String,java.lang.String[]>> chkoutDataOfAllVersion= getCheckoutInfoAllVersions(session,objIdsVector);
				Map<String,Boolean> allVersionChkoutAbortData=  isAllVersionCheckoutAborted(session,objIdsVector);
				
				DfLogger.info(this, "Processing Object Id ["+docObjId+"]  Updating repeating attributes for older version Start....", null, null);
				for (int i=0; i<multiAttrList.size();i++)
				{
					versionUpdateResult=updateRepeatingAttributeOnVersionedDoc( docObjId, sysObject,  session, multiAttrList.get(i), versionCount,  objIdsVector) ;
					if(versionUpdateResult>0)
					{
						isUpdateVersionPerformed=true;
					}
				}
				DfLogger.info(this, "Processing Object Id ["+docObjId+"]  Updating repeating attributes for older version Done.... Is any attribute updated ["+isUpdateVersionPerformed+"]", null, null);

				DfLogger.debug(this, "Processing Object Id ["+docObjId+"]  Updating Single attributes for older version Start....", null, null);
				String singleAttrArr[]=new String[singleAttrList.size()];
				for (int i=0; i<singleAttrList.size();i++)
				{

					singleAttrArr[i]=singleAttrList.get(i);
				}
				versionUpdateResult=updateSingleAttributeOnVersionedDoc( docObjId, sysObject,  session, singleAttrArr, versionCount,  objIdsVector) ;
				if(versionUpdateResult>0)
				{
					isUpdateVersionPerformed=true;
				}
				DfLogger.debug(this, "Processing Object Id ["+docObjId+"]  Updating single attributes for older version Done.... Is any attribute updated ["+isUpdateVersionPerformed+"]", null, null);		

				if(isUpdateVersionPerformed)
				{
					if(isAuditNeeded)
					{
						for(int i=0;i<versionCount;i++)
						{
							String tmoPVerObjId=objIdsVector.get(i);
							String auditAttrList=generateAttributesAuditEntry(tmoPVerObjId,session,tarAttrList);

							attrNewValMap.put(tmoPVerObjId, auditAttrList);
						}

						if(attrCurrValMap.size()==attrNewValMap.size() && attrNewValMap.size()==versionCount)
						{
							for(int i=0;i<versionCount;i++)
							{
								String tmpPrevVerObjId=objIdsVector.get(i);
								String auditAttrList=attrNewValMap.get(tmpPrevVerObjId);
								String auditAttrListOld=attrCurrValMap.get(tmpPrevVerObjId);

								createAuditObject(tmpPrevVerObjId,session,arg_auditEvent,arg_auditEventMsg,auditAttrList,auditAttrListOld);
							}
						}
					}
				}
				
				if(allVersionChkoutAbortData!=null && allVersionChkoutAbortData.size()>0)
				{
					if(chkoutDataOfAllVersion!=null && chkoutDataOfAllVersion.size()>0)
					{
						allVersionCheckoutAbortCancelled(session,allVersionChkoutAbortData,chkoutDataOfAllVersion);
					}
				}
				/**
				 * Start : Added on June 12, 2020
				 */
				if ((multiAttrList.size()>0 || singleAttrList.size() >0) && versionCount>0)
				{
					disableObjectsImmutability(false,session,docObjId,versionCount,  objIdsVector);
				}
				/**
				 * End : Added on June 12, 2020
				 */
				
				
			}
		}

		catch (Exception e) {
			DfLogger.error(this, e.getLocalizedMessage(), null, e);
		}
	}


	public Map<String,Map<java.lang.String,java.lang.String[]>> getCheckoutInfoAllVersions(IDfSession session,Vector<String> objectIds)
	{
		DfLogger.debug(this, "getCheckoutInfoAllVersions", null,null);
		Map<String,Map<java.lang.String,java.lang.String[]>> allVersionChkOutInfoMap=new HashMap<String,Map<java.lang.String,java.lang.String[]>>();
		try 
		{
			int versionCount=objectIds.size();
			DfLogger.debug(this, "getCheckoutInfoAllVersions::: versionCount "+versionCount, null,null);
			for(int i=0;i<versionCount;i++)
			{
				String tmpVerObjId=objectIds.get(i);
				DfLogger.debug(this, "getCheckoutInfoAllVersions::: versionObjId["+tmpVerObjId+"]", null,null);
				Map<java.lang.String,java.lang.String[]> checkedoutObjInfo=getCheckoutInfo(tmpVerObjId,session);;

				if(allVersionChkOutInfoMap==null || allVersionChkOutInfoMap.size()==0)
				{
					allVersionChkOutInfoMap.put(tmpVerObjId, checkedoutObjInfo);
					DfLogger.info(this, "retriveing versioned chkout details new entry ["+tmpVerObjId+"]", null, null);
				}
				else
				{
					if(!allVersionChkOutInfoMap.containsKey(tmpVerObjId))
					{
						allVersionChkOutInfoMap.put(tmpVerObjId, checkedoutObjInfo);
						DfLogger.info(this, "retriveing versioned chkout details new entryyy ["+tmpVerObjId+"]", null, null);
					}
					else
					{
						DfLogger.info(this, "Key already exist ["+tmpVerObjId+"]", null, null);
					}

				}
			}
		}
		catch (Exception e)
		{
			DfLogger.error(this, e.getLocalizedMessage(), null, e);
		}
		return  allVersionChkOutInfoMap;
	}

	public Map<String,Boolean>  isAllVersionCheckoutAborted(IDfSession session,Vector<String> objectIds)
	{
		DfLogger.debug(this, "isAllVersionCheckoutAborted", null,null);
		Map<String,Boolean> chkoutabortedDetails=new HashMap<String,Boolean>() ;
		try 
		{
			int versionCount=objectIds.size();
			for(int i=0;i<versionCount;i++)
			{
				String tmpVerObjId=objectIds.get(i);
				boolean isChkOutAborted=isCheckOutAborted(tmpVerObjId,session);

				if(chkoutabortedDetails==null || chkoutabortedDetails.size()==0)
				{
					chkoutabortedDetails.put(tmpVerObjId, isChkOutAborted);
					DfLogger.info(this, "After Checkout aborted["+isChkOutAborted+"] new entry ["+tmpVerObjId+"]", null, null);
				}
				else
				{
					if(!chkoutabortedDetails.containsKey(tmpVerObjId))
					{
						chkoutabortedDetails.put(tmpVerObjId, isChkOutAborted);
						DfLogger.info(this, "After Checkout aborted["+isChkOutAborted+"] new entryyy ["+tmpVerObjId+"]", null, null);
					}
					else
					{
						DfLogger.info(this, "Keyyy already exist ["+tmpVerObjId+"]", null, null);
					}

				}
			}
		}
		catch (Exception e)
		{
			DfLogger.error(this, e.getLocalizedMessage(), null, e);
		}
		return chkoutabortedDetails;
	}

	public void allVersionCheckoutAbortCancelled(IDfSession session,Map<String,Boolean> allVersionsChkOutAbortMap,Map<String,Map<java.lang.String,java.lang.String[]>> allVersionsChkOutDataMap)
	{
		DfLogger.debug(this, "allVersionCheckoutAbortCancelled", null,null);
		try
		{
			Set<String> objIdsKeySet = allVersionsChkOutAbortMap.keySet();
			ArrayList<String> listOfObjIdsKeys = new ArrayList<String>(objIdsKeySet);
			DfLogger.debug(this, "allVersionCheckoutAbortCancelled::: "+listOfObjIdsKeys.size(), null,null);
			for(int i=0;i<listOfObjIdsKeys.size();i++)
			{
				String objId=listOfObjIdsKeys.get(i);

				boolean wasChkOutAborted=allVersionsChkOutAbortMap.get(objId);
				DfLogger.debug(this, "allVersionCheckoutAbortCancelled::: wasChkOutAborted earlier " +objId, null,null);

				if(wasChkOutAborted)
				{
					isAbortcheckoutCancelled(objId,session, allVersionsChkOutDataMap.get(objId));
					DfLogger.info(this, "cancelcheckoutAbort done ["+objId+"]", null, null);
				}
			}
		}
		catch(Exception e)
		{
			DfLogger.error(this, e.getLocalizedMessage(), null, e);
		}
	}

	public void disableObjectsImmutability(boolean disableImmutability,IDfSession sessionObj,String docObjId,int versionCount, 
			Vector<String> objectIdsVector) throws DfException
	{
		
		DfLogger.debug(this,"Processing All Versions for Id ["+docObjId+"]  Total Versions available ["+versionCount+"]",null,null);

		String immutableDql="";
		if(disableImmutability) // Disabling Immutability : Ready for update on old version documents
		{
			immutableDql="EXECUTE exec_sql WITH QUERY='update dm_sysobject_s set r_immutable_flag=0 where r_object_id  in (select distinct r.r_object_id from dm_sysobject_r r, dm_sysobject_s s where r.r_object_id=s.r_object_id and r.r_version_label!=''CURRENT'' and r.r_object_id!=''"+docObjId+"'' and s.i_chronicle_id=(select i_chronicle_id from dm_sysobject_s where r_object_id=''"+docObjId+"''))'";
			DfLogger.debug(this,"Processing Object Id ["+docObjId+"] Object Immutability False ["+immutableDql+"]",null,null);
		}
		else // Enabling Immutability : Locking for any update on old version documents
		{
			immutableDql="EXECUTE exec_sql WITH QUERY='update dm_sysobject_s set r_immutable_flag=1 where r_object_id  in (select distinct r.r_object_id from dm_sysobject_r r, dm_sysobject_s s where r.r_object_id=s.r_object_id and r.r_version_label!=''CURRENT'' and r.r_object_id!=''"+docObjId+"'' and s.i_chronicle_id=(select i_chronicle_id from dm_sysobject_s where r_object_id=''"+docObjId+"''))'";
			DfLogger.debug(this,"Processing Object Id ["+docObjId+"]  Object Immutability False ["+immutableDql+"]",null,null);

		}
		String immutableTrueDqlResultStr=QueryUtils.execQuery(immutableDql, sessionObj);

		DfLogger.debug(this, "Processing Object Id ["+docObjId+"]  Object Immutability Disable Request ["+disableImmutability+"] with DQL ["+immutableDql+"] and result  ["+immutableTrueDqlResultStr+"]", null, null);

	}
	/*public void disableObjectsImmutability(boolean disableImmutability,IDfSession sessionObj,String docObjId,int versionCount, 
			Vector<String> objectIdsVector) throws DfException
	{
		int batchSize=100;
		int no_of_batch=versionCount/batchSize;
		int doc_count_outside_batch=versionCount%batchSize;
		DfLogger.info(this,"Total Versions available ["+versionCount+"] No. Of batch["+no_of_batch+"] Documents count outside batch ["+doc_count_outside_batch+"] BatchSize["+batchSize+"]",null,null);

		int counter=0;
		String versionIdsAsPredicate=null;
		int total_batch=doc_count_outside_batch>0?no_of_batch+1:no_of_batch;


		for (int batchCounter=0;batchCounter<total_batch;batchCounter++)
		{
			versionIdsAsPredicate=null;
			if(batchCounter==no_of_batch)
				batchSize=doc_count_outside_batch;
			for(int j=0;j<batchSize;j++)
			{
				if(versionIdsAsPredicate==null || versionIdsAsPredicate.trim().equalsIgnoreCase(""))
				{
					versionIdsAsPredicate="'"+objectIdsVector.get(counter)+"'";
				}
				else
				{
					versionIdsAsPredicate=versionIdsAsPredicate+ " , '"+objectIdsVector.get(counter)+"'";
				}
				counter=counter+1;
			}

			//System.out.println("Batch ["+(batchCounter+1)+"] Processed records ["+counter+"] Version Object Ids ["+versionIdsAsPredicate+"]");
			DfLogger.debug(this, "Processing Object Id ["+docObjId+"] Batch ["+(batchCounter+1)+"] Processed records ["+counter+"] Versions Object IDs as predicate ["+versionIdsAsPredicate+"]", null, null);

			if(versionIdsAsPredicate!=null && !versionIdsAsPredicate.trim().equalsIgnoreCase(""))
			{
				String immutableDql="";
				if(disableImmutability) // Disabling Immutability : Ready for update on old version documents
				{
					immutableDql="EXECUTE exec_sql WITH QUERY='update dm_sysobject_s set r_immutable_flag=0 where r_object_id  in (" + versionIdsAsPredicate.replace("'", "''") +")'";
					DfLogger.debug(this,"Processing Object Id ["+docObjId+"] Object Immutability False ["+immutableDql+"]",null,null);
				}
				else // Enabling Immutability : Locking for any update on old version documents
				{
					immutableDql="EXECUTE exec_sql WITH QUERY='update dm_sysobject_s set r_immutable_flag=1 where r_object_id in ("+versionIdsAsPredicate.replace("'", "''")+") and not exists(select r_object_id from dm_sysobject_r where r_object_id in ("+ versionIdsAsPredicate.replace("'", "''") +") and r_version_label=''CURRENT'')'";
					DfLogger.debug(this,"Processing Object Id ["+docObjId+"]  Object Immutability False ["+immutableDql+"]",null,null);

				}
				String immutableTrueDqlResultStr=QueryUtils.execQuery(immutableDql, sessionObj);

				DfLogger.info(this, "Processing Object Id ["+docObjId+"]  Object Immutability Disable Request ["+disableImmutability+"] with DQL ["+immutableDql+"] and result  ["+immutableTrueDqlResultStr+"]", null, null);

			}
		}
	}*/

	public ArrayList<String> getAttributeValue(IDfSysObject docObject, String docAttribute) throws DfException
	{
		ArrayList<String> docDataList = new ArrayList<String>();

		String value = "";
		if (docObject.isAttrRepeating(docAttribute)) {
			int attrDataType = docObject.getAttrDataType(docAttribute);
			int valcount = docObject.getValueCount(docAttribute);
			if (valcount > 0) {
				for (int i = 0; i < valcount; i++) {
					value = docObject.getRepeatingString(docAttribute, i);
					if (value != null && !value.equalsIgnoreCase("")
							&& !value.trim().equalsIgnoreCase("nulldate")) {
						if (attrDataType == 4) // Time
						{
							value = "date('" + value + " utc','"
									+ ISWYApplyInheritanceConstants.DCTM_DATE_ATTR_FORMAT + "')";
							docDataList.add(value );
						} else if (attrDataType == 0) // Boolean
						{
							if (value.equalsIgnoreCase("true") || value.equalsIgnoreCase("t")
									|| value.equalsIgnoreCase("1")) {
								value = "1";
							} else if (value.equalsIgnoreCase("false")
									|| value.equalsIgnoreCase("f") || value.equalsIgnoreCase("0")) {
								value = "0";
							}
							docDataList.add(value);
						} 
						else if (attrDataType == 1 || attrDataType == 5) // Number  ||  Double
						{
							docDataList.add(value );
						} 
						else if (attrDataType == 2 || attrDataType == 3) // String  || Id
						{
							docDataList.add(value);
						}

					}
				}
			}
		} else {
			value = docObject.getString(docAttribute);
			if (value != null && !value.equalsIgnoreCase("")
					&& !value.trim().equalsIgnoreCase("nulldate")) {
				int attrDataType = docObject.getAttrDataType(docAttribute);

				if (attrDataType == 4) // Time
				{
					value = "date('" + value + " utc','"
							+ ISWYApplyInheritanceConstants.DCTM_DATE_ATTR_FORMAT + "')";
					docDataList.add(value);
				} else if (attrDataType == 0) // Boolean
				{
					if (value.equalsIgnoreCase("true") || value.equalsIgnoreCase("t")
							|| value.equalsIgnoreCase("1")) {
						value = "1";
					} else if (value.equalsIgnoreCase("false") || value.equalsIgnoreCase("f")
							|| value.equalsIgnoreCase("0")) {
						value = "0";
					}
					docDataList.add(value );
				} else if (attrDataType == 1 || attrDataType == 5) // Number
					// ||
					// Double
				{
					docDataList.add(value);
				} else if (attrDataType == 2 || attrDataType == 3) // String
					// ||
					// Id
				{
					docDataList.add(value);
				}

			}
		}
		return docDataList;
	}

	public int updateSingleAttributeOnVersionedDoc(String docObjId,IDfSysObject sysObject, IDfSession session, String[] attr_to_be_update, int versionCount, Vector<String> objVector) throws Exception
	{
		DfLogger.debug(this, "Updating Single Attributes....", null, null);

		String dqlPredicate=null;
		for(int i=0;i<attr_to_be_update.length;i++)
		{
			String attr_name=attr_to_be_update[i];
			int attrDataType=sysObject.getAttrDataType(attr_name);
			String value=null;
			if (attrDataType == 4) // Time
			{
				value=sysObject.getTime(attr_name).asString(ISWYApplyInheritanceConstants.DCTM_DATE_ATTR_FORMAT);

				if(value!=null && !value.trim().equalsIgnoreCase("nulldate") && !value.trim().equalsIgnoreCase(""))
				{
					value = "date('" + value + " utc','"
							+ ISWYApplyInheritanceConstants.DCTM_DATE_ATTR_FORMAT + "')";
				}
				else
				{
					value ="date('nulldate')";
				}
				if(dqlPredicate==null || dqlPredicate.trim().equalsIgnoreCase(""))
				{
					dqlPredicate = " set "+attr_name +" ="+value;
				}
				else
				{
					dqlPredicate=dqlPredicate + " , set "+attr_name +" ="+value;;
				}

			} 
			else if (attrDataType == 0) // Boolean
			{
				value=String.valueOf(sysObject.getBoolean(attr_name));
				if (value.equalsIgnoreCase("true") || value.equalsIgnoreCase("t")
						|| value.equalsIgnoreCase("1")) {
					value = "1";
				} else if (value.equalsIgnoreCase("false")
						|| value.equalsIgnoreCase("f") || value.equalsIgnoreCase("0")) {
					value = "0";
				}

				if(dqlPredicate==null || dqlPredicate.trim().equalsIgnoreCase(""))
				{
					dqlPredicate = " set "+attr_name +" ="+value;
				}
				else
				{
					dqlPredicate=dqlPredicate + " , set "+attr_name +" ="+value;;
				}
			} 
			else if (attrDataType == 1 ) // Number 

			{
				value=String.valueOf(sysObject.getInt(attr_name));
				if(dqlPredicate==null || dqlPredicate.trim().equalsIgnoreCase(""))
				{
					dqlPredicate = " set "+attr_name +" ="+value;
				}
				else
				{
					dqlPredicate=dqlPredicate + " , set "+attr_name +" ="+value;;
				}
			}
			else if ( attrDataType == 5) //  DOUBLE

			{
				value=String.valueOf(sysObject.getDouble(attr_name));
				if(dqlPredicate==null || dqlPredicate.trim().equalsIgnoreCase(""))
				{
					dqlPredicate = " set "+attr_name +" ="+value;
				}
				else
				{
					dqlPredicate=dqlPredicate + " , set "+attr_name +" ="+value;;
				}
			}
			else if (attrDataType == 2 || attrDataType == 3) // String || ID
			{
				value=String.valueOf(sysObject.getString(attr_name));
				if(dqlPredicate==null || dqlPredicate.trim().equalsIgnoreCase(""))
				{
					dqlPredicate = " set "+attr_name +" ='"+value+"'";
				}
				else
				{
					dqlPredicate=dqlPredicate + " , set "+attr_name +" ='"+value+"'";
				}
			}
		}

		DfLogger.info(this, "Processing Object Id ["+docObjId+"]  DQL Syntax to update ["+dqlPredicate+"]", null, null);

		int versionUpdateResult=0;

		if(dqlPredicate!=null && !dqlPredicate.trim().equalsIgnoreCase(""))
		{

			int batchSize=100;
			int no_of_batch=versionCount/batchSize;
			int doc_count_outside_batch=versionCount%batchSize;
			System.out.println("Total Versions available ["+versionCount+"] No. Of batch["+no_of_batch+"] Documents count outside batch ["+doc_count_outside_batch+"] BatchSize["+batchSize+"]");
			DfLogger.debug(this, "Total Versions available ["+versionCount+"] No. Of batch["+no_of_batch+"] Documents count outside batch ["+doc_count_outside_batch+"] BatchSize["+batchSize+"]", null, null);
			int counter=0;
			String versionIdsAsPredicate=null;
			int total_batch=doc_count_outside_batch>0?no_of_batch+1:no_of_batch;


			for (int batchCounter=0;batchCounter<total_batch;batchCounter++)
			{
				versionIdsAsPredicate=null;
				if(batchCounter==no_of_batch)
					batchSize=doc_count_outside_batch;
				for(int j=0;j<batchSize;j++)
				{
					if(versionIdsAsPredicate==null || versionIdsAsPredicate.trim().equalsIgnoreCase(""))
					{
						versionIdsAsPredicate="'"+objVector.get(counter)+"'";
					}
					else
					{
						versionIdsAsPredicate=versionIdsAsPredicate+ " , '"+objVector.get(counter)+"'";
					}
					counter=counter+1;
				}

				//System.out.println("Batch ["+(batchCounter+1)+"] Processed records ["+counter+"] Version Object Ids ["+versionIdsAsPredicate+"]");
				DfLogger.debug(this, "Processing Object Id ["+docObjId+"] Batch ["+(batchCounter+1)+"] Processed records ["+counter+"] Versions Object IDs as predicate ["+versionIdsAsPredicate+"]", null, null);

				String dqlToExecute=null;
				if(dqlPredicate!=null && !dqlPredicate.trim().equalsIgnoreCase("") && versionIdsAsPredicate!=null && !versionIdsAsPredicate.trim().equalsIgnoreCase(""))
				{
					dqlToExecute="Update "+sysObject.getTypeName()+"(all) objects "+ dqlPredicate +" where r_object_id in ("+versionIdsAsPredicate+")";
					DfLogger.debug(this, "Processing Object Id ["+docObjId+"]  DQL to update version ["+dqlToExecute+"]", null, null);
				}


				if(dqlToExecute!=null && !dqlToExecute.trim().equalsIgnoreCase(""))
				{
					String versionUpdateResultStr=QueryUtils.execQuery(dqlToExecute, session);
					versionUpdateResult=versionUpdateResult+Integer.parseInt(versionUpdateResultStr);
					DfLogger.debug(this, "Processing Object Id ["+docObjId+"]  No. of Version Obects Updated ["+versionUpdateResult+"]", null, null);
				}
			}

		}
		DfLogger.info(this, "Updating Single Attributes....END", null, null);
		return versionUpdateResult;
	}

	public int updateRepeatingAttributeOnVersionedDoc(String docObjId,IDfSysObject sysObject, IDfSession session, String attr_name, int versionCount, Vector<String> objVector) throws Exception
	{

		String dqlPredicate=null;

		int versionUpdateResult=0;
		if(dqlPredicate==null || dqlPredicate.trim().equalsIgnoreCase(""))
		{
			dqlPredicate="";
		}

		dqlPredicate= dqlPredicate+ " truncate "+attr_name + " ";

		int attrValCnt=sysObject.getValueCount(attr_name);

		if(attrValCnt>0)
		{
			int attrDataType=sysObject.getAttrDataType(attr_name);

			int attrValBatchSize=100;
			int no_of_attr_val_batch=attrValCnt/attrValBatchSize;
			int attr_val_count_outside_batch=attrValCnt%attrValBatchSize;
			DfLogger.debug(this,"Attribute Name ["+attr_name+"] Total Attribute Value available ["+attrValCnt+"] No. Of batch["+no_of_attr_val_batch+"] Attribute Value count outside batch ["+attr_val_count_outside_batch+"] BatchSize["+attrValBatchSize+"]",null,null);

			int attrValCounter=0;
			int attr_val_total_batch=attr_val_count_outside_batch>0?no_of_attr_val_batch+1:no_of_attr_val_batch;


			for (int attrValBatchCounter=0;attrValBatchCounter<attr_val_total_batch;attrValBatchCounter++)
			{
				versionUpdateResult=0;

				if(attrValBatchCounter>0)
					dqlPredicate="";

				if(attrValBatchCounter==no_of_attr_val_batch)
					attrValBatchSize=attr_val_count_outside_batch;

				for(int incr=0;incr<attrValBatchSize;incr++)
				{

					String value=null;
					if (attrDataType == 4) // Time
					{
						value=sysObject.getRepeatingTime(attr_name,attrValCounter).asString(ISWYApplyInheritanceConstants.DCTM_DATE_ATTR_FORMAT);
						if(value!=null && !value.trim().equalsIgnoreCase("nulldate") && !value.trim().equalsIgnoreCase(""))
						{
							value = "date('" + value + " utc','"
									+ ISWYApplyInheritanceConstants.DCTM_DATE_ATTR_FORMAT + "')";
						}
						else
						{
							value ="date('nulldate')";
						}

						if(attrValBatchCounter==0)
							dqlPredicate = dqlPredicate +" , append "+attr_name +" ="+value;
						else
						{
							if(incr==0)
								dqlPredicate = dqlPredicate +"  append "+attr_name +" ="+value;
							else
								dqlPredicate = dqlPredicate +" , append "+attr_name +" ="+value;
						}
					} 
					else if (attrDataType == 0) // Boolean
					{
						value=String.valueOf(sysObject.getRepeatingBoolean(attr_name,attrValCounter));
						if (value.equalsIgnoreCase("true") || value.equalsIgnoreCase("t")
								|| value.equalsIgnoreCase("1")) {
							value = "1";
						} else if (value.equalsIgnoreCase("false")
								|| value.equalsIgnoreCase("f") || value.equalsIgnoreCase("0")) {
							value = "0";
						}
						if(attrValBatchCounter==0)
							dqlPredicate = dqlPredicate +" , append "+attr_name +" ="+value;
						else
						{
							if(incr==0)
								dqlPredicate = dqlPredicate +"  append "+attr_name +" ="+value;
							else
								dqlPredicate = dqlPredicate +" , append "+attr_name +" ="+value;
						}
					} 
					else if (attrDataType == 1 ) // Number 

					{
						value=String.valueOf(sysObject.getRepeatingInt(attr_name,attrValCounter));
						if(attrValBatchCounter==0)
							dqlPredicate = dqlPredicate +" , append "+attr_name +" ="+value;
						else
						{
							if(incr==0)
								dqlPredicate = dqlPredicate +"  append "+attr_name +" ="+value;
							else
								dqlPredicate = dqlPredicate +" , append "+attr_name +" ="+value;
						}
					}
					else if ( attrDataType == 5) //  DOUBLE

					{
						value=String.valueOf(sysObject.getRepeatingDouble(attr_name,attrValCounter));
						if(attrValBatchCounter==0)
							dqlPredicate = dqlPredicate +" , append "+attr_name +" ="+value;
						else
						{
							if(incr==0)
								dqlPredicate = dqlPredicate +"  append "+attr_name +" ="+value;
							else
								dqlPredicate = dqlPredicate +" , append "+attr_name +" ="+value;
						}
					}
					else if (attrDataType == 2 || attrDataType == 3) // String || ID
					{
						value=String.valueOf(sysObject.getRepeatingString(attr_name,attrValCounter));
						if(attrValBatchCounter==0)
							dqlPredicate = dqlPredicate +" , append "+attr_name +" ='"+value+"'";
						else
						{
							if(incr==0)
								dqlPredicate = dqlPredicate +"  append "+attr_name +" ='"+value+"'";
							else
								dqlPredicate = dqlPredicate +" , append "+attr_name +" ='"+value+"'";
						}
					}

					attrValCounter=attrValCounter+1;
				}


				DfLogger.debug(this, "Processing Object Id ["+docObjId+"]  DQL Syntax to update ["+dqlPredicate+"]", null, null);

				if(dqlPredicate!=null && !dqlPredicate.trim().equalsIgnoreCase(""))
				{
					versionUpdateResult=updateAttributeOnVersionDoc( dqlPredicate,docObjId, sysObject,  session, versionCount,  objVector) ;
				}

			}
		}
		else
		{
			versionUpdateResult=updateAttributeOnVersionDoc( dqlPredicate,docObjId, sysObject,  session, versionCount,  objVector) ;
		}

		return versionUpdateResult;

	}

	private int updateAttributeOnVersionDoc(String dqlPredicate,String docObjId,IDfSysObject sysObject, IDfSession session, int versionCount, Vector<String> objVector) throws Exception
	{
		int versionUpdateResult=0;
		if(dqlPredicate!=null && !dqlPredicate.trim().equalsIgnoreCase(""))
		{

			int batchSize=100;
			int no_of_batch=versionCount/batchSize;
			int doc_count_outside_batch=versionCount%batchSize;
			System.out.println("Total Versions available ["+versionCount+"] No. Of batch["+no_of_batch+"] Documents count outside batch ["+doc_count_outside_batch+"] BatchSize["+batchSize+"]");
			DfLogger.debug(this, "Total Versions available ["+versionCount+"] No. Of batch["+no_of_batch+"] Documents count outside batch ["+doc_count_outside_batch+"] BatchSize["+batchSize+"]", null, null);
			int counter=0;
			String versionIdsAsPredicate=null;
			int total_batch=doc_count_outside_batch>0?no_of_batch+1:no_of_batch;


			for (int batchCounter=0;batchCounter<total_batch;batchCounter++)
			{
				versionIdsAsPredicate=null;
				if(batchCounter==no_of_batch)
					batchSize=doc_count_outside_batch;
				for(int j=0;j<batchSize;j++)
				{
					if(versionIdsAsPredicate==null || versionIdsAsPredicate.trim().equalsIgnoreCase(""))
					{
						versionIdsAsPredicate="'"+objVector.get(counter)+"'";
					}
					else
					{
						versionIdsAsPredicate=versionIdsAsPredicate+ " , '"+objVector.get(counter)+"'";
					}
					counter=counter+1;
				}

				//System.out.println("Batch ["+(batchCounter+1)+"] Processed records ["+counter+"] Version Object Ids ["+versionIdsAsPredicate+"]");
				DfLogger.debug(this, "Processing Object Id ["+docObjId+"] Batch ["+(batchCounter+1)+"] Processed records ["+counter+"] Versions Object IDs as predicate ["+versionIdsAsPredicate+"]", null, null);

				String dqlToExecute=null;
				if(dqlPredicate!=null && !dqlPredicate.trim().equalsIgnoreCase("") && versionIdsAsPredicate!=null && !versionIdsAsPredicate.trim().equalsIgnoreCase(""))
				{
					dqlToExecute="Update "+sysObject.getTypeName()+"(all) objects "+ dqlPredicate +" where r_object_id in ("+versionIdsAsPredicate+")";
					//System.out.println("[dqlToExecute=="+dqlToExecute+"]");
					DfLogger.debug(this, "Processing Object Id ["+docObjId+"]  DQL to update version ["+dqlToExecute+"]", null, null);
				}


				if(dqlToExecute!=null && !dqlToExecute.trim().equalsIgnoreCase(""))
				{
					String versionUpdateResultStr=QueryUtils.execQuery(dqlToExecute, session);
					versionUpdateResult=versionUpdateResult+Integer.parseInt(versionUpdateResultStr);
					DfLogger.debug(this, "Processing Object Id ["+docObjId+"]  No. of Version Obects Updated ["+versionUpdateResult+"]", null, null);
				}
			}

		}
		return versionUpdateResult;
	}

	public Vector<String> getPreviousVersionsIds(String docObjId, IDfSession session) throws DfException
	{
		IDfSysObject sysObject	=(IDfSysObject)session.getObject(new DfId(docObjId));
		Vector<String> objIdsVector=new Vector<String>();
		IDfCollection versionColl=null;
		try
		{
			versionColl=sysObject.getVersions("r_modify_date ,"+ISWYApplyInheritanceConstants.DOC_R_OBJECT_ID_ATTR);

			while(versionColl.next())
			{
				String versionObjId=versionColl.getString(ISWYApplyInheritanceConstants.DOC_R_OBJECT_ID_ATTR);
				if(!docObjId.equalsIgnoreCase(versionObjId))
				{
					objIdsVector.addElement(versionObjId);
				}
			}
		}
		finally
		{
			if(versionColl!=null)
			{
				versionColl.close();
				DfLogger.info(this, "::: getPreviousVersionsIds() ::: Collection Closed" , null, null);

			}
		}
		return objIdsVector;
	}

	public void updateSingleValueAttribute(String newValue, String targetAttribute, IDfSysObject targetObject)
			throws DfException
	{
		switch (targetObject.getAttrDataType(targetAttribute)) {
		case 2:
			targetObject.setString(targetAttribute, newValue);
			break;
		case 4:
			targetObject.setTime(targetAttribute, new DfTime(newValue,ISWYApplyInheritanceConstants.DCTM_DATE_ATTR_FORMAT));
			break;
		case 0:
			targetObject.setBoolean(targetAttribute, Boolean.parseBoolean(newValue));
			break;
		case 1:
			targetObject.setInt(targetAttribute, Integer.parseInt(newValue));
			break;
		case 5:
			targetObject.setDouble(targetAttribute, Double.parseDouble(newValue));
			break;
		case 3:
			targetObject.setId(targetAttribute, new DfId(newValue));
			break;
		default:
			DfLogger.warn(this, new StringBuilder().append("Unsupported data type: {0}").append(targetObject.getAttrDataType(targetAttribute)).toString(), null, null);
		}
	}

	public void updateRepeatedAttribute(String[] newValues, String targetAttribute, IDfSysObject targetObject,boolean merge,boolean replace)
			throws DfException
	{
		switch (targetObject.getAttrDataType(targetAttribute)) {
		case 2:
			if (replace) {
				targetObject.truncate(targetAttribute, 0);
			}
			for (String newValue : newValues) {    			
				if ((replace) || (targetObject.findString(targetAttribute, newValue) < 0)) 
				{
					targetObject.appendString(targetAttribute, newValue);
				}
			}
			break;
		case 4:
			if (replace) {
				targetObject.truncate(targetAttribute, 0);
			}
			for (String newValue : newValues)
				if ((replace) || (targetObject.findTime(targetAttribute, new DfTime(newValue,ISWYApplyInheritanceConstants.DCTM_DATE_ATTR_FORMAT)) < 0)) 
				{
					targetObject.appendTime(targetAttribute, new DfTime(newValue,ISWYApplyInheritanceConstants.DCTM_DATE_ATTR_FORMAT));
				}

			break;
		case 0:
			if (replace) {
				targetObject.truncate(targetAttribute, 0);
			}
			for (String newValue : newValues)
			{
				if ((replace) || (targetObject.findBoolean(targetAttribute, Boolean.parseBoolean(newValue)) < 0)) 
				{
					targetObject.appendBoolean(targetAttribute, Boolean.parseBoolean(newValue));
				}
			}

			break;
		case 1:
			if (replace) {
				targetObject.truncate(targetAttribute, 0);
			}
			for (String newValue : newValues)
			{
				if ((replace) || (targetObject.findInt(targetAttribute, Integer.parseInt(newValue)) < 0)) 
				{
					targetObject.appendInt(targetAttribute, Integer.parseInt(newValue));
				}
			}

			break;
		case 5:
			if (replace) {
				targetObject.truncate(targetAttribute, 0);
			}
			for (String newValue : newValues)
			{
				if ((replace) || (targetObject.findDouble(targetAttribute,  Double.parseDouble(newValue)) < 0)) 
				{
					targetObject.appendDouble(targetAttribute, Double.parseDouble(newValue));
				}
			}

			break;
		case 3:
			if (replace) {
				targetObject.truncate(targetAttribute, 0);
			}
			for (String newValue : newValues)
			{
				if ((replace) || (targetObject.findId(targetAttribute,  new DfId(newValue)) < 0)) 
				{
					targetObject.appendId(targetAttribute, new DfId(newValue));
				}
			}

			break;
		default:
			DfLogger.warn(this, new StringBuilder().append("Unsupported data type: {0}").append(targetObject.getAttrDataType(targetAttribute)).toString(), null, null);
		}		
	}

	public void createAuditObject(String objId, IDfSession session,String audit_event ,String auditEventMsg, String auditAttrList,String auditAttrListOld) throws DfException
	{
		AuditTrailItem auditItem=new AuditTrailItem(session,audit_event);            
		auditItem.setAuditedId(new DfId(objId));
		auditItem.setTimeStamp(new DfTime());
		auditItem.setAttributeListOld(auditAttrListOld);
		auditItem.setAttributeList(auditAttrList);

		auditItem.setEventSource(this.getClass().getName());// max 64 chars.
		auditItem.setString1(auditEventMsg);
		auditItem.save();

		DfLogger.debug(this, "Audit Trail item created for object ["+objId+"]", null, null);
	}

	public String generateAttributesAuditEntry(String objId, IDfSession session,ArrayList<String> attrsList ) throws DfException
	{
		IDfSysObject targetObject=(IDfSysObject)session.getObject(new DfId(objId));
		String auditAttrList=null;

		if(attrsList!=null && attrsList.size()>0)
		{

			for(int i=0;i<attrsList.size();i++)
			{
				String tarAttr=attrsList.get(i);

				ArrayList<String> targetValueList=getAttributeValue(targetObject, tarAttr);
				String[] tarCurValArr=new String[targetValueList.size()];
				targetValueList.toArray(tarCurValArr);

				if (tarCurValArr!=null && tarCurValArr.length>0)
				{
					for (int j=0;j<tarCurValArr.length;j++)
					{

						if(j==0)
						{
							if (auditAttrList==null )
							{
								auditAttrList = tarAttr + "=\"";
							}
							else
							{
								auditAttrList = auditAttrList + ", "+ tarAttr + "=\"";
							}

							auditAttrList=auditAttrList + tarCurValArr[j] ;
						}
						else
						{
							auditAttrList=auditAttrList + "," + tarCurValArr[j] ;
						}						
					}

					auditAttrList=auditAttrList + "\"";
				}
			}
		}

		return auditAttrList;
	}

	public Map<java.lang.String,java.lang.String[]> getCheckoutInfo(String objId,IDfSession session)  throws DfException
	{
		String dql_get_checkedOutInfo="select r_lock_owner,r_lock_machine,datetostring(r_lock_date,'"+ISWYApplyInheritanceConstants.DQL_DATE_ATTR_YYYYMMDDHHMISS_FORMAT+"') as r_lock_date,r_modifier,i_vstamp from dm_document(all)  where r_object_id='"+objId+"'";
		
		DfLogger.debug(this, "dql_get_checkedOutInfo :::"+dql_get_checkedOutInfo, null, null);
		Map<java.lang.String,java.lang.String[]> coll_Checked_Out=QueryUtils.getAllQueryResultColumnValues(dql_get_checkedOutInfo,true,session);

		return coll_Checked_Out;
	}

	/**
	 * This method cancel the checkout operation by releasing the lock from document.
	 * @param objId : Object Id of the document for which performing cancel checkout
	 * @param session : session
	 * @param calculate_sec_statistics: True or False. If true, means checkout operation needs to check only for statistics. If false, checkout operation needs to perform on document. 
	 * @return
	 * @throws DfException
	 */
	public boolean isCheckOutAborted(String objId,IDfSession session) throws DfException
	{
		//boolean calculate_sec_statistics=argParser.getBooleanArgument(ARG_CALCULATE_SECRF_STATISTICS, false);
		boolean isCheckOutCancel=false;
		DfLogger.info(this, "::: isCheckOutAborted () ::  >> "+objId  ,null, null);

		Map<java.lang.String,java.lang.String[]> coll_Checked_Out=getCheckoutInfo(objId,session);
		DfLogger.debug(this, "::: isCheckOutAborted () ::  checkout data.size>> "+coll_Checked_Out.size()  ,null, null);
		String lock_owner=coll_Checked_Out.get("r_lock_owner")[0];

		DfLogger.debug(this, "::: isCheckOutAborted () ::  lock_owner>> "+lock_owner  ,null, null);
		//DfLogger.info(this,"Validating Document["+objId+"] is Checked-out or not r_lock_date["+lock_time+"] r_lock_owner["+lock_owner+"] r_lock_machine["+lock_machine+"] r_modifier["+doc_last_modifier+"] i_vstamp["+count_vstamp+"]",null,null);

		//if(!StringUtils.isNullOrEmpty(lock_owner) )	//Document is checked-out
		if(!lock_owner.trim().equalsIgnoreCase("") )	//Document is checked-out
		{
			DfLogger.info(this,"Document ["+objId+"] is checked out",null,null);
			String empty_val=" ";

			String lock_machine=coll_Checked_Out.get("r_lock_machine")[0];
			int count_vstamp=Integer.parseInt(coll_Checked_Out.get("i_vstamp")[0]);

			String tmpDQL="EXECUTE exec_sql WITH query='update dm_sysobject_s set r_lock_owner=''"+empty_val+"'' , i_vstamp=''"+(count_vstamp+1)+"'' where r_object_id=''"+objId+"'' ';";
			DfLogger.info(this,"DQL to remove lock owner for applying SecRF ["+tmpDQL+"]",null,null);
			System.out.println("DQL to remove lock owner for applying SecRF ["+tmpDQL+"]");
			QueryUtils.execQuery(tmpDQL,session);

			String auditAttrList="r_lock_owner="+empty_val+", i_vstamp="+(count_vstamp+1)+",r_lock_machine="+empty_val;
			String auditAttrListOld="r_lock_owner="+lock_owner+", i_vstamp="+(count_vstamp)+",r_lock_machine="+lock_machine;
			createAuditObject(objId,session,"dm_unlock","Update attributes to unlock object before applying SecRF",auditAttrList,auditAttrListOld);

			isCheckOutCancel=true;

			DfLogger.info(this, "Document Checkout cancellation status ["+isCheckOutCancel+"]", null, null);
		}
		return isCheckOutCancel;
	}

	public boolean isAbortcheckoutCancelled(String objId,IDfSession session, Map<java.lang.String,java.lang.String[]> coll_Checked_Out) throws DfException
	{
		//boolean calculate_sec_statistics=argParser.getBooleanArgument(ARG_CALCULATE_SECRF_STATISTICS, false);
		IDfSysObject sysTmpObject=(IDfSysObject)session.getObject(new DfId(objId));
		sysTmpObject.fetch(null);

		boolean isAbortcheckoutCancel=false;
		DfLogger.info(this, "::: isAbortcheckoutCancelled () ::: >> " , null, null);
		String lock_time=coll_Checked_Out.get("r_lock_date")[0];
		DfLogger.debug(this,"lock_time   ["+lock_time+"]",null,null);
		String lock_owner=coll_Checked_Out.get("r_lock_owner")[0];
		String lock_machine=coll_Checked_Out.get("r_lock_machine")[0];
		String doc_last_modifier=coll_Checked_Out.get("r_modifier")[0];
		int count_vstamp=sysTmpObject.getVStamp();

		if(lock_machine==null || lock_machine.length()==0)
		{
			DfLogger.debug(this," Lock machine was null for object id ["+objId+"]",null,null);
			lock_machine=" ";
		}

		String empty_val=" ";

		String tmpDQL="EXECUTE exec_sql WITH query='update dm_sysobject_s set r_modifier=''"+doc_last_modifier+"'' , r_lock_owner=''"+lock_owner+"'' "
				+ ", r_lock_machine=''"+lock_machine+"'' , r_lock_date=TO_DATE(''"+lock_time+"'' ,''"+ISWYApplyInheritanceConstants.ORACLE_DATE_ATTR_FORMAT+"'' ) , i_vstamp=''"+(count_vstamp+1)+"'' "
				+ "where r_object_id=''"+objId+"'' ';";
		DfLogger.info(this,"DQL to put lock owner after applying SecRF ["+tmpDQL+"]",null,null);
		System.out.println("DQL to put lock owner after applying SecRF ["+tmpDQL+"]");
		QueryUtils.execQuery(tmpDQL,session);

		String auditAttrList="r_lock_owner="+lock_owner+", i_vstamp="+(count_vstamp+1)+",r_lock_machine="+lock_machine+",r_lock_date="+lock_time+",r_modifier="+doc_last_modifier;
		String auditAttrListOld="r_lock_owner="+empty_val+", i_vstamp="+(count_vstamp)+",r_lock_machine="+empty_val;
		createAuditObject(objId,session,"dm_lock","Update attributes to relock object",auditAttrList,auditAttrListOld);

		isAbortcheckoutCancel=true;

		DfLogger.debug(this, "Document isAbortcheckoutCancel status ["+isAbortcheckoutCancel+"]", null, null);
		return isAbortcheckoutCancel;
	}

	public void applyingSecurity(String qualification, IDfSession session,boolean needToapplysecurity, String acl_threshold) 
	{

		try {
			DfLogger.debug(this, "session.getDocbaseName() "+ session.getDocbaseName()+ "  session.getLoginUserName()  "+session.getLoginUserName(), null, null);
			//HashMap<String, String> aParserMap = new HashMap<String, String>();
			//aParserMap.put("-class_name", "com.emc.d2.api.methods.D2CoreMethod");
			//aParserMap.put("-docbase_name", session.getDocbaseName());
			//aParserMap.put("-user_name", session.getLoginUserName());
			//aParserMap.put("-password", "");
			//aParserMap.put("-qualifier", qualification);
			//aParserMap.put("-distributed_processing_threshold", ISWYApplyInheritanceConstants.MTHD_DISTRIBUTED_PROCESSING_THRESHOLD);
			//aParserMap.put("-id", docObjectId);
			//aParserMap.put("-create", Boolean.toString(false));
			//aParserMap.put("-naming", Boolean.toString(false));
			//aParserMap.put("-autolink", Boolean.toString(false));
			//aParserMap.put("-security", Boolean.toString(needToapplysecurity));
			//aParserMap.put("-force_security", Boolean.toString(false));
			//aParserMap.put("-apply_for_vd", Boolean.toString(false));
			//aParserMap.put("-transaction", Boolean.toString(false));

			//ArgumentParser aParser = new ArgumentParser(aParserMap);

			//applyD2CoreMethod(aParser);


			String method_args= " -docbase_name " + session.getDocbaseName();
			method_args=method_args+" -user_name " + session.getServerConfig().getString("r_install_owner");
			method_args=method_args+" -qualifier " + qualification;

			if(acl_threshold!=null && !acl_threshold.isEmpty())
			{
				int threshold=0;
				try
				{
					threshold=Integer.parseInt(acl_threshold);
				}
				catch(NumberFormatException e)
				{
					threshold=0;
				}

				if (threshold!=0 && threshold>100 )
				{
					method_args=method_args+" -distributed_processing_threshold " + acl_threshold+"";
				}
			}

			method_args=method_args+" -create false" ;
			method_args=method_args+" -naming false" ;
			method_args=method_args+" -autolink false" ;
			method_args=method_args+" -security "+ Boolean.toString(needToapplysecurity)+"";
			method_args=method_args+" -force_security false" ;
			method_args=method_args+" -apply_for_vd false" ;

			IDfList list1=new DfList();
			IDfList list2=new DfList();
			IDfList list3=new DfList();

			list1.append("METHOD");
			list1.appendString("RUN_AS_SERVER");
			list1.appendString("LAUNCH_ASYNC");
			list1.append("ARGUMENTS");

			list2.append("s");		// Corresponding to "METHOD" 
			list2.appendString("b");
			list2.appendString("b");
			list2.append("s");		// Corre4sponding to "ARGUMENTS"

			list3.append(ISWYApplyInheritanceConstants.MTHD_AD2C_NAME);
			list3.appendString("T");
			list3.appendString("F");
			list3.append(method_args);

			DfLogger.info(this, "Applying Security with: method name {0} and arguments {1}", new String[]{ISWYApplyInheritanceConstants.MTHD_AD2C_NAME,method_args}, null);
			IDfCollection methodColl=null;
			try
			{
				methodColl=session.apply(null,"DO_METHOD",list1,list2,list3); 
				DfLogger.info(this, "Applying Security called with: method name {0} and arguments {1}", new String[]{ISWYApplyInheritanceConstants.MTHD_AD2C_NAME,method_args}, null);

			}
			finally
			{
				if (methodColl!=null)
				{
					methodColl.close();

					DfLogger.debug(this, "Closing the methods call that was opened for Applying Security request", null, null);
				}
			}
		}
		catch (Exception e) {
			DfLogger.error(this, e.getLocalizedMessage(), null, e);
		}		
	}

	public void applyD2CoreMethod(ArgumentParser aParser) throws Exception {
		DfLogger.info(this, "Applying Security:::: processing applyD2CoreMethod()", null, null);

		try {
			D2Method.main(aParser);
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			DfLogger.error(this, "Applying Security:::: processing applyD2CoreMethod() " + e.getLocalizedMessage(),
					null, e);
		}
	}
}
