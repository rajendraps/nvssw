package com.novartis.swy.inheritance.utils;

import java.io.Serializable;

public class SWYTargetObjectsBean implements Serializable
{
	private String objectId=null;
	private String srcObjectId=null;
	
	private SWYAttributeInheritanceBean inheritBeanObj=null;
	
	public SWYAttributeInheritanceBean getAttributeInheritanceData()
	{
		return inheritBeanObj;
	}
	
	
	public void setAttributeInheritanceData(SWYAttributeInheritanceBean beanObj)
	{
		inheritBeanObj=beanObj;
	}
	
	
	
	public String getTargetObjectId()
	{
		return objectId;
	}
	
	
	public void setTargetObjectId(String objId)
	{
		objectId=objId;
	}
	

	
	public String getSourceObjectId()
	{
		return srcObjectId;
	}
	
	
	public void setSourceObjectId(String objId)
	{
		srcObjectId=objId;
	}
	
	
}
