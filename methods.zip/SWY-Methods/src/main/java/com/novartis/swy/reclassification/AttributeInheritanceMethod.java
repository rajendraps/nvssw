package com.novartis.swy.reclassification;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import com.documentum.d2.model.D2Dictionary;
import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfModule;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfId;
import com.documentum.utils.AttributeExpression;
import com.documentum.utils.DfcUtils;
import com.documentum.utils.StringUtils;
import com.emc.common.java.utils.ArgumentParser;
import com.emc.d2.api.methods.D2Method;
import com.emc.d2.api.methods.D2methodBean;
import com.emc.d2.api.methods.ID2Method;
import com.emc.documentum.ls.constants.ControlledDocumentConstants;

/**
 * D2 server method that executed DQL statements defined in the Dictionary for
 * reclassification of the documents and objects.
 * <p>
 * <strong>Method-specific arguments:</strong>
 * <ul>
 * <p>
 * <li><strong>id</strong> - Object ID of the selected object
 * <strong>(Mandatory)</strong></li>
 * </p>
 *
 * <p>
 * <li><strong>context_user</strong> - User name of the user through which
 * session method can be invoked.</li>
 * </p>
 *
 * 
 * <p>
 * <li><strong>dql_dictionary</strong> - <strong>Mandatory, Dictionary object
 * which contains all the DQL statements where the $values will be resolved by
 * Attribute Expressions which then will be executed sequentially.</li>
 * </p>
 *
 *
 * @author Senthil Naathan P M
 *
 */
public class AttributeInheritanceMethod implements ID2Method, IDfModule {

	public static final String ARG_CONTEXT_USER = "-context_user";

	public static final String ARG_SELECTED_OBJECT_ID = "-id";
	public static final String ARG_DQL_DICTIONARY_NAME = "-dql_dictionary";

	private String aliasName = "DQL";
	private String docbaseNamePH = "<<<docbase_name>>>";

	@Override
	public D2methodBean execute(IDfSession dfSession, IDfSysObject sysObject, Locale paramLocale,
			ArgumentParser argParser) throws Exception {

		String result = null;
		String resultType = null;

		DfLogger.debug(this, "****************************** Attribute Inheritance Method ****************************",
				null, null);
		IDfId objID = argParser.getIdArgument(ARG_SELECTED_OBJECT_ID, null);
		if (sysObject == null) {
			sysObject = (IDfSysObject) dfSession.getObject(objID);
		}
		String contextUser = argParser.getStringArgument(ARG_CONTEXT_USER, null);

		String dqlDictName = argParser.getStringArgument(ARG_DQL_DICTIONARY_NAME, null);

		DfLogger.debug(this, " Object ID : " + objID.getId() + "\n Context User " + contextUser
				+ "\n DQL Dictionary Name : " + dqlDictName, null, null);

		try {
			if (dqlDictName == null || dqlDictName.trim().equalsIgnoreCase("") || objID == null
					|| objID.getId().trim().equalsIgnoreCase("")) {
				throw new IllegalArgumentException(" Object ID is null or empty OR Dictionary Name is null or Empty");
			}

			D2Dictionary dictionary = D2Dictionary.getDictionary(dqlDictName, dfSession, sysObject, contextUser, false,
					false);
			String docbaseName = dfSession.getDocbaseName();

			if (dictionary == null) {
				throw new IllegalArgumentException(
						"Specified Dictionary \"" + dqlDictName + "\" does not exists in the system");
			}
			List<String> dqlQueries = new ArrayList<>();
			Map<String, String> dqlMap = dictionary.getKeyToAliasValueMap(aliasName);

			if (dqlMap == null || dqlMap.isEmpty()) {
				DfLogger.info(this, "No DQLs specified in the Dictionary. No operations performed", null, null);
				result = "Record doesn't exists";
				resultType = D2Method.RETURN_WARNING_STR;
			} else {
				for (int i = 1; i <= dqlMap.size(); i++) {
					String unresolvedQuery = dqlMap.get(Integer.toString(i));
					DfLogger.debug(this, "Unresolved Query : " + unresolvedQuery, null, null);
					String resolvedQueryInt = AttributeExpression.resolve(unresolvedQuery, sysObject, contextUser);
					String resolvedQuery = null;
					if (!StringUtils.isNullOrEmpty(resolvedQueryInt)) {
						resolvedQuery = resolvedQueryInt.replaceAll(docbaseNamePH, docbaseName);
					}
					DfLogger.debug(this, "Resolved Query : " + resolvedQuery, null, null);
					dqlQueries.add(i - 1, resolvedQuery);
				}
			}
			for (String qry : dqlQueries) {
				if (qry != null) {
					try {
						IDfQuery query = new DfQuery();
						query.setDQL(qry);
						query.execute(dfSession, IDfQuery.DF_EXEC_QUERY);
						result = "Query Execution successfull";
						resultType = D2Method.RETURN_SUCCESS_STR;
					} catch (DfException e) {
						e.printStackTrace();
						result = "Query Exection Failed";
						resultType = D2Method.RETURN_FATAL_STR;
						throw new RuntimeException(e.getMessage());
					}
				}
			}
			DfLogger.debug(this, "Reset attributes from Source object",
					null, null);
			sysObject.fetch(null);
			sysObject.setString(ControlledDocumentConstants.ATTR_CST_STRING_S_01, null);
			sysObject.setString(ControlledDocumentConstants.ATTR_CST_STRING_S_02, null);
			sysObject.setString(ControlledDocumentConstants.ATTR_CST_STRING_S_03, null);
			sysObject.setString(ControlledDocumentConstants.ATTR_CST_STRING_S_04, null);
			sysObject.setString(ControlledDocumentConstants.ATTR_CST_STRING_S_05, null);
			sysObject.removeAll(ControlledDocumentConstants.ATTR_CST_STRING_R_01);
			sysObject.removeAll(ControlledDocumentConstants.ATTR_CST_STRING_R_02);
			sysObject.save();
			
		} catch (Exception ex) {
			DfLogger.error(this, ex.getMessage(), null, ex);
		} 
		DfLogger.debug(this, "Attribute Inheritance completed... " + "  " + resultType, null, null);
		return new D2methodBean(resultType, result);
	}
}
