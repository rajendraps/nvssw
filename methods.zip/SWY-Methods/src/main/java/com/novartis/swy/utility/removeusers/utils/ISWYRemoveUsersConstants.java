package com.novartis.swy.utility.removeusers.utils;

public class ISWYRemoveUsersConstants {

	final public static char CSV_READ_USERS_DELIMITER = '#';
	final public static String CSV_STR_READ_USERS_DELIMITER = "#";
	
	final public static String EXIST_ATTR_COMMA_DELIMITER = ",";

	final public static String DM_METHOD_NAME = "SWYRemoveRestrictedCountryUsers";
	
	final public static String DCTM_DATE_ATTR_FORMAT="mm/dd/yyyy hh:mi:ss a";
	
	final public static String DQL_DATE_ATTR_YYYYMMDDHHMISS_FORMAT=	"yyyy/mm/dd hh:mi:ss";
	
	final public static String ORACLE_DATE_ATTR_FORMAT="yyyy/mm/dd hh24:mi:ss";
	
	final public static String DOC_R_OBJECT_ID_ATTR="r_object_id";
	
	//final public static String MTHD_DISTRIBUTED_PROCESSING_THRESHOLD="99";
	
	final public static String MTHD_AD2C_NAME="CDFApplyD2ConfigurationsAsyncMethod";
	
	final public static String SUCCESS="SUCCESS";
	final public static String ERROR="ERROR";
	final public static String WARN="WARNING";
	
	final public static String PROCESS_REQUIRED="PROCESS REQUIRED";
	final public static String PROCESS_NOT_REQUIRED="PROCESS NOT REQUIRED";
	final public static String INFORM_BUSINESS="NO NEED TO PROCESS";
	
	final public static String ATTRIBUTES="format_reviewers,approvers,qo_approvers,authors,auditors,reviewers,readers,doc_coordinators,"
			 + "review_notif_recipients,form_users,qc_group,qc_user,swy_topic_readers";
	final public static String EXCLUDE_TYPES="cd_submission_element"+EXIST_ATTR_COMMA_DELIMITER+"cd_quality_gmp_approved"+EXIST_ATTR_COMMA_DELIMITER+"cd_quality_gmp_effective";
}
