package com.novartis.swy.security.methods;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Vector;

import com.documentum.cdf.methods.DistributedD2Method;
import com.documentum.cdf.methods.IDistributedD2Method;
import com.documentum.cdf.methods.NotifyUsers;
import com.documentum.cdf.methods.TaskResult;
import com.documentum.cdf.methods.UpdateAttrsViaQuery;
import com.documentum.d2.model.D2Dictionary;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.client.IDfUser;
import com.documentum.fc.client.IDfVersionLabels;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfList;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.common.IDfList;
import com.documentum.utils.AttributeExpression;
import com.documentum.utils.DfcObjectUtils;
import com.documentum.utils.QueryUtils;
import com.documentum.utils.StringUtils;
import com.emc.common.java.utils.ArgumentParser;
import com.novartis.swy.security.utils.ISWYApplySECRFConstants;
import com.novartis.swy.security.utils.ResultBean;
import com.novartis.swy.security.utils.SWYApplySecRFHelper;
import com.novartis.swy.security.utils.TargetDocumentBean;

/**
 * D2 server method that applies/associate SecRF object with documents
 * <p>
 *<strong>Method-specific arguments:</strong>
 *<ul>
 *
 * <p><li><strong>id</strong> -  <p style="text-indent :5em;"> 1. Object id of SecRF (Context) object when using this method from "apply to existing document" <strong>(Mandatory)</strong>.</p>
 *<p style="text-indent :5em;"> 2. Object id of document object when using this method from "init" or other calls from document object. <strong>(Mandatory)</strong> </p>
 *<p style="text-indent :5em;"> 3. Object id of SecRF (Context) object when using this method from "Deactivate SECRF and De-classify Docs...". <strong>(Mandatory)</strong> </p>
 *</li></p>
 *
 *<p><li><strong>target</strong> - <p style="text-indent :5em;"> 1. Complete DQL to get list of objects from cd_controlled_doc or their childs, in case of migration. <strong>(Mandatory)</strong> </p>
 *<p style="text-indent :5em;"> 2. DQL after <type> or  from "where" clause to get the list of cd_controlled_doc or their childs, in case of "apply to existing document". <strong>(Mandatory)</strong>      </p>
 *<p style="text-indent :5em;"> 3. Complete DQL to get list of objects from cd_controlled_doc or their childs, to apply inactive logic, in case of migration "Deactivate SECRF and De-classify Docs...". <strong>(Mandatory)</strong> </p>
 *</li></p>
 *
 * <p><li><strong>if</strong> - Applicable for migration only. <strong>(Optional)</strong></li></p>
 *
 * <p><li><strong>context_user</strong> - User name of the user through which session method can be invoked.</li></p>
 *
 * 
 *<p><li><strong>send_notification</strong> - <strong>Optional, either true , false or we should not mention it </strong>, it can be trigger from anywhere except "init" or any other invocation from Doc object.</li></p>
 *
 *<p><li><strong>notification_scenario... </strong> - <b>Optional</b>: should defined as:
 *<p style="text-indent :5em;"><b> -notification_scenario1</b></p>
 *<p style="text-indent :5em;"><b> -notification_scenario2</b></p>
 *<p style="text-indent :5em;"><b> -notification_scenario3</b></p>
 *<p style="text-indent :5em;"><b> .........</b></p>
 *<p style="text-indent :5em;"><b> -notification_scenarioN</b></p>
 *It will be considered only when <b>-send_notification is defined as true</b>.
 *</li></p>
 *
 * 
 * 
 *<p><li><strong>assign_performers</strong> - Optional, either true , false or should not mentioned , can be trigger from anywhere except "init" or any other call from Doc object. It might require in
 *<p style="text-indent :5em;">1.               apply to existing document.</p>
 *<p style="text-indent :5em;">2.               Migration. </p>
 *</li></p>
 *
 * <p><li><strong>performers_mapping_scenario</strong> - <b>Optional</b>: should defined as:*
 *<p style="text-indent :5em;"><b> - performers_mapping_scenario1</b></p>
 *<p style="text-indent :5em;"><b> - performers_mapping_scenario2</b></p>
 *<p style="text-indent :5em;"><b> - performers_mapping_scenario3</b></p>
 *<p style="text-indent :5em;"><b> .........</b></p>
 *<p style="text-indent :5em;"><b> - performers_mapping_scenarioN</b></p>
 *It will be considered only when <strong> -assign_performers </strong> is defined as true. If <b> -assign_performers</b> is defined as true but scenario is not available, it will apply default performers from applied SecRF (all 8 performers).
 *It might require in
 *<p style="text-indent :5em;">1.apply to existing document.</p>
 *<p style="text-indent :5em;">2.                Migration</p>
 *
 *</li></p>
 *
 * <p><li><strong>copy_attrs</strong> - <strong>Optional</strong>:
 *                In form of sourceAttr1-TargetAttr1,sourceAttr2-TargetAttr2 , both (Source and Target)from document objects, which is supposed to be processed. It might require in
 *                                <p style="text-indent :5em;"><b> 1.      apply to existing document.</b></p>
 *                                <p style="text-indent :5em;"><b> 2.      Migration</b></p>
 *
 *</li></p>
 *
 *<p><li><strong>security</strong> - <b> Optional</b> : either true , false or should not mentioned . it is required to update the ACL. It might be needed for :
 * <p style="text-indent :5em;"><b>1.       apply to existing document.</b></p>
 * <p style="text-indent :5em;"><b>2.       Migration</b></p>
 *<p style="text-indent :5em;"><b>3.       Deactivate SECRF and De-classify Docs...</b></p>
 *
 * 
 *</li></p>
 *
 * 
 * <p><li><strong>ignore_doc_creator_check</strong> - Either true , false or should not mentioned  . If it is true, it will skip the steps to check whether r_creator_name of document object is defined as author in applied SecRF or not. Can be used for <b>Migration and should defined as true</b>.
 *</li></p>
 *
 *<p><li><strong>is_migrated_document</strong> - Same as <b> -assign_performers </b>, only applicable for Migration. It should always defined as <b>true</b>.
 *</li></p>
 *
 *<p><li><strong>secrf_inactive</strong> - Either true , false or should not mentioned  . Mandatory for :
 *                                                                <p style="text-indent :5em;"><b>1.       Deactivate SECRF and De-classify Docs... (Mandatory)</b></p>
 *                                                                                should be <b>true</b> always, to start the inactive process on document. It will not set SecRF status as Inactive, that we need to handle from LC. It will only do document related tasks.
 *
 *</li></p>
 *
 *<p><li><strong>secrf_default_value</strong> - <b>Optional</b> , Applicable for :
 *<p style="text-indent :5em;"><b>1.       Deactivate SECRF and De-classify Docs...</b></p>
 *Default values for attributes which needs to update on document object while deactivating SecRF object. E.g.  attr1-defaultvalue11~defaultvalue12,attr2-defaultvalue21~defaultvalue22
 *useful for static value or null. To set null on some attribute, we should use null .
 *e.g.
 *-secrf_default_value swy_conflicting_secrf-null
 *</li></p>
 *
 *<p><li><strong>secrf_default_value_dql</strong> - <b>Optional</b> , Applicable for :
 *<p style="text-indent :5em;"><b>1.       Deactivate SECRF and De-classify Docs...</b></p>
 *Default values for attributes which needs to update in form of DQL on document object while deactivating SecRF object. 
 *e.g.
 *-secrf_default_value_dql "select 'Default' as swy_security_rest_form , 'Default' as swy_secrf_application_mode, 'Default' as swy_sel_security_rest_forms, DATE(NOW) as swy_declassification_date,'BUO' as *swy_confidentiality, 0 as swy_applicable_secrf_count from dm_docbase_config"
 *</li></p> 

 * <p><li><strong>secrf_default_role</strong> - Optional: either true , false or should not mentioned . </li></p>

 *<p><li><strong>secrf_default_role_scenario</strong> - Optional: should defined as:
 *<p style="text-indent :5em;"><b> - secrf_default_role_scenario1</b></p>
 *<p style="text-indent :5em;"><b> - secrf_default_role_scenario2</b></p>
 *<p style="text-indent :5em;"><b> - secrf_default_role_scenario3</b></p>
 *<p style="text-indent :5em;"><b> .........</b></p>
 *<p style="text-indent :5em;"><b> - secrf_default_role_scenarioN</b></p>
 *It will be considered only when <b>-secrf_default_role is defined as true</b>.
 *</li></p>
 *
 *<p><li><strong>remove_inactive_users</strong> - Optional, by default it is false. If it is true, it will remove inactive users from respective roles. It might applicable for 
 *<p style="text-indent :5em;"><b> 1.      apply to existing document.</b></p>
 *<p style="text-indent :5em;"><b> 2.      Deactivate SECRF and De-classify Docs...</b></p>
 *</li></p>
 *
 *<p><li><strong>result_tracking_level</strong> - Mandatory for 
 *<p style="text-indent :5em;"><b> 1. New / Update</b></p>
 *<p style="text-indent :5em;"><b> 2. Apply to existing document</b></p>
 *<p style="text-indent :5em;"><b> 3. Calculate SecRF Statistics</b></p>
 *Optional for <b>Migration</b>
 *It is required for handleResult() of D2Distributed class, where we can do some post-process operation for each task.
 *</li></p>
 *
 *<p style="text-indent :5em;"><li><strong>applied_by</strong> - Mandatory for 
 *<p style="text-indent :5em;"><b>1. New / Update</b></p>
 *<p style="text-indent :5em;"><b>2. Apply to existing document</b></p>
 *To keep tracking of the user, who has initiated the operation (internally everything will be processed through dmadmin, but it is required for mail notification)
 *</li></p>
 *<p>
 *<li><strong>calculate_secrf_statistics</strong> - Mandatory for 
 *<b>Mandatory</b> for
 *<p style="text-indent :5em;"><b>1. Calculate SecRF Statistics</b></p>
 *If true then only calculate statistics. Default value is false and when false save() will be called on doc object.
 *</li>
 *</p>
 *<p>
 *<li><strong>is_custom_notification_needed</strong> - If it is true, custom mail notification logic will be processed. It can be used with 
 *<p style="text-indent :5em;"><b>1. New / Update</b></p>
 *<p style="text-indent :5em;"><b>2. Apply to existing document</b></p>
 *</li>
 *</p>
 *</ul>
 *</p>

 * @author Kumar Shubham, Karthik Patil
 * 
 * *************JIRA 2959*******************************************
 * Date : 21-Dec-2020 , Author : SHUBHKU1, SUKANRA1
 * Re-factored code, handled collection leak issue (JIRA# 2959)
 * ***************************************************************** * 
 * Date : 14-Nov-2022 , Author : SHAHRU7
 * JIRA# 4816 - method getSecRFDataDetails() & getNonEmptySecRFDataInArray() - Replaced "AND" with ISWYApplySECRFConstants.DEFAULT_SEPARATOR
 * JIRA# 5195 - Added or condition to ignore placeholders when the object_type is cd_clinical
 * *****************************************************************
 */


public class SWYApplySecRF extends DistributedD2Method implements IDistributedD2Method
{

	private static final long serialVersionUID = 1L;
	//	private String dlRole_names[]={"doc_coordinators","authors","reviewers","format_reviewers","approvers","readers","auditors","qo_approvers"};//

	// Document-specific argument keys
	public static final String ARG_SELECTED_OBJECT_ID = "-id";

	/** if -target is defined (as dql), -id will be ignored
	 IF -is_migrated_document is true, it should have complete DQL to fetch document objects. 
	 In case it is configured in D2 application, it should have only predicate including "where" keyword.
	 The type will be configured in separate parameter in case of D2 application.
	 */
	public static final String ARG_TARGET_OBJECT_IDS= "-target";	// target dql to retrieve target docs
	//public static final String ARG_TARGET_OBJECT_TYPE= "-type";	// object type, in case of D2 application, by default its values is "cd_controlled_doc"

	public static final String ARG_PRECONDITION = "-if";
	public static final String ARG_CONTEXT_USER = "-context_user";

	public static final String ARG_APPLIED_BY="-applied_by";	// login user name, to keep track the information who has started the execution

	public static final String ARG_SECRF_NAME="-secrf";	
	public static final String ARG_SEND_NOTIFICATION="-send_notification";	
	public static final String ARG_NOTIFICATION_SCENARIO="-notification_scenario";
	public static final String ARG_PERFORMERS_NOTIFICATION_SCENARIO="-performers_mapping_scenario";	
	public static final String ARG_COPY_ATTRS="-copy_attrs";	//in form of sourceAttr1|TargetAttr1,sourceAttr2|TargetAttr2 , both from document objects, which is supposed to be processed
	public static final String ARG_SECURITY = "-security";	// to update the ACL on document
	public static final String ARG_ASSIGN_PERFORMERS="-assign_performers";		// if it is true, Performers from SecRF will gets apply to the document
	public static final String ARG_IGNORE_DOC_CREATOR_CHECK = "-ignore_doc_creator_check";	// if it is true, it will ship the steps to check whether r_creator_name of document object is defined as author of applied SecRF or not.

	public static final String ARG_MIGRATED_DOCUMENT = "-is_migrated_document"; // if it is true, Performers from SecRF will gets apply to the document

	public static final String ARG_INACTIVE_SECRF = "-secrf_inactive";	// true to deactivate/Inactive the selected SeCRF
	public static final String ARG_DEFAULT_VALUE_PROVIDED="-is_defualt_value_provided";	// if value is provided (or dql), then its value will be true
	public static final String ARG_DEFAULT_SECRF_VALUES = "-secrf_default_value";	// default values for attributes which needs to update as attr1-defaultvalue11~defaultvalue12,attr2-defaultvalue21~defaultvalue22. Date value should be in format "mm/dd/yyyy hh:mi:ss a" .
	public static final String ARG_DEFAULT_SECRF_VALUES_DQL = "-secrf_default_value_dql";	// default values for attributes which needs to update in form of DQL
	public static final String ARG_DEFAULT_SECRF_ROLES = "-secrf_default_role";		// should be true  
	public static final String ARG_SECRF_DEFAULT_ROLE_SCENARIO="-secrf_default_role_scenario";	
	public static final String ARG_REMOVE_INACTIVE_USERS="-remove_inactive_users";	//Remove inactive users from respective roles


	public static final String ARG_CALCULATE_SECRF_STATISTICS="-calculate_secrf_statistics";	// if it is true just calculate the statistics and not call save() on document object. if it is false, calling save() on document object
	public static final String ARG_CUSTOM_MAIL_NOTIFICATION_NEEDED="-is_custom_notification_needed";	// if yes, need to process custom mail object logic. Required for New/Update and "Apply to existing document"


	public static final String INT_ARG_APPLY_TO_EXISTING_DOC="-apply_to_existing_doc";	// Parameter getting used internally.

	public static final String INT_ARG_APPLY_TO_PREVIOUS_VERSIONS="-apply_to_previous_versions";	// Default value is true. If true, secrf will be applied to applied on previous versions of document else not.
	public static final String INT_ARG_APPLY_SEL_SECRF_TO_PREVIOUS_VERSIONS="-apply_sel_secrf_to_previous_versions";// Default value is false

	public static final String ARG_TMF_RENAME_ENABLED="-tmf_rename_enabled";  //If its value is true , means we need to rename the existing value of TMF users (e.g. QC Users, External Participants)
	public static final String ARG_TMF_RENAME_SUFFIX="-tmf_rename_suffix";  // Whatever value mentioned with this argument, we need to append / remove that value at the end of all the existing values.
	public static final String ARG_TMF_RENAME_ATTR_LIST="-tmf_rename_attr_list"; // Need to append / remove the suffix with existing values from the attributes mentioned in this argument
	//public static final String ARG_DEFAULT_VALUE_PROVIDED="-is_defualt_value_provided";	// if value is provided , then its value will be true

	String precondition=null;
	String context_user=null;
	String applied_by_user=null;
	String copy_attrs=null;
	String doc_obj_type=null;
	boolean igonre_doc_creator_check=false;

	String srfObjName =null;	

	boolean assign_performers=false;
	boolean is_migrated_document=false;
	boolean is_secrf_call=false;

	boolean send_notification=false;

	boolean secrf_inactive=false;
	boolean is_defualt_value_provided=false;
	String secrf_default_value=null;
	String secrf_default_value_dql=null;
	boolean secrf_default_role=false;
	boolean remove_inactive_users=false;
	boolean calculate_secrf_statistics=false;
	boolean is_custom_mail_needed=false;

	boolean is_tmf_renaming_enabled=false;
	String tmf_suffix_for_renaming=null;
	String tmf_attr_to_be_rename=null;


	Map<String,String> notification_scenario_map=null;
	Map<String,String> perf_mapping_scenario_map=null;
	Map<String,String> secrf_default_role_mapping_scenario_map=null;

	private ArgumentParser argParser=null;
	private boolean isApplySecurity=false;
	private boolean isApplyToPreviousVersions=true;
	private boolean isApplySelSecRFToPreviousVersions=true;
	private String callOriginatedFrom=null;



	@Override
	public String getMethodName() {
		return ISWYApplySECRFConstants.DM_METHOD_NAME;
	}

	@Override
	public Serializable[] getTaskData(IDfSession paramIDfSession, IDfSysObject paramIDfSysObject, Locale paramLocale, 
			ArgumentParser paramArgumentParser) throws DfException {

		DfLogger.debug(this,"************************************** SWYApplySecRF *****************************************************************",null,null);

		is_migrated_document=paramArgumentParser.getBooleanArgument(ARG_MIGRATED_DOCUMENT, false);
		assign_performers=paramArgumentParser.getBooleanArgument(ARG_ASSIGN_PERFORMERS, false);
		send_notification=paramArgumentParser.getBooleanArgument(ARG_SEND_NOTIFICATION, false);
		precondition = paramArgumentParser.getStringArgument(ARG_PRECONDITION, null);
		context_user=paramArgumentParser.getStringArgument(ARG_CONTEXT_USER, null);
		applied_by_user=paramArgumentParser.getStringArgument(ARG_APPLIED_BY, null);
		copy_attrs=paramArgumentParser.getStringArgument(ARG_COPY_ATTRS, null);
		isApplySecurity = paramArgumentParser.getBooleanArgument(ARG_SECURITY, false);

		secrf_inactive=paramArgumentParser.getBooleanArgument(ARG_INACTIVE_SECRF, false);
		secrf_default_value = paramArgumentParser.getStringArgument(ARG_DEFAULT_SECRF_VALUES, null);
		secrf_default_value_dql = paramArgumentParser.getStringArgument(ARG_DEFAULT_SECRF_VALUES_DQL, null);
		secrf_default_role=paramArgumentParser.getBooleanArgument(ARG_DEFAULT_SECRF_ROLES, false);
		igonre_doc_creator_check=paramArgumentParser.getBooleanArgument(ARG_IGNORE_DOC_CREATOR_CHECK, false);
		remove_inactive_users=paramArgumentParser.getBooleanArgument(ARG_REMOVE_INACTIVE_USERS, false);
		calculate_secrf_statistics=paramArgumentParser.getBooleanArgument(ARG_CALCULATE_SECRF_STATISTICS, false);
		is_custom_mail_needed=paramArgumentParser.getBooleanArgument(ARG_CUSTOM_MAIL_NOTIFICATION_NEEDED, false);
		isApplyToPreviousVersions =paramArgumentParser.getBooleanArgument(INT_ARG_APPLY_TO_PREVIOUS_VERSIONS, true);
		isApplySelSecRFToPreviousVersions =paramArgumentParser.getBooleanArgument(INT_ARG_APPLY_SEL_SECRF_TO_PREVIOUS_VERSIONS, false);

		is_tmf_renaming_enabled=paramArgumentParser.getBooleanArgument(ARG_TMF_RENAME_ENABLED, false);
		tmf_attr_to_be_rename = paramArgumentParser.getStringArgument(ARG_TMF_RENAME_ATTR_LIST, null);
		tmf_suffix_for_renaming = paramArgumentParser.getStringArgument(ARG_TMF_RENAME_SUFFIX, null);
		is_defualt_value_provided=paramArgumentParser.getBooleanArgument(ARG_DEFAULT_VALUE_PROVIDED, false);

		IDfId  objId 	  = paramArgumentParser.getIdArgument(ARG_SELECTED_OBJECT_ID, null);
		IDfId  secrfObjId=objId;
		String targetQuery=null;
		SWYApplySecRFHelper swyHelperObj=new SWYApplySecRFHelper();

		TargetDocumentBean [] swyBeanArray=null;

		if(!secrf_inactive)
		{
			DfLogger.debug(this, "apply SecRF to existing document or call from document object", null, null);
			if(objId!=null && objId.isObjectId())
			{
				IDfSysObject sysObj=(IDfSysObject) paramIDfSession.getObject(objId);
				DfLogger.debug(this, "apply SecRF to existing document", null, null); 
				if(sysObj.getTypeName().equalsIgnoreCase(ISWYApplySECRFConstants.SRF_TYPE))
				{
					objId=null;
					srfObjName=sysObj.getObjectName();
					is_secrf_call=true;		// for "apply to existing document"

					boolean is_secrf_cross_domain=sysObj.getBoolean(ISWYApplySECRFConstants.SRF_IS_CROSS_DOMAIN_ATTR_NAME);
					if(is_secrf_cross_domain)
					{
						doc_obj_type=ISWYApplySECRFConstants.CONTROLLED_DOC_TYPE;
					}
					else
					{
						String domain=sysObj.getString(ISWYApplySECRFConstants.SRF_DOMAIN_ATTR_NAME);
						doc_obj_type=swyHelperObj.getObjtypeFromDomain( paramIDfSession,  domain) ;
					}


					targetQuery=paramArgumentParser.getStringArgument(ARG_TARGET_OBJECT_IDS,null);
					DfLogger.info(this, "DQL as passed from application  > " + targetQuery, null, null);
					targetQuery=AttributeExpression.resolve(targetQuery, sysObj, context_user);

					if(doc_obj_type==null || doc_obj_type.trim().equalsIgnoreCase(""))
					{
						doc_obj_type=ISWYApplySECRFConstants.CONTROLLED_DOC_TYPE;
					}

					if(doc_obj_type.trim().equalsIgnoreCase(ISWYApplySECRFConstants.TMF_DOC_TYPE))
					{
						String domain=sysObj.getString(ISWYApplySECRFConstants.SRF_DOMAIN_ATTR_NAME);
						boolean isSecRFDomainCrossover=swyHelperObj.chkDocDomainCrossOver(paramIDfSession,sysObj.getString(ISWYApplySECRFConstants.SRF_ARTIFACT_NAME_ATTR),domain);
						if(isSecRFDomainCrossover)
						{
							List<String> domainList= swyHelperObj.getListOfCrossOverDomains(paramIDfSession,sysObj.getString(ISWYApplySECRFConstants.SRF_ARTIFACT_NAME_ATTR));

							if(domainList!=null && domainList.size()>0)
							{
								DfLogger.debug(this, "Checking SecRF ["+sysObj.getObjectId().getId()+"] applicable for Crossover B documents",null, null);

								if(domainList.contains(ISWYApplySECRFConstants.TMF_DOMAIN))
								{
									for(int i=0;i<domainList.size();i++)
									{
										if(!domainList.get(i).equalsIgnoreCase(ISWYApplySECRFConstants.TMF_DOMAIN))
										{
											String otherDomainName=domainList.get(i);
											doc_obj_type=swyHelperObj.getObjtypeFromDomain( paramIDfSession,  otherDomainName) ;

											targetQuery=targetQuery.replace(ISWYApplySECRFConstants.TMF_DOMAIN, otherDomainName);
											break;
										}
									}
								}

							}
						}
					}

					String additionalPredicates=swyHelperObj.generateMorePredicates(targetQuery,sysObj,doc_obj_type);
					if(additionalPredicates.trim().equalsIgnoreCase("error"))
					{
						DfLogger.debug(this, "Error as SecRF have few filters defined which is not needed", null, null);
						swyHelperObj.updateStatisticsData(secrfObjId.getId(),paramIDfSession,0,0,0,0);
						swyBeanArray=null;
						return swyBeanArray;
					}
					else if(additionalPredicates!=null && !additionalPredicates.trim().equalsIgnoreCase(""))
					{
						targetQuery=" where "+additionalPredicates + " and " + targetQuery;
					}
					else
					{
						targetQuery=" where " + targetQuery;
					}
           //2022-11-17 : SUB-5195 - Added or condition to ignore placeholders when the object_type is cd_clinical				
					if(doc_obj_type.trim().equalsIgnoreCase(ISWYApplySECRFConstants.TMF_DOC_TYPE) || doc_obj_type.trim().equalsIgnoreCase(ISWYApplySECRFConstants.CLINICAL_DOC_TYPE))
					{
						targetQuery= targetQuery + " and is_placeholder=0" ;
					}
					targetQuery="select r_object_id from "+doc_obj_type +" "+targetQuery;
					DfLogger.warn(this, "DQL as passed from application and after adding further predicates > " + targetQuery, null, null);
				}
				else
				{					
					DfLogger.debug(this, "call initiated from document ["+objId+"]", null, null); 
				}
			}
		}
		else if(secrf_inactive)
		{
			// Inactive SecRF to existing document
			if(objId!=null && objId.isObjectId())
			{
				IDfSysObject sysObj=(IDfSysObject) paramIDfSession.getObject(objId);
				if(sysObj.getTypeName().equalsIgnoreCase(ISWYApplySECRFConstants.SRF_TYPE))
				{
					srfObjName=sysObj.getObjectName();
				}
			}
		}

		// Document is migrated or secrf is deactivating, in that case get the list of controlled doc from target query, defined in method arguments
		if(is_migrated_document || secrf_inactive)
		{
			targetQuery=paramArgumentParser.getStringArgument(ARG_TARGET_OBJECT_IDS,null);
		}

		String[] targetIds=null;

		if(targetQuery!=null && !targetQuery.equalsIgnoreCase(""))
		{
			targetIds=QueryUtils.getAllQueryResultsAsStrings(targetQuery,paramIDfSession) ;
		}



		DfLogger.info(this, "Object ID of the Document > " + objId, null, null);
		DfLogger.debug(this,"**********************************************************************************************************************",null, null);
		DfLogger.info(this, "DQL to fetch target documents  > " + targetQuery, null, null);
		DfLogger.debug(this,"**********************************************************************************************************************",null, null);
		DfLogger.debug(this, "Pre-condition  > " + precondition, null, null);
		DfLogger.debug(this,"**********************************************************************************************************************",null, null);
		DfLogger.debug(this, "Is Document Migrated  > " + is_migrated_document + " Performers will gets applied , if it is true" , null, null);
		DfLogger.debug(this,"**********************************************************************************************************************",null, null);
		DfLogger.debug(this, "Does Performers need to update  > " + assign_performers, null, null);
		DfLogger.debug(this,"**********************************************************************************************************************",null, null);
		DfLogger.debug(this, "Need to Send Notification  > " + send_notification, null, null);
		DfLogger.debug(this,"**********************************************************************************************************************",null, null);
		DfLogger.debug(this, "Context User  > " + context_user, null, null);
		DfLogger.debug(this,"**********************************************************************************************************************",null, null);
		DfLogger.debug(this, "Session Intialized from the user> " + paramIDfSession.getLoginUserName(), null, null);
		DfLogger.debug(this,"**********************************************************************************************************************",null, null);
		DfLogger.debug(this, "Attributes to be copied [SourceAttr|TargetAttr]> " + copy_attrs, null, null);
		DfLogger.debug(this,"**********************************************************************************************************************",null, null);

		DfLogger.debug(this, "Deactivate/Inactive SecRFs  > " + secrf_inactive, null, null);
		DfLogger.debug(this,"**********************************************************************************************************************",null, null);
		DfLogger.debug(this, "Attributes and their value with which object need to update while deactivating> " + secrf_default_value, null, null);
		DfLogger.debug(this,"**********************************************************************************************************************",null, null);
		DfLogger.debug(this, "Default Value which needs to update through DQL> " + secrf_default_value_dql, null, null);
		DfLogger.debug(this,"**********************************************************************************************************************",null, null);
		DfLogger.debug(this, "Role Attributes and their value with which object need to update while deactivating> " + secrf_default_role, null, null);
		DfLogger.debug(this,"**********************************************************************************************************************",null, null);
		DfLogger.debug(this, "Ignore Doc Creator Check > " + igonre_doc_creator_check, null, null);
		DfLogger.debug(this,"**********************************************************************************************************************",null, null);
		DfLogger.debug(this, "Remove Inactive Users from Respective Roles> " + remove_inactive_users, null, null);
		DfLogger.debug(this,"**********************************************************************************************************************",null, null);
		DfLogger.debug(this, "Need to Calculate SecRF Statistics " + calculate_secrf_statistics, null, null);
		DfLogger.debug(this,"**********************************************************************************************************************",null, null);

		DfLogger.debug(this,"**********************************************************************************************************************",null, null);
		DfLogger.debug(this, "Is TMF Performers renaming needed > " + is_tmf_renaming_enabled, null, null);
		DfLogger.debug(this,"**********************************************************************************************************************",null, null);
		DfLogger.debug(this, "TMF Renaming Suffix > " + tmf_suffix_for_renaming, null, null);
		DfLogger.debug(this,"**********************************************************************************************************************",null, null);
		DfLogger.debug(this, "TMF Attributes to be renamed " + tmf_attr_to_be_rename, null, null);
		DfLogger.debug(this,"**********************************************************************************************************************",null, null);


		if(is_migrated_document)
			assign_performers=is_migrated_document;

		DfLogger.info(this," ~~~~~~~~ Checking Notification and Performers Mapping Scenario Available~~~~~~~~ ",null,null);

		Iterator<Entry<String,String>> ArgParserIterator= paramArgumentParser.iterator();

		while(ArgParserIterator.hasNext())
		{
			Entry<String,String> tmpEntry=ArgParserIterator.next();
			String tmpNotiKey=tmpEntry.getKey().toLowerCase().trim();
			if(tmpNotiKey.startsWith(ARG_NOTIFICATION_SCENARIO))
			{
				if(notification_scenario_map==null)
					notification_scenario_map=new HashMap<String,String>();

				notification_scenario_map.put(tmpNotiKey, tmpEntry.getValue());
			}
			else if(tmpNotiKey.startsWith(ARG_PERFORMERS_NOTIFICATION_SCENARIO))
			{
				if(perf_mapping_scenario_map==null)
					perf_mapping_scenario_map=new HashMap<String,String>();

				perf_mapping_scenario_map.put(tmpNotiKey, tmpEntry.getValue());
			}
			else if(tmpNotiKey.startsWith(ARG_SECRF_DEFAULT_ROLE_SCENARIO))
			{
				if(secrf_default_role_mapping_scenario_map==null)
					secrf_default_role_mapping_scenario_map=new HashMap<String,String>();

				secrf_default_role_mapping_scenario_map.put(tmpNotiKey, tmpEntry.getValue());
				secrf_default_role=true;
			}


		}

		DfLogger.info(this," ~~~~~~~~ Checking Notification and Performers Mapping Scenario Available Done~~~~~~~~ ",null,null);

		if(context_user==null || context_user.trim().equalsIgnoreCase(""))
		{
			context_user=paramIDfSession.getLoginUserName();
			DfLogger.debug(this, "Updated Context User as  " + context_user, null, null);
		}

		if(applied_by_user==null || applied_by_user.trim().equalsIgnoreCase(""))
		{
			applied_by_user=paramIDfSession.getLoginUserName();
			DfLogger.debug(this, "Updated Applied By User as  " + applied_by_user, null, null);
		}

		if (targetIds==null || targetIds.length==0)
		{
			if(objId==null || !objId.isObjectId() || secrf_inactive) // In case we need to deactivate the SecRF, target objects are mandatory, we couldn't consider context object as Target
			{
				DfLogger.debug(this,"Target Id/Ids not defined",null, null);
			}
			else if(objId.isObjectId())
			{
				swyBeanArray=new TargetDocumentBean[1];
				swyBeanArray[0]=new TargetDocumentBean();
				swyBeanArray[0].setObjectId(objId.getId());
			}
		}
		else
		{
			swyBeanArray=new TargetDocumentBean[targetIds.length];

			for(int i=0;i<swyBeanArray.length;i++)
			{
				swyBeanArray[i]=new TargetDocumentBean();
				swyBeanArray[i].setObjectId(targetIds[i]);
			}
		}

		if( swyBeanArray!=null)
		{
			DfLogger.debug(this, "No. of objects to be processed  " + swyBeanArray.length, null, null);
		}
		else
		{

			if(secrfObjId!=null && secrfObjId.isObjectId())
			{
				IDfSysObject sysObj=(IDfSysObject) paramIDfSession.getObject(secrfObjId);
				if(sysObj.getTypeName().equalsIgnoreCase(ISWYApplySECRFConstants.SRF_TYPE))
				{

					swyHelperObj.updateStatisticsData(secrfObjId.getId(),paramIDfSession,0,0,0,0);
				}
			}
			DfLogger.debug(this, "Nothing to process", null, null);
		}
		return swyBeanArray;
	}

	@Override
	public Map<String, String> getSlaveMethodArgs() throws DfException 
	{
		DfLogger.debug(this,"****************Starting getSlaveMethodArgs()*******************************************",null, null);
		Map<String, String> methodArgs = new HashMap<>();

		if(srfObjName!=null)
			methodArgs.put(ARG_SECRF_NAME, srfObjName);

		if(precondition!=null)
			methodArgs.put(ARG_PRECONDITION, precondition);

		methodArgs.put(ARG_ASSIGN_PERFORMERS, String.valueOf(assign_performers));
		methodArgs.put(ARG_SEND_NOTIFICATION, String.valueOf(send_notification));

		if(context_user!=null)
			methodArgs.put(ARG_CONTEXT_USER, context_user);

		if(copy_attrs!=null)
			methodArgs.put(ARG_COPY_ATTRS,copy_attrs);

		methodArgs.put(ARG_SECURITY, String.valueOf(isApplySecurity));
		methodArgs.put(ARG_IGNORE_DOC_CREATOR_CHECK, String.valueOf(igonre_doc_creator_check));


		methodArgs.put(ARG_INACTIVE_SECRF, String.valueOf(secrf_inactive));
		methodArgs.put(ARG_DEFAULT_VALUE_PROVIDED, String.valueOf(is_defualt_value_provided));

		if(secrf_default_value!=null)
			methodArgs.put(ARG_DEFAULT_SECRF_VALUES,secrf_default_value);

		if(secrf_default_value_dql!=null)
			methodArgs.put(ARG_DEFAULT_SECRF_VALUES_DQL,secrf_default_value_dql);

		methodArgs.put(INT_ARG_APPLY_TO_PREVIOUS_VERSIONS, String.valueOf(isApplyToPreviousVersions));
		methodArgs.put(ARG_MIGRATED_DOCUMENT, String.valueOf(is_migrated_document));
		methodArgs.put(ARG_DEFAULT_SECRF_ROLES, String.valueOf(secrf_default_role));
		methodArgs.put(ARG_REMOVE_INACTIVE_USERS, String.valueOf(remove_inactive_users));
		methodArgs.put(INT_ARG_APPLY_TO_EXISTING_DOC, String.valueOf(is_secrf_call));
		methodArgs.put(ARG_CALCULATE_SECRF_STATISTICS, String.valueOf(calculate_secrf_statistics));

		if(tmf_suffix_for_renaming!=null)
			methodArgs.put(ARG_TMF_RENAME_SUFFIX, tmf_suffix_for_renaming);

		if(tmf_attr_to_be_rename!=null)
			methodArgs.put(ARG_TMF_RENAME_ATTR_LIST,tmf_attr_to_be_rename);


		methodArgs.put(ARG_TMF_RENAME_ENABLED, String.valueOf(is_tmf_renaming_enabled));


		if(notification_scenario_map!=null && notification_scenario_map.size()>0)
			methodArgs.putAll(notification_scenario_map);

		if(perf_mapping_scenario_map!=null && perf_mapping_scenario_map.size()>0)
			methodArgs.putAll(perf_mapping_scenario_map);

		if(secrf_default_role_mapping_scenario_map!=null && secrf_default_role_mapping_scenario_map.size()>0)
			methodArgs.putAll(secrf_default_role_mapping_scenario_map);


		DfLogger.debug(this,"****************Completing getSlaveMethodArgs()*******************************************",null, null);
		argParser=new ArgumentParser(methodArgs);
		return methodArgs;
	}

	@Override
	public void initSlaveProcess(IDfSession session, IDfSysObject job, Locale locale, ArgumentParser argumentParser)
			throws DfException 
	{
		DfLogger.debug(this,"****************Starting initSlaveProcess()*******************************************",null, null);
		argParser=argumentParser;
		DfLogger.debug(this,"****************Completing initSlaveProcess()*******************************************",null, null);
	}

	@Override
	public void handleResults(IDfSession session, TaskResult[] taskResults)
	{
		DfLogger.debug(this, "In HandleResults , # of Results to process::: "+taskResults.length, null, null);
		try
		{
			DfLogger.debug(this, "In HandleResults , Need to calculate SecRF Statistics ["+calculate_secrf_statistics+"]", null, null);
			if(!calculate_secrf_statistics)
			{
				DfLogger.debug(this, "In HandleResults ,Need to send Custom Mail Notification ["+is_custom_mail_needed+"]", null, null);

				if(is_custom_mail_needed)
				{
					HashMap<String, String> dataMap=null;
					for(int i=0;i<taskResults.length;i++)
					{
						ResultBean beanObj=(ResultBean) taskResults[i].getTaskResult();

						if(beanObj.getProcessStatus().trim().equalsIgnoreCase(ISWYApplySECRFConstants.SUCCESS_STATUS))
						{
							if(beanObj.isMailObjectNeeded())
							{
								String doc_objectId=beanObj.getObjectId();


								String dql_to_check_obj_exist="select r_object_id from "+ISWYApplySECRFConstants.MAIL_OBJECT_TYPE+" where "+ISWYApplySECRFConstants.MAIL_OBJECT_TYPE_ATTR_01+"='"+doc_objectId+"'";

								String resultObjExist=QueryUtils.execQuery(dql_to_check_obj_exist, session);
								String dql_create_mail_object=null;
								boolean isObjectNeedsToCreate=false;
								boolean isObjectExist=false;

								if(resultObjExist!=null && !resultObjExist.trim().equalsIgnoreCase(""))
								{
									DfId resultObjExistId=new DfId(resultObjExist);

									if(resultObjExistId!=null && resultObjExistId.isObjectId())
									{
										dql_create_mail_object="Update " +ISWYApplySECRFConstants.MAIL_OBJECT_TYPE + " objects"
												+ " set "+ISWYApplySECRFConstants.MAIL_OBJECT_TYPE_ATTR_01 + "= '"+doc_objectId+"'";
										isObjectExist=true;
									}
									else
									{
										dql_create_mail_object="Create " +ISWYApplySECRFConstants.MAIL_OBJECT_TYPE + " object"
												+ " set "+ISWYApplySECRFConstants.MAIL_OBJECT_TYPE_ATTR_01 + "= '"+doc_objectId+"'";
										isObjectNeedsToCreate=true;
									}
								}
								else
								{
									dql_create_mail_object="Create " +ISWYApplySECRFConstants.MAIL_OBJECT_TYPE + " object"
											+ " set "+ISWYApplySECRFConstants.MAIL_OBJECT_TYPE_ATTR_01 + "= '"+doc_objectId+"'";
									isObjectNeedsToCreate=true;
								}

								if(beanObj.getDocConflictStatus()!=null && !beanObj.getDocConflictStatus().trim().equals(""))
									dql_create_mail_object=dql_create_mail_object+" , "	+ " set "+ISWYApplySECRFConstants.MAIL_OBJECT_TYPE_ATTR_02 + "= '"+beanObj.getDocConflictStatus()+"'";
								else	
									dql_create_mail_object=dql_create_mail_object+" , "	+ " set "+ISWYApplySECRFConstants.MAIL_OBJECT_TYPE_ATTR_02 + "= ''";

								if(beanObj.getRemarks()!=null && !beanObj.getRemarks().trim().equals(""))	
								{
									DfLogger.debug(this, "Remarks not null and Checkout status ["+beanObj.isDocCheckoutCancelled()+"]", null, null);
									if(beanObj.isDocCheckoutCancelled())
									{
										dql_create_mail_object=dql_create_mail_object+" , "+ " set "+ISWYApplySECRFConstants.MAIL_OBJECT_TYPE_ATTR_03 + "= ' Checkout Cancelled and "+beanObj.getRemarks()+"'";
									}
									else
									{
										dql_create_mail_object=dql_create_mail_object+" , "+ " set "+ISWYApplySECRFConstants.MAIL_OBJECT_TYPE_ATTR_03 + "= '"+beanObj.getRemarks()+"'";
									}
								}
								else
								{
									DfLogger.debug(this, "Remarks null and Checkout status ["+beanObj.isDocCheckoutCancelled()+"]", null, null);
									if(beanObj.isDocCheckoutCancelled())
									{
										dql_create_mail_object=dql_create_mail_object+" , "+ " set "+ISWYApplySECRFConstants.MAIL_OBJECT_TYPE_ATTR_03 + "= 'Checkout Cancelled'";
									}
									else
									{
										dql_create_mail_object=dql_create_mail_object+" , "+ " set "+ISWYApplySECRFConstants.MAIL_OBJECT_TYPE_ATTR_03 + "= ''";
									}
								}

								dql_create_mail_object=dql_create_mail_object+" , "+ " truncate "+ISWYApplySECRFConstants.MAIL_OBJECT_TYPE_ATTR_04 ;

								if(beanObj.getDocFormManagers()!=null && beanObj.getDocFormManagers().length>0)
								{
									String[] form_managers=beanObj.getDocFormManagers();
									for(int j=0;j<form_managers.length;j++)
									{
										if(form_managers[j]!=null && !form_managers[j].trim().equalsIgnoreCase(""))
										{
											dql_create_mail_object=dql_create_mail_object+" , "+ " append "+ISWYApplySECRFConstants.MAIL_OBJECT_TYPE_ATTR_04 + "= '"+form_managers[j]+"'";
										}
									}
								}

								dql_create_mail_object=dql_create_mail_object+" , "+ " truncate "+ISWYApplySECRFConstants.MAIL_OBJECT_TYPE_ATTR_05 ;

								if(beanObj.getDocNewAuthors()!=null && beanObj.getDocNewAuthors().length>0)
								{
									String[] new_authors=beanObj.getDocNewAuthors();
									for(int j=0;j<new_authors.length;j++)
									{
										if(new_authors[j]!=null && !new_authors[j].trim().equalsIgnoreCase(""))
										{
											dql_create_mail_object=dql_create_mail_object+" , "+ " append "+ISWYApplySECRFConstants.MAIL_OBJECT_TYPE_ATTR_05 + "= '"+new_authors[j]+"'";
										}
									}
								}

								dql_create_mail_object=dql_create_mail_object+" , "+ " truncate "+ISWYApplySECRFConstants.MAIL_OBJECT_TYPE_ATTR_06 ;

								if(beanObj.getDocPreviousAuthors()!=null && beanObj.getDocPreviousAuthors().length>0)
								{
									String[] previous_authors=beanObj.getDocPreviousAuthors();
									for(int j=0;j<previous_authors.length;j++)
									{
										if(previous_authors[j]!=null && !previous_authors[j].trim().equalsIgnoreCase(""))
										{
											dql_create_mail_object=dql_create_mail_object+" , "+ " append "+ISWYApplySECRFConstants.MAIL_OBJECT_TYPE_ATTR_06 + "= '"+previous_authors[j]+"'";
										}
									}
								}

								if(beanObj.isWorkflowAborted())
									dql_create_mail_object=dql_create_mail_object+" , "+ " set "+ISWYApplySECRFConstants.MAIL_OBJECT_TYPE_ATTR_07 + "= 1";
								else
									dql_create_mail_object=dql_create_mail_object+" , "+ " set "+ISWYApplySECRFConstants.MAIL_OBJECT_TYPE_ATTR_07 + "= 0";

								if(isObjectExist)
								{
									dql_create_mail_object=dql_create_mail_object+ " where "+ISWYApplySECRFConstants.MAIL_OBJECT_TYPE_ATTR_01+"='"+doc_objectId+"'";
								}
								else if(isObjectNeedsToCreate)
								{
									dql_create_mail_object=dql_create_mail_object+ " link '"+ISWYApplySECRFConstants.MAIL_OBJECT_CREATE_PATH+"'";
								}

								DfLogger.debug(this, "In HandleResults , DQL to create/update Mail Object {0}", new String[]{dql_create_mail_object}, null);

								String result=QueryUtils.execQuery(dql_create_mail_object, session);
								if(result!=null && !result.trim().equalsIgnoreCase(""))
								{
									DfId resultId=new DfId(result);
									boolean isObjCreatedUpdated=false;
									if(resultId!=null && resultId.isObjectId())
									{
										DfLogger.debug(this, "In HandleResults , DQL to create Mail Object {0} with execution result as {1}", new String[]{dql_create_mail_object,resultId.getId()}, null);
										isObjCreatedUpdated=true;
									}
									else
									{
										int updatecObjCount=0;
										try
										{
											updatecObjCount=Integer.parseInt(result);
										}
										catch(NumberFormatException nfe)
										{
											//nfe.printStackTrace();
											DfLogger.error(this, nfe.getLocalizedMessage(), null, nfe);
										}

										if(updatecObjCount>=1)
										{
											isObjCreatedUpdated=true;
										}
									}

									if(isObjCreatedUpdated)
									{
										String applicable_templates[]=beanObj.getTemplateName();
										DfLogger.debug(this, "In HandleResults , Prepare data map for Mail Object Processing", null, null);
										if(applicable_templates!=null && applicable_templates.length>0)
										{
											for(int j=0;j<applicable_templates.length;j++)
											{
												if(dataMap==null)
													dataMap=new HashMap<String,String>();

												if(dataMap.containsKey(applicable_templates[j]))
												{
													String objIds=dataMap.get(applicable_templates[j]);
													if(objIds!=null && !objIds.trim().equalsIgnoreCase(""))
													{
														objIds=objIds+","+doc_objectId;
														dataMap.put(applicable_templates[j], objIds);
													}
												}
												else
												{
													dataMap.put(applicable_templates[j], doc_objectId);
												}
											}
										}
									}
								}

							}
						}
					}

					//Call mail notification
					//SWYSecrfEmailNotification mail_notification_obj=null;
					if(dataMap!=null && dataMap.size()>0)
					{
						DfLogger.debug(this, "In HandleResults , Mail Object Processing, # of request would {0}", new String[]{String.valueOf(dataMap.size())}, null);
						Iterator<String> keyIterator=dataMap.keySet().iterator();
						String method_args="";

						int mail_scenario_counter=0;
						while(keyIterator.hasNext())
						{
							String template_name=keyIterator.next();
							String target_ids=dataMap.get(template_name);

							mail_scenario_counter=mail_scenario_counter+1;


							if(template_name!=null && !template_name.trim().equalsIgnoreCase("") && 
									(template_name.trim().equalsIgnoreCase(ISWYApplySECRFConstants.MAIL_OBJECT_MSGS_TEMPLATE1_KEY) || 
											template_name.trim().equalsIgnoreCase(ISWYApplySECRFConstants.MAIL_OBJECT_MSGS_TEMPLATE2_KEY)))
							{
								IDfSysObject secrfSysObj=(IDfSysObject)session.getObjectByQualification("swy_sec_registration_form where object_name='"+srfObjName+"'");
								if(mail_scenario_counter==1)
									method_args="-mail_scenario"+mail_scenario_counter+" \"-template_name "+template_name+" -target_ids "+target_ids + " -seperator , "+ARG_APPLIED_BY +" "+applied_by_user+" -secrf_id "+secrfSysObj.getObjectId().getId()+"\"";
								else	
									method_args=method_args+ " -mail_scenario"+mail_scenario_counter+" \"-template_name "+template_name+" -target_ids "+target_ids + " -seperator , "+ARG_APPLIED_BY +" "+applied_by_user+" -secrf_id "+secrfSysObj.getObjectId().getId()+"\"";
							}
							else
							{
								if(mail_scenario_counter==1)
									method_args="-mail_scenario"+mail_scenario_counter+" \"-template_name "+template_name+" -target_ids "+target_ids + " -seperator , "+ARG_APPLIED_BY +" "+applied_by_user+"\"";
								else	
									method_args=method_args+ " -mail_scenario"+mail_scenario_counter+" \"-template_name "+template_name+" -target_ids "+target_ids + " -seperator , "+ARG_APPLIED_BY +" "+applied_by_user+"\"";
							}
							DfLogger.debug(this, "In HandleResults , Mail request creating for template name {0} and target ids {1}", new String[]{template_name,target_ids}, null);
						}

						method_args=method_args+ " -docbase_name " + session.getDocbaseName();
						method_args=method_args+" -user_name " + session.getServerConfig().getString("r_install_owner");

						IDfList list1=new DfList();
						IDfList list2=new DfList();
						IDfList list3=new DfList();

						list1.append("METHOD");
						list1.appendString("RUN_AS_SERVER");
						list1.appendString("LAUNCH_ASYNC");
						list1.append("ARGUMENTS");

						list2.append("s");		// Corresponding to "METHOD" 
						list2.appendString("b");
						list2.appendString("b");
						list2.append("s");		// Corre4sponding to "ARGUMENTS"

						list3.append(ISWYApplySECRFConstants.MAIL_OBJECT_NOTIFICATION_METHOD_NAME);
						list3.appendString("T");
						list3.appendString("F");
						list3.append(method_args);

						DfLogger.debug(this, "In HandleResults , Mail request arguments: method name {0} with arguments {1}", new String[]{ISWYApplySECRFConstants.MAIL_OBJECT_NOTIFICATION_METHOD_NAME,method_args}, null);
						IDfCollection methodColl=null;
						try
						{
							methodColl=session.apply(null,"DO_METHOD",list1,list2,list3); 
							DfLogger.debug(this, "In HandleResults , Mail request sent to method name {0} with arguments {1}", new String[]{ISWYApplySECRFConstants.MAIL_OBJECT_NOTIFICATION_METHOD_NAME,method_args}, null);
						}
						finally
						{
							if (methodColl!=null)
							{
								methodColl.close();

								DfLogger.debug(this, "Closing the methods call that was opened for mail request", null, null);
							}
						}
					}

				}
			}
			else  //calculate_secrf_statistics is true
			{
				int wf_qc_abort_cnt=0;
				int doc_conflicted_cnt=0;
				int doc_affected_count=0;
				int doc_checkout_count=0;

				DfLogger.debug(this, "Calculating SecRF Statistics", null, null);
				if(is_secrf_call)	// only if calls from "apply to existing document"
				{
					for(int i=0;i<taskResults.length;i++)
					{
						ResultBean beanObj=(ResultBean) taskResults[i].getTaskResult();

						if(beanObj.getProcessStatus().trim().equalsIgnoreCase(ISWYApplySECRFConstants.SUCCESS_STATUS))
						{
							if(beanObj.getDocConflictStatus()!=null && beanObj.getDocConflictStatus().trim().equalsIgnoreCase(ISWYApplySECRFConstants.DOC_SECRF_CONFLICT_STATUS))
							{
								doc_conflicted_cnt=doc_conflicted_cnt+1;
							}

							if (beanObj.isWorkflowAborted())
							{
								wf_qc_abort_cnt=wf_qc_abort_cnt+1;
							}

							if(beanObj.isDocAffectedDueToSecRF())
							{
								doc_affected_count=doc_affected_count+1;
							}

							if(beanObj.isDocCheckoutCancelled())
							{
								doc_checkout_count=doc_checkout_count+1;
							}
						}
					}

					String dql="select r_object_id from "+ISWYApplySECRFConstants.SRF_TYPE+" where object_name='"+srfObjName+"'";
					DfLogger.debug(this, "Calculating SecRF Statistics, DQL to retrieve SecRF object ["+dql+"]", null, null);
					String secrf_obj_id=QueryUtils.execQuery(dql, session);
					if(secrf_obj_id!=null && !secrf_obj_id.trim().equalsIgnoreCase(""))
					{

						SWYApplySecRFHelper swyHelperObj=new SWYApplySecRFHelper(session);
						swyHelperObj.updateStatisticsData(secrf_obj_id,session,doc_affected_count,doc_conflicted_cnt,wf_qc_abort_cnt,doc_checkout_count);
					}

				}

			}
		}
		catch(Exception ex)
		{
			DfLogger.error(this, ex.getLocalizedMessage(), null, ex);
		}
		DfLogger.debug(this, "In HandleResults Processing DONE", null, null);
	}

	@Override
	public Serializable performTask(int arg0, String arg1, Serializable arg2, IDfSession session) throws DfException 
	{
		if(arg2!=null)
		{
			TargetDocumentBean beanObj=(TargetDocumentBean)arg2;
			String objId=beanObj.getObjectId();

			DfLogger.info(this,"In performTask() :: Processing Object "+objId,null,null);

			//return setSecurityRegistrationForm(session,objId);
			return setSecurityRegistrationForm(session,objId);
		}
		else
		{
			return "Serializable Object is null";
		}

	}

	/**
	 * Applying the Security Registration Form.
	 * At First, checking if any security registration form found or not.
	 * If nothing is found , it will set "default" on attribute "swy_security_rest_form".
	 * If found, check the size of map. 
	 * 		If it is one, apply the registration form to object on attribute "swy_security_rest_form".
	 * 		If it is more than one, just update the name of all registration form with different repeating attribute "swy_sel_security_rest_forms". This attribute is further used to populate the name of available forms on UI.
	 *
	 * @param dgSession
	 * @param paramIDfSysObject
	 * @param paramLocale
	 * @param objId
	 * @param dlSecRegForm
	 * @return
	 */
	private ResultBean setSecurityRegistrationForm(IDfSession session, String targetId) 
	{
		DfLogger.warn(this,"************************************** Executing Logic to Apply SecRF on Document/ Calculate Statistics [id="+targetId+"] *****************************************************************",null,null);
		DfLogger.debug(this, "::: setSecurityRegistrationForm () ::: Beforee Getting ResultBean Object ", null, null);
		ResultBean resultBeanObj=new ResultBean();
		DfLogger.debug(this, "::: setSecurityRegistrationForm () ::: After Getting ResultBean Object ", null, null);
		String secrfObjectName=argParser.getStringArgument(ARG_SECRF_NAME,null);
		DfLogger.info(this, "::: setSecurityRegistrationForm () ::: SECRF NAME (Not Null, if call initiated from SecRF Object) >> " + secrfObjectName, null, null);
		String precond=argParser.getStringArgument(ARG_PRECONDITION,null);
		DfLogger.info(this, "::: setSecurityRegistrationForm () ::: Pre-condition  >> " + precondition, null, null);
		boolean is_assign_performers=argParser.getBooleanArgument(ARG_ASSIGN_PERFORMERS, false);
		DfLogger.info(this, "::: setSecurityRegistrationForm () ::: is_assign_performers  >> " + is_assign_performers, null, null);
		String ctxUsr=argParser.getStringArgument(ARG_CONTEXT_USER, null);
		DfLogger.info(this, "::: setSecurityRegistrationForm () ::: context user  >> " + ctxUsr, null, null);
		boolean is_send_notification_needed=argParser.getBooleanArgument(ARG_SEND_NOTIFICATION,false);
		DfLogger.info(this, "::: setSecurityRegistrationForm () ::: is_send_notification_needed  >> " + is_send_notification_needed, null, null);
		String attr_to_be_copied=argParser.getStringArgument(ARG_COPY_ATTRS, null);
		DfLogger.info(this, "::: setSecurityRegistrationForm () ::: attr_to_be_copied  >> " + attr_to_be_copied, null, null);
		boolean need_to_apply_security=argParser.getBooleanArgument(ARG_SECURITY,false);
		DfLogger.info(this, "::: setSecurityRegistrationForm () ::: need_to_apply_security  >> " + need_to_apply_security, null, null);

		boolean is_document_migr8ed=argParser.getBooleanArgument(ARG_MIGRATED_DOCUMENT,false);
		DfLogger.info(this, "::: setSecurityRegistrationForm () ::: IS DOCUMENT MIGRATED >> " + is_document_migr8ed, null, null);

		boolean isSecrfInactiveCall=argParser.getBooleanArgument(ARG_INACTIVE_SECRF,false);
		DfLogger.info(this, "::: setSecurityRegistrationForm () ::: Call to make SecRF Inactive  >> " + isSecrfInactiveCall, null, null);
		boolean ignoreDocCreatorChk=argParser.getBooleanArgument(ARG_IGNORE_DOC_CREATOR_CHECK,false);
		DfLogger.info(this, "::: setSecurityRegistrationForm () ::: Ignore Doc Creator Check  >> " + ignoreDocCreatorChk, null, null);
		boolean removeInactiveUser=argParser.getBooleanArgument(ARG_REMOVE_INACTIVE_USERS,false);
		DfLogger.info(this, "::: setSecurityRegistrationForm () ::: removeInactiveUser  >> " + removeInactiveUser, null, null);
		boolean apply_to_existing_doc=argParser.getBooleanArgument(INT_ARG_APPLY_TO_EXISTING_DOC,false);
		DfLogger.info(this, "::: setSecurityRegistrationForm () ::: apply_to_existing_doc  >> " + apply_to_existing_doc, null, null);
		boolean find_secrf_statistics=argParser.getBooleanArgument(ARG_CALCULATE_SECRF_STATISTICS, false);
		DfLogger.info(this, "::: setSecurityRegistrationForm () ::: find_secrf_statistics  >> " + find_secrf_statistics, null, null);

		boolean is_tmf_rename_enabled=argParser.getBooleanArgument(ARG_TMF_RENAME_ENABLED, false);
		DfLogger.info(this, "::: setSecurityRegistrationForm () ::: is_tmf_rename_enabled  >> " + is_tmf_rename_enabled, null, null);
		String tmf_attr_to_be_renamed = argParser.getStringArgument(ARG_TMF_RENAME_ATTR_LIST, null);
		DfLogger.info(this, "::: setSecurityRegistrationForm () ::: tmf_attr_to_be_renamed  >> " + tmf_attr_to_be_renamed, null, null);
		String tmf_suffix_for_rename = argParser.getStringArgument(ARG_TMF_RENAME_SUFFIX, null);
		DfLogger.info(this, "::: setSecurityRegistrationForm () ::: tmf_suffix_for_rename  >> " + tmf_suffix_for_rename, null, null);

		boolean isRequireToPreviousVersions =argParser.getBooleanArgument(INT_ARG_APPLY_TO_PREVIOUS_VERSIONS, true);
		DfLogger.info(this, "::: setSecurityRegistrationForm () ::: Is Required to Previous Versions  >> " + isRequireToPreviousVersions, null, null);

		secrf_default_role = argParser.getBooleanArgument(ARG_DEFAULT_SECRF_ROLES, false);

		is_defualt_value_provided = argParser.getBooleanArgument(ARG_DEFAULT_VALUE_PROVIDED, false);

		boolean isSecrfInactive_ChangeNeeded=false;	// if true, need to do changes related with SecRF default values , if it is deactivated
		boolean isSecrfListRefreshNeeded=true;		// if true, will execute the logic to get updated applicable SecRF objects

		DfLogger.info(this,"Object id["+targetId+"] PreCodition =["+precond+"] SecRF performers need to map =["+is_assign_performers+"] "
				+ "Context user =["+ctxUsr+"] Notification Needed =["+is_send_notification_needed+"] Deactivate/Inactive SecRF=["+isSecrfInactiveCall+"] SecRF Statistics Needed ["+find_secrf_statistics+"]",null,null);

		boolean isSatisfiedForDefault=false;	//'Default' as swy_security_rest_form , 'Default' as swy_secrf_application_mode, 'Default' as swy_sel_security_rest_forms
		boolean need_to_remove_performer=false;
		boolean is_document_conflicted=false;
		String document_mode=null;

		ArrayList<String> automaticList=new ArrayList<String>();
		ArrayList<String> manualList=new ArrayList<String>();

		String r_creator_name=null;
		DfLogger.info(this,"Object id["+targetId+"]  Initializing abcdefghijklmnopqrstuvwxyz",null,null);

		SWYApplySecRFHelper swyHelperObj=new SWYApplySecRFHelper(session);
		UpdateAttrsViaQuery updateAttrViaQueryObj=new UpdateAttrsViaQuery();

		String myQuery=  "select distinct v.object_name as name from d2_dictionary d,"
				+ "d2_dictionary_value v where d.object_name = v.dictionary_name and "
				+ "d.object_name = 'CMN-DIC-Security Registration Roles' and  v.i_position=d.i_position "
				+ "enable (ROW_BASED)";

		String[] rolesArr =null;
		IDfSysObject sysObject = null;
		IDfId targetObjId=null;
		try{
			rolesArr = QueryUtils.getAllQueryResultsAsStrings(myQuery, session);

			targetObjId=new DfId(targetId);

			if(targetObjId.isObjectId())
			{

				sysObject = (IDfSysObject)session.getObject(targetObjId);
				IDfVersionLabels versionLabels= sysObject.getVersionLabels();
				boolean isDocCurrent=true;

				/**
				 * @@ 18-Nov-2017 : Issue# 2308, checking if document is not current version, returning from here itself, not processing further.
				 */
				DfLogger.debug(this,"["+targetId+"] @@ 18-Nov-2017 : Issue# 2308, checking if document is not current version, returning from here itself, not processing further.",null,null);
				if(!versionLabels.hasSymbolicVersionLabel())
				{
					isDocCurrent=false;
					DfLogger.debug(this,"["+targetId+"] Object doesn't have any Symbolic Version Labels, assuming it is not current",null,null);

				}
				else 
				{
					int versionLblCont=versionLabels.getVersionLabelCount();

					for(int i=0;i<versionLblCont;i++)
					{
						String versionLbl=versionLabels.getVersionLabel(i);
						if(versionLbl.equalsIgnoreCase(ISWYApplySECRFConstants.SYS_CURRENT_VERSION_LABEL))
						{
							isDocCurrent=true;
							DfLogger.debug(this,"["+targetId+"] Object is current",null,null);
							break;
						}
						else
						{
							isDocCurrent=false;
							DfLogger.debug(this,"["+targetId+"] Object is Not Current",null,null);
						}
					}
				}
				if(!isDocCurrent)
				{
					DfLogger.debug(this,"["+targetId+"] After Checking Version label seems oject is non-current",null,null);

					resultBeanObj.setProcessStatus(ISWYApplySECRFConstants.FAILED_STATUS);
					resultBeanObj.setObjectId(targetId);
					resultBeanObj.setProcessMsg("Failed : " +"Object ["+targetId+"] is not CURRENT ");
					resultBeanObj.setMailObjectNeeded(false);
					resultBeanObj.setDocAffectedDueToSecRF(false);
					return resultBeanObj;

				}

				if(sysObject.hasAttr(ISWYApplySECRFConstants.DOC_FORCED_UNBLIND_ATTR))
				{
					boolean is_forced_unblind=sysObject.getBoolean(ISWYApplySECRFConstants.DOC_FORCED_UNBLIND_ATTR);
					DfLogger.debug(this,"Object ["+targetId+"] if is_forced_unblind is true SecRF will not applied , currently its value is ["+is_forced_unblind+"]  ",null,null);
					if(is_forced_unblind)
					{
						//SecRF logic will not process further and values remains as it is.

						String conf_val=sysObject.getString(ISWYApplySECRFConstants.CONFIDENTIALITY_ATTR_NAME);

						if(conf_val.equalsIgnoreCase(ISWYApplySECRFConstants.RESTRICTED_CONFIDENTIALITY_VALUE))
						{
							sysObject.setString(ISWYApplySECRFConstants.SECURITY_APPLICATION_MODE_ATTR_NAME, ISWYApplySECRFConstants.DEFAULT);
							sysObject.setString(ISWYApplySECRFConstants.SRF_ATTR_NAME, ISWYApplySECRFConstants.DEFAULT);
							sysObject.removeAll(ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME);	
							sysObject.appendString(ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME, ISWYApplySECRFConstants.DEFAULT);	
							sysObject.setString(ISWYApplySECRFConstants.CONFIDENTIALITY_ATTR_NAME, ISWYApplySECRFConstants.BUO_CONFIDENTIALITY_VALUEE);

							//swyHelperObj.applyChangesToAllVersions(sysObject, new String[]{ISWYApplySECRFConstants.SECURITY_APPLICATION_MODE_ATTR_NAME,ISWYApplySECRFConstants.SRF_ATTR_NAME,ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME}, new String[]{ ISWYApplySECRFConstants.DEFAULT,ISWYApplySECRFConstants.DEFAULT,ISWYApplySECRFConstants.DEFAULT}, session, isApplyToPreviousVersions);

							if(sysObject.getTypeName().equalsIgnoreCase(ISWYApplySECRFConstants.TMF_DOC_TYPE))
							{
								tmf_suffix_for_rename="SECRF";
								tmf_attr_to_be_renamed="qc_group,external_authors,external_approvers,external_auditors,external_doc_coordinators,external_readers,external_reviewers";
								String[] attrArr= tmf_attr_to_be_renamed.split(ISWYApplySECRFConstants.COMMA_SEPARATOR);
								swyHelperObj.rollbackTMFPerformersChange(sysObject,attrArr,tmf_suffix_for_rename);

								swyHelperObj.chkAppliedQcUsersIsPartOfQcgroup(sysObject,session);
							}
							DfLogger.debug(this,"Object id["+targetId+"]::: is satisfied to apply standard ["+isSatisfiedForDefault+"] done",null,null);
							need_to_remove_performer=false;
							isSecrfListRefreshNeeded=false;
							DfcObjectUtils.fetchObjectIfRequired(sysObject);
							sysObject.save();
						}

						resultBeanObj.setProcessStatus(ISWYApplySECRFConstants.FAILED_STATUS);
						resultBeanObj.setObjectId(targetId);
						resultBeanObj.setProcessMsg("Object ["+targetId+"] is unblinded since its value is ["+is_forced_unblind+"] thus SecRF will not applied");
						resultBeanObj.setMailObjectNeeded(false);
						resultBeanObj.setDocAffectedDueToSecRF(false);
						return resultBeanObj;
					}
				}

				// -------------------------End of Issue#2308-------------------------------------------------

				// Check for preconditions and apply if necessary

				if(precond!=null && !precond.trim().equalsIgnoreCase(""))
				{
					DfLogger.info(this, "Precondition as passed from application  > " + precond, null, null);
					precond=AttributeExpression.resolve(precond, sysObject, context_user);

					if (!QueryUtils.checkObjectConditionExpression(sysObject, precond, session)) 
					{
						String strMsg=String.format("Object id["+targetId+"]::: Preconditions not satisfied for object \"%s\" of type %s with object id %s and precondition %s ",  sysObject.getObjectName(),sysObject.getTypeName(),sysObject.getObjectId().getId(),precond) ;
						DfLogger.info(this,"Failed : " +strMsg,null,null);

						resultBeanObj.setProcessStatus(ISWYApplySECRFConstants.FAILED_STATUS);
						resultBeanObj.setObjectId(targetId);
						resultBeanObj.setProcessMsg("Failed : " +strMsg);
						resultBeanObj.setMailObjectNeeded(false);
						resultBeanObj.setDocAffectedDueToSecRF(false);
						return resultBeanObj;
					}
					else
					{
						String strMsg=String.format("Object id["+targetId+"]::: Preconditions satisfied, Ready to Process: for object \"%s\" of type %s with object id %s and precondition %s ",  sysObject.getObjectName(),sysObject.getTypeName(),targetObjId,precond) ;
						DfLogger.info(this,strMsg,null,null);
					}
				}
				else
				{
					String strMsg=String.format("Object id["+targetId+"]::: Preconditions not defined, Ready to Process: for object \"%s\" of type %s with object id %s and precondition %s ",  sysObject.getObjectName(),sysObject.getTypeName(),targetObjId,precond) ;
					DfLogger.info(this,strMsg,null,null);
				}
			}

			r_creator_name=sysObject.getString(ISWYApplySECRFConstants.CREATOR_NAME_ATTR);
		}
		catch(Exception ex)
		{
			DfLogger.error(this,ex.getLocalizedMessage(),null,ex);
		}

		if(isSecrfInactiveCall)
		{

			try
			{
				if(!ignoreDocCreatorChk)
				{
					String mig_obj_id=sysObject.getString(ISWYApplySECRFConstants.DOC_MIG_OBJ_ID_ATTR);

					if(mig_obj_id!=null &&  !mig_obj_id.trim().equalsIgnoreCase("") )
					{
						ignoreDocCreatorChk=true;
					}
				}

				DfLogger.info(this, "Object id["+targetId+"]::: Processing Inactive logic", null, null);
				int avail_secrf_count=sysObject.getValueCount(ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME);

				// Added on 26-June-2020 SUB-1271 Checkout is not getting cancelled when document get restricted: Start
				/***** Cancel Checkout Logic ****/

				if(!find_secrf_statistics)
				{
					DfLogger.debug(this, "Object id["+targetId+"]::: SecRF Call to deactivate ["+isSecrfInactiveCall+"]", null, null);
					if(sysObject.isCheckedOut())
					{
						DfLogger.debug(this, "Object id["+targetId+"]::: Processing Inactive logic ,Saving checkedout details", null, null);
						resultBeanObj.setIsReCheckinRequired(true);
						resultBeanObj.setCheckoutInfo(swyHelperObj.getCheckoutInfo(targetId, session));
					}
					callOriginatedFrom="From Creation / Updation of Object";
					boolean ischkOutAborted=swyHelperObj.isCheckOutAborted(targetId,session,find_secrf_statistics);
					resultBeanObj.setDocCheckoutCancelled(ischkOutAborted);
					DfLogger.debug(this,"["+targetId+"]*****Call "+callOriginatedFrom+"  Is Checkout Aborted ["+ischkOutAborted+"] while deactivating ***********************VStamp="+ sysObject.getVStamp(),null,null);	
					if (ischkOutAborted)
					{
						DfLogger.debug(this,"********************* Is Checkout Abort done ["+ischkOutAborted+"] in if block to set its value in bean obj",null,null);	
						resultBeanObj.setDocAffectedDueToSecRF(true);
						/*sysObject=null;
							sysObject=(IDfSysObject)session.getObject(targetObjId);*/
						sysObject.fetch(null);


						DfLogger.debug(this,"********************* Is Checkout Abort done ["+ischkOutAborted+"] going out from if block after set its value in bean obj VStamp="+ sysObject.getVStamp(),null,null);	
					}
				}
				// Added on 26-June-2020 SUB-1271 Checkout is not getting cancelled when document get restricted: Start

				if(avail_secrf_count==1)
				{
					DfLogger.debug(this, "Object id["+targetId+"]::: Processing Inactive logic , Available SecRF Count [1]", null, null);

					isSecrfInactive_ChangeNeeded=true;
					isSatisfiedForDefault=true;	//'Default' as swy_security_rest_form , 'Default' as swy_secrf_application_mode, 'Default' as swy_sel_security_rest_forms
					need_to_remove_performer=false;
					DfLogger.debug(this, "Object id["+targetId+"]::: Processing Inactive logic , Available SecRF Count [1] COMPLETED", null, null);
				}
				else if(avail_secrf_count==2)
				{
					DfLogger.debug(this, "Object id["+targetId+"]::: Processing Inactive logic , Available SecRF Count [2]", null, null);
					String appliedSR=sysObject.getString(ISWYApplySECRFConstants.SRF_ATTR_NAME);
					String inActiveSecRF=null;
					String applicableSecrfName=null;

					if(secrfObjectName!=null && !secrfObjectName.trim().equalsIgnoreCase(""))
					{
						inActiveSecRF=secrfObjectName;
					}
					else
					{
						inActiveSecRF=sysObject.getString(ISWYApplySECRFConstants.SRF_ATTR_NAME);
					}

					for(int i=0;i<avail_secrf_count;i++)
					{
						String tmpSecrfName=sysObject.getRepeatingString(ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME,i);

						if(tmpSecrfName!=null && !tmpSecrfName.trim().equalsIgnoreCase(""))
						{
							if(!inActiveSecRF.trim().equals(tmpSecrfName.trim()))
							{
								applicableSecrfName=tmpSecrfName;
								break;
							}
						}
					}

					if(appliedSR!=null && !appliedSR.trim().equalsIgnoreCase("") && appliedSR.equals(applicableSecrfName))
					{
						DfLogger.debug(this, "Object id["+targetId+"]::: Processing Inactive logic , when SecRF which need to inactive ["+inActiveSecRF+"] and which is already applied ["+appliedSR+"] are not same ", null, null);

						sysObject.setString(ISWYApplySECRFConstants.DOC_SECRF_CONFLICTING_ATTR,null);
						sysObject.removeAll(ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME);
						sysObject.setRepeatingString(ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME,0, applicableSecrfName);
						//swyHelperObj.applyChangesToAllVersions(sysObject,new String[] {ISWYApplySECRFConstants.DOC_SECRF_CONFLICTING_ATTR,ISWYApplySECRFConstants.DOC_SECRF_CONFLICTING_ATTR,ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME}, new String[] {null,null,applicableSecrfName}, session,isApplyToPreviousVersions);


						isSatisfiedForDefault=false;
						need_to_remove_performer=false;
						is_assign_performers =false;
						DfLogger.debug(this, "Object id["+targetId+"]::: Processing Inactive logic , when SecRF which need to inactive ["+inActiveSecRF+"] and which is already applied ["+appliedSR+"] are not same same, Performers not removing, new performers not applying", null, null);
					}
					else
					{
						/***** Cancel Checkout Logic ****/
						// Added on 26-June-2020 SUB-1271 Checkout is not getting cancelled when document get restricted: Start
						resultBeanObj.setIsReCheckinRequired(false);
						// Added on 26-June-2020 SUB-1271 Checkout is not getting cancelled when document get restricted: end

						DfLogger.debug(this, "Object id["+targetId+"]::: Processing Inactive logic , when SecRF which need to inactive ["+inActiveSecRF+"] and which is already applied ["+appliedSR+"] are same", null, null);
						if(ignoreDocCreatorChk)
						{
							DfLogger.debug(this, "Object id["+targetId+"]::: Processing Inactive logic , Available SecRF Count [1]:::Ignore Doc Creator Check is true", null, null);
							sysObject.setString(ISWYApplySECRFConstants.SRF_ATTR_NAME,applicableSecrfName);
							//swyHelperObj.applyChangesToAllVersions(sysObject,new String[] {ISWYApplySECRFConstants.SRF_ATTR_NAME}, new String[] {applicableSecrfName}, session,isApplyToPreviousVersions);
						}
						else
						{
							DfLogger.debug(this, "Object id["+targetId+"]::: Processing Inactive logic , Available SecRF Count [1]:::Ignore Doc Creator Check is false", null, null);
							boolean isAuthorExist=swyHelperObj.checkAuthorExistInSelectedSecRF(applicableSecrfName,r_creator_name,session);
							if(isAuthorExist)
							{
								sysObject.setString(ISWYApplySECRFConstants.SRF_ATTR_NAME,applicableSecrfName);
							}
							else
							{
								is_document_conflicted=true;
								secrf_default_role=false;
								document_mode=sysObject.getString(ISWYApplySECRFConstants.SECURITY_APPLICATION_MODE_ATTR_NAME);
								resultBeanObj.setApplicableSecRFs(new String[]{applicableSecrfName});
								sysObject.setString(ISWYApplySECRFConstants.SRF_ATTR_NAME,null);
							}
						}

						sysObject.removeAll(ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME);
						sysObject.setRepeatingString(ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME,0, applicableSecrfName);

						if(is_document_conflicted)
						{
							sysObject.setString(ISWYApplySECRFConstants.DOC_SECRF_CONFLICTING_ATTR,ISWYApplySECRFConstants.DOC_SECRF_CONFLICT_STATUS);
						}
						else
						{
							sysObject.setString(ISWYApplySECRFConstants.DOC_SECRF_CONFLICTING_ATTR,null);
						}

						isSatisfiedForDefault=false;
						need_to_remove_performer=true;
						is_assign_performers =true;
						DfLogger.debug(this, "Object id["+targetId+"]::: Processing Inactive logic , Available SecRF Count [2] COMPLETED", null, null);
						DfLogger.debug(this, "Object id["+targetId+"]::: Processing Inactive logic , when SecRF which need to inactive ["+inActiveSecRF+"] and which is already applied ["+appliedSR+"] are same, Performers removing, new performers applying", null, null);
					}
				}
				else if (avail_secrf_count>2)
				{
					DfLogger.debug(this, "Object id["+targetId+"]::: Processing Inactive logic , Available SecRF Count ["+avail_secrf_count+"] ", null, null);

					String appliedSR=sysObject.getString(ISWYApplySECRFConstants.SRF_ATTR_NAME);
					String inActiveSecRF=null;

					if(secrfObjectName!=null && !secrfObjectName.trim().equalsIgnoreCase(""))
					{
						inActiveSecRF=secrfObjectName;
					}
					else
					{
						inActiveSecRF=sysObject.getString(ISWYApplySECRFConstants.SRF_ATTR_NAME);
					}

					if(appliedSR!=null && !appliedSR.trim().equalsIgnoreCase("") && appliedSR!=null && !appliedSR.trim().equalsIgnoreCase("") 
							&& !appliedSR.equals(inActiveSecRF))
					{
						DfLogger.debug(this, "Object id["+targetId+"]::: Processing Inactive logic , when SecRF which need to inactive ["+inActiveSecRF+"] and which is already applied ["+appliedSR+"] are not same", null, null);

						//sysObject.setString(ISWYApplySECRFConstants.DOC_SECRF_CONFLICTING_ATTR,ISWYApplySECRFConstants.DOC_SECRF_CONFLICT_STATUS);
						sysObject.remove(ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME,sysObject.findString(ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME, inActiveSecRF));
						//sysObject.setRepeatingString(ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME,0, applicableSecrfName);

						isSatisfiedForDefault=false;
						need_to_remove_performer=false;
						is_assign_performers =false;
						is_document_conflicted=false;
						secrf_default_role=false;
						document_mode=sysObject.getString(ISWYApplySECRFConstants.SECURITY_APPLICATION_MODE_ATTR_NAME);

						resultBeanObj.setApplicableSecRFs(sysObject.getAllRepeatingStrings(ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME, ISWYApplySECRFConstants.DEFAULT_SEPARATOR).split(ISWYApplySECRFConstants.DEFAULT_SEPARATOR));

						DfLogger.debug(this, "Object id["+targetId+"]::: Processing Inactive logic , when SecRF which need to inactive ["+inActiveSecRF+"] and which is already applied ["+appliedSR+"] are not same, Performers not removing, new performers not applying", null, null);
					}
					else
					{		
						DfLogger.debug(this, "Object id["+targetId+"]::: Processing Inactive logic , when SecRF which need to inactive ["+inActiveSecRF+"] and which is already applied ["+appliedSR+"] are same", null, null);
						inActiveSecRF=null;
						if(secrfObjectName!=null && !secrfObjectName.trim().equalsIgnoreCase(""))
						{
							inActiveSecRF=secrfObjectName;
						}
						if(!StringUtils.isNullOrEmpty(inActiveSecRF))
						{
							/***** Cancel Checkout *************/
							// Added on 26-June-2020 SUB-1271 Checkout is not getting cancelled when document get restricted: Start
							resultBeanObj.setIsReCheckinRequired(false);
							// Added on 26-June-2020 SUB-1271 Checkout is not getting cancelled when document get restricted: end

							//String appliedSR=sysObject.getString(ISWYApplySECRFConstants.SRF_ATTR_NAME);
							int counter=0;
							String[] avail_secrfs=sysObject.getAllRepeatingStrings(ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME, ";").split(";");
							sysObject.removeAll(ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME);
							//swyHelperObj.applyChangesToAllVersions(sysObject,new String[] {ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME}, new String[] {null}, session,isApplyToPreviousVersions);

							for(int i=0;i<avail_secrf_count;i++)
							{
								String tmpSecrfName=avail_secrfs[i];

								if(tmpSecrfName!=null && !tmpSecrfName.trim().equalsIgnoreCase(""))
								{
									if(!(inActiveSecRF.trim().equals(tmpSecrfName.trim())))
									{
										sysObject.setRepeatingString(ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME,counter, tmpSecrfName);
										counter++;
									}
								}
							}

							resultBeanObj.setApplicableSecRFs(sysObject.getAllRepeatingStrings(ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME, ISWYApplySECRFConstants.DEFAULT_SEPARATOR).split(ISWYApplySECRFConstants.DEFAULT_SEPARATOR));
							sysObject.setString(ISWYApplySECRFConstants.SRF_ATTR_NAME,null);
							//sysObject.setString(ISWYApplySECRFConstants.DOC_SECRF_CONFLICTING_ATTR,null);
							sysObject.setString(ISWYApplySECRFConstants.DOC_SECRF_CONFLICTING_ATTR,ISWYApplySECRFConstants.DOC_SECRF_CONFLICT_STATUS);

							//swyHelperObj.applyChangesToAllVersions(sysObject,new String[] {ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME,ISWYApplySECRFConstants.SRF_ATTR_NAME,ISWYApplySECRFConstants.DOC_SECRF_CONFLICTING_ATTR}, new String[] {StringUtil.join(Arrays.asList(avail_secrfs),"|"),null,null}, session,isApplyToPreviousVersions);

							isSatisfiedForDefault=false;
							need_to_remove_performer=true;
							is_assign_performers =false;
							secrf_default_role=false;
							is_document_conflicted=true;
							document_mode=sysObject.getString(ISWYApplySECRFConstants.SECURITY_APPLICATION_MODE_ATTR_NAME);

							DfLogger.debug(this, "Object id["+targetId+"]:::Processing Inactive logic , Available SecRF Count ["+avail_secrf_count+"] COMPLETED with update to Document Available SecRF", null, null);
						}
						else
						{
							DfLogger.debug(this, "Object id["+targetId+"]::: Processing Inactive logic , Available SecRF Count ["+avail_secrf_count+"] COMPLETED-Without any update to Document Available SecRF", null, null);
						}
					}
				}
				isSecrfListRefreshNeeded=false;
			}
			catch(Exception ex)
			{
				DfLogger.error(this,ex.getLocalizedMessage(), null, ex);
			}
		}

		try{
			if(isSecrfListRefreshNeeded)
			{
				DfLogger.info(this,"Object id["+targetId+"]::: Into Security Selection Block for document object id "+targetId,null,null);
				//DocAttr as Key, SecRF_Attr as Value.
				HashMap<String, String> secFiltersMap=(HashMap<String, String>)swyHelperObj.getSecRFFilterMap(sysObject);

				//process dictionary "CMN-DIC-Security Registration Form Filter" and return only those Doc object attributes which is multiple (comma separated ) mapped with one SecRF 
				//attribute as one single row in dictionary 
				//Map<String, ArrayList<String>> secDocFiltersMap= swyHelperObj.getMultipleDocAttrMappedWithSameSecRFAttr(sysObject);

				if (null != secFiltersMap)
				{
					HashMap<String, String[]> secRFInfoMap=(HashMap<String, String[]>)swyHelperObj.getSecRFDataDetails(ISWYApplySECRFConstants.SRF_TYPE,sysObject,secFiltersMap,find_secrf_statistics);


					//Check the size of map and then proceed
					if(secRFInfoMap!=null && secRFInfoMap.size()>0)
					{
						DfLogger.debug(this,"Object id["+targetId+"]::: SWYApplySecRF: Returning available SecRF data details in a Map based on domain and Division "+secRFInfoMap.values(),null,null);

						DfLogger.debug(this,"Object id["+targetId+"]::: SecRF Data Received",null,null);
						//Map holds Object Ids (of SecRF objects) as key and non-empty attributes data (of SecRF objects)as value in arraylist.The arraylist 
						// holds value as docAttr=Corresponding secRF attribute's value .
						HashMap<String, ArrayList<String>> secRFDataMap=swyHelperObj.getNonEmptySecRFDataInArray(secRFInfoMap,secFiltersMap,sysObject);

						DfLogger.debug(this,"Object id["+targetId+"]::: Retrieved Value of Non-Empty Attributes from resultant SecRF :::"+secRFDataMap.toString(),null,null);

						if (null != secRFDataMap &&  secRFDataMap.size()>0) 
						{
							//Map, no.of non-null attributes (from document object based on SecRF filter Map's key , which holds attribute from doc object.) as key and 
							// string arraylist as value. The arraylist holds non-null attributes and their value as docAttrName=docAttrValue. 
							Map<String, ArrayList<String>> docDataMap=swyHelperObj.getDocumentData(sysObject,secFiltersMap);

							//Getting a list of SecRF data, which contains matched registration form data
							List<Entry<String, String[]>> matchedSRFormsData= swyHelperObj.getMatchedAndMostRestrictiveSecRF(secRFDataMap,docDataMap,secRFInfoMap);

							if(matchedSRFormsData==null || matchedSRFormsData.size()==0)
							{
								isSatisfiedForDefault=true;	
								need_to_remove_performer=false;
								DfLogger.debug(this,"Object id["+targetId+"]::: No matched SecRF found :::",null,null);
							}
							else
							{

								List<Entry<String, String[]>> newMatchedSRFormsData=swyHelperObj.chkSelectedSecRFReturnsSameDocObject(matchedSRFormsData,sysObject);
								if(newMatchedSRFormsData==null || newMatchedSRFormsData.size()==0)
								{
									isSatisfiedForDefault=true;	
									need_to_remove_performer=true;
									DfLogger.debug(this,"Object id["+targetId+"]::: chkSelectedSecRFReturnsSameDocObject() returns null :::",null,null);
								}
								else
								{
									//Qualification as String to fetch security registration forms
									String srfQualification =swyHelperObj.getQualificationToFetchSRF(newMatchedSRFormsData,secFiltersMap);

									//Check if Qualification is not null then proceed
									if (null != srfQualification) 
									{
										// fetching security registration from , based on the qualification	
										String secRegFormsDQL="";
										if(find_secrf_statistics)
										{
											secRegFormsDQL="Select r_object_id, object_name from "+ISWYApplySECRFConstants.SRF_TYPE+" where " + srfQualification
													+ " and lower(a_status) in ('"+ISWYApplySECRFConstants.SRF_STATUS_ACTIVE_VALUE.toLowerCase()+"', '"+ISWYApplySECRFConstants.SRF_STATUS_INACTIVE_VALUE.toLowerCase()+"' ) ";
										}
										else
										{
											secRegFormsDQL="Select r_object_id, object_name from "+ISWYApplySECRFConstants.SRF_TYPE+" where " + srfQualification
													+ " and lower(a_status)='"+ISWYApplySECRFConstants.SRF_STATUS_ACTIVE_VALUE.toLowerCase()+"'";
										}

										DfLogger.debug(this, "::secRegFormsDQL"+secRegFormsDQL, null,null);

										// map, r_object_id as key and object_name as value of security registration forms, based on the query
										Map<String, String> srfNamesMap=QueryUtils.getQueryResultMap(secRegFormsDQL, "r_object_id","object_name",session);
										DfLogger.debug(this,"::Retrieved SecRF Names Map---"+srfNamesMap.values(), null,null);

										/**
										 * Checking if any security registration form found or not.
										 * if nothing is found , it will set "default" on object on attribute "swy_security_rest_form".
										 * If found, check the size of map. 
										 * 		if it is one, apply the registration form to object on attribute "swy_security_rest_form".
										 * 		if it is more than one, just update the name of all registration form with different repeating attribute "swy_sel_security_rest_forms". This attribute is further used to populate the name of available forms on UI.
										 */
										if(srfNamesMap.size()==0)
										{
											isSatisfiedForDefault=true;	
											DfLogger.debug(this,"Object id["+targetId+"]::: No SecRF found , based on the qualification :::",null,null);
										}
										else
										{
											Iterator<String> srfNamesKeyItr=srfNamesMap.keySet().iterator();
											while(srfNamesKeyItr.hasNext())
											{
												String dlSecRFNamesKey=srfNamesKeyItr.next();
												String secRegFormObjname=srfNamesMap.get(dlSecRFNamesKey);

												String getSecModeDQL="";
												if(find_secrf_statistics)
												{
													getSecModeDQL="select "+ISWYApplySECRFConstants.SECURITY_MODE+" from "+ISWYApplySECRFConstants.SRF_TYPE+" where r_object_id='"+dlSecRFNamesKey+"'"
															+ " and lower(a_status) in ('"+ISWYApplySECRFConstants.SRF_STATUS_ACTIVE_VALUE.toLowerCase()+"', '"+ISWYApplySECRFConstants.SRF_STATUS_INACTIVE_VALUE.toLowerCase()+"' ) ";

												}
												else
												{
													getSecModeDQL="select "+ISWYApplySECRFConstants.SECURITY_MODE+" from "+ISWYApplySECRFConstants.SRF_TYPE+" where r_object_id='"+dlSecRFNamesKey+"'"
															+ " and lower(a_status)=lower('"+ISWYApplySECRFConstants.SRF_STATUS_ACTIVE_VALUE+"')";
												}


												DfLogger.debug(this,"Object id["+targetId+"]::: DQL to check retrieved SecRF's mode :::"+getSecModeDQL,null,null);
												String[] modes=	QueryUtils.getAllQueryResultsAsStrings(getSecModeDQL, session);

												if(modes!=null && modes.length>0)
												{
													if(modes[0].trim().equalsIgnoreCase(ISWYApplySECRFConstants.AUTOMATIC))
													{
														automaticList.add(secRegFormObjname);
														DfLogger.debug(this,"Object id["+targetId+"]::: SecRF got added in automatic list ["+secRegFormObjname+"] :::",null,null);
													}
													else
													{
														manualList.add(secRegFormObjname);
														DfLogger.debug(this,"Object id["+targetId+"]::: SecRF got added in manual list ["+secRegFormObjname+"] :::",null,null);
													}
												}
												else
												{
													DfLogger.debug(this,"Object id["+targetId+"]::: No Records found, based on Security Registration Forms Mode",null,null);
												}
											}

										}

									}
									else
									{
										isSatisfiedForDefault=true;	
									}
								}
							}
						}
						else
						{
							isSatisfiedForDefault=true;
							need_to_remove_performer=false;
							DfLogger.debug(this,"Object id["+targetId+"]::: No SecRF With Non-empty data found",null,null);
						}
					}
					else
					{
						isSatisfiedForDefault=true;
						need_to_remove_performer=false;
						DfLogger.debug(this,"Object id["+targetId+"]::: No SecRF found",null,null);
					}


					// If invocation is from SecRF object	
					if(apply_to_existing_doc)
					{
						DfLogger.debug(this, "Object id["+targetId+"]::: Automatic SecRF=["+automaticList.size()+"] Manual SecRF =["+manualList.size()+"]", null, null);	
						if(automaticList.contains(secrfObjectName) || manualList.contains(secrfObjectName))
						{
							int attachedSecRFValCount=sysObject.getValueCount(ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME);
							String appliedSecRF=sysObject.getString(ISWYApplySECRFConstants.SRF_ATTR_NAME);

							//SecRF can be attached and applied  only if Selected SecRF is "Default" or  nothing is attached
							// 0 to check no Secrf applied , means no automatic and no manual, if confidentiality=rstd
							//Default to check "standard" secrf applied, means no automatic secrf applied , if confidentiality =BUO
							if(appliedSecRF.trim().equalsIgnoreCase(ISWYApplySECRFConstants.DEFAULT) || attachedSecRFValCount==0)
							{
								String tmpStrMsg="Object id["+targetId+"]::: SecRF ["+secrfObjectName+"] can attached or applied or both with sysobject having object id ["+targetObjId+"]";
								DfLogger.debug(this, tmpStrMsg, null, null);
								callOriginatedFrom="From Apply to Existing Document";
							}
							else // Attach SecRF
							{
								//String tmpSecRFValue=sysObject.getAllRepeatingStrings(ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME, ",");

								DfLogger.debug(this, "Object id["+targetId+"]::: Trying to attach SecRF ["+secrfObjectName+"] sysobject having object id ["+targetObjId+"]", null, null);
								ArrayList<String> tmpSecRFValue=new ArrayList<String>();


								/*String[] allExistingVals=DfcObjectUtils.getAllStringAttributeValues(sysObject, ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME, true);


								if(allExistingVals!=null && allExistingVals.length>0)
								{
									tmpSecRFValue=Arrays.asList(allExistingVals);
								}*/

								int existing_Secrf_count=sysObject.getValueCount(ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME);

								for(int valcountr=0;valcountr<existing_Secrf_count;valcountr++)
								{
									String tmpStr=sysObject.getRepeatingString(ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME, valcountr);

									if(tmpStr!=null && !tmpStr.trim().equalsIgnoreCase(""))
									{
										tmpSecRFValue.add(tmpStr);
									}
								}
								DfLogger.debug(this, "Object id["+targetId+"]::: sysobject with object id ["+targetObjId+"] already have existing SecRF , count ["+tmpSecRFValue.size()+"]", null, null);

								if((tmpSecRFValue!=null && tmpSecRFValue.size()>0  && !tmpSecRFValue.contains(secrfObjectName) ) 
										|| (tmpSecRFValue==null || tmpSecRFValue.size()==0)
										)
								{
									if(!tmpSecRFValue.contains(secrfObjectName))
									{
										if(!find_secrf_statistics)
										{
											// Added on 26-June-2020 SUB-1271 Checkout is not getting cancelled for other documents when context document get restricted: Start
											/*	if multiple and any secrf already applied, just add the secrf in the list, no need to do anything
											 *	if multiple and no secrf applied, implement the cancel checkout functionality
											 */
											if (appliedSecRF== null || appliedSecRF.trim().equalsIgnoreCase(""))
											{
												boolean ischkOutAborted=swyHelperObj.isCheckOutAborted(targetId,session,find_secrf_statistics);
												resultBeanObj.setDocCheckoutCancelled(ischkOutAborted);
												DfLogger.debug(this,"["+targetId+"]*****Call From Apply to Existing Document  Is Checkout Aborted ["+ischkOutAborted+"] ***********************",null,null);	
												if (ischkOutAborted)
												{
													resultBeanObj.setDocAffectedDueToSecRF(true);
													sysObject.fetch(null);
												}
											}
											// Added on 26-June-2020 SUB-1271 Checkout is not getting cancelled for other documents when context document get restricted: end


											sysObject.appendString(ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME, secrfObjectName);
											sysObject.setString(ISWYApplySECRFConstants.DOC_SECRF_CONFLICTING_ATTR, ISWYApplySECRFConstants.DOC_SECRF_CONFLICT_STATUS);

											resultBeanObj.setApplicableSecRFs(new String[]{secrfObjectName});
											swyHelperObj.updateBAsWithFormMgrs(sysObject,new String[]{secrfObjectName},session,isRequireToPreviousVersions);


											DfLogger.info(this,"****Call From Apply to Existing Document [objectId:::"+ targetId+"] *** going to check Object is in WF or not ***********************",null,null);	 

											boolean isWFAborted=swyHelperObj.isWorkflowOrQcAborted(sysObject,session,find_secrf_statistics);

											DfLogger.debug(this,"*****Call From Apply to Existing Document  Is Workflow Aborted ["+isWFAborted+"] ***********************",null,null);	
											resultBeanObj.setWorkflowAborted(isWFAborted);

											DfLogger.info(this,"******Call From Apply to Existing Document  Finally Saving *** "+targetId+" *** Object ***********************",null,null);	

											if(isWFAborted)
											{
												DfLogger.debug(this,"*****Call From Apply to Existing Document  Is Workflow Aborted ["+isWFAborted+"]  Updating WF related Attributes START***********************",null,null);	
												if(!sysObject.getTypeName().equalsIgnoreCase(ISWYApplySECRFConstants.TMF_DOC_TYPE))
													swyHelperObj.updateWFAttributesAfterAbort(sysObject);
												DfLogger.debug(this,"*****Call From Apply to Existing Document  Is Workflow Aborted ["+isWFAborted+"]  Updating WF related Attributes DONE***********************",null,null);
												resultBeanObj.setDocAffectedDueToSecRF(true);
											}
											DfcObjectUtils.fetchObjectIfRequired(sysObject);
											sysObject.save();
//											sysObject.fetch(null);

											DfLogger.info(this,"*******Call From Apply to Existing Document  Finally Saved *** "+targetId+" *** Object ***********************",null,null);

											swyHelperObj.applyingSecurity(targetId,session, true,false);
											DfLogger.info(this,"Object Id ["+sysObject.getObjectId().getId()+"]::: Applying Security from Apply to existing document DONE", null,null);

											callOriginatedFrom="From Apply to Existing Document";
											swyHelperObj.applyChangesToDocAllVersions(targetId, session,true,is_document_migr8ed);
											/*DfLogger.debug(this, "Object Id ["+targetObjId+"]::: Updating Document's versions -- From Apply to Existing Document", null, null);
											swyHelperObj.applyChangesToDocAllVersions(targetId, session,true,is_migrated_document);	// Current object id, Session, boolean to indicate security need to apply or not, boolean to indicate document is migrated or not.
											DfLogger.debug(this, "Object Id ["+targetObjId+"]::: Updating Document's versions DONE -- From Apply to Existing Document", null, null);
											 */
											/*DfLogger.info(this,"Object Id ["+sysObject.getObjectId().getId()+"]::: Applying Security from Apply to existing document", null,null);
											//Since workflow is aborted security need to be applied to all versions, So apply_security is explicitly passed true
											swyHelperObj.applyingSecurity(sysObject, true,isApplyToPreviousVersions,is_migrated_document);*/


											if(isWFAborted)
											{
												DfLogger.debug(this,"******Call From Apply to Existing Document  Is Workflow Aborted ["+isWFAborted+"]  Updating WF related Attributes through LC State***********************",null,null);
												boolean isLcCalled=swyHelperObj.callLifecycleState(targetId,session,ISWYApplySECRFConstants.WF_ABORT_LC_TRANSITIONSTATE);
												DfLogger.debug(this,"*****Call From Apply to Existing Document  Is Workflow Aborted ["+isWFAborted+"]  Updating WF related Attributes through LC State DONE with result as ["+isLcCalled+"]***********************",null,null);

												if(isLcCalled)
													//sysObject=(IDfSysObject)session.getObject(targetObjId);
													sysObject.fetch(null);
											}

											/*boolean ischkOutAborted=swyHelperObj.isCheckOutAborted(targetId,session,find_secrf_statistics);
											resultBeanObj.setDocCheckoutCancelled(ischkOutAborted);
											DfLogger.debug(this,"["+targetId+"]*****Call From Apply to Existing Document  Is Checkout Aborted ["+ischkOutAborted+"] ***********************",null,null);	
											if (ischkOutAborted)
											{
												resultBeanObj.setDocAffectedDueToSecRF(true);
												sysObject=(IDfSysObject)session.getObject(targetObjId);
											}*/

											DfLogger.info(this,"******Call From Apply to Existing Document Finally Saved *** "+targetId+" *** Object ***********************",null,null);

										}
										else
										{
											boolean isQC_WFAborted=swyHelperObj.isWorkflowOrQcAborted(sysObject,session,find_secrf_statistics);
											resultBeanObj.setWorkflowAborted(isQC_WFAborted);
											if(isQC_WFAborted)
											{
												resultBeanObj.setDocAffectedDueToSecRF(true);
											}

											boolean ischkOutAborted=swyHelperObj.isCheckOutAborted(targetId,session,find_secrf_statistics);
											resultBeanObj.setDocCheckoutCancelled(ischkOutAborted);
											DfLogger.debug(this,"["+targetId+"]*****Call From Apply to Existing Document (Stats)  Is Checkout Aborted ["+ischkOutAborted+"] ***********************",null,null);	
											if (ischkOutAborted)
											{
												resultBeanObj.setDocAffectedDueToSecRF(true);
											}
										}

										String tmpStrMsg="Object id["+targetId+"]::: SecRF ["+secrfObjectName+"] attached with sysobject having object id ["+targetObjId+"]";
										DfLogger.info(this, tmpStrMsg, null, null);

										resultBeanObj.setProcessStatus(ISWYApplySECRFConstants.SUCCESS_STATUS);
										resultBeanObj.setObjectId(targetId);
										resultBeanObj.setProcessMsg(tmpStrMsg);
										resultBeanObj.setTemplateName(new String[]{ISWYApplySECRFConstants.MAIL_OBJECT_MSGS_TEMPLATE1_KEY,ISWYApplySECRFConstants.MAIL_OBJECT_MSGS_TEMPLATE2_KEY});
										resultBeanObj.setRemarks(ISWYApplySECRFConstants.DOC_CONFLICT_REMARKS);
										resultBeanObj.setDocConflictStatus(ISWYApplySECRFConstants.DOC_SECRF_CONFLICT_STATUS);
										resultBeanObj.setDocAffectedDueToSecRF(true);

										String docExistingAuthor=sysObject.getAllRepeatingStrings("authors", ISWYApplySECRFConstants.DEFAULT_SEPARATOR);
										resultBeanObj.setDocNewAuthors(docExistingAuthor!=null && !docExistingAuthor.trim().equalsIgnoreCase("") ? docExistingAuthor.split( ISWYApplySECRFConstants.DEFAULT_SEPARATOR) : null);

										String docsApplicableSecRFMgrs=swyHelperObj.getAllApplicableFormMgrs(sysObject);
										resultBeanObj.setDocFormManagers(docsApplicableSecRFMgrs!=null && !docsApplicableSecRFMgrs.trim().equalsIgnoreCase("") ? docsApplicableSecRFMgrs.split( ISWYApplySECRFConstants.DEFAULT_SEPARATOR) : null);

										resultBeanObj.setMailObjectNeeded(true);
										return resultBeanObj;
									}
								}
								else	//Already attached
								{
									String tmpStrMsg="Object id["+targetId+"]::: SecRF ["+secrfObjectName+"] already attached with sysobject having object id ["+targetObjId+"]";
									DfLogger.info(this, tmpStrMsg, null, null);

									resultBeanObj.setProcessStatus(ISWYApplySECRFConstants.SUCCESS_STATUS);
									resultBeanObj.setObjectId(targetId);
									resultBeanObj.setProcessMsg(tmpStrMsg);

									resultBeanObj.setMailObjectNeeded(false);
									return resultBeanObj;
								}

							}
						}
						else	
						{
							String tmpStrMsg="Object id["+targetId+"]::: SecRF ["+secrfObjectName+"] not applicable for sysobject with object id ["+targetObjId+"]";
							DfLogger.info(this, tmpStrMsg, null, null);

							resultBeanObj.setProcessStatus(ISWYApplySECRFConstants.SUCCESS_STATUS);
							resultBeanObj.setObjectId(targetId);
							resultBeanObj.setProcessMsg(tmpStrMsg);

							resultBeanObj.setMailObjectNeeded(false);
							resultBeanObj.setDocAffectedDueToSecRF(false);
							return resultBeanObj;
						}
					}

					if(automaticList.size()>0 || manualList.size()>0)
					{
						if(!find_secrf_statistics)
						{
							DfLogger.debug(this, "Object id["+targetId+"]::: Is It SecRF Call to deactivate ["+isSecrfInactiveCall+"]", null, null);
							if(!isSecrfInactiveCall)
							{
								// Added on 26-June-2020 SUB-1271 Checkout is not getting cancelled when document get restricted: Start
								//callOriginatedFrom="From Creation / Updation of Object";
								boolean ischkOutAborted=swyHelperObj.isCheckOutAborted(targetId,session,find_secrf_statistics);
								resultBeanObj.setDocCheckoutCancelled(ischkOutAborted);
								DfLogger.debug(this,"["+targetId+"]*****Call "+callOriginatedFrom+"  Is Checkout Aborted ["+ischkOutAborted+"] ***********************VStamp="+ sysObject.getVStamp(),null,null);	
								if (ischkOutAborted)
								{
									DfLogger.debug(this,"********************* Is Checkout Abort done ["+ischkOutAborted+"] in if block to set its value in bean obj",null,null);	
									resultBeanObj.setDocAffectedDueToSecRF(true);
									/*sysObject=null;
									sysObject=(IDfSysObject)session.getObject(targetObjId);*/
									sysObject.fetch(null);

									DfLogger.debug(this,"********************* Is Checkout Abort done ["+ischkOutAborted+"] going out from if block after set its value in bean obj VStamp="+ sysObject.getVStamp(),null,null);	
								}

								// Added on 26-June-2020 SUB-1271 Checkout is not getting cancelled when document get restricted: end

							}
						}
						sysObject.removeAll(ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME);	
						sysObject.setString(ISWYApplySECRFConstants.SRF_ATTR_NAME,null);
						sysObject.setString(ISWYApplySECRFConstants.SECURITY_APPLICATION_MODE_ATTR_NAME,null);
						//swyHelperObj.applyChangesToAllVersions(sysObject, new String[]{ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME,ISWYApplySECRFConstants.SRF_ATTR_NAME,ISWYApplySECRFConstants.SECURITY_APPLICATION_MODE_ATTR_NAME },new String[]{null,null,null},session,isApplyToPreviousVersions);
					}

					String docConfidentionality=sysObject.getString(ISWYApplySECRFConstants.CONFIDENTIALITY_ATTR_NAME);

					//Exactly one automatic SECRF is found
					if(automaticList.size()==1 && (docConfidentionality.trim().equalsIgnoreCase(ISWYApplySECRFConstants.BUO_CONFIDENTIALITY_VALUEE) || 
							docConfidentionality.trim().equalsIgnoreCase(ISWYApplySECRFConstants.RESTRICTED_CONFIDENTIALITY_VALUE)))
					{
						String auto_secrf_name=automaticList.get(0);
						isSatisfiedForDefault=false;
						String tmpMsgStr=null;

						sysObject.setString(ISWYApplySECRFConstants.CONFIDENTIALITY_ATTR_NAME, ISWYApplySECRFConstants.RESTRICTED_CONFIDENTIALITY_VALUE);					
						sysObject.appendString(ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME, auto_secrf_name);	

						tmpMsgStr=String.format ("Object id["+targetId+"]::: An Automatic SecRF \"%s\" gets associated ",auto_secrf_name);

						sysObject.setString(ISWYApplySECRFConstants.SECURITY_APPLICATION_MODE_ATTR_NAME, ISWYApplySECRFConstants.AUTOMATIC);

						/*if(!StringUtils.isNullOrEmpty(sysObject.getAllRepeatingStrings(ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME, "|")))
							swyHelperObj.applyChangesToAllVersions(sysObject, new String[]{ISWYApplySECRFConstants.CONFIDENTIALITY_ATTR_NAME,ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME,ISWYApplySECRFConstants.SECURITY_APPLICATION_MODE_ATTR_NAME},new String[]{ISWYApplySECRFConstants.RESTRICTED_CONFIDENTIALITY_VALUE,sysObject.getAllRepeatingStrings(ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME, "|")+"|"+auto_secrf_name,ISWYApplySECRFConstants.AUTOMATIC},session,isApplyToPreviousVersions);
						else
							swyHelperObj.applyChangesToAllVersions(sysObject, new String[]{ISWYApplySECRFConstants.CONFIDENTIALITY_ATTR_NAME,ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME,ISWYApplySECRFConstants.SECURITY_APPLICATION_MODE_ATTR_NAME},new String[]{ISWYApplySECRFConstants.RESTRICTED_CONFIDENTIALITY_VALUE,auto_secrf_name,ISWYApplySECRFConstants.AUTOMATIC},session,isApplyToPreviousVersions);
						 */
						need_to_remove_performer=true;
						if(!find_secrf_statistics)
						{
							secrfObjectName=auto_secrf_name;
						}

						if(!ignoreDocCreatorChk)
						{
							String mig_obj_id=sysObject.getString(ISWYApplySECRFConstants.DOC_MIG_OBJ_ID_ATTR);

							if(mig_obj_id!=null &&  !mig_obj_id.trim().equalsIgnoreCase("") )
							{
								ignoreDocCreatorChk=true;
							}
						}

						if(ignoreDocCreatorChk)
						{
							sysObject.setString(ISWYApplySECRFConstants.SRF_ATTR_NAME,auto_secrf_name);
							//swyHelperObj.applyChangesToAllVersions(sysObject, new String[]{ISWYApplySECRFConstants.SRF_ATTR_NAME},new String[]{auto_secrf_name},session,isApplyToPreviousVersions);
							tmpMsgStr=String.format (tmpMsgStr + " And applied ,-ignore_doc_creator_check is true");
						}
						else
						{
							boolean isAuthorExist=swyHelperObj.checkAuthorExistInSelectedSecRF(auto_secrf_name,r_creator_name,session);
							if(isAuthorExist)
							{
								sysObject.setString(ISWYApplySECRFConstants.SRF_ATTR_NAME,auto_secrf_name);
								//swyHelperObj.applyChangesToAllVersions(sysObject, new String[]{ISWYApplySECRFConstants.SRF_ATTR_NAME},new String[]{auto_secrf_name},session,isApplyToPreviousVersions);
								tmpMsgStr=String.format (tmpMsgStr + " And applied");
							}
							else
							{
								sysObject.setString(ISWYApplySECRFConstants.DOC_SECRF_CONFLICTING_ATTR, ISWYApplySECRFConstants.DOC_SECRF_CONFLICT_STATUS);
								//swyHelperObj.applyChangesToAllVersions(sysObject, new String[]{ISWYApplySECRFConstants.DOC_SECRF_CONFLICTING_ATTR},new String[]{ISWYApplySECRFConstants.DOC_SECRF_CONFLICT_STATUS},session,isApplyToPreviousVersions);
								resultBeanObj.setApplicableSecRFs(new String []{auto_secrf_name});
								is_document_conflicted=true;
							}
						}

						tmpMsgStr=String.format (tmpMsgStr +" with object id %s and removed pre-selected performers",targetId);
						DfLogger.debug(this,tmpMsgStr,null,null);
						document_mode=ISWYApplySECRFConstants.AUTOMATIC;
					}
					//Multiple automatic SECRFs are found
					else if(automaticList.size()>1 && (docConfidentionality.trim().equalsIgnoreCase(ISWYApplySECRFConstants.BUO_CONFIDENTIALITY_VALUEE) || 
							docConfidentionality.trim().equalsIgnoreCase(ISWYApplySECRFConstants.RESTRICTED_CONFIDENTIALITY_VALUE)))

					{
						isSatisfiedForDefault=false;
						String tmpMsgStr=null;
						sysObject.setString(ISWYApplySECRFConstants.CONFIDENTIALITY_ATTR_NAME, ISWYApplySECRFConstants.RESTRICTED_CONFIDENTIALITY_VALUE);
						//swyHelperObj.applyChangesToAllVersions(sysObject, new String[]{ISWYApplySECRFConstants.CONFIDENTIALITY_ATTR_NAME},new String[]{ISWYApplySECRFConstants.RESTRICTED_CONFIDENTIALITY_VALUE},session,isApplyToPreviousVersions);

						tmpMsgStr=String.format ("Object id["+targetId+"]::: Multiple Automatic SecRF " );
						//String autoSecrfWithPipe = "";
						for(int i=0;i<automaticList.size();i++)
						{

							String auto_secrf_name=automaticList.get(i);
							/*if(i==0)
								autoSecrfWithPipe = autoSecrfWithPipe+auto_secrf_name;
							else 
								autoSecrfWithPipe = autoSecrfWithPipe+"|"+auto_secrf_name;*/
							sysObject.appendString(ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME, auto_secrf_name);


							if(i==0)
							{
								tmpMsgStr=String.format (tmpMsgStr +" \"%s\" ",auto_secrf_name);
							}
							else
							{
								tmpMsgStr=String.format (tmpMsgStr +", \"%s\" ",auto_secrf_name);
							}

						}
						/* if(!StringUtils.isNullOrEmpty(sysObject.getAllRepeatingStrings(ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME, "|")))
						swyHelperObj.applyChangesToAllVersions(sysObject, new String[]{ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME},new String[]{sysObject.getAllRepeatingStrings(ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME, "|")+"|"+autoSecrfWithPipe},session,isApplyToPreviousVersions);
						 else
							 swyHelperObj.applyChangesToAllVersions(sysObject, new String[]{ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME},new String[]{autoSecrfWithPipe},session,isApplyToPreviousVersions);

						 */						
						tmpMsgStr=String.format (tmpMsgStr +" gets associated ");

	/*SUB 3077 @ March 18th, 2022 */
						ArrayList<String> secrfOnCrDocList=swyHelperObj.secRFOnCrossoverDocuments(sysObject,automaticList);
						if(secrfOnCrDocList!=null && secrfOnCrDocList.size()==2 && secrfOnCrDocList.get(0).equalsIgnoreCase("true"))
						{
							String resolvedSecRFName=secrfOnCrDocList.get(1);
							sysObject.setString(ISWYApplySECRFConstants.SRF_ATTR_NAME,resolvedSecRFName);					
							DfLogger.info(this,"Conflict resolve with SecRF ["+resolvedSecRFName+"]",null,null);
						}
						else
						{
							is_document_conflicted=true;
							DfLogger.info(this,"Conflict not resolve",null,null);
						}
	/*SUB 3077 @ March 18th, 2022 */
						sysObject.setString(ISWYApplySECRFConstants.SECURITY_APPLICATION_MODE_ATTR_NAME, ISWYApplySECRFConstants.AUTOMATIC);
						need_to_remove_performer=true;

						tmpMsgStr=String.format (tmpMsgStr +" with object id %s and removed pre-selected performers",targetId);
						DfLogger.debug(this,tmpMsgStr,null,null);
						sysObject.setString(ISWYApplySECRFConstants.DOC_SECRF_CONFLICTING_ATTR, ISWYApplySECRFConstants.DOC_SECRF_CONFLICT_STATUS);
						//swyHelperObj.applyChangesToAllVersions(sysObject, new String[]{ISWYApplySECRFConstants.DOC_SECRF_CONFLICTING_ATTR},new String[]{ISWYApplySECRFConstants.DOC_SECRF_CONFLICT_STATUS},session,isApplyToPreviousVersions);
						resultBeanObj.setApplicableSecRFs(automaticList.toArray(new String[automaticList.size()]));
					
						document_mode=ISWYApplySECRFConstants.AUTOMATIC;
					}
					// If no automatic SECRF is found (manual SECRFs are not considered) and if confidentiality is Business Use Only
					else if (automaticList.size()==0  && docConfidentionality.trim().equalsIgnoreCase(ISWYApplySECRFConstants.BUO_CONFIDENTIALITY_VALUEE))
					{
						isSatisfiedForDefault=true;
						need_to_remove_performer=false;

						String tmpMsgStr=String.format ("Object id["+targetId+"]::: No Automatic SecRF found and manual SecRF not considered since confidentiality is \"BUO\" for object id %s "
								+ "and applying \"Standard\" SecRF with pre-selected performers",targetId);
						DfLogger.debug(this,tmpMsgStr,null,null);

						if(!find_secrf_statistics)
						{
							DfLogger.debug(this, "Object id["+targetId+"]::: Is It SecRF Call to deactivate ["+isSecrfInactiveCall+"]", null, null);
							if(!isSecrfInactiveCall)
							{
								// Added on 26-June-2020 SUB-1271 Checkout is not getting cancelled when document get restricted: Start
								callOriginatedFrom="From Creation / Updation of Object";
								boolean ischkOutAborted=swyHelperObj.isCheckOutAborted(targetId,session,find_secrf_statistics);
								resultBeanObj.setDocCheckoutCancelled(ischkOutAborted);
								DfLogger.debug(this,"["+targetId+"]*****Call "+callOriginatedFrom+"  Is Checkout Aborted ["+ischkOutAborted+"] ***********************VStamp="+ sysObject.getVStamp(),null,null);	
								if (ischkOutAborted)
								{
									DfLogger.debug(this,"********************* Is Checkout Abort done ["+ischkOutAborted+"] in if block to set its value in bean obj",null,null);	
									resultBeanObj.setDocAffectedDueToSecRF(true);
									/*sysObject=null;
									sysObject=(IDfSysObject)session.getObject(targetObjId);*/
									sysObject.fetch(null);

									DfLogger.debug(this,"********************* Is Checkout Abort done ["+ischkOutAborted+"] going out from if block after set its value in bean obj VStamp="+ sysObject.getVStamp(),null,null);	
								}
							}
						}

						// Added on 26-June-2020 SUB-1271 Checkout is not getting cancelled when document get restricted: end

					}
					// If no automatic SECRF is found (manual SECRFs are considered) and if confidentiality is Restricted
					else if (automaticList.size()==0  && docConfidentionality.trim().equalsIgnoreCase(ISWYApplySECRFConstants.RESTRICTED_CONFIDENTIALITY_VALUE))
					{
						DfLogger.debug(this, "Object id["+targetId+"]::: Date March 30, 2017 :: Version 1.3 :: Updated the code to check both auotmatic and manual SecRF not found,  ", null, null);
						if(manualList.size()>0)
						{
							isSatisfiedForDefault=false;
							String tmpMsgStr=null;

							tmpMsgStr=String.format ("Object id["+targetId+"]::: Manual SecRF/s " );
							for(int i=0;i<manualList.size();i++)
							{
								String manual_secrf_name=manualList.get(i);

								sysObject.appendString(ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME, manualList.get(i));

								if(i==0)
								{
									tmpMsgStr=String.format (tmpMsgStr +" \"%s\" ",manual_secrf_name);
								}
								else
								{
									tmpMsgStr=String.format (tmpMsgStr +", \"%s\" ",manual_secrf_name);
								}
							}

							tmpMsgStr=String.format (tmpMsgStr +" gets associated ");

							sysObject.setString(ISWYApplySECRFConstants.SECURITY_APPLICATION_MODE_ATTR_NAME, ISWYApplySECRFConstants.MANUAL);
							//swyHelperObj.applyChangesToAllVersions(sysObject, new String []{ISWYApplySECRFConstants.SECURITY_APPLICATION_MODE_ATTR_NAME}, new String[]{ISWYApplySECRFConstants.MANUAL}, session,isApplyToPreviousVersions);
							need_to_remove_performer=true;
							document_mode=ISWYApplySECRFConstants.MANUAL;
							resultBeanObj.setApplicableSecRFs(manualList.toArray(new String[manualList.size()]));
							sysObject.setString(ISWYApplySECRFConstants.DOC_SECRF_CONFLICTING_ATTR, ISWYApplySECRFConstants.DOC_SECRF_CONFLICT_STATUS);
							//swyHelperObj.applyChangesToAllVersions(sysObject, new String []{ISWYApplySECRFConstants.DOC_SECRF_CONFLICTING_ATTR}, new String[]{ISWYApplySECRFConstants.DOC_SECRF_CONFLICT_STATUS}, session,isApplyToPreviousVersions);
							is_document_conflicted=true;

							tmpMsgStr=String.format (tmpMsgStr +" with object id %s and removed pre-selected performers",targetId);
							DfLogger.debug(this,tmpMsgStr,null,null);
						}
						else
						{
							DfLogger.debug(this, "Object id["+targetId+"]::: Date April 18, 2017 :: Version 2.0 :: Updated the code if both auotmatic and manual SecRF not found,  ", null, null);
							isSatisfiedForDefault=false;
							sysObject.removeAll(ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME);
							sysObject.setString(ISWYApplySECRFConstants.SRF_ATTR_NAME,null);
							sysObject.setString(ISWYApplySECRFConstants.SECURITY_APPLICATION_MODE_ATTR_NAME,null);
							//swyHelperObj.applyChangesToAllVersions(sysObject, new String[]{ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME,ISWYApplySECRFConstants.SRF_ATTR_NAME,ISWYApplySECRFConstants.SECURITY_APPLICATION_MODE_ATTR_NAME},new String[]{null,null,null},session,isApplyToPreviousVersions);
							need_to_remove_performer=true;
							document_mode=ISWYApplySECRFConstants.MANUAL;
							String tmpMsgStr=String.format ("Object id["+targetId+"]::: No Automatic / Manual SecRF found. Manual SecRF also considered since confidentiality is \"RSTD\" for object id %s "
									+ ". SecRF is empty and removed pre-selected performers",targetId);
							DfLogger.debug(this,tmpMsgStr,null,null);
						}
					}
				}
				else 
				{
					DfLogger.debug(this,"Object id["+targetId+"]::: No Values defined for filtering the attributes in dictionary \""+ISWYApplySECRFConstants.SRF_FILTER_ATTR_DICTIOANRY_NAME+"\" ",null,null);
				}
			}

			DfLogger.debug(this,"Object id["+targetId+"]::: Performers Need to Remove ["+need_to_remove_performer+"]",null,null);
			if(need_to_remove_performer)
			{
				if(apply_to_existing_doc || (isSecrfListRefreshNeeded && !apply_to_existing_doc) )	// apply to existing document || new or update
				{
					String docExistingAuthor=swyHelperObj.getAllExistingAuthors(sysObject);
					resultBeanObj.setDocPreviousAuthors(docExistingAuthor!=null && !docExistingAuthor.trim().equalsIgnoreCase("") ? docExistingAuthor.split( ISWYApplySECRFConstants.DEFAULT_SEPARATOR) : null);
				}
				if(rolesArr!=null && rolesArr.length>0)
				{
					for(int i=0;i<rolesArr.length;i++)
					{
						sysObject.removeAll(rolesArr[i]);
						//swyHelperObj.applyChangesToAllVersions(sysObject, new String [] {rolesArr[i]}, new String[]{null}, session,isApplyToPreviousVersions);
					}
				}

				if(!ignoreDocCreatorChk)
					sysObject.setRepeatingString(ISWYApplySECRFConstants.AUTHORS_NAME_ATTR, 0, r_creator_name);
				//swyHelperObj.applyChangesToAllVersions(sysObject, new String [] {ISWYApplySECRFConstants.AUTHORS_NAME_ATTR}, new String[]{r_creator_name}, session,isApplyToPreviousVersions);
			}

			DfLogger.debug(this,"Object id["+targetId+"]::: is_document_conflicted ["+is_document_conflicted+"]",null,null);
			if(is_document_conflicted)	// Multiple Automatic, Manual, Authors are not defined in SecRF
			{
				DfLogger.debug(this,"Object id["+targetId+"]::: is_document_conflicted ["+is_document_conflicted+"] block start",null,null);
				if(document_mode!=null && (document_mode.trim().equalsIgnoreCase(ISWYApplySECRFConstants.MANUAL)|| 
						document_mode.trim().equalsIgnoreCase(ISWYApplySECRFConstants.AUTOMATIC)))
				{
					sysObject.setString(ISWYApplySECRFConstants.DOC_SECRF_CONFLICTING_ATTR,ISWYApplySECRFConstants.DOC_SECRF_CONFLICT_STATUS);	
					swyHelperObj.updateBAsWithFormMgrs(sysObject,resultBeanObj.getApplicableSecRFs(),session,isRequireToPreviousVersions);


					if (document_mode.trim().equalsIgnoreCase(ISWYApplySECRFConstants.AUTOMATIC))
					{
						sysObject.removeAll(ISWYApplySECRFConstants.AUTHORS_NAME_ATTR);
						//swyHelperObj.applyChangesToAllVersions(sysObject,new String[]{ ISWYApplySECRFConstants.AUTHORS_NAME_ATTR}, new String[]{null}, session, isApplyToPreviousVersions);
					}

					DfLogger.debug(this,"Object id["+targetId+"]::: is_document_conflicted ["+is_document_conflicted+"] block done",null,null);
				}
			}

			DfLogger.debug(this,"Object id["+targetId+"]::: is secrf call to make it inactive and change needed ["+isSecrfInactive_ChangeNeeded+"] ",null,null);
			if(isSecrfInactive_ChangeNeeded || (apply_to_existing_doc && (automaticList.contains(secrfObjectName) || manualList.contains(secrfObjectName))))
			{
				DfLogger.debug(this,"Object id["+targetId+"]::: Processing SecRF Inactive Specific changes for \"Default Values \"",null,null);
				secrf_default_value = argParser.getStringArgument(ARG_DEFAULT_SECRF_VALUES, null);
				secrf_default_value_dql = argParser.getStringArgument(ARG_DEFAULT_SECRF_VALUES_DQL, null);

				if(secrf_default_value_dql!=null && !secrf_default_value_dql.equalsIgnoreCase(""))
				{
					DfLogger.debug(this,"Object id["+targetId+"]::: Processing SecRF Default Value through DQL ["+secrf_default_value_dql+"]",null,null);
					Map<String,String[]> defaultValMap= QueryUtils.getAllQueryResultColumnValues(secrf_default_value_dql, false, session);

					Iterator<String> keyIterator=defaultValMap.keySet().iterator();

					while(keyIterator.hasNext())
					{
						String key=keyIterator.next();
						String[] valArr=defaultValMap.get(key);

						if(valArr!=null && valArr.length>0)
						{
							String value=valArr[0];

							if(sysObject.hasAttr(key))
							{
								if(sysObject.isAttrRepeating(key))
								{
									sysObject.removeAll(key);
									sysObject.setRepeatingString(key, 0, value);
									//swyHelperObj.applyChangesToAllVersions(sysObject, new String[]{key},  new String[]{value}, session, isApplyToPreviousVersions);
									DfLogger.debug(this, "Object id["+targetId+"]::: SecRF Inactive and Change Needed::: value ["+value+"] updated for Repeating key["+key+"] from DQL["+secrf_default_value_dql+"]", null, null);
								}
								else
								{
									sysObject.setString(key,value);
									//swyHelperObj.applyChangesToAllVersions(sysObject, new String[]{key},  new String[]{value}, session, isApplyToPreviousVersions);
									DfLogger.debug(this, "Object id["+targetId+"]::: SecRF Inactive and Change Needed::: value ["+value+"] updated for key["+key+"] from DQL["+secrf_default_value_dql+"]", null, null);
								}
							}
						}
						else
						{
							DfLogger.debug(this, "Object id["+targetId+"]::: SecRF Inactive and Change Needed::: value doesn't exist for key["+key+"] from DQL["+secrf_default_value_dql+"]", null, null);
						}
					}
				}

				//attr1-defaultvalue11~defaultvalue12,attr2-defaultvalue21~defaultvalue22
				if(secrf_default_value!=null && !secrf_default_value.equalsIgnoreCase(""))
				{
					DfLogger.debug(this,"Object id["+targetId+"]::: Processing SecRF Default Value",null,null);
					String[] attr_val_arr=secrf_default_value.split(",");
					if(attr_val_arr!=null && attr_val_arr.length>0)
					{
						DfLogger.debug(this,"Object id["+targetId+"]::: Processing SecRF Default Value for each configured attribute in argument",null,null);
						for(int i=0;i<attr_val_arr.length;i++)
						{
							String attr_val_str=attr_val_arr[i];
							if(attr_val_str!=null && !attr_val_str.equalsIgnoreCase(""))
							{
								String[] attrVal=attr_val_str.split("-");
								String key=null;
								String value=null;
								if(attrVal!=null && attrVal.length>0)
								{
									if(attrVal[0]!=null)
										key=attrVal[0];
									if(attrVal[1]!=null)
										value=attrVal[1];

									if(value!=null && (value.trim().equalsIgnoreCase("null")|| value.trim().equalsIgnoreCase("nulldate")))
										value=null;
								}

								if(key!=null)
								{
									if(sysObject.hasAttr(key))
									{
										int attrDataType=sysObject.getAttrDataType(key);
										if (attrDataType == 4) // Time
										{
											if(sysObject.isAttrRepeating(key))
											{
												if(value!=null)
												{
													String repeatValArr[]=value.split(ISWYApplySECRFConstants.DEFAULT_SEPARATOR);
													sysObject.removeAll(key);
													for(int j=0;j<repeatValArr.length;j++)
													{
														value = "date('" + repeatValArr[j] + " utc','"
																+ ISWYApplySECRFConstants.DCTM_DATE_ATTR_FORMAT + "')";
														DfLogger.debug(this, "Object id["+targetId+"]::: SecRF Inactive and Change Needed::: value ["+value+"] at index["+j+"] updated for key["+key+"] ", null, null);
													}
													//swyHelperObj.applyChangesToAllVersions(sysObject, new String[]{key}, new String[]{StringUtil.join(Arrays.asList(repeatValArr), "|")}, session, isApplyToPreviousVersions);
												}
												else
												{
													sysObject.removeAll(key);
													//swyHelperObj.applyChangesToAllVersions(sysObject, new String[]{key}, new String[]{null}, session, isApplyToPreviousVersions);
												}
											}
											else
											{
												sysObject.setTime(key,null);
												//swyHelperObj.applyChangesToAllVersions(sysObject, new String[]{key}, new String[]{value}, session, isApplyToPreviousVersions);
												DfLogger.debug(this, "Object id["+targetId+"]::: SecRF Inactive and Change Needed::: value ["+value+"] updated for key["+key+"] ", null, null);

											}
										}
										else
										{
											if(sysObject.isAttrRepeating(key))
											{
												if(value!=null)
												{
													String repeatValArr[]=value.split(ISWYApplySECRFConstants.DEFAULT_SEPARATOR);
													sysObject.removeAll(key);
													for(int j=0;j<repeatValArr.length;j++)
													{
														sysObject.setRepeatingString(key, j, repeatValArr[j]);
														DfLogger.debug(this, "Object id["+targetId+"]::: SecRF Inactive and Change Needed::: value ["+value+"] at index["+j+"] updated for key["+key+"] ", null, null);
													}
													//swyHelperObj.applyChangesToAllVersions(sysObject, new String[]{key}, new String[]{StringUtil.join(Arrays.asList(repeatValArr), "|")}, session, isApplyToPreviousVersions);
												}
												else
												{
													sysObject.removeAll(key);
													//swyHelperObj.applyChangesToAllVersions(sysObject, new String[]{key}, new String[]{null}, session, isApplyToPreviousVersions);
												}
											}
											else
											{
												sysObject.setString(key,value);
												//swyHelperObj.applyChangesToAllVersions(sysObject, new String[]{key}, new String[]{value}, session, isApplyToPreviousVersions);
												DfLogger.debug(this, "Object id["+targetId+"]::: SecRF Inactive and Change Needed::: value ["+value+"] updated for key["+key+"] ", null, null);

											}
										}
									}
								}
							}
						}
					}
					else
					{
						DfLogger.debug(this,"Object id["+targetId+"]::: Processing SecRF Default Value, no default value found",null,null);
					}
				}
				DfLogger.debug(this,"Object id["+targetId+"]::: Processing to make SecRF Inactive done",null,null);
			}

			//'Default' as swy_security_rest_form , 'Default' as swy_secrf_application_mode, 'Default' as swy_sel_security_rest_forms
			DfLogger.debug(this,"Object id["+targetId+"]::: is satisfied to apply standard ["+isSatisfiedForDefault+"]",null,null);
			if(isSatisfiedForDefault)	// If no security registration found
			{
				sysObject.setString(ISWYApplySECRFConstants.SECURITY_APPLICATION_MODE_ATTR_NAME, ISWYApplySECRFConstants.DEFAULT);
				sysObject.setString(ISWYApplySECRFConstants.SRF_ATTR_NAME, ISWYApplySECRFConstants.DEFAULT);
				sysObject.removeAll(ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME);	
				sysObject.appendString(ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME, ISWYApplySECRFConstants.DEFAULT);	

				//swyHelperObj.applyChangesToAllVersions(sysObject, new String[]{ISWYApplySECRFConstants.SECURITY_APPLICATION_MODE_ATTR_NAME,ISWYApplySECRFConstants.SRF_ATTR_NAME,ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME}, new String[]{ ISWYApplySECRFConstants.DEFAULT,ISWYApplySECRFConstants.DEFAULT,ISWYApplySECRFConstants.DEFAULT}, session, isApplyToPreviousVersions);

				if(sysObject.getTypeName().equalsIgnoreCase(ISWYApplySECRFConstants.TMF_DOC_TYPE))
				{
					// Remove the suffix from TMF Specific users
					if(is_tmf_rename_enabled)
					{
						if(tmf_suffix_for_rename!=null  && !tmf_suffix_for_rename.trim().equalsIgnoreCase("") && 
								tmf_attr_to_be_renamed!=null && !tmf_attr_to_be_renamed.trim().equalsIgnoreCase(""))
						{
							String[] attrArr= tmf_attr_to_be_renamed.split(ISWYApplySECRFConstants.COMMA_SEPARATOR);
							swyHelperObj.rollbackTMFPerformersChange(sysObject,attrArr,tmf_suffix_for_rename);

							swyHelperObj.chkAppliedQcUsersIsPartOfQcgroup(sysObject,session);
						}
					}

				}
				DfLogger.debug(this,"Object id["+targetId+"]::: is satisfied to apply standard ["+isSatisfiedForDefault+"] done",null,null);
			}
			else
			{
				if(sysObject.getTypeName().equalsIgnoreCase(ISWYApplySECRFConstants.TMF_DOC_TYPE))
				{
					// Add the suffix with TMF Specific users
					if(is_tmf_rename_enabled)
					{
						if(tmf_suffix_for_rename!=null  && !tmf_suffix_for_rename.trim().equalsIgnoreCase("") && 
								tmf_attr_to_be_renamed!=null && !tmf_attr_to_be_renamed.trim().equalsIgnoreCase(""))
						{
							String[] attrArr= tmf_attr_to_be_renamed.split(ISWYApplySECRFConstants.COMMA_SEPARATOR);
							swyHelperObj.applyTMFPerformersChange(sysObject,attrArr,tmf_suffix_for_rename);
						}
					}
				}
			}


			DfLogger.debug(this,"Object id["+targetId+"]::: Need to find SecRF Statistics ["+find_secrf_statistics+"] or save object",null,null);
			if(!find_secrf_statistics)
			{
				DfLogger.debug(this, "Object id["+targetId+"]::: Is It SecRF Call to deactivate ["+isSecrfInactiveCall+"]", null, null);
				if(!isSecrfInactiveCall)
				{
					/*// Added on 26-June-2020 SUB-1271 Checkout is not getting cancelled when document get restricted: Start
					callOriginatedFrom="From Creation / Updation of Object";
					boolean ischkOutAborted=swyHelperObj.isCheckOutAborted(targetId,session,find_secrf_statistics);
					resultBeanObj.setDocCheckoutCancelled(ischkOutAborted);
					DfLogger.debug(this,"["+targetId+"]*****Call "+callOriginatedFrom+"  Is Checkout Aborted ["+ischkOutAborted+"] ***********************VStamp="+ sysObject.getVStamp(),null,null);	
					if (ischkOutAborted)
					{
						DfLogger.debug(this,"********************* Is Checkout Abort done ["+ischkOutAborted+"] in if block to set its value in bean obj",null,null);	
						resultBeanObj.setDocAffectedDueToSecRF(true);
						sysObject=null;
						sysObject=(IDfSysObject)session.getObject(targetObjId);
						sysObject.fetch(null);

						DfLogger.debug(this,"********************* Is Checkout Abort done ["+ischkOutAborted+"] going out from if block after set its value in bean obj VStamp="+ sysObject.getVStamp(),null,null);	
					}

					// Added on 26-June-2020 SUB-1271 Checkout is not getting cancelled when document get restricted: end

					 */
					DfLogger.info(this,"********************* [objectId:::"+ targetId+"] *** going to check Object is in WF or not ***********************",null,null);	 

					boolean isWFAborted=swyHelperObj.isWorkflowOrQcAborted(sysObject,session,find_secrf_statistics);

					DfLogger.debug(this,"********************* Is Workflow Aborted ["+isWFAborted+"] ***********************",null,null);	
					resultBeanObj.setWorkflowAborted(isWFAborted);

					DfLogger.info(this,"********************* Finally Saving *** "+targetId+" *** Object ***********************",null,null);	

					if(isWFAborted)
					{
						DfLogger.debug(this,"********************* Is Workflow Aborted ["+isWFAborted+"]  Updating WF related Attributes START***********************",null,null);	
						if(!sysObject.getTypeName().equalsIgnoreCase(ISWYApplySECRFConstants.TMF_DOC_TYPE))
							swyHelperObj.updateWFAttributesAfterAbort(sysObject);
						DfLogger.debug(this,"********************* Is Workflow Aborted ["+isWFAborted+"]  Updating WF related Attributes DONE***********************",null,null);
						resultBeanObj.setDocAffectedDueToSecRF(true);
					}
					DfLogger.debug(this,"*********************Obj VStamp="+ sysObject.getVStamp(),null,null);	
					DfcObjectUtils.fetchObjectIfRequired(sysObject);
					sysObject.save();
					DfLogger.info(this,"Object Id ["+sysObject.getObjectId().getId()+"]::: Applying Security ", null,null);

					// Passing explicitly true for apply security since Workflow is aborted, isApplyToPrevious Version is passed false as previous version cannot be in workflow
					swyHelperObj.applyingSecurity(targetId,session, true,is_document_migr8ed);

					//callOriginatedFrom="From Creation / Updation of Object";
					/*DfLogger.debug(this, "Object Id ["+targetObjId+"]::: Updating Document's versions -- Creation of Object ", null, null);
					swyHelperObj.applyChangesToDocAllVersions(targetId, session,true,is_migrated_document);
					DfLogger.debug(this, "Object Id ["+targetObjId+"]::: Updating Document's versions -- Creation of Object DONE ", null, null);
					 */
					//sysObject=(IDfSysObject)session.getObject(targetObjId);
//					sysObject.fetch(null);

					DfLogger.info(this,"********************* Finally Saved *** "+targetId+" *** Creation of Object ***********************",null,null);


					//swyHelperObj.applyingSecurity(sysObject, true,isApplyToPreviousVersions);


					DfLogger.info(this,"Object Id ["+sysObject.getObjectId().getId()+"]::: Applying Security DONE", null,null);

					if(isWFAborted)
					{
						DfLogger.debug(this,"********************* Is Workflow Aborted ["+isWFAborted+"]  Updating WF related Attributes through LC State***********************",null,null);
						boolean isLcCalled=swyHelperObj.callLifecycleState(targetId,session,ISWYApplySECRFConstants.WF_ABORT_LC_TRANSITIONSTATE);
						DfLogger.debug(this,"********************* Is Workflow Aborted ["+isWFAborted+"]  Updating WF related Attributes through LC State DONE with result as ["+isLcCalled+"]***********************",null,null);

						if(isLcCalled)
							//sysObject=(IDfSysObject)session.getObject(targetObjId);
							sysObject.fetch(null);
					}

					/*boolean ischkOutAborted=swyHelperObj.isCheckOutAborted(targetId,session,find_secrf_statistics);
					resultBeanObj.setDocCheckoutCancelled(ischkOutAborted);
					DfLogger.debug(this,"["+targetId+"]*****Call "+callOriginatedFrom+"  Is Checkout Aborted ["+ischkOutAborted+"] ***********************",null,null);	
					if (ischkOutAborted)
					{
						resultBeanObj.setDocAffectedDueToSecRF(true);
						sysObject=(IDfSysObject)session.getObject(targetObjId);
					}*/

					DfLogger.info(this,"********************* Finally Saved *** "+targetId+" *** Object ***********************",null,null);
				}
				else
				{
					DfLogger.info(this,"************** SECRF INACTIVE CALL ******* Finally Saving *** "+targetId+" *** Object ***********************",null,null);
					DfcObjectUtils.fetchObjectIfRequired(sysObject);
					sysObject.save();

					/*
					DfLogger.info(this,"Object Id ["+sysObject.getObjectId().getId()+"]::: Applying Security DONE", null,null);
					 */
					DfLogger.info(this,"Object Id ["+sysObject.getObjectId().getId()+"]::: Applying Security For Inbactive call", null,null);
					// Passing explicitly true for apply_security since secrf was deactivated and security need to be applied 
					swyHelperObj.applyingSecurity(targetId,session, true,is_document_migr8ed);

					callOriginatedFrom="From SECRF INACTIVE CALL";
					/*DfLogger.debug(this, "Object Id ["+targetObjId+"]::: Updating Document's versions -- From SECRF INACTIVE CALL", null, null);
					swyHelperObj.applyChangesToDocAllVersions(targetId, session,true,is_migrated_document);
					DfLogger.debug(this, "Object Id ["+targetObjId+"]::: Updating Document's versions DONE -- From SECRF INACTIVE CALL", null, null);*/

					//sysObject=(IDfSysObject)session.getObject(targetObjId);
//					sysObject.fetch(null);

					DfLogger.info(this,"************** SECRF INACTIVE CALL ******* Finally Saved *** "+targetId+" *** Object ***********************",null,null);
				}
			}
			else
			{
				DfLogger.info(this,"********************* [objectId:::"+ targetId+"] *** going to check Object is in WF or not for SecRF statistics ***********************",null,null);	 

				boolean isWFAborted=swyHelperObj.isWorkflowOrQcAborted(sysObject,session,find_secrf_statistics);

				DfLogger.debug(this,"*********** [objectId:::"+ targetId+"] ************* Is Workflow Aborted ["+isWFAborted+"] ***********************",null,null);	
				resultBeanObj.setWorkflowAborted(isWFAborted);
				if(isWFAborted)
					resultBeanObj.setDocAffectedDueToSecRF(true);

				boolean ischkOutAborted=swyHelperObj.isCheckOutAborted(targetId,session,find_secrf_statistics);
				resultBeanObj.setDocCheckoutCancelled(ischkOutAborted);
				DfLogger.debug(this,"********************* [objectId:::"+ targetId+"] *** going to check Object is Checkedout or not ["+ischkOutAborted+"] for SecRF statistics ***********************",null,null);	 
				if (ischkOutAborted)
				{
					resultBeanObj.setDocAffectedDueToSecRF(true);
				}

				DfLogger.info(this,"********************* [objectId:::"+ targetId+"] *** going to check Object is in WF or not for SecRF statistics  DONE***********************",null,null);

			}

			boolean isImmutabilityDisable=false;
			Vector<String> objIdsVector=null;

			//Assigning performers
			boolean is_performers_scenario_exist=false;
			if(is_assign_performers && need_to_remove_performer)
			{
				DfLogger.debug(this,"Object id["+targetId+"]::: Existing Performers Removed, applying new performers",null,null);
				ArgumentParser argumentParser=null;
				HashMap<String, String> parserMap=null;
				Iterator<Entry<String,String>> argParserIterator= argParser.iterator();

				while(argParserIterator.hasNext())
				{
					Entry<String,String> tmpEntry=argParserIterator.next();
					String tmpNotiKey=tmpEntry.getKey().toLowerCase().trim();
					if(tmpNotiKey.startsWith(ARG_PERFORMERS_NOTIFICATION_SCENARIO))
					{
						DfLogger.debug(this,"Object id["+targetId+"]:::  ~~~~~~~~ Performers Mapping Scenario Processing for object id ["+targetId+"]~~~~~~~~ ",null,null);
						String tmpNotiVal= tmpEntry.getValue();
						parserMap=swyHelperObj.getMapFromArguments(tmpNotiVal);

						parserMap.put("-id", targetId);

						argumentParser=new ArgumentParser(parserMap);

						try 
						{
							if(!find_secrf_statistics)
							{
								updateAttrViaQueryObj.execute(session, null, null, argumentParser);
								//Apply changes to previous versions
								if(isRequireToPreviousVersions)
								{
									/*if(!isImmutabilityDisable)
									{
										objIdsVector=swyHelperObj.getPreviousVersionsIds(targetId,session);
										swyHelperObj.disableObjectsImmutability(true,session,targetId,objIdsVector.size(), objIdsVector);
										isImmutabilityDisable=true;

										DfLogger.debug(this,"Object id["+targetId+"]::: <<is_assign_performers && need_to_remove_performer>> ~~~~~~~~ Previous versions doc made mutable~~~~~~~~ ",null,null);
									}*/

									parserMap.remove("-id");
									parserMap.remove("-if");
									//parserMap.put("-if","'"+sysObject.getValue("a_status")+"'='"+sysObject.getValue("a_status")+"'");								
									String queryParamValue = parserMap.get("-query");

									IDfSysObject tmpSysObject = (IDfSysObject) session.getObject(new DfId(targetId));

									if(queryParamValue.contains("$value(swy_security_rest_form)"))
									{
										parserMap.remove("-query");
										queryParamValue = queryParamValue.replace("$value(swy_security_rest_form)", tmpSysObject.getString("swy_security_rest_form"));
										parserMap.put("-query", queryParamValue);
									}
									String dqlToFetchVersions = "select r_object_id from "+sysObject.getTypeName()+"(all) where i_chronicle_id='"+tmpSysObject.getString("i_chronicle_id")+"' and r_object_id!='"+tmpSysObject.getObjectId().toString()+"'";
									String allVersionIds[] = QueryUtils.getAllQueryResultsAsStrings(dqlToFetchVersions, session);
									for (String versionId : allVersionIds) {
										parserMap.put("-id", versionId);
										argumentParser=new ArgumentParser(parserMap);
										updateAttrViaQueryObj.execute(session, null,null,argumentParser);
									}

								}
							}
							is_performers_scenario_exist=true;
							DfLogger.debug(this,"Object id["+targetId+"]:::  Updated Performers based on condition for migrated document "+targetId,null,null);


						} catch (Exception e) {
							// TODO Auto-generated catch block
							DfLogger.error(this, e.getLocalizedMessage(), null, e);
						}
						DfLogger.debug(this,"Object id["+targetId+"]:::  Done with Performers update, based on condition for migrated document "+targetId,null,null);
					}
				}

				if(!is_performers_scenario_exist)
				{
					/*
					 * Applying SecRF performers (i.e. auditors, authors, qo_approvers, readers, doc_coordinators, reviewers, approvers, format_reviewers) on document object 
					 * if document's any swy_sel_security_rest_forms <> 'Default' and swy_security_rest_form <> 'Default' and swy_security_rest_form is not nullstring
					 */
					try 
					{
						if(!find_secrf_statistics)
						{
							parserMap=new HashMap<String , String>();
							DfLogger.info(this,"Object id["+targetId+"]::: Updating Performers with default setting for non/migrated document "+targetId,null,null);
							parserMap.put("-if", "any swy_sel_security_rest_forms <> 'Default' and swy_security_rest_form <> 'Default' and swy_security_rest_form is not nullstring" );
							parserMap.put("-query", "select auditors, authors, qo_approvers, readers, doc_coordinators, reviewers, approvers, format_reviewers from swy_sec_registration_form where object_name='$value(swy_security_rest_form)'" );
							parserMap.put("-context_user", ctxUsr);
							parserMap.put("-truncate", "true");
							parserMap.put("-ignore_duplicate_values", "true");
							parserMap.put("-ignore_null_values", "true");
							parserMap.put("-all_rows", "true");

							parserMap.put("-id", targetId);
							argumentParser=new ArgumentParser(parserMap);

							updateAttrViaQueryObj.execute(session, null, null, argumentParser);

							//Update previous versions of document
							if(isRequireToPreviousVersions)
							{
								/*if(!isImmutabilityDisable)
								{
									objIdsVector=swyHelperObj.getPreviousVersionsIds(targetId,session);
									swyHelperObj.disableObjectsImmutability(true,session,targetId,objIdsVector.size(), objIdsVector);
									isImmutabilityDisable=true;

									DfLogger.debug(this,"Object id["+targetId+"]::: <<!is_performers_scenario_exist>> ~~~~~~~~ Previous versions doc made mutable~~~~~~~~ ",null,null);

								}*/

								IDfSysObject tmpObj = (IDfSysObject) session.getObject(new DfId(targetId));
								String dqlToFetchVersions = "select r_object_id from "+sysObject.getTypeName()+"(all) where i_chronicle_id='"+tmpObj.getString("i_chronicle_id")+"' and r_object_id!='"+tmpObj.getObjectId().toString()+"'";
								String allVersionIds[] = QueryUtils.getAllQueryResultsAsStrings(dqlToFetchVersions, session);
								for (String versionId : allVersionIds) {
									parserMap=new HashMap<String , String>();
									//parserMap.put("-if", "any swy_sel_security_rest_forms <> 'Default' and swy_security_rest_form <> 'Default' and swy_security_rest_form is not nullstring" );
									parserMap.put("-query", "select auditors, authors, qo_approvers, readers, doc_coordinators, reviewers, approvers, format_reviewers from swy_sec_registration_form where object_name='"+tmpObj.getString("swy_security_rest_form")+"'" );
									parserMap.put("-context_user", ctxUsr);
									parserMap.put("-truncate", "true");
									parserMap.put("-ignore_duplicate_values", "true");
									parserMap.put("-ignore_null_values", "true");
									parserMap.put("-all_rows", "true");

									parserMap.put("-id", versionId);
									argumentParser=new ArgumentParser(parserMap);
									updateAttrViaQueryObj.execute(session, null, null, argumentParser);
								}

							}
						}
						is_performers_scenario_exist=true;
						DfLogger.debug(this,"Object id["+targetId+"]:::  Updated Performers based on condition for migrated document "+targetId,null,null);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						DfLogger.error(this, e.getLocalizedMessage(), null, e);
					}
				}

				try 
				{
					if(!find_secrf_statistics)
					{
						parserMap=new HashMap<String, String>();

						parserMap.put("-id",targetId );
						parserMap.put("-query", "select count(swy_sel_security_rest_forms) as swy_applicable_secrf_count  from cd_controlled_doc where r_object_id ='"+targetId+"' and any swy_sel_security_rest_forms <> 'Default' group by object_name  enable(row_based)" );
						parserMap.put("-context_user",  ctxUsr );
						parserMap.put("-override", "true");

						argumentParser=new ArgumentParser(parserMap);

						updateAttrViaQueryObj.execute(session, null, null, argumentParser);

						//Update the same on previous versions
						if(isRequireToPreviousVersions)
						{
							/*if(!isImmutabilityDisable)
							{
								objIdsVector=swyHelperObj.getPreviousVersionsIds(targetId,session);
								swyHelperObj.disableObjectsImmutability(true,session,targetId,objIdsVector.size(), objIdsVector);
								isImmutabilityDisable=true;

								DfLogger.debug(this,"Object id["+targetId+"]::: <<Updating SecRf count>> ~~~~~~~~ Previous versions doc made mutable~~~~~~~~ ",null,null);

							}*/

							IDfSysObject tmpObj = (IDfSysObject) session.getObject(new DfId(targetId));
							String dqlToFetchVersions = "select r_object_id from "+sysObject.getTypeName()+"(all) where i_chronicle_id='"+tmpObj.getString("i_chronicle_id")+"' and r_object_id!='"+tmpObj.getObjectId().toString()+"'";
							String allVersionIds[] = QueryUtils.getAllQueryResultsAsStrings(dqlToFetchVersions, session);
							for (String versionId : allVersionIds) {
								parserMap=new HashMap<String, String>();
								parserMap.put("-id", versionId);
								parserMap.put("-query", "select count(swy_sel_security_rest_forms) as swy_applicable_secrf_count  from cd_controlled_doc(all) where r_object_id ='"+versionId+"' and any swy_sel_security_rest_forms <> 'Default' group by object_name  enable(row_based)" );
								parserMap.put("-context_user",  ctxUsr );
								parserMap.put("-override", "true");

								argumentParser=new ArgumentParser(parserMap);

								updateAttrViaQueryObj.execute(session, null, null, argumentParser);
							}
						}

						DfLogger.debug(this,"Object id["+targetId+"]::: Attached SecRF count Updatde",null,null);
					}

				} catch (Exception e) {
					// TODO Auto-generated catch block
					DfLogger.error(this, e.getLocalizedMessage(), null, e);
				}
				//sysObject=(IDfSysObject)session.getObject(targetObjId);
				sysObject.fetch(null);
				DfLogger.debug(this,"Object id["+targetId+"]:::  Done with Performers update, based on condition for migrated document "+targetId,null,null);
			}

			/*if(isImmutabilityDisable)
			{
				swyHelperObj.disableObjectsImmutability(false,session,targetId,objIdsVector.size(), objIdsVector);
				isImmutabilityDisable=false;
				DfLogger.debug(this,"Object id["+targetId+"]::: <<>> ~~~~~~~~ Previous versions doc made back to immutable~~~~~~~~ ",null,null);

			}*/

			//copying attribute value from Source to target attribute , of same document object
			if(attr_to_be_copied!=null && !attr_to_be_copied.trim().equalsIgnoreCase("") && need_to_remove_performer)
			{
				if(!find_secrf_statistics)
				{
					DfLogger.debug(this,"Object id["+targetId+"]:::  Start copying attribute, after applying new performers "+targetId,null,null);
					String[] src_target_attrs=attr_to_be_copied.split(",");

					for(int i=0;i<src_target_attrs.length;i++)
					{
						String src_target_attr=src_target_attrs[i];
						src_target_attr=swyHelperObj.replaceChar(src_target_attr,"-",ISWYApplySECRFConstants.DEFAULT_SEPARATOR);
						String[] attrs= src_target_attr.split(ISWYApplySECRFConstants.DEFAULT_SEPARATOR);

						if(attrs!=null && attrs.length==2)
						{
							String targetAttr=attrs[1];
							String srcAttr=attrs[0];

							if(sysObject.hasAttr(srcAttr) && sysObject.hasAttr(targetAttr))
							{
								if(sysObject.isAttrRepeating(srcAttr) && sysObject.isAttrRepeating(targetAttr))
								{
									sysObject.removeAll(targetAttr);
									int valueCnt=	sysObject.getValueCount(srcAttr);

									if(valueCnt>0)
									{
										for(int j=0;j<valueCnt;j++)
										{
											String tmpAttrVal=sysObject.getRepeatingString(srcAttr,j);
											if(tmpAttrVal!=null && !tmpAttrVal.equalsIgnoreCase(""))
											{
												sysObject.setRepeatingString(targetAttr, j, tmpAttrVal);
											}
											//swyHelperObj.applyChangesToAllVersions(sysObject, new String[]{targetAttr}, new String[]{sysObject.getAllRepeatingStrings(srcAttr,"|")}, session, isApplyToPreviousVersions);
										}									
									}
									DfcObjectUtils.fetchObjectIfRequired(sysObject);
									sysObject.save();
									//sysObject=(IDfSysObject)session.getObject(targetObjId);
//									sysObject.fetch(null);
									DfLogger.debug(this,"Object id["+targetId+"]:::  SourceAttr|TargetAttr ["+src_target_attr+"] Repeating Attribute combination are updated for the object  "+targetId,null,null);
								}
								else if(!sysObject.isAttrRepeating(srcAttr) && !sysObject.isAttrRepeating(targetAttr))
								{
									String tmpAttrVal=sysObject.getString(srcAttr);
									if(tmpAttrVal!=null && !tmpAttrVal.equalsIgnoreCase(""))
									{
										sysObject.setString(targetAttr,tmpAttrVal );
										DfcObjectUtils.fetchObjectIfRequired(sysObject);
										sysObject.save();

										//swyHelperObj.applyChangesToAllVersions(sysObject, new String[]{targetAttr}, new String[]{tmpAttrVal}, session, isApplyToPreviousVersions);

										//sysObject=(IDfSysObject)session.getObject(targetObjId);
//										sysObject.fetch(null);
										DfLogger.debug(this,"Object id["+targetId+"]:::  SourceAttr|TargetAttr ["+src_target_attr+"] Single Attribute combination are updated for the object  "+targetId,null,null);
									}
								}
								else
								{
									DfLogger.debug(this,"Object id["+targetId+"]:::  SourceAttr|TargetAttr ["+src_target_attr+"] combination are not same for object id "+targetId,null,null);
								}
							}
							else
							{
								DfLogger.debug(this,"Object id["+targetId+"]:::  SourceAttr|TargetAttr ["+src_target_attr+"] doesn't exist for object id "+targetId,null,null);
							}
						}
						else
						{
							DfLogger.debug(this,"Object id["+targetId+"]:::  SourceAttr|TargetAttr ["+src_target_attr+"] properly not configured for object id "+targetId,null,null);
						}
					}
					DfLogger.debug(this,"Object id["+targetId+"]:::  Done with copying attribute "+targetId,null,null);
				}
			}
			else
			{
				DfLogger.debug(this,"Object id["+targetId+"]:::  No attributes to copy",null,null);
			}

			//Applying Default performers respective to their Role , passed as argument , if required

			if(secrf_default_role)
			{
				DfLogger.debug(this,"Object id["+targetId+"]::: Applying Default Roles , after making SecRF Inactive ",null,null);
				ArgumentParser argumentParser=null;
				HashMap<String, String> parserMap=null;
				Iterator<Entry<String,String>> argParserIterator= argParser.iterator();

				while(argParserIterator.hasNext())
				{
					Entry<String,String> tmpEntry=argParserIterator.next();
					String tmpNotiKey=tmpEntry.getKey().toLowerCase().trim();
					if(tmpNotiKey.startsWith(ARG_SECRF_DEFAULT_ROLE_SCENARIO))
					{
						DfLogger.debug(this,"Object id["+targetId+"]:::  ~~~~~~~~ Default Roles Mapping Scenario, Processing for object id ["+targetId+"]~~~~~~~~ ",null,null);
						String tmpNotiVal= tmpEntry.getValue();
						parserMap=swyHelperObj.getMapFromArguments(tmpNotiVal);

						parserMap.put("-id", targetId);

						argumentParser=new ArgumentParser(parserMap);

						try 
						{
							if(!find_secrf_statistics)
							{
								updateAttrViaQueryObj.execute(session, null, null, argumentParser);
								//Update same on previous version
								IDfSysObject tmpObj = (IDfSysObject) session.getObject(new DfId(targetId));
								String dqlToFetchVersions = "select r_object_id from "+sysObject.getTypeName()+"(all) where i_chronicle_id='"+tmpObj.getString("i_chronicle_id")+"' and r_object_id!='"+tmpObj.getObjectId().toString()+"'";
								String allVersionIds[] = QueryUtils.getAllQueryResultsAsStrings(dqlToFetchVersions, session);
								for (String versionId : allVersionIds) {
									parserMap=new HashMap<String, String>();

									parserMap=swyHelperObj.getMapFromArguments(tmpNotiVal);
									parserMap.put("-id",versionId);
									argumentParser=new ArgumentParser(parserMap);
									updateAttrViaQueryObj.execute(session, null, null, argumentParser);

								}


								DfLogger.debug(this,"Object id["+targetId+"]:::  Updated Default Roles on condition for Deactivated SecRF "+targetId,null,null);
							}
							is_performers_scenario_exist=true;

						} catch (Exception e) {
							// TODO Auto-generated catch block
							DfLogger.error(this, e.getLocalizedMessage(), null, e);
						}
						DfLogger.debug(this,"Object id["+targetId+"]:::  Done with applying Default Roles , after making SecRF Inactive  "+targetId,null,null);
					}
				}
				//sysObject=(IDfSysObject)session.getObject(targetObjId);
				sysObject.fetch(null);
			}


			//Ignore  or Remove InActive users from their respective roles
			if(removeInactiveUser)
			{
				if(!find_secrf_statistics)
				{
					DfLogger.debug(this,"Object id["+targetId+"]:::  Removing Inactive Users "+targetId,null,null);
					D2Dictionary dAttr = D2Dictionary.getDictionary(ISWYApplySECRFConstants.ROLES_DICTIONARY, session, null, null, true, false);
					String[] roles=dAttr.getKeys();
					boolean isRoleUsersUpdated=false;

					if(roles!=null && roles.length>0)
					{
						for(int i=0;i<roles.length;i++)
						{
							String role=roles[i];
							DfLogger.debug(this,"Object id["+targetId+"]:::  Removing Inactive Users for role ["+role+"] "+targetId,null,null);
							if(role!=null && !role.trim().equalsIgnoreCase(""))
							{
								ArrayList<String> tmpRoleList=null;
								boolean is_any_user_inactive=false;
								int roleCount=sysObject.getValueCount(role);
								if(roleCount>0)
								{
									for(int j=0;j<roleCount;j++)
									{
										String userName=sysObject.getRepeatingString(role, j);
										if(userName!=null && !userName.trim().equalsIgnoreCase(""))
										{
											String userQual="dm_user where user_name='"+userName+"'";
											DfLogger.debug(this,"Object id["+targetId+"]:::  DQL to check whether User is Active or not ["+userQual+"] for role ["+role+"]",null,null);
											IDfUser userObj=(IDfUser)session.getObjectByQualification(userQual);
											if(userObj!=null)
											{
												if(userObj.isGroup())
												{
													DfLogger.debug(this,"Object id["+targetId+"]:::  User ["+userName+"] is GROUP",null,null);
													if(tmpRoleList==null)
														tmpRoleList=new ArrayList<String> ();
													tmpRoleList.add(userName);
													DfLogger.debug(this,"Object id["+targetId+"]:::  Assuming GROUP ["+userName+"] is active",null,null);
												}
												else
												{
													DfLogger.debug(this,"Object id["+targetId+"]:::  User ["+userName+"] is USER",null,null);
													if(userObj.getUserState()==0)	//UserActive
													{
														if(tmpRoleList==null)
															tmpRoleList=new ArrayList<String> ();
														tmpRoleList.add(userName);
														DfLogger.debug(this,"Object id["+targetId+"]:::  User ["+userName+"] is active",null,null);
													}
													else
													{
														is_any_user_inactive=true;
														DfLogger.debug(this,"Object id["+targetId+"]:::  User ["+userName+"] is Inactive",null,null);
													}
												}
											}
											else
											{
												is_any_user_inactive=true;
												DfLogger.debug(this,"Object id["+targetId+"]:::  User ["+userName+"] is Inactive, since corresponding object is null",null,null);
											}
										}
									}
								}
								if(is_any_user_inactive)
								{
									sysObject.removeAll(role);
									if(tmpRoleList!=null && tmpRoleList.size()>0)
									{
										for(int j=0;j<tmpRoleList.size();j++)
										{
											sysObject.setRepeatingString(role, j, tmpRoleList.get(j));
										}
									}
									isRoleUsersUpdated=true;
									DfLogger.debug(this,"Object id["+targetId+"]:::  User is Removed for role ["+role+"]",null,null);
								}

							}
						}
					}

					if(isRoleUsersUpdated)
					{
						DfcObjectUtils.fetchObjectIfRequired(sysObject);
						sysObject.save();
						//sysObject=(IDfSysObject)session.getObject(targetObjId);
						sysObject.fetch(null);
						DfLogger.debug(this,"Object id["+targetId+"]:::  Removed Inactive Users , Object saved "+targetId,null,null);
					}
				}				
			}


			//Applying Security
			if(is_performers_scenario_exist || need_to_remove_performer)
			{
				if(!find_secrf_statistics)
				{
					//apply security
					if(need_to_apply_security)
					{
						DfLogger.debug(this,"Object Id ["+sysObject.getObjectId().getId()+"]::: Applying Security with is_performers_scenario_exist["+is_performers_scenario_exist+"] Selected performer Removed =["+need_to_remove_performer+"] Need to apply Security["+need_to_apply_security+"]", null,null);
						DfLogger.info(this,"Object Id ["+sysObject.getObjectId().getId()+"]::: Applying Security", null,null);
						try
						{
							// Since -security parameter was passed true, apply security for all versions of document
							swyHelperObj.applyingSecurity(targetId,session, need_to_apply_security,is_document_migr8ed);
						} 
						catch (Exception e) 
						{
							DfLogger.error(this,e.getLocalizedMessage(),null,e);
						}
						DfLogger.info(this,"Object Id ["+sysObject.getObjectId().getId()+"]::: Applying Security DONE", null,null);
					}
				}
			}

			//Sending Notification
			if(is_send_notification_needed)
			{
				if(!find_secrf_statistics)
				{
					DfLogger.info(this,"Object id["+targetId+"]:::  ~~~~~~~~ Processing Send Notification for object with id "+targetId +" ~~~~~~~~ ",null,null);

					Iterator<Entry<String,String>> ArgParserIterator= argParser.iterator();

					while(ArgParserIterator.hasNext())
					{
						Entry<String,String> tmpEntry=ArgParserIterator.next();
						String tmpNotiKey=tmpEntry.getKey().toLowerCase().trim();
						if(tmpNotiKey.startsWith(ARG_NOTIFICATION_SCENARIO))
						{
							DfLogger.debug(this,"Object id["+targetId+"]:::  ~~~~~~~~ Notification Scenario Processing for object id ["+targetId+"]~~~~~~~~ ",null,null);
							String tmpNotiVal= tmpEntry.getValue();
							HashMap<String, String> parserMap=swyHelperObj.getMapFromArguments(tmpNotiVal);
							parserMap.put("-id", targetId);

							ArgumentParser argumentParser=new ArgumentParser(parserMap);
							try {
								NotifyUsers notifyUserObj=new NotifyUsers();
								notifyUserObj.execute(session, null, null, argumentParser);
								DfLogger.debug(this,"Object id["+targetId+"]:::  Argument Parser for Notify User ["+argumentParser.toString()+"] for object id ["+targetId+"]",null,null);
							} catch (Exception e) {
								// TODO Auto-generated catch block
								DfLogger.error(this,e.getLocalizedMessage(),null,e);
							}
						}
					}
					DfLogger.info(this,"Object id["+targetId+"]:::  ~~~~~~~~ Processing Send Notification DONE for object with id "+targetId +" ~~~~~~~~ ",null,null);
				}
			}

			if(!find_secrf_statistics && callOriginatedFrom!=null)
			{
				DfLogger.debug(this, "Object Id ["+targetObjId+"]::: Updating Document's versions -- "+callOriginatedFrom, null, null);
				swyHelperObj.applyChangesToDocAllVersions(targetId, session,true,is_document_migr8ed);
				DfLogger.debug(this, "Object Id ["+targetObjId+"]::: Updating Document's versions DONE -- "+callOriginatedFrom, null, null);
			}

			DfLogger.info(this,"Object id["+targetId+"]:::  ~~~~~~~~ SECRF Processing DONE for object with id "+targetId +" ~~~~~~~~ ",null,null);
		}
		catch(Exception e)
		{
			DfLogger.error(this,"Object id["+targetId+"]::: There is some issue with Automatic Security Selection"+e.getMessage(),null,e);
		}


		if(apply_to_existing_doc && !isSatisfiedForDefault && is_document_conflicted)	// conflicted for apply to existing document
		{
			DfLogger.info(this,"Object id["+targetId+"]::: conflicted for -- apply to existing document start",null,null);
			//Previous author already added in code above
			//Conflict status will be blank or nullstring
			String docExistingAuthor=swyHelperObj.getAllExistingAuthors(sysObject);
			resultBeanObj.setDocNewAuthors(docExistingAuthor!=null && !docExistingAuthor.trim().equalsIgnoreCase("") ? docExistingAuthor.split( ISWYApplySECRFConstants.DEFAULT_SEPARATOR) : null);

			resultBeanObj.setDocConflictStatus(ISWYApplySECRFConstants.DOC_SECRF_CONFLICT_STATUS);
			resultBeanObj.setDocAffectedDueToSecRF(true);
			resultBeanObj.setRemarks( ISWYApplySECRFConstants.DOC_CONFLICT_REMARKS );
			resultBeanObj.setTemplateName(new String[]{ISWYApplySECRFConstants.MAIL_OBJECT_MSGS_TEMPLATE1_KEY,ISWYApplySECRFConstants.MAIL_OBJECT_MSGS_TEMPLATE2_KEY});

			String docsApplicableSecRFMgrs=swyHelperObj.getAllApplicableFormMgrs(sysObject);
			DfLogger.debug(this, "updating bean object's BAs with ["+docsApplicableSecRFMgrs+"] values", null, null);
			resultBeanObj.setDocFormManagers(docsApplicableSecRFMgrs!=null && !docsApplicableSecRFMgrs.trim().equalsIgnoreCase("") ? docsApplicableSecRFMgrs.split( ISWYApplySECRFConstants.DEFAULT_SEPARATOR) : null);

			resultBeanObj.setMailObjectNeeded(true);
			DfLogger.debug(this,"Object id["+targetId+"]::: not conflicted for -- apply to existing document done",null,null);
		}
		else if(apply_to_existing_doc && !isSatisfiedForDefault && !is_document_conflicted)	// not conflicted for apply to existing document
		{
			DfLogger.info(this,"Object id["+targetId+"]::: not conflicted for -- apply to existing document start",null,null);
			//Previous author already added in code above
			//Conflict status will be blank or nullstring
			String docExistingAuthor=swyHelperObj.getAllExistingAuthors(sysObject);
			resultBeanObj.setDocNewAuthors(docExistingAuthor!=null && !docExistingAuthor.trim().equalsIgnoreCase("") ? docExistingAuthor.split( ISWYApplySECRFConstants.DEFAULT_SEPARATOR) : null);

			resultBeanObj.setRemarks(  String.format(ISWYApplySECRFConstants.DOC_SECRF_RSTD_REMARKS, secrfObjectName));
			resultBeanObj.setTemplateName(new String[]{ISWYApplySECRFConstants.MAIL_OBJECT_MSGS_TEMPLATE1_KEY,ISWYApplySECRFConstants.MAIL_OBJECT_MSGS_TEMPLATE2_KEY});

			String docsApplicableSecRFMgrs=swyHelperObj.getAllApplicableFormMgrs(sysObject);
			DfLogger.debug(this, "updating bean object's BAs with ["+docsApplicableSecRFMgrs+"] values", null, null);
			resultBeanObj.setDocFormManagers(docsApplicableSecRFMgrs!=null && !docsApplicableSecRFMgrs.trim().equalsIgnoreCase("") ? docsApplicableSecRFMgrs.split( ISWYApplySECRFConstants.DEFAULT_SEPARATOR) : null);

			resultBeanObj.setDocAffectedDueToSecRF(true);
			resultBeanObj.setMailObjectNeeded(true);
			DfLogger.debug(this,"Object id["+targetId+"]::: not conflicted for -- apply to existing document done",null,null);
		}
		else if (isSecrfListRefreshNeeded && is_document_conflicted && !apply_to_existing_doc && !isSatisfiedForDefault)	// new or update but conflicted (Multiple Automatic, Manual, Authors are not defined in SecRF). 
		{
			DfLogger.info(this,"Object id["+targetId+"]::: new or update but conflicted (Multiple Automatic, Manual, Authors are not defined in SecR). start",null,null);
			String docExistingAuthor=swyHelperObj.getAllApplicableAuthors(sysObject);
			//Since we are applying authors from LC
			resultBeanObj.setDocNewAuthors(docExistingAuthor!=null && !docExistingAuthor.trim().equalsIgnoreCase("") ? docExistingAuthor.split( ISWYApplySECRFConstants.DEFAULT_SEPARATOR) : null);

			resultBeanObj.setDocConflictStatus(ISWYApplySECRFConstants.DOC_SECRF_CONFLICT_STATUS);
			resultBeanObj.setDocAffectedDueToSecRF(true);
			resultBeanObj.setRemarks( ISWYApplySECRFConstants.DOC_CONFLICT_REMARKS );
			resultBeanObj.setTemplateName(new String[]{ISWYApplySECRFConstants.MAIL_OBJECT_MSGS_TEMPLATE3_KEY,ISWYApplySECRFConstants.MAIL_OBJECT_MSGS_TEMPLATE4_KEY});

			String docsApplicableSecRFMgrs=swyHelperObj.getAllApplicableFormMgrs(sysObject);
			DfLogger.debug(this, "updating bean object's BAs with ["+docsApplicableSecRFMgrs+"] values", null, null);
			resultBeanObj.setDocFormManagers(docsApplicableSecRFMgrs!=null && !docsApplicableSecRFMgrs.trim().equalsIgnoreCase("") ? docsApplicableSecRFMgrs.split( ISWYApplySECRFConstants.DEFAULT_SEPARATOR) : null);

			resultBeanObj.setMailObjectNeeded(true);
			DfLogger.debug(this,"Object id["+targetId+"]::: new or update but conflicted (Multiple Automatic, Manual, Authors are not defined in SecR). done",null,null);
		}
		else if (isSecrfListRefreshNeeded && !apply_to_existing_doc && !isSatisfiedForDefault)	// new or update, not conflicted And No Manual SECRF form found for Restricted document
		{
			DfLogger.info(this,"Object id["+targetId+"]::: new or update, not conflicted start",null,null);
			//Previous author not required
			//Conflict status will be blank or nullstring
			String docExistingAuthor=swyHelperObj.getAllApplicableAuthors(sysObject);
			//Since we are applying authors from LC
			resultBeanObj.setDocNewAuthors(docExistingAuthor!=null && !docExistingAuthor.trim().equalsIgnoreCase("") ? docExistingAuthor.split( ISWYApplySECRFConstants.DEFAULT_SEPARATOR) : null);

			if(need_to_remove_performer && !isSatisfiedForDefault && document_mode.trim().equalsIgnoreCase(ISWYApplySECRFConstants.MANUAL))	// No Manual SECRF form found for Restricted document
			{
				DfLogger.info(this,"Object id["+targetId+"]::: new or update, No Manual SECRF form found for Restricted document ",null,null);
				resultBeanObj.setRemarks(ISWYApplySECRFConstants.  DOC_SECRF_NOT_FOUND_REMARKS);
				resultBeanObj.setTemplateName(new String[]{ISWYApplySECRFConstants.MAIL_OBJECT_MSGS_TEMPLATE6_KEY});
				resultBeanObj.setDocAffectedDueToSecRF(false);
			}
			else
			{
				DfLogger.info(this,"Object id["+targetId+"]::: new or update, Normal document ",null,null);
				resultBeanObj.setRemarks(  String.format(ISWYApplySECRFConstants.DOC_SECRF_RSTD_REMARKS, secrfObjectName));
				resultBeanObj.setTemplateName(new String[]{ISWYApplySECRFConstants.MAIL_OBJECT_MSGS_TEMPLATE5_KEY});
				resultBeanObj.setDocAffectedDueToSecRF(true);
			}

			String docsApplicableSecRFMgrs=swyHelperObj.getAllApplicableFormMgrs(sysObject); 
			DfLogger.debug(this, "updating bean object's BAs with ["+docsApplicableSecRFMgrs+"] values", null, null);
			resultBeanObj.setDocFormManagers(docsApplicableSecRFMgrs!=null && !docsApplicableSecRFMgrs.trim().equalsIgnoreCase("") ? docsApplicableSecRFMgrs.split( ISWYApplySECRFConstants.DEFAULT_SEPARATOR) : null);

			resultBeanObj.setMailObjectNeeded(true);
			DfLogger.debug(this,"Object id["+targetId+"]::: new or update, not conflicted done",null,null);
		}
		//	Setting workflow abort status , while calling save() on document object
		resultBeanObj.setProcessStatus(ISWYApplySECRFConstants.SUCCESS_STATUS);
		resultBeanObj.setObjectId(targetId);
		resultBeanObj.setProcessMsg("Passed and Processed: "+targetId);


		if (resultBeanObj.isReCheckinRequired())
		{
			try {
				swyHelperObj.documnetReCheckinWithOldDetails(targetId, session,resultBeanObj.getCheckoutInfo(),find_secrf_statistics);
				sysObject.fetch(null);
			} catch (DfException e) {

				DfLogger.error(this,"Object id["+targetId+"]::: There is some issue with reCheckIn operation"+e.getMessage(),null,e);
				e.printStackTrace();
			}
		}

		DfLogger.debug(this,"Object id["+targetId+"]::: Passed and Processed: Returning ResultBean Object",null,null);

		return resultBeanObj;

	}
}	