package com.novartis.swy.utility.removeusers.utils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Map;

import com.documentum.fc.common.DfLogger;

public class SWYRemoveUsersResultBean implements Serializable 
{
	private boolean isWorkflowAborted=false;
	private String target_object_id=null;
	private String source_object_id=null;
	private String type_name=null;
	private String process_msg=null;
	private String success_process_status=null;	//Failed
	private String failed_process_status=null;	//Failed 

	private boolean isDocChkoutCancelled=false;
	private boolean isDocAffectedWithSecRF=false;
	
	private boolean isReCheckinReq=false;
	private boolean isAuditDone=false;
	private boolean isVersionUpdated=false;
	private boolean isApplySecurity=false;
	
	private Map<java.lang.String,java.lang.String[]> chkOutInfoMap=null;
	private Map<java.lang.String,ArrayList<String>> updateValuesMap=null;
	
	
	public SWYRemoveUsersResultBean()
	{
		DfLogger.debug(this,"ResultBean() ::: Constructor :::",null,null);
	}
	
	public String getFailedProcessStatus()
	{
		return this.failed_process_status;
	}
	
	public void setFailedProcessStatus(String processStatus)
	{
		this.failed_process_status=processStatus;
	}
	
	public String getSuccessProcessStatus()
	{
		return this.success_process_status;
	}
	
	public void setSuccessProcessStatus(String processStatus)
	{
		this.success_process_status=processStatus;
	}
	
	public String getProcessMsg()
	{
		return this.process_msg;
	}
	
	public void setProcessMsg(String processMsg)
	{
		this.process_msg=processMsg;
	}
	
	public String getTargetObjectId()
	{
		return this.target_object_id;
	}
	
	public void setTargetObjectId(String tar_objectid)
	{
		this.target_object_id=tar_objectid;
	}
	
	public String getSourceObjectId()
	{
		return this.source_object_id;
	}
	
	public void setSourceObjectId(String srcObjectid)
	{
		this.source_object_id=srcObjectid;
	}
	public String getTypeName()
	{
		return this.type_name;
	}
	
	public void setTypeName(String typeName)
	{
		this.type_name=typeName;
	}
	
	public boolean isWorkflowAborted()
	{
		return this.isWorkflowAborted;
	}
	
	public void setWorkflowAborted(boolean isWFAborted)
	{
		this.isWorkflowAborted=isWFAborted;
	}
	
	public boolean isDocCheckoutCancelled()
	{
		return this.isDocChkoutCancelled;
	}
	
	public void setDocCheckoutCancelled(boolean isDocChkoutCancel)
	{
		this.isDocChkoutCancelled=isDocChkoutCancel;
	}
	
	public boolean isDocAffectedDueToSecRF()
	{
		return this.isDocAffectedWithSecRF;
	}	
	public void setDocAffectedDueToSecRF(boolean isDocAffectedDueToSecRF)
	{
		this.isDocAffectedWithSecRF=isDocAffectedDueToSecRF;
	}	
	
	public boolean isReCheckinRequired()
	{
		return this.isReCheckinReq;
	}
	public void setIsReCheckinRequired(boolean isReChkInReqd)
	{
		this.isReCheckinReq=isReChkInReqd;
	}
	
	public boolean isAudited()
	{
		return this.isAuditDone;
	}
	public void setIsAudited(boolean isAudited)
	{
		this.isAuditDone=isAudited;
	}
	
	public boolean isVersionUpdated()
	{
		return this.isVersionUpdated;
	}
	public void setIsVersionUpdated(boolean isVersionObjUpdated)
	{
		this.isVersionUpdated=isVersionObjUpdated;
	}
	
	public boolean isACLUpdateNeeded()
	{
		return this.isApplySecurity;
	}
	public void setIsACLUpdateNeeded(boolean isACLUpdateNeeded)
	{
		this.isApplySecurity=isACLUpdateNeeded;
	}
	
	public void setCheckoutInfo(Map<java.lang.String,java.lang.String[]> chkOutCollMap)
	{
		this.chkOutInfoMap=chkOutCollMap;
	}
	public Map<java.lang.String,java.lang.String[]> getCheckoutInfo()
	{
		return this.chkOutInfoMap;
	}
	
	public void setUpdateValueMap(Map<java.lang.String,ArrayList<String>> valueMAp)
	{
		this.updateValuesMap=valueMAp;
	}
	public Map<java.lang.String,ArrayList<String>> getUpdateValueMap()
	{
		return this.updateValuesMap;
	}
}
