package com.novartis.swy.tmf.methods;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.mail.MessagingException;

import com.documentum.d2.exceptions.ConfigurationException;
import com.documentum.d2.model.D2Dictionary;
import com.documentum.fc.client.IDfModule;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.client.IDfTypedObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.utils.QueryUtils;
import com.documentum.utils.StringUtils;
import com.emc.common.java.utils.ArgumentParser;
import com.emc.d2.api.config.modules.mailing.D2MailingConfig;
import com.emc.d2.api.config.modules.mailing.ID2MailingConfig;
import com.emc.d2.api.methods.D2Method;
import com.emc.d2.api.methods.D2methodBean;
import com.emc.d2.api.methods.ID2Method;
import com.novartis.swy.tmf.model.SWYTMFQcNotificationObject;

/** * <br> Modifier:    kumarr3y (Rahul Kumar) </br>
 * <br> Modified on: 	28-Mar-2017</br>
 * <br> Comments: Method to process the documents which needs to be QC and send mail notification to the respective active user of a group.<br> 
 * <br> Configuration Elements used : Mailing ListCLN-ML-Send user qc notification <br>
 * <br> URL with in the link shall be dependent on Dictionary System Parameters
 * @author Rahul Kumar
 * 
 */
public class SWYNotifyDocumentsToQcGroup implements ID2Method, IDfModule {

	private String baseD2URL = null;
	public final static String SYSTEM_PARAMETERS_DICTIONARY = "System Parameters";
	public final static String D2_URL_PREFIX_SYSTEM_PARTAMETER = "d2_url";
	public final static String SYSTEM_PARTAMETER_ALIAS = "Value";
	public final static String NOTIFY_MAIL_CONFIG = "CLN-ML-Send user qc notification";
	public final static String NOTIFY_INDEX = "QC";
	public final static String NOTIFY_MESSAGE = "notify_message";
	public final static String MAIL_HEADER = "HEADER";
	public final static String MAIL_BODY = "BODY";
	public final static String MAIL_FOOTER = "FOOTER";

	public D2methodBean execute(IDfSession session, IDfSysObject job,Locale locale, ArgumentParser argumentParser) throws Exception {
		DfLogger.info(this,"Executing Notify Documents for Qcing method", null, null);
		String strGroupName 	  = argumentParser.getStringArgument("-group_name", null);
		DfLogger.debug(this, "Group Name to send the notification > " + strGroupName, null, null);

		if((null!=strGroupName) && !strGroupName.equals(""))
		{
		baseD2URL = getBaseD2Url(session);
		String repoName = session.getDocbaseName();
		// Process the query for finding document which need indexing and adding
		List<SWYTMFQcNotificationObject> qC=	processQcDocuments(session);
		String[] groupMembers=getGroupMember(strGroupName, session);
		// Finally to iterate each user related record in the list
		processMailNotification(session, qC,groupMembers, baseD2URL, repoName);
		return new D2methodBean(D2Method.RETURN_SUCCESS_STR, null);
		}
		else
			return new D2methodBean(D2Method.RETURN_FATAL_STR, null);
	}

	/**
	 * Processing the Mail Notification for the QC document
	 * @param session	IDf Session
	 * @param indexAttrMap 	Contributors, Document attributes Map
	 * @param baseD2Url	D2 URL
	 * @param repoName	Docbase Name
	 * @throws DfException
	 * @throws MessagingException
	 */
	private void processMailNotification(IDfSession session,List<SWYTMFQcNotificationObject> qcResultSet,String[] groupMembers,String baseD2Url, String repoName) throws DfException,MessagingException {
		DfLogger.info(this,"Processing Email Notification", null, null);
		// Get the Users in the Group
		
		int groupMembersLength  =groupMembers.length;
		int qcResultSetLength  = qcResultSet.size();
		IDfSysObject sysObj=null;
		
		if(groupMembersLength > 0 && qcResultSetLength > 0)
		{	
			sysObj = (IDfSysObject) session.newObject("dm_document");
			for (int groupMembersCount = 0; groupMembersCount < groupMembersLength; groupMembersCount++) {
				String UserName = groupMembers[groupMembersCount];
				sysObj.setAuthors(groupMembersCount, UserName);
			}
			sysObj.save();
		
		String indexDocMessage_header = "";
		String indexDocMessage_body = "";
		String indexDocMessage_footer = "";
		
		indexDocMessage_header = indexDocMessage_header.concat("<h3 align=\"center\">****************Documents in QC****************</h3>");
		indexDocMessage_header = indexDocMessage_header.concat("<table cellpadding =2px; cellspacing=2px; border =1px;>");			
		indexDocMessage_header = indexDocMessage_header.concat("<th>Name</th><th>Artifact Number</th><th>Artifact</th><th>Scope</th><th>Product</th><th>Trial</th><th>Zone</th><th>Section</th><th>QC User</th><th>Date Created</th>");
		updateQcDocuments(sysObj, session, indexDocMessage_header,MAIL_HEADER);			

		
		for (int i = 0; i < qcResultSetLength; i++) {
			SWYTMFQcNotificationObject record = qcResultSet.get(i);
			String trialId = record.getClinicalTrialId();
			String objectName = record.getObjectName();
			String objectId = record.getrObjectId();
			String artifactNum = record.getArtifactNum();
			String tmfArtifactName = record.getTmfArtifactName();
			String tmfScope = record.getTmfScope();
			String zone = record.getZone();
			String section = record.getSection();
			String productCode = record.getProductCode();
			String creationDate = record.getrCreationDate();
			String qcUser=record.getQCUser();
			String locateUrl = null;
			if (baseD2Url != null) {
				locateUrl = getDocUrl(baseD2Url, objectId, repoName);
			}
			indexDocMessage_body = indexDocMessage_body.concat("<tr><td><a href='"+ locateUrl + "'>" + objectName + "</a></td><td>"+ artifactNum+ "</td><td>" + tmfArtifactName + "</td><td>" + tmfScope + "</td><td>" + productCode + "</td><td>" + trialId
							  + "</td><td>" + zone + "</td><td>" + section + "</td><td>"+qcUser+"</td><td>" + creationDate + "</td></tr>");
			updateQcDocuments(sysObj, session, indexDocMessage_body,MAIL_BODY);
			indexDocMessage_body="";
		}			
		indexDocMessage_footer = indexDocMessage_footer.concat("</table>");

		DfLogger.info(this,"Processed HTML message", null, null);
		// Once the message is created add it in the registered
		// notify_message table
		updateQcDocuments(sysObj, session, indexDocMessage_footer,MAIL_FOOTER);			
		// Call the mail config for notifying the respective contributors
		ID2MailingConfig sendEmail = D2MailingConfig.getInstanceByName(session, NOTIFY_MAIL_CONFIG);
		sendEmail.sendMail(sysObj.getObjectId());
		// Destroy all versions of the dm_document created
		sysObj.destroyAllVersions();
		getCleanUp(session);
		DfLogger.info(this,"Email Notification successful.", null, null);
		}
	}

	/**
	 * Update/insert  Qc document information in registered table
	 * @param sysObj Sys Object created for notification
	 * @param session IDf Session
	 * @param indexDocMessage HTML message constructed
	 * @param type of String entered in the table
	 * @throws DfException
	 */
	private void updateQcDocuments(IDfSysObject sysObj,IDfSession session, String indexDocMessage,String type) throws DfException {
		DfLogger.info(SWYNotifyDocumentsToQcGroup.class,"Executing update table", null, null);
		String updateEnabledUsersQuery = "";
		String objectID="";
		
		if(type.equals(MAIL_HEADER))
			objectID=sysObj.getObjectId()+"-1";
		else if(type.equals(MAIL_BODY))
			objectID=sysObj.getObjectId()+"-2";
		else
			objectID=sysObj.getObjectId()+"-3";
		
		updateEnabledUsersQuery = "insert into dm_dbo." + NOTIFY_MESSAGE+ " values(" + StringUtils.quote(NOTIFY_INDEX) + ", '"+ objectID+ "', " + StringUtils.quote(indexDocMessage) + ")";
		DfLogger.info(SWYNotifyDocumentsToQcGroup.class,	"Enabled User Update Query {0}",new String[] { updateEnabledUsersQuery }, null);
		QueryUtils.execQuery(updateEnabledUsersQuery, session);
		DfLogger.info(SWYNotifyDocumentsToQcGroup.class,"Processed table updates", null, null);
	}

		
	/**
	 * Process the locate URL for document
	 * @param baseD2Url	D2 URL
	 * @param objectId	r_object_id of document
	 * @param repoName	Docbase name
	 * @return
	 */
	private String getDocUrl(String baseD2Url, String objectId, String repoName) {
		DfLogger.info(this,
				"Url After document processed {0}", new String[] { baseD2Url
						+ "?locateId=" + objectId + "&docbase=" + repoName },
				null);
		return baseD2Url + "?locateId=" + objectId + "&docbase=" + repoName;
	}
	
	/**
	 * Select all the documents that need to be indexed
	 * @param session IDfSession
	 * @param indexAttrMap Map for storing the Contributor and Document information
	 * @throws DfException
	 */
	private List processQcDocuments(IDfSession session) throws DfException {
		DfLogger.info(this,"Processing Qcing document", null, null);
		List<SWYTMFQcNotificationObject> notificationAttr = new ArrayList<SWYTMFQcNotificationObject>();
		String query = "select distinct(object_name),r_object_id,product_code,clinical_trial_id,artifact_num,tmf_artifact_name, zone,section,tmf_scope,r_creation_date,qc_user from cd_clinical_tmf_doc d where a_status ='Quality Check' order by object_name enable(row_based)";
		IDfTypedObject[] results = QueryUtils.getAllQueryResults(query,session);

		// Iterate through the results and use contributors as key and add the
		// values in the list
		if ((results != null) && (results.length > 0)) {

			for (int i = 0; i < results.length; ++i) {
				String rObjectId = results[i].getString("r_object_id");
				String objectName = results[i].getString("object_name");
				String productCode = results[i].getString("product_code");
				String clinicalTrialId = results[i].getString("clinical_trial_id");
				String ArtifactNum = results[i].getString("artifact_num");
				String tmfArtifactName = results[i].getString("tmf_artifact_name");
				String section = results[i].getString("section");
				String zone = results[i].getString("zone");
				String tmfScope = results[i].getString("tmf_scope");
				String rCreationDate = results[i].getString("r_creation_date");
				String qc_user = results[i].getString("qc_user");
				SWYTMFQcNotificationObject qc = new SWYTMFQcNotificationObject(rObjectId, objectName, productCode, clinicalTrialId,ArtifactNum,tmfArtifactName, section,zone,tmfScope, rCreationDate, qc_user);
				notificationAttr.add(qc);
			}
			DfLogger.info(this,"Processed Qc Documents", null, null);
		}
		return notificationAttr;
	}

	/**
	 * Retrieve D2 URL  
	 * @param session IDf Session
	 * @return	D2 URL configured in the System Administrator Dictionary
	 * @throws DfException
	 * @throws ConfigurationException
	 */
	private String getBaseD2Url(IDfSession session) throws DfException,ConfigurationException {
		baseD2URL = D2Dictionary.getAliasValue(SYSTEM_PARAMETERS_DICTIONARY,D2_URL_PREFIX_SYSTEM_PARTAMETER, SYSTEM_PARTAMETER_ALIAS,session, null, null, true, false);
		if ((baseD2URL == null) || (baseD2URL.length() == 0)) {
			throw new ConfigurationException(
					"The base D2 client URL must be specified in the D2 \""
							+ SYSTEM_PARAMETERS_DICTIONARY
							+ "\" dictionary to enable links in the mail notification that are navigable within D2. Specify the relevant D2 client URL in the \""
							+ SYSTEM_PARTAMETER_ALIAS + "\" alias of the \""
							+ D2_URL_PREFIX_SYSTEM_PARTAMETER + "\" parameter.");
		}
		DfLogger.info(this,"Using base D2 client URL: {0}", new String[] { baseD2URL },null);
		return baseD2URL;
	}


	/**
	 * Get all the users in the group
	 * @param session IDf Session
	 * @param group String
	 * @return	String[] 
	 * @throws DfException
	 */
	private String[] getGroupMember(String groupname,IDfSession session) throws DfException {
		String query = "Select user_name from dm_user where user_name in (Select i_all_users_names from dm_group where group_name='"+groupname+"') and user_state=0";
		String[] results = QueryUtils.getAllQueryResultsAsStrings(query, session);
		return results;
		
	}


	/**
	 * Removing the content after the emails
	 * @param session IDf Session
	 * @param group String
	 * @return	String[] 
	 * @throws DfException
	 */
	private void getCleanUp(IDfSession session) throws DfException {
		String query = "Delete from dm_dbo.notify_message where notificationtype='"+NOTIFY_INDEX+"'";
		String results = QueryUtils.execQuery(query, session);
		DfLogger.info(this,"Number of Rows cleaned up after sending email :"+results, null,null);
	}


}
