package com.novartis.swy.tmf.model;

public class SWYTMFQcNotificationObject
{
  private String m_rObjectId = null;
  private String m_objectName = null;
  private String m_ArtifacNum = null;
  private String m_tmfArtifactName = null;
  private String m_tmfScope = null;
  private String m_productCode = null;
  private String m_clinicalTrialId = null;
  private String m_zone = null;
  private String m_section = null;
  private String m_rCreationDate = null;
  private String m_qc_user = null;

  public SWYTMFQcNotificationObject(String rObjectId, String objectName,String productCode,String clinicalTrialId,String ArtifactNum,String tmfArtifactName,String section,String zone,String tmfScope,String rCreationDate,String qc_user)
  {
    this.m_rObjectId = rObjectId;
    this.m_objectName = objectName;
    this.m_ArtifacNum = ArtifactNum;
    this.m_tmfArtifactName = tmfArtifactName;
    this.m_tmfScope = tmfScope;
    this.m_productCode = productCode;
    this.m_clinicalTrialId = clinicalTrialId;
    this.m_zone = zone;
    this.m_section = section;
    this.m_rCreationDate = rCreationDate;
    this.m_qc_user = qc_user;
  }

  public String getrObjectId()
  {
    return this.m_rObjectId;
  }

  public String getObjectName()
  {
    return this.m_objectName;
  }

  public String getTmfArtifactName()
  {
    return this.m_tmfArtifactName;
  }

  public String getArtifactNum()
  {
    return this.m_ArtifacNum;
  }

  public String getTmfScope()
  {
    return this.m_tmfScope;
  }

  public String getProductCode()
  {
    return this.m_productCode;
  }

  public String getClinicalTrialId()
  {
    return this.m_clinicalTrialId;
  }

  public String getZone()
  {
    return this.m_zone;
  }

  public String getSection()
  {
    return this.m_section;
  }

  public String getrCreationDate()
  {
    return this.m_rCreationDate;
  }

  public String getQCUser()
  {
    return this.m_qc_user;
  }

  
  
  public SWYTMFQcNotificationObject()
  {
  }
}

