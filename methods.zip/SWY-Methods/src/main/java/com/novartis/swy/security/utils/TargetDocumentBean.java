package com.novartis.swy.security.utils;

import java.io.Serializable;

public class TargetDocumentBean implements Serializable
{
	private String objectId=null;
	
	public String getObjectId()
	{
		return objectId;
	}
	
	
	public void setObjectId(String objId)
	{
		objectId=objId;
	}
	
}
