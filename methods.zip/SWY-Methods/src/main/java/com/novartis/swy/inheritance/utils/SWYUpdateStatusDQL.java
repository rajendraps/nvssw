package com.novartis.swy.inheritance.utils;

import com.documentum.fc.client.DfClient;
import com.documentum.fc.client.IDfClient;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.fc.common.IDfLoginInfo;

public class SWYUpdateStatusDQL {

	/*
	 * public final static String ARG_QUERY_STRING =
	 * "\"update d2_dictionary_value objects set alias_value[6]= (select distinct documentsprocessed + ' ' +"
	 * +
	 * " 'ClinicalTMFRef'  from dm_dbo.cmndiclotusspecialaccess where productcode='$value(product_code)' and "
	 * +
	 * "lower(documentsprocessed) not like '%clinicaltmfref%' and lower(domain) in ('clinical','clinical tmf','safety')) "
	 * +
	 * "where dictionary_name='CMN-DIC-Lotus-Special Access' and any alias_value='$value(product_code)'\" "
	 * ;
	 */

	IDfSysObject sysObject = null;
	IDfSessionManager sessionMgr = null;
	IDfSession session = null;

	public SWYUpdateStatusDQL(String docBaseName, String userName, String userPassword) throws Exception {
		getDfcSession(docBaseName, userName, userPassword);
	}

	/**
	 * @param docBaseName
	 * @param userName
	 * @param userPassword
	 * @return
	 * @throws Exception
	 */
	public IDfSession getDfcSession(String docBaseName, String userName, String userPassword) throws Exception {

		IDfLoginInfo login = new DfLoginInfo();
		IDfClient client = DfClient.getLocalClient();

		login.setUser(userName);
		login.setPassword(userPassword);

		sessionMgr.setIdentity(docBaseName, login);
		session = sessionMgr.getSession(docBaseName);

		if (session != null)
			System.out.println("Session Created Successfully");

		return session;
	}
	
	public void releaseSession() throws Exception
	{
		sessionMgr.release(session);		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String docBaseName = "";
		String userName = "";
		String userPassword = "";
		
		
		

	}

}
