package com.novartis.swy.utility.removeusers.utils;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfList;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.DfTime;
import com.documentum.fc.common.IDfList;
import com.documentum.ls.audit.AuditTrailItem;
import com.documentum.utils.DfcObjectUtils;
import com.documentum.utils.QueryUtils;
import com.emc.common.java.utils.ArgumentParser;
import com.emc.d2.api.methods.D2Method;
import com.opencsv.CSVParser;
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;

public class SWYRemoveUsersUtil {

	public void applyChangesToDocAllVersions(String docObjId, IDfSession session,List<String> attr_to_be_modified,
			List<String> users_to_be_updated_list, boolean isAuditNeeded, String ctxUsr,String arg_auditEvent,
			String arg_auditEventMsg, boolean arg_byPassLocks) 
	{
		HashMap<String, String> attrCurrValMap=new HashMap<String, String>();
		HashMap<String, String> attrNewValMap=new HashMap<String, String>();

		try {

			IDfSysObject sysObject	=(IDfSysObject)session.getObject(new DfId(docObjId));
			Vector<String> objIdsVector=getPreviousVersionsIds(docObjId,session);
			int versionCount=objIdsVector.size();
			DfLogger.info(this, "Processing Object Id ["+docObjId+"] No of Versions ["+versionCount+"] and Ids["+objIdsVector.toString()+"]" , null, null);

			if(versionCount>0)
			{
				for(int i=0;i<versionCount;i++)
					{

						boolean isUpdateVersionPerformed=false;
						String tmpVerObjId=objIdsVector.get(i);
						IDfSysObject versionSysObject	=(IDfSysObject)session.getObject(new DfId(tmpVerObjId));
						SWYRemoveUsersResultBean resultBeanObj=new SWYRemoveUsersResultBean();
						resultBeanObj=getUsersDataToBeRemoved(versionSysObject, attr_to_be_modified, users_to_be_updated_list, resultBeanObj);
						if(resultBeanObj.getSuccessProcessStatus()!=null && 
								resultBeanObj.getSuccessProcessStatus().toUpperCase().startsWith("SUCCESS"))
						{
							if(isAuditNeeded)
							{
								String auditAttrList=generateAttributesAuditEntry(tmpVerObjId,session,attr_to_be_modified);

								attrCurrValMap.put(tmpVerObjId, auditAttrList);
							}
							Vector<String> objIdVectorList=new Vector<String>();
							objIdVectorList.addElement(tmpVerObjId);
							disableObjectsImmutability(true,session,docObjId,objIdVectorList.size(), objIdVectorList);
							
							Map<java.lang.String,java.lang.String[]> checkedoutObjInfo=null;
							boolean isVersionChkOutAborted=false;							
							if((versionSysObject.isCheckedOut() && arg_byPassLocks))
							{
								DfLogger.info(this, "Previous version Object ["+tmpVerObjId+"] cancel checkout start ", null, null);
								checkedoutObjInfo=getCheckoutInfo(tmpVerObjId,session);
								isVersionChkOutAborted=isCheckOutAborted(tmpVerObjId,session);

								DfcObjectUtils.fetchObjectIfRequired(versionSysObject);
								DfLogger.info(this, "Previous version  Object ["+tmpVerObjId+"] cancel checkout done ", null, null);
							}
							
							Map<java.lang.String,ArrayList<String>> tmpValMAp=resultBeanObj.getUpdateValueMap();
							DfcObjectUtils.fetchObjectIfRequired(versionSysObject);

							if(tmpValMAp!=null && tmpValMAp.size()>0)
							{

								for (Map.Entry<String, ArrayList<String>> entry : tmpValMAp.entrySet()) 
								{
									String key = entry.getKey(); //attrname
									ArrayList<String> value = entry.getValue(); //values

									String srcValArr[]=value.toArray(new String[value.size()]);

									updateRepeatedAttribute(srcValArr, key, versionSysObject, false, true);
									isUpdateVersionPerformed=true;
								}
							}
							
							if(isUpdateVersionPerformed)
							{
								DfcObjectUtils.saveChangesToObjectIfRequired(versionSysObject, false, true, false, ctxUsr, session);
								DfLogger.info(this, "Target Object ["+docObjId+"] , version object ["+tmpVerObjId+"]updated and Restricted Country users removed", null, null);
								resultBeanObj.setTargetObjectId(tmpVerObjId);
								resultBeanObj.setTypeName(versionSysObject.getTypeName());
								
								if(isVersionChkOutAborted)
								{
									isAbortcheckoutCancelled(tmpVerObjId,session, checkedoutObjInfo);
									DfcObjectUtils.fetchObjectIfRequired(versionSysObject);
								}
								
								disableObjectsImmutability(false,session,docObjId,objIdVectorList.size(), objIdVectorList);
								resultBeanObj.setSuccessProcessStatus("Success");
							}

							if(isAuditNeeded)
							{
								String auditNewAttrStr=generateAttributesAuditEntry(tmpVerObjId,session,attr_to_be_modified);

								attrNewValMap.put(tmpVerObjId, auditNewAttrStr);
								String auditNewAttrList=attrNewValMap.get(tmpVerObjId);
								String auditAttrListOld=attrCurrValMap.get(tmpVerObjId);

								createAuditObject(tmpVerObjId,session,arg_auditEvent,arg_auditEventMsg,auditNewAttrList,auditAttrListOld);
							}

						}
					}
			}
		}
		catch (Exception e) {
			DfLogger.error(this, e.getLocalizedMessage(), null, e);
		}
	}

	public void disableObjectsImmutability(boolean disableImmutability,IDfSession sessionObj,String docObjId,int versionCount, 
			Vector<String> objectIdsVector) throws DfException
	{
		DfLogger.debug(this,"Processing All Versions for Id ["+docObjId+"]  Total Versions available ["+versionCount+"]",null,null);

		String immutableDql="";
		if(disableImmutability) // Disabling Immutability : Ready for update on old version documents
		{
			immutableDql="EXECUTE exec_sql WITH QUERY='update dm_sysobject_s set r_immutable_flag=0 where r_object_id  in (select distinct r.r_object_id from dm_sysobject_r r, dm_sysobject_s s where r.r_object_id=s.r_object_id and r.r_version_label!=''CURRENT'' and r.r_object_id!=''"+docObjId+"'' and s.i_chronicle_id=(select i_chronicle_id from dm_sysobject_s where r_object_id=''"+docObjId+"''))'";
			DfLogger.debug(this,"Processing Object Id ["+docObjId+"] Object Immutability False ["+immutableDql+"]",null,null);
		}
		else // Enabling Immutability : Locking for any update on old version documents
		{
			immutableDql="EXECUTE exec_sql WITH QUERY='update dm_sysobject_s set r_immutable_flag=1 where r_object_id  in (select distinct r.r_object_id from dm_sysobject_r r, dm_sysobject_s s where r.r_object_id=s.r_object_id and r.r_version_label!=''CURRENT'' and r.r_object_id!=''"+docObjId+"'' and s.i_chronicle_id=(select i_chronicle_id from dm_sysobject_s where r_object_id=''"+docObjId+"''))'";
			DfLogger.debug(this,"Processing Object Id ["+docObjId+"]  Object Immutability False ["+immutableDql+"]",null,null);

		}
		String immutableTrueDqlResultStr=QueryUtils.execQuery(immutableDql, sessionObj);

		DfLogger.debug(this, "Processing Object Id ["+docObjId+"]  Object Immutability Disable Request ["+disableImmutability+"] with DQL ["+immutableDql+"] and result  ["+immutableTrueDqlResultStr+"]", null, null);

	}
	
	/*public void disableObjectsImmutability(boolean disableImmutability,IDfSession sessionObj,String docObjId,int versionCount, 
			Vector<String> objectIdsVector) throws DfException
	{
		int batchSize=100;
		int no_of_batch=versionCount/batchSize;
		int doc_count_outside_batch=versionCount%batchSize;
		DfLogger.info(this,"Total Versions available ["+versionCount+"] No. Of batch["+no_of_batch+"] Documents count outside batch ["+doc_count_outside_batch+"] BatchSize["+batchSize+"]",null,null);

		int counter=0;
		String versionIdsAsPredicate=null;
		int total_batch=doc_count_outside_batch>0?no_of_batch+1:no_of_batch;


		for (int batchCounter=0;batchCounter<total_batch;batchCounter++)
		{
			versionIdsAsPredicate=null;
			if(batchCounter==no_of_batch)
				batchSize=doc_count_outside_batch;
			for(int j=0;j<batchSize;j++)
			{
				DfLogger.info(this,"Counter=["+counter+"]",null,null);
				if(versionIdsAsPredicate==null || versionIdsAsPredicate.trim().equalsIgnoreCase(""))
				{
					versionIdsAsPredicate="'"+objectIdsVector.get(counter)+"'";
				}
				else
				{
					versionIdsAsPredicate=versionIdsAsPredicate+ " , '"+objectIdsVector.get(counter)+"'";
				}
				counter=counter+1;
				DfLogger.info(this,"Counterrrrr=["+counter+"]",null,null);
			}

			//System.out.println("Batch ["+(batchCounter+1)+"] Processed records ["+counter+"] Version Object Ids ["+versionIdsAsPredicate+"]");
			DfLogger.info(this, "Processing Object Id ["+docObjId+"] Batch ["+(batchCounter+1)+"] Processed records ["+counter+"] Versions Object IDs as predicate ["+versionIdsAsPredicate+"]", null, null);

			if(versionIdsAsPredicate!=null && !versionIdsAsPredicate.trim().equalsIgnoreCase(""))
			{
				String immutableDql="";
				if(disableImmutability) // Disabling Immutability : Ready for update on old version documents
				{
					immutableDql="EXECUTE exec_sql WITH QUERY='update dm_sysobject_s set r_immutable_flag=0 where r_object_id  in (" + versionIdsAsPredicate.replace("'", "''") +")'";
					DfLogger.info(this,"Processing Object Id ["+docObjId+"] Object Immutability False ["+immutableDql+"]",null,null);
				}
				else // Enabling Immutability : Locking for any update on old version documents
				{
					immutableDql="EXECUTE exec_sql WITH QUERY='update dm_sysobject_s set r_immutable_flag=1 where r_object_id in ("+versionIdsAsPredicate.replace("'", "''")+") and not exists(select r_object_id from dm_sysobject_r where r_object_id in ("+ versionIdsAsPredicate.replace("'", "''") +") and r_version_label=''CURRENT'')'";
					DfLogger.info(this,"Processing Object Id ["+docObjId+"]  Object Immutability False ["+immutableDql+"]",null,null);

				}
				String immutableTrueDqlResultStr=QueryUtils.execQuery(immutableDql, sessionObj);

				DfLogger.info(this, "Processing Object Id ["+docObjId+"]  Object Immutability Disable Request ["+disableImmutability+"] with DQL ["+immutableDql+"] and result  ["+immutableTrueDqlResultStr+"]", null, null);

			}
		}
	}
*/
	public ArrayList<String> getAttributeValue(IDfSysObject docObject, String docAttribute) throws DfException
	{
		ArrayList<String> docDataList = new ArrayList<String>();

		String value = "";
		if (docObject.isAttrRepeating(docAttribute)) {
			int attrDataType = docObject.getAttrDataType(docAttribute);
			int valcount = docObject.getValueCount(docAttribute);
			if (valcount > 0) {
				for (int i = 0; i < valcount; i++) {
					value = docObject.getRepeatingString(docAttribute, i);
					if (value != null && !value.equalsIgnoreCase("")
							&& !value.trim().equalsIgnoreCase("nulldate")) {
						if (attrDataType == 4) // Time
						{
							value = "date('" + value + " utc','"
									+ ISWYRemoveUsersConstants.DCTM_DATE_ATTR_FORMAT + "')";
							docDataList.add(value );
						} else if (attrDataType == 0) // Boolean
						{
							if (value.equalsIgnoreCase("true") || value.equalsIgnoreCase("t")
									|| value.equalsIgnoreCase("1")) {
								value = "1";
							} else if (value.equalsIgnoreCase("false")
									|| value.equalsIgnoreCase("f") || value.equalsIgnoreCase("0")) {
								value = "0";
							}
							docDataList.add(value);
						} 
						else if (attrDataType == 1 || attrDataType == 5) // Number  ||  Double
						{
							docDataList.add(value );
						} 
						else if (attrDataType == 2 || attrDataType == 3) // String  || Id
						{
							docDataList.add(value);
						}

					}
				}
			}
		} else {
			value = docObject.getString(docAttribute);
			if (value != null && !value.equalsIgnoreCase("")
					&& !value.trim().equalsIgnoreCase("nulldate")) {
				int attrDataType = docObject.getAttrDataType(docAttribute);

				if (attrDataType == 4) // Time
				{
					value = "date('" + value + " utc','"
							+ ISWYRemoveUsersConstants.DCTM_DATE_ATTR_FORMAT + "')";
					docDataList.add(value);
				} else if (attrDataType == 0) // Boolean
				{
					if (value.equalsIgnoreCase("true") || value.equalsIgnoreCase("t")
							|| value.equalsIgnoreCase("1")) {
						value = "1";
					} else if (value.equalsIgnoreCase("false") || value.equalsIgnoreCase("f")
							|| value.equalsIgnoreCase("0")) {
						value = "0";
					}
					docDataList.add(value );
				} else if (attrDataType == 1 || attrDataType == 5) // Number
					// ||
					// Double
				{
					docDataList.add(value);
				} else if (attrDataType == 2 || attrDataType == 3) // String
					// ||
					// Id
				{
					docDataList.add(value);
				}

			}
		}
		return docDataList;
	}

	public int updateSingleAttributeOnVersionedDoc(String docObjId,IDfSysObject sysObject, IDfSession session, String[] attr_to_be_update, int versionCount, Vector<String> objVector) throws Exception
	{
		DfLogger.info(this, "Updating Single Attributes....", null, null);

		String dqlPredicate=null;
		for(int i=0;i<attr_to_be_update.length;i++)
		{
			String attr_name=attr_to_be_update[i];
			int attrDataType=sysObject.getAttrDataType(attr_name);
			String value=null;
			if (attrDataType == 4) // Time
			{
				value=sysObject.getTime(attr_name).asString(ISWYRemoveUsersConstants.DCTM_DATE_ATTR_FORMAT);

				if(value!=null && !value.trim().equalsIgnoreCase("nulldate") && !value.trim().equalsIgnoreCase(""))
				{
					value = "date('" + value + " utc','"
							+ ISWYRemoveUsersConstants.DCTM_DATE_ATTR_FORMAT + "')";
				}
				else
				{
					value ="date('nulldate')";
				}
				if(dqlPredicate==null || dqlPredicate.trim().equalsIgnoreCase(""))
				{
					dqlPredicate = " set "+attr_name +" ="+value;
				}
				else
				{
					dqlPredicate=dqlPredicate + " , set "+attr_name +" ="+value;;
				}

			} 
			else if (attrDataType == 0) // Boolean
			{
				value=String.valueOf(sysObject.getBoolean(attr_name));
				if (value.equalsIgnoreCase("true") || value.equalsIgnoreCase("t")
						|| value.equalsIgnoreCase("1")) {
					value = "1";
				} else if (value.equalsIgnoreCase("false")
						|| value.equalsIgnoreCase("f") || value.equalsIgnoreCase("0")) {
					value = "0";
				}

				if(dqlPredicate==null || dqlPredicate.trim().equalsIgnoreCase(""))
				{
					dqlPredicate = " set "+attr_name +" ="+value;
				}
				else
				{
					dqlPredicate=dqlPredicate + " , set "+attr_name +" ="+value;;
				}
			} 
			else if (attrDataType == 1 ) // Number 

			{
				value=String.valueOf(sysObject.getInt(attr_name));
				if(dqlPredicate==null || dqlPredicate.trim().equalsIgnoreCase(""))
				{
					dqlPredicate = " set "+attr_name +" ="+value;
				}
				else
				{
					dqlPredicate=dqlPredicate + " , set "+attr_name +" ="+value;;
				}
			}
			else if ( attrDataType == 5) //  DOUBLE

			{
				value=String.valueOf(sysObject.getDouble(attr_name));
				if(dqlPredicate==null || dqlPredicate.trim().equalsIgnoreCase(""))
				{
					dqlPredicate = " set "+attr_name +" ="+value;
				}
				else
				{
					dqlPredicate=dqlPredicate + " , set "+attr_name +" ="+value;;
				}
			}
			else if (attrDataType == 2 || attrDataType == 3) // String || ID
			{
				value=String.valueOf(sysObject.getString(attr_name));
				if(dqlPredicate==null || dqlPredicate.trim().equalsIgnoreCase(""))
				{
					dqlPredicate = " set "+attr_name +" ='"+value+"'";
				}
				else
				{
					dqlPredicate=dqlPredicate + " , set "+attr_name +" ='"+value+"'";
				}
			}
		}

		DfLogger.info(this, "Processing Object Id ["+docObjId+"]  DQL Syntax to update ["+dqlPredicate+"]", null, null);

		int versionUpdateResult=0;

		if(dqlPredicate!=null && !dqlPredicate.trim().equalsIgnoreCase(""))
		{

			int batchSize=100;
			int no_of_batch=versionCount/batchSize;
			int doc_count_outside_batch=versionCount%batchSize;
			//System.out.println("Total Versions available ["+versionCount+"] No. Of batch["+no_of_batch+"] Documents count outside batch ["+doc_count_outside_batch+"] BatchSize["+batchSize+"]");
			DfLogger.info(this, "Total Versions available ["+versionCount+"] No. Of batch["+no_of_batch+"] Documents count outside batch ["+doc_count_outside_batch+"] BatchSize["+batchSize+"]", null, null);
			int counter=0;
			String versionIdsAsPredicate=null;
			int total_batch=doc_count_outside_batch>0?no_of_batch+1:no_of_batch;


			for (int batchCounter=0;batchCounter<total_batch;batchCounter++)
			{
				versionIdsAsPredicate=null;
				if(batchCounter==no_of_batch)
					batchSize=doc_count_outside_batch;
				for(int j=0;j<batchSize;j++)
				{
					if(versionIdsAsPredicate==null || versionIdsAsPredicate.trim().equalsIgnoreCase(""))
					{
						versionIdsAsPredicate="'"+objVector.get(counter)+"'";
					}
					else
					{
						versionIdsAsPredicate=versionIdsAsPredicate+ " , '"+objVector.get(counter)+"'";
					}
					counter=counter+1;
				}

				//System.out.println("Batch ["+(batchCounter+1)+"] Processed records ["+counter+"] Version Object Ids ["+versionIdsAsPredicate+"]");
				DfLogger.info(this, "Processing Object Id ["+docObjId+"] Batch ["+(batchCounter+1)+"] Processed records ["+counter+"] Versions Object IDs as predicate ["+versionIdsAsPredicate+"]", null, null);

				String dqlToExecute=null;
				if(dqlPredicate!=null && !dqlPredicate.trim().equalsIgnoreCase("") && versionIdsAsPredicate!=null && !versionIdsAsPredicate.trim().equalsIgnoreCase(""))
				{
					dqlToExecute="Update "+sysObject.getTypeName()+"(all) objects "+ dqlPredicate +" where r_object_id in ("+versionIdsAsPredicate+")";
					DfLogger.info(this, "Processing Object Id ["+docObjId+"]  DQL to update version ["+dqlToExecute+"]", null, null);
				}


				if(dqlToExecute!=null && !dqlToExecute.trim().equalsIgnoreCase(""))
				{
					String versionUpdateResultStr=QueryUtils.execQuery(dqlToExecute, session);
					versionUpdateResult=versionUpdateResult+Integer.parseInt(versionUpdateResultStr);
					DfLogger.info(this, "Processing Object Id ["+docObjId+"]  No. of Version Obects Updated ["+versionUpdateResult+"]", null, null);
				}
			}

		}
		DfLogger.info(this, "Updating Single Attributes....END", null, null);
		return versionUpdateResult;
	}

	public int updateRepeatingAttributeOnVersionedDoc(String docObjId,IDfSysObject sysObject, IDfSession session, String attr_name, int versionCount, Vector<String> objVector) throws Exception
	{

		String dqlPredicate=null;

		int versionUpdateResult=0;
		if(dqlPredicate==null || dqlPredicate.trim().equalsIgnoreCase(""))
		{
			dqlPredicate="";
		}

		dqlPredicate= dqlPredicate+ " truncate "+attr_name + " ";

		int attrValCnt=sysObject.getValueCount(attr_name);

		if(attrValCnt>0)
		{
			int attrDataType=sysObject.getAttrDataType(attr_name);

			int attrValBatchSize=100;
			int no_of_attr_val_batch=attrValCnt/attrValBatchSize;
			int attr_val_count_outside_batch=attrValCnt%attrValBatchSize;
			DfLogger.info(this,"Attribute Name ["+attr_name+"] Total Attribute Value available ["+attrValCnt+"] No. Of batch["+no_of_attr_val_batch+"] Attribute Value count outside batch ["+attr_val_count_outside_batch+"] BatchSize["+attrValBatchSize+"]",null,null);

			int attrValCounter=0;
			int attr_val_total_batch=attr_val_count_outside_batch>0?no_of_attr_val_batch+1:no_of_attr_val_batch;


			for (int attrValBatchCounter=0;attrValBatchCounter<attr_val_total_batch;attrValBatchCounter++)
			{
				versionUpdateResult=0;

				if(attrValBatchCounter>0)
					dqlPredicate="";

				if(attrValBatchCounter==no_of_attr_val_batch)
					attrValBatchSize=attr_val_count_outside_batch;

				for(int incr=0;incr<attrValBatchSize;incr++)
				{

					String value=null;
					if (attrDataType == 4) // Time
					{
						value=sysObject.getRepeatingTime(attr_name,attrValCounter).asString(ISWYRemoveUsersConstants.DCTM_DATE_ATTR_FORMAT);
						if(value!=null && !value.trim().equalsIgnoreCase("nulldate") && !value.trim().equalsIgnoreCase(""))
						{
							value = "date('" + value + " utc','"
									+ ISWYRemoveUsersConstants.DCTM_DATE_ATTR_FORMAT + "')";
						}
						else
						{
							value ="date('nulldate')";
						}

						if(attrValBatchCounter==0)
							dqlPredicate = dqlPredicate +" , append "+attr_name +" ="+value;
						else
						{
							if(incr==0)
								dqlPredicate = dqlPredicate +"  append "+attr_name +" ="+value;
							else
								dqlPredicate = dqlPredicate +" , append "+attr_name +" ="+value;
						}
					} 
					else if (attrDataType == 0) // Boolean
					{
						value=String.valueOf(sysObject.getRepeatingBoolean(attr_name,attrValCounter));
						if (value.equalsIgnoreCase("true") || value.equalsIgnoreCase("t")
								|| value.equalsIgnoreCase("1")) {
							value = "1";
						} else if (value.equalsIgnoreCase("false")
								|| value.equalsIgnoreCase("f") || value.equalsIgnoreCase("0")) {
							value = "0";
						}
						if(attrValBatchCounter==0)
							dqlPredicate = dqlPredicate +" , append "+attr_name +" ="+value;
						else
						{
							if(incr==0)
								dqlPredicate = dqlPredicate +"  append "+attr_name +" ="+value;
							else
								dqlPredicate = dqlPredicate +" , append "+attr_name +" ="+value;
						}
					} 
					else if (attrDataType == 1 ) // Number 

					{
						value=String.valueOf(sysObject.getRepeatingInt(attr_name,attrValCounter));
						if(attrValBatchCounter==0)
							dqlPredicate = dqlPredicate +" , append "+attr_name +" ="+value;
						else
						{
							if(incr==0)
								dqlPredicate = dqlPredicate +"  append "+attr_name +" ="+value;
							else
								dqlPredicate = dqlPredicate +" , append "+attr_name +" ="+value;
						}
					}
					else if ( attrDataType == 5) //  DOUBLE

					{
						value=String.valueOf(sysObject.getRepeatingDouble(attr_name,attrValCounter));
						if(attrValBatchCounter==0)
							dqlPredicate = dqlPredicate +" , append "+attr_name +" ="+value;
						else
						{
							if(incr==0)
								dqlPredicate = dqlPredicate +"  append "+attr_name +" ="+value;
							else
								dqlPredicate = dqlPredicate +" , append "+attr_name +" ="+value;
						}
					}
					else if (attrDataType == 2 || attrDataType == 3) // String || ID
					{
						value=String.valueOf(sysObject.getRepeatingString(attr_name,attrValCounter));
						if(attrValBatchCounter==0)
							dqlPredicate = dqlPredicate +" , append "+attr_name +" ='"+value+"'";
						else
						{
							if(incr==0)
								dqlPredicate = dqlPredicate +"  append "+attr_name +" ='"+value+"'";
							else
								dqlPredicate = dqlPredicate +" , append "+attr_name +" ='"+value+"'";
						}
					}

					attrValCounter=attrValCounter+1;
				}


				DfLogger.info(this, "Processing Object Id ["+docObjId+"]  DQL Syntax to update ["+dqlPredicate+"]", null, null);

				if(dqlPredicate!=null && !dqlPredicate.trim().equalsIgnoreCase(""))
				{
					versionUpdateResult=updateAttributeOnVersionDoc( dqlPredicate,docObjId, sysObject,  session, versionCount,  objVector) ;
				}

			}
		}
		else
		{
			versionUpdateResult=updateAttributeOnVersionDoc( dqlPredicate,docObjId, sysObject,  session, versionCount,  objVector) ;
		}

		return versionUpdateResult;

	}

	private int updateAttributeOnVersionDoc(String dqlPredicate,String docObjId,IDfSysObject sysObject, IDfSession session, int versionCount, Vector<String> objVector) throws Exception
	{
		int versionUpdateResult=0;
		if(dqlPredicate!=null && !dqlPredicate.trim().equalsIgnoreCase(""))
		{

			int batchSize=100;
			int no_of_batch=versionCount/batchSize;
			int doc_count_outside_batch=versionCount%batchSize;
		//	System.out.println("Total Versions available ["+versionCount+"] No. Of batch["+no_of_batch+"] Documents count outside batch ["+doc_count_outside_batch+"] BatchSize["+batchSize+"]");
			DfLogger.info(this, "Total Versions available ["+versionCount+"] No. Of batch["+no_of_batch+"] Documents count outside batch ["+doc_count_outside_batch+"] BatchSize["+batchSize+"]", null, null);
			int counter=0;
			String versionIdsAsPredicate=null;
			int total_batch=doc_count_outside_batch>0?no_of_batch+1:no_of_batch;


			for (int batchCounter=0;batchCounter<total_batch;batchCounter++)
			{
				versionIdsAsPredicate=null;
				if(batchCounter==no_of_batch)
					batchSize=doc_count_outside_batch;
				for(int j=0;j<batchSize;j++)
				{
					if(versionIdsAsPredicate==null || versionIdsAsPredicate.trim().equalsIgnoreCase(""))
					{
						versionIdsAsPredicate="'"+objVector.get(counter)+"'";
					}
					else
					{
						versionIdsAsPredicate=versionIdsAsPredicate+ " , '"+objVector.get(counter)+"'";
					}
					counter=counter+1;
				}

				//System.out.println("Batch ["+(batchCounter+1)+"] Processed records ["+counter+"] Version Object Ids ["+versionIdsAsPredicate+"]");
				DfLogger.info(this, "Processing Object Id ["+docObjId+"] Batch ["+(batchCounter+1)+"] Processed records ["+counter+"] Versions Object IDs as predicate ["+versionIdsAsPredicate+"]", null, null);

				String dqlToExecute=null;
				if(dqlPredicate!=null && !dqlPredicate.trim().equalsIgnoreCase("") && versionIdsAsPredicate!=null && !versionIdsAsPredicate.trim().equalsIgnoreCase(""))
				{
					dqlToExecute="Update "+sysObject.getTypeName()+"(all) objects "+ dqlPredicate +" where r_object_id in ("+versionIdsAsPredicate+")";
					//System.out.println("[dqlToExecute=="+dqlToExecute+"]");
					DfLogger.info(this, "Processing Object Id ["+docObjId+"]  DQL to update version ["+dqlToExecute+"]", null, null);
				}


				if(dqlToExecute!=null && !dqlToExecute.trim().equalsIgnoreCase(""))
				{
					String versionUpdateResultStr=QueryUtils.execQuery(dqlToExecute, session);
					versionUpdateResult=versionUpdateResult+Integer.parseInt(versionUpdateResultStr);
					DfLogger.info(this, "Processing Object Id ["+docObjId+"]  No. of Version Obects Updated ["+versionUpdateResult+"]", null, null);
				}
			}

		}
		return versionUpdateResult;
	}

	public Vector<String> getPreviousVersionsIds(String docObjId, IDfSession session) throws DfException
	{
		IDfSysObject sysObject	=(IDfSysObject)session.getObject(new DfId(docObjId));
		Vector<String> objIdsVector=new Vector<String>();
		IDfCollection versionColl=null;
		try
		{
			versionColl=sysObject.getVersions("r_modify_date ,"+ISWYRemoveUsersConstants.DOC_R_OBJECT_ID_ATTR);

			while(versionColl.next())
			{
				String versionObjId=versionColl.getString(ISWYRemoveUsersConstants.DOC_R_OBJECT_ID_ATTR);
				if(!docObjId.equalsIgnoreCase(versionObjId))
				{
					objIdsVector.addElement(versionObjId);
				}
			}
		}
		finally
		{
			if(versionColl!=null)
			{
				versionColl.close();
				DfLogger.info(this, "::: getPreviousVersionsIds() ::: Collection Closed" , null, null);

			}
		}
		return objIdsVector;
	}

	public void updateSingleValueAttribute(String newValue, String targetAttribute, IDfSysObject targetObject)
			throws DfException
	{
		switch (targetObject.getAttrDataType(targetAttribute)) {
		case 2:
			targetObject.setString(targetAttribute, newValue);
			break;
		case 4:
			targetObject.setTime(targetAttribute, new DfTime(newValue,ISWYRemoveUsersConstants.DCTM_DATE_ATTR_FORMAT));
			break;
		case 0:
			targetObject.setBoolean(targetAttribute, Boolean.parseBoolean(newValue));
			break;
		case 1:
			targetObject.setInt(targetAttribute, Integer.parseInt(newValue));
			break;
		case 5:
			targetObject.setDouble(targetAttribute, Double.parseDouble(newValue));
			break;
		case 3:
			targetObject.setId(targetAttribute, new DfId(newValue));
			break;
		default:
			DfLogger.warn(this, new StringBuilder().append("Unsupported data type: {0}").append(targetObject.getAttrDataType(targetAttribute)).toString(), null, null);
		}
	}

	public void updateRepeatedAttribute(String[] newValues, String targetAttribute, IDfSysObject targetObject,boolean merge,boolean replace)
			throws DfException
	{
		switch (targetObject.getAttrDataType(targetAttribute)) {
		case 2:
			if (replace) {
				targetObject.truncate(targetAttribute, 0);
			}
			for (String newValue : newValues) {    			
				if ((replace) || (targetObject.findString(targetAttribute, newValue) < 0)) 
				{
					targetObject.appendString(targetAttribute, newValue);
				}
			}
			break;
		case 4:
			if (replace) {
				targetObject.truncate(targetAttribute, 0);
			}
			for (String newValue : newValues)
				if ((replace) || (targetObject.findTime(targetAttribute, new DfTime(newValue,ISWYRemoveUsersConstants.DCTM_DATE_ATTR_FORMAT)) < 0)) 
				{
					targetObject.appendTime(targetAttribute, new DfTime(newValue,ISWYRemoveUsersConstants.DCTM_DATE_ATTR_FORMAT));
				}

			break;
		case 0:
			if (replace) {
				targetObject.truncate(targetAttribute, 0);
			}
			for (String newValue : newValues)
			{
				if ((replace) || (targetObject.findBoolean(targetAttribute, Boolean.parseBoolean(newValue)) < 0)) 
				{
					targetObject.appendBoolean(targetAttribute, Boolean.parseBoolean(newValue));
				}
			}

			break;
		case 1:
			if (replace) {
				targetObject.truncate(targetAttribute, 0);
			}
			for (String newValue : newValues)
			{
				if ((replace) || (targetObject.findInt(targetAttribute, Integer.parseInt(newValue)) < 0)) 
				{
					targetObject.appendInt(targetAttribute, Integer.parseInt(newValue));
				}
			}

			break;
		case 5:
			if (replace) {
				targetObject.truncate(targetAttribute, 0);
			}
			for (String newValue : newValues)
			{
				if ((replace) || (targetObject.findDouble(targetAttribute,  Double.parseDouble(newValue)) < 0)) 
				{
					targetObject.appendDouble(targetAttribute, Double.parseDouble(newValue));
				}
			}

			break;
		case 3:
			if (replace) {
				targetObject.truncate(targetAttribute, 0);
			}
			for (String newValue : newValues)
			{
				if ((replace) || (targetObject.findId(targetAttribute,  new DfId(newValue)) < 0)) 
				{
					targetObject.appendId(targetAttribute, new DfId(newValue));
				}
			}

			break;
		default:
			DfLogger.warn(this, new StringBuilder().append("Unsupported data type: {0}").append(targetObject.getAttrDataType(targetAttribute)).toString(), null, null);
		}		
	}

	public void createAuditObject(String objId, IDfSession session,String audit_event ,String auditEventMsg, String auditAttrList,String auditAttrListOld) throws DfException
	{
		AuditTrailItem auditItem=new AuditTrailItem(session,audit_event);            
		auditItem.setAuditedId(new DfId(objId));
		auditItem.setTimeStamp(new DfTime());
		auditItem.setAttributeListOld(auditAttrListOld);
		auditItem.setAttributeList(auditAttrList);

		auditItem.setEventSource(this.getClass().getName());// max 64 chars.
		auditItem.setString1(auditEventMsg);
		auditItem.save();

		DfLogger.info(this, "Audit Trail item created for object ["+objId+"]", null, null);
	}

	public String generateAttributesAuditEntry(String objId, IDfSession session,List<String> attrsList ) throws DfException
	{
		IDfSysObject targetObject=(IDfSysObject)session.getObject(new DfId(objId));
		String auditAttrList=null;

		if(attrsList!=null && attrsList.size()>0)
		{

			for(int i=0;i<attrsList.size();i++)
			{
				String tarAttr=attrsList.get(i);

				if(targetObject.hasAttr(tarAttr))
				{
				ArrayList<String> targetValueList=getAttributeValue(targetObject, tarAttr);
				String[] tarCurValArr=new String[targetValueList.size()];
				targetValueList.toArray(tarCurValArr);

				if (tarCurValArr!=null && tarCurValArr.length>0)
				{
					for (int j=0;j<tarCurValArr.length;j++)
					{

						if(j==0)
						{
							if (auditAttrList==null )
							{
								auditAttrList = tarAttr + "=\"";
							}
							else
							{
								auditAttrList = auditAttrList + ", "+ tarAttr + "=\"";
							}

							auditAttrList=auditAttrList + tarCurValArr[j] ;
						}
						else
						{
							auditAttrList=auditAttrList + "," + tarCurValArr[j] ;
						}						
					}

					auditAttrList=auditAttrList + "\"";
				}
			}
			}
		}

		return auditAttrList;
	}

	public Map<java.lang.String,java.lang.String[]> getCheckoutInfo(String objId,IDfSession session)  throws DfException
	{
		String dql_get_checkedOutInfo="select r_lock_owner,r_lock_machine,datetostring(r_lock_date,'"+ISWYRemoveUsersConstants.DQL_DATE_ATTR_YYYYMMDDHHMISS_FORMAT+"') as r_lock_date,r_modifier,i_vstamp from dm_document(all)  where r_object_id='"+objId+"'";
		Map<java.lang.String,java.lang.String[]> coll_Checked_Out=QueryUtils.getAllQueryResultColumnValues(dql_get_checkedOutInfo,true,session);

		return coll_Checked_Out;
	}

	/**
	 * This method cancel the checkout operation by releasing the lock from document.
	 * @param objId : Object Id of the document for which performing cancel checkout
	 * @param session : session
	 * @param calculate_sec_statistics: True or False. If true, means checkout operation needs to check only for statistics. If false, checkout operation needs to perform on document. 
	 * @return
	 * @throws DfException
	 */
	public boolean isCheckOutAborted(String objId,IDfSession session) throws DfException
	{
		//boolean calculate_sec_statistics=argParser.getBooleanArgument(ARG_CALCULATE_SECRF_STATISTICS, false);
		boolean isCheckOutCancel=false;
		DfLogger.info(this, "::: isCheckOutAborted () ::  >> "+objId  ,null, null);

		Map<java.lang.String,java.lang.String[]> coll_Checked_Out=getCheckoutInfo(objId,session);
		String lock_owner=coll_Checked_Out.get("r_lock_owner")[0];

		//DfLogger.info(this,"Validating Document["+objId+"] is Checked-out or not r_lock_date["+lock_time+"] r_lock_owner["+lock_owner+"] r_lock_machine["+lock_machine+"] r_modifier["+doc_last_modifier+"] i_vstamp["+count_vstamp+"]",null,null);

		//if(!StringUtils.isNullOrEmpty(lock_owner) )	//Document is checked-out
		if(!lock_owner.trim().equalsIgnoreCase("") )	//Document is checked-out
		{
			DfLogger.info(this,"Document ["+objId+"] is checked out",null,null);
			String empty_val=" ";

			String lock_machine=coll_Checked_Out.get("r_lock_machine")[0];
			int count_vstamp=Integer.parseInt(coll_Checked_Out.get("i_vstamp")[0]);

			String tmpDQL="EXECUTE exec_sql WITH query='update dm_sysobject_s set r_lock_owner=''"+empty_val+"'' , i_vstamp=''"+(count_vstamp+1)+"'' where r_object_id=''"+objId+"'' ';";
			DfLogger.info(this,"DQL to remove lock owner for applying SecRF ["+tmpDQL+"]",null,null);
			//System.out.println("DQL to remove lock owner for applying SecRF ["+tmpDQL+"]");
			QueryUtils.execQuery(tmpDQL,session);

			String auditAttrList="r_lock_owner="+empty_val+", i_vstamp="+(count_vstamp+1)+",r_lock_machine="+empty_val;
			String auditAttrListOld="r_lock_owner="+lock_owner+", i_vstamp="+(count_vstamp)+",r_lock_machine="+lock_machine;
			createAuditObject(objId,session,"dm_unlock","Update attributes to unlock object before applying SecRF",auditAttrList,auditAttrListOld);

			isCheckOutCancel=true;

			DfLogger.info(this, "Document Checkout cancellation status ["+isCheckOutCancel+"]", null, null);
		}
		return isCheckOutCancel;
	}

	public boolean isAbortcheckoutCancelled(String objId,IDfSession session, Map<java.lang.String,java.lang.String[]> coll_Checked_Out) throws DfException
	{
		//boolean calculate_sec_statistics=argParser.getBooleanArgument(ARG_CALCULATE_SECRF_STATISTICS, false);
		IDfSysObject sysTmpObject=(IDfSysObject)session.getObject(new DfId(objId));
		sysTmpObject.fetch(null);

		boolean isAbortcheckoutCancel=false;
		DfLogger.info(this, "::: isAbortcheckoutCancelled () ::: >> " , null, null);
		String lock_time=coll_Checked_Out.get("r_lock_date")[0];
		DfLogger.info(this,"lock_time   ["+lock_time+"]",null,null);
		String lock_owner=coll_Checked_Out.get("r_lock_owner")[0];
		String lock_machine=coll_Checked_Out.get("r_lock_machine")[0];
		String doc_last_modifier=coll_Checked_Out.get("r_modifier")[0];
		int count_vstamp=sysTmpObject.getVStamp();

		if(lock_machine==null || lock_machine.length()==0)
		{
			DfLogger.info(this," Lock machine was null for object id ["+objId+"]",null,null);
			lock_machine=" ";
		}

		String empty_val=" ";

		String tmpDQL="EXECUTE exec_sql WITH query='update dm_sysobject_s set r_modifier=''"+doc_last_modifier+"'' , r_lock_owner=''"+lock_owner+"'' "
				+ ", r_lock_machine=''"+lock_machine+"'' , r_lock_date=TO_DATE(''"+lock_time+"'' ,''"+ISWYRemoveUsersConstants.ORACLE_DATE_ATTR_FORMAT+"'' ) , i_vstamp=''"+(count_vstamp+1)+"'' "
				+ "where r_object_id=''"+objId+"'' ';";
		DfLogger.info(this,"DQL to put lock owner after applying SecRF ["+tmpDQL+"]",null,null);
		//System.out.println("DQL to put lock owner after applying SecRF ["+tmpDQL+"]");
		QueryUtils.execQuery(tmpDQL,session);

		String auditAttrList="r_lock_owner="+lock_owner+", i_vstamp="+(count_vstamp+1)+",r_lock_machine="+lock_machine+",r_lock_date="+lock_time+",r_modifier="+doc_last_modifier;
		String auditAttrListOld="r_lock_owner="+empty_val+", i_vstamp="+(count_vstamp)+",r_lock_machine="+empty_val;
		createAuditObject(objId,session,"dm_lock","Update attributes to relock object",auditAttrList,auditAttrListOld);

		isAbortcheckoutCancel=true;

		DfLogger.info(this, "Document isAbortcheckoutCancel status ["+isAbortcheckoutCancel+"]", null, null);
		return isAbortcheckoutCancel;
	}

	public void applyingSecurity(String qualification, IDfSession session,boolean needToapplysecurity, String acl_threshold) 
	{

		try {
			DfLogger.info(this, "session.getDocbaseName() "+ session.getDocbaseName()+ "  session.getLoginUserName()  "+session.getLoginUserName(), null, null);
			HashMap<String, String> aParserMap = new HashMap<String, String>();
			//aParserMap.put("-class_name", "com.emc.d2.api.methods.D2CoreMethod");
			//aParserMap.put("-docbase_name", session.getDocbaseName());
			//aParserMap.put("-user_name", session.getLoginUserName());
			//aParserMap.put("-password", "");
			//aParserMap.put("-qualifier", qualification);
			//aParserMap.put("-distributed_processing_threshold", ISWYRemoveUsersConstants.MTHD_DISTRIBUTED_PROCESSING_THRESHOLD);
			//aParserMap.put("-id", docObjectId);
			//aParserMap.put("-create", Boolean.toString(false));
			//aParserMap.put("-naming", Boolean.toString(false));
			//aParserMap.put("-autolink", Boolean.toString(false));
			//aParserMap.put("-security", Boolean.toString(needToapplysecurity));
			//aParserMap.put("-force_security", Boolean.toString(false));
			//aParserMap.put("-apply_for_vd", Boolean.toString(false));
			//aParserMap.put("-transaction", Boolean.toString(false));

			//ArgumentParser aParser = new ArgumentParser(aParserMap);

			//applyD2CoreMethod(aParser);


			String method_args= " -docbase_name " + session.getDocbaseName();
			method_args=method_args+" -user_name " + session.getServerConfig().getString("r_install_owner");
			method_args=method_args+" -qualifier " + qualification;

			if(acl_threshold!=null && !acl_threshold.isEmpty())
			{
				int threshold=0;
				try
				{
					threshold=Integer.parseInt(acl_threshold);
				}
				catch(NumberFormatException e)
				{
					threshold=0;
				}

				if (threshold!=0 && threshold>100 )
				{
					method_args=method_args+" -distributed_processing_threshold " + acl_threshold+"";
				}
			}

			method_args=method_args+" -create false" ;
			method_args=method_args+" -naming false" ;
			method_args=method_args+" -autolink false" ;
			method_args=method_args+" -security "+ Boolean.toString(needToapplysecurity)+"";
			method_args=method_args+" -force_security false" ;
			method_args=method_args+" -apply_for_vd false" ;

			IDfList list1=new DfList();
			IDfList list2=new DfList();
			IDfList list3=new DfList();

			list1.append("METHOD");
			list1.appendString("RUN_AS_SERVER");
			list1.appendString("LAUNCH_ASYNC");
			list1.append("ARGUMENTS");

			list2.append("s");		// Corresponding to "METHOD" 
			list2.appendString("b");
			list2.appendString("b");
			list2.append("s");		// Corre4sponding to "ARGUMENTS"

			list3.append(ISWYRemoveUsersConstants.MTHD_AD2C_NAME);
			list3.appendString("T");
			list3.appendString("F");
			list3.append(method_args);

			DfLogger.info(this, "Applying Security with: method name {0} and arguments {1}", new String[]{ISWYRemoveUsersConstants.MTHD_AD2C_NAME,method_args}, null);
			IDfCollection methodColl=null;
			try
			{
				methodColl=session.apply(null,"DO_METHOD",list1,list2,list3); 
				DfLogger.info(this, "Applying Security called with: method name {0} and arguments {1}", new String[]{ISWYRemoveUsersConstants.MTHD_AD2C_NAME,method_args}, null);

			}
			finally
			{
				if (methodColl!=null)
				{
					methodColl.close();

					DfLogger.info(this, "Closing the methods call that was opened for Applying Security request", null, null);
				}
			}
		}
		catch (Exception e) {
			DfLogger.error(this, e.getLocalizedMessage(), null, e);
		}		
	}

	public void applyD2CoreMethod(ArgumentParser aParser) throws Exception {
		DfLogger.info(this, "Applying Security:::: processing applyD2CoreMethod()", null, null);

		try {
			D2Method.main(aParser);
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			DfLogger.error(this, "Applying Security:::: processing applyD2CoreMethod() " + e.getLocalizedMessage(),
					null, e);
		}
	}

	public ArrayList<String> getUserListFromCSV(String csvFilePath)
	{
		//CSV with one column only

		List<String[]> allData= null;
		ArrayList<String> csvUserNameList =null;
		try {

			FileReader filereader = new FileReader(csvFilePath);

			CSVParser parser = new CSVParserBuilder().withSeparator(ISWYRemoveUsersConstants.CSV_READ_USERS_DELIMITER).build();

			CSVReader csvReader = new CSVReaderBuilder(filereader)
					.withCSVParser(parser)
					.build();

			allData = csvReader.readAll();
			csvUserNameList = new ArrayList<String> ();

			if(allData!=null && allData.size()>0)
			{
				for(int i=0;i<allData.size();i++)
				{
					if (i>0)
					{
						for (String cell : allData.get(i)) {
							csvUserNameList.add(cell);
							//System.out.print(cell + "\t");
						}

						//System.out.println();
					}
				}
			}

		}
		catch(IOException ioe) {
			ioe.printStackTrace();
		}
		return csvUserNameList;
	}

	public SWYRemoveUsersResultBean getUsersDataToBeRemoved(IDfSysObject targetObj,List<String> attr_to_be_modified, List<String> users_to_be_updated_list, 
			SWYRemoveUsersResultBean beanObj ) 
					throws DfException 
	{
		if(targetObj!=null)
		{
			String targetObjType=targetObj.getTypeName();
			String targetObjId=targetObj.getObjectId().getId();
			if (users_to_be_updated_list!=null && users_to_be_updated_list.size()>0)
			{
				if(attr_to_be_modified!=null && attr_to_be_modified.size()>0)
				{
					for (int i=0;i<attr_to_be_modified.size();i++)
					{
						String attrToBeModified=attr_to_be_modified.get(i);
						if (targetObj.hasAttr(attrToBeModified))
						{
							ArrayList<String> objAttrValueList=getAttributeValue(targetObj, attrToBeModified);
							//String[] srcValArr=new String[valueList.size()];
							//valueList.toArray(srcValArr);
							if(targetObj.isAttrRepeating(attrToBeModified))  //repeating
							{
								boolean isExistingValueRemoved=false;
								if (objAttrValueList!=null && objAttrValueList.size()>0)
								{
									ArrayList<String> tmpObjArrayList=new ArrayList<String> (objAttrValueList);

								//	System.out.println(objAttrValueList.size() +" " + users_to_be_updated_list.size());
									if(objAttrValueList.size() >= users_to_be_updated_list.size())
									{
										DfLogger.info(this,targetObjId+" ::: objAttrValueList.size() >= users_to_be_updated_list.size()",null,null);
										for(int j=0;j<users_to_be_updated_list.size();j++)
										{
											String usertoBeRemoved=users_to_be_updated_list.get(j);
											if(tmpObjArrayList.contains(usertoBeRemoved))
											{
												//int index=targetObj.findString(attrToBeModified, usertoBeRemoved);
												tmpObjArrayList.remove(usertoBeRemoved);
												isExistingValueRemoved=true;
												DfLogger.info(this,targetObjId+" ::: usertoBeRemoved "+usertoBeRemoved +" valueSize="+objAttrValueList.size()+"",null,null);
											}
										}
									}
									else if(users_to_be_updated_list.size() > objAttrValueList.size())
									{
										DfLogger.info(this,targetObjId+" ::: users_to_be_updated_list.size() > objAttrValueList.size()",null,null);
										for(int j=0;j<objAttrValueList.size();j++)
										{
											String usertoBeRemoved=objAttrValueList.get(j);
											if(users_to_be_updated_list.contains(usertoBeRemoved))
											{
												tmpObjArrayList.remove(usertoBeRemoved);
												isExistingValueRemoved=true;
												DfLogger.info(this,targetObjId+" ::: usertoBeRemoved "+usertoBeRemoved +" valueSize="+objAttrValueList.size()+"",null,null);
											}
										}

									}

									if (isExistingValueRemoved)
									{
										if(tmpObjArrayList.size()>0)
										{
											objAttrValueList=null;
											objAttrValueList=new ArrayList<String> (tmpObjArrayList);

											Map<java.lang.String,ArrayList<String>> tmpMap=beanObj.getUpdateValueMap();

											if(tmpMap!=null && tmpMap.size()>0)
											{
												if(!tmpMap.containsKey(attrToBeModified))
												{
													tmpMap.put(attrToBeModified, objAttrValueList);
												}
											}
											else
											{
												if(tmpMap==null)
												{
													tmpMap=new HashMap<java.lang.String,ArrayList<String>>();	
												}
												tmpMap.put(attrToBeModified, objAttrValueList);
											}

											beanObj.setUpdateValueMap(tmpMap);
											beanObj.setSuccessProcessStatus("SUCCESS "+ISWYRemoveUsersConstants.PROCESS_REQUIRED);
											DfLogger.info(this,targetObjId+" ::: Values needs to update against attribute ["+attrToBeModified+"]",null,null);
										}
										else if(tmpObjArrayList.size()==0)
										{
											objAttrValueList=new ArrayList<String> ();											
											Map<java.lang.String,ArrayList<String>> tmpMap=beanObj.getUpdateValueMap();

											if(tmpMap!=null && tmpMap.size()>0)
											{
												if(!tmpMap.containsKey(attrToBeModified))
												{
													tmpMap.put(attrToBeModified, objAttrValueList);
												}
											}
											else
											{
												if(tmpMap==null)
												{
													tmpMap=new HashMap<java.lang.String,ArrayList<String>>();	
												}
												tmpMap.put(attrToBeModified, objAttrValueList);
											}
											
											beanObj.setUpdateValueMap(tmpMap);
											beanObj.setSuccessProcessStatus("SUCCESS "+ISWYRemoveUsersConstants.INFORM_BUSINESS);
											beanObj.setTypeName(targetObj.getTypeName());
											beanObj.setTargetObjectId(targetObjId);
											DfLogger.info(this,targetObjId+" ::: Need to inform Business as all existing values could be deleted from attribute ["+attrToBeModified+"]",null,null);
											//inform Business as all existing values could be deleted
										}
										DfLogger.info(this,targetObjId+" ::: New value size ["+objAttrValueList.size()+"]",null,null);
									}
									else
									{
										beanObj.setFailedProcessStatus("Failed "+ISWYRemoveUsersConstants.PROCESS_NOT_REQUIRED);
										beanObj.setTypeName(targetObj.getTypeName());
										beanObj.setTargetObjectId(targetObjId);
										DfLogger.info(this,targetObjId+" ::: Nothing removed from attribute ["+attrToBeModified+"]",null,null);
									}
								}
								else
								{
									DfLogger.info(this,targetObjId+" ::: Attribute doesn't have any value ["+attrToBeModified+"]",null,null);
								}
							}
							else //single
							{
								if (objAttrValueList!=null && objAttrValueList.size()>0)
								{
									String valueToBeChkAndRemove=objAttrValueList.get(0);
									if(users_to_be_updated_list.contains(valueToBeChkAndRemove))
									{
										objAttrValueList=new ArrayList<String> ();											
										Map<java.lang.String,ArrayList<String>> tmpMap=beanObj.getUpdateValueMap();

										if(tmpMap!=null && tmpMap.size()>0)
										{
											if(!tmpMap.containsKey(attrToBeModified))
											{
												tmpMap.put(attrToBeModified, objAttrValueList);
											}
										}
										else
										{
											if(tmpMap==null)
											{
												tmpMap=new HashMap<java.lang.String,ArrayList<String>>();	
											}
											tmpMap.put(attrToBeModified, objAttrValueList);
										}
										beanObj.setUpdateValueMap(tmpMap);
										beanObj.setSuccessProcessStatus("SUCCESS "+ISWYRemoveUsersConstants.INFORM_BUSINESS);
										beanObj.setTypeName(targetObj.getTypeName());
										beanObj.setTargetObjectId(targetObjId);
										//inf
										DfLogger.info(this,targetObjId+" ::: Need to inform Business as all existing values (single attribute ["+attrToBeModified+"] ) could be deleted",null,null);
									}
								}
							}
						}
						else
						{
							String warn_msg="Object id ["+targetObjId+"] of type ["+targetObjType+"] doesn't have attribute ["+attrToBeModified+"] ";

							beanObj.setFailedProcessStatus(ISWYRemoveUsersConstants.WARN + "#" + warn_msg);
							DfLogger.info(this,warn_msg , null, null);
						}
					}

				}
				else
				{
					String warn_msg="List of attributes which needs to validate and update is empty";
					beanObj.setFailedProcessStatus(ISWYRemoveUsersConstants.WARN + "#" + warn_msg);
					DfLogger.info(this, warn_msg, null, null);
				}
			}
			else
			{
				String warn_msg="List of users which needs to remove is empty";
				beanObj.setFailedProcessStatus(ISWYRemoveUsersConstants.WARN + "#" + warn_msg);
				DfLogger.info(this,warn_msg , null, null);
			}
		}
		else
		{
			String warn_msg="Object is null ";
			beanObj.setFailedProcessStatus(ISWYRemoveUsersConstants.WARN + "#" + warn_msg);
			DfLogger.info(this,warn_msg , null, null);
		}

		return beanObj;
	}


}
