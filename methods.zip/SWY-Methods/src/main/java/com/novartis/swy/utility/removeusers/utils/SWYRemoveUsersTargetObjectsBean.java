package com.novartis.swy.utility.removeusers.utils;

import java.io.Serializable;

public class SWYRemoveUsersTargetObjectsBean implements Serializable
{
	private String targetObjectId=null;
	private String targetObjectType=null;
	private String srcObjectId=null;
	
	private SWYRemoveUsersBean inheritBeanObj=null;
	
	public SWYRemoveUsersBean getAttributeInheritanceData()
	{
		return inheritBeanObj;
	}
	
	
	public void setAttributeInheritanceData(SWYRemoveUsersBean beanObj)
	{
		inheritBeanObj=beanObj;
	}
	
	
	
	public String getTargetObjectId()
	{
		return targetObjectId;
	}
	
	
	public void setTargetObjectId(String objId)
	{
		targetObjectId=objId;
	}
	
	public String getTargetObjectType()
	{
		return targetObjectType;
	}
	
	
	public void setTargetObjectType(String targetType)
	{
		targetObjectType=targetType;
	}
	
	public String getSourceObjectId()
	{
		return srcObjectId;
	}
	
	
	public void setSourceObjectId(String objId)
	{
		srcObjectId=objId;
	}
	
	
}
