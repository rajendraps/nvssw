package com.novartis.swy.inheritance;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import com.documentum.cdf.methods.DistributedD2Method;
import com.documentum.cdf.methods.IDistributedD2Method;
import com.documentum.cdf.methods.TaskResult;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfId;
import com.documentum.utils.AttributeExpression;
import com.documentum.utils.DfcObjectUtils;
import com.documentum.utils.QueryUtils;
import com.emc.common.java.utils.ArgumentParser;
import com.emc.d2.api.methods.D2Method;
import com.emc.d2.api.methods.D2methodBean;
import com.novartis.swy.inheritance.utils.SWYAttributeInheritanceBean;
import com.novartis.swy.inheritance.utils.ISWYApplyInheritanceConstants;
import com.novartis.swy.inheritance.utils.SWYResultBean;
import com.novartis.swy.inheritance.utils.SWYInheritanceUtil;
import com.novartis.swy.inheritance.utils.SWYTargetObjectsBean;

// merge, replace , @--> Target Objects , $--> Source Objects
public class SWYApplyInheritance extends DistributedD2Method implements IDistributedD2Method{

	public static final String ARG_CONTEXT_USER = "-context_user";
	public static final String ARG_SELECTED_OBJECT_ID = "-id";
	public static final String ARG_TARGET_OBJECT_DQL= "-target";
	public static final String ARG_SOURCE_OBJECT_ID= "-source"; // Required 
	public static final String ARG_ATTRIBUTES= "-attributes";  // Required
	/**
	 * -attributes "merge-tar1-src1~replace-tar2-src2~replace-tar3-src3~replace-tar5-@tar4~replace-tar4-[staticvalue]
	 * ~replace-swy_lotus_divisions-#execdql(select name from dm_dbo.cmndicdivisions where name in (select  swy_divisions from cd_quality where r_object_id='@value(r_object_id)'))"
	 */
	public static final String ARG_ENABLED_AUDIT= "-audit_enabled";  // true or false
	public static final String ARG_AUDIT_EVENT_NAME="-audited_event_name"; // optional
	public static final String ARG_AUDIT_EVENT_MSG="-audited_event_msg"; // optional
	public static final String ARG_BYPASS_LOCKS="-bypass_locks"; // true or false -->Default . // true means unlock , process and relock. False means skip the object 
	public static final String ARG_UPDATE_versions="-update_versions"; // true or false -->Default
	public static final String ARG_SECURITY = "-update_security"; // true or false -->Default
	public static final String ARG_UPDATE_ACL_QUAL = "-update_security_qual"; // the DQL qualification on which ACL needs to refresh
	public static final String ARG_ACL_THRESHOLD= "-security_qual_threshold"; // ACL Threshold
	public static final String ARG_SINGLE_UPDATE_DQL = "-update_status_DQL"; // this DQL can be use to update some objects to maintain status of processed objects

	private ArgumentParser argParser=null;
	private String attributes=null;
	private Boolean enabledAudit=false;
	private String auditEvent=null;
	private String auditEventMsg=null;
	private Boolean byPassLocks=false; // true means unlock , process and relock. False means skip the object 
	private String aclThreshold=null;
	private Boolean updateVersions=false;
	private Boolean applySecurity=false;
	String context_user=null;
	private String updateACLQual=null;
	private String updateStatusDQL=null;

	SWYInheritanceUtil inheritUtil=new SWYInheritanceUtil();

	@Override
	public String getMethodName() {
		return ISWYApplyInheritanceConstants.DM_METHOD_NAME;
	}

	public Serializable[] getTaskData(IDfSession paramIDfSession, IDfSysObject paramIDfSysObject, Locale paramLocale, 
			ArgumentParser paramArgumentParser) throws DfException {

		DfLogger.warn(this,"************************************** "+ISWYApplyInheritanceConstants.DM_METHOD_NAME+" *****************************************************************",null,null);

		//IDfId  objId 	  = paramArgumentParser.getIdArgument(ARG_SELECTED_OBJECT_ID, null); // current context object
		String targetQuery=paramArgumentParser.getStringArgument(ARG_TARGET_OBJECT_DQL, null); // Complete DQL to retrieve target objects
		String source=paramArgumentParser.getStringArgument(ARG_SOURCE_OBJECT_ID, null);  // Single r_object_id or complete DQL which returns single r_object_id only
		attributes=paramArgumentParser.getStringArgument(ARG_ATTRIBUTES, null);
		enabledAudit=paramArgumentParser.getBooleanArgument(ARG_ENABLED_AUDIT, false);
		auditEvent=paramArgumentParser.getStringArgument(ARG_AUDIT_EVENT_NAME, null);
		auditEventMsg=paramArgumentParser.getStringArgument(ARG_AUDIT_EVENT_MSG, null);
		byPassLocks=paramArgumentParser.getBooleanArgument(ARG_BYPASS_LOCKS, false);
		updateVersions=paramArgumentParser.getBooleanArgument(ARG_UPDATE_versions, false);
		applySecurity=paramArgumentParser.getBooleanArgument(ARG_SECURITY, false);
		context_user=paramArgumentParser.getStringArgument(ARG_CONTEXT_USER, null);
		updateACLQual=paramArgumentParser.getStringArgument(ARG_UPDATE_ACL_QUAL, null);
		updateStatusDQL=paramArgumentParser.getStringArgument(ARG_SINGLE_UPDATE_DQL, null);
		aclThreshold=paramArgumentParser.getStringArgument(ARG_ACL_THRESHOLD, null);


		String[] targetIds=null;
		SWYTargetObjectsBean [] swyBeanArray=null;
		String srcObjectId=null;

		/** 
		 * start of Retrieving source object 
		 * 
		 */
		if (source!=null  && !source.isEmpty())
		{
			IDfId  tmpSrcObjId=new DfId(source);
			if(tmpSrcObjId.isObjectId())
			{
				srcObjectId=tmpSrcObjId.getId();
				DfLogger.info(this,"Source object is explicitly defined i.e. "+srcObjectId,null, null);
			}
			else
			{
				//DQL
				if(source.toLowerCase().startsWith("select") && source.toLowerCase().contains("from"))
				{
					String[] srcIds=null;
					srcIds=QueryUtils.getAllQueryResultsAsStrings(source,paramIDfSession) ;

					if(srcIds!=null && srcIds.length==1)
					{
						DfLogger.info(this,"Source DQL is returning 1 object",null, null);
						srcObjectId=srcIds[0];
					}
					else if (srcIds==null || srcIds.length==0 || srcIds.length>1)
					{
						DfLogger.error(this,"Source DQL is not defined properly, either returning 0 or more than 1 records",null, null);
						swyBeanArray=new SWYTargetObjectsBean [1] ;
						swyBeanArray[0]=new SWYTargetObjectsBean();
						return swyBeanArray;
					}
				}
				else
				{
					DfLogger.error(this,"Source DQL is incorrectly defined",null, null);
					swyBeanArray=new SWYTargetObjectsBean [1] ;
					swyBeanArray[0]=new SWYTargetObjectsBean();
					return swyBeanArray;
				}
			}
		}

		/** 
		 * End of Retrieving source object 
		 * 
		 */	

		/** 
		 * start of Retrieving source object data based on sourced attributes 
		 * 
		 */
		IDfSysObject sourceObject=(IDfSysObject)paramIDfSession.getObject(new DfId(srcObjectId));

		String arg_attributes=attributes;

		ArrayList<String[]> action_attributes_list=new ArrayList<String[]>();

		if(arg_attributes!=null && !arg_attributes.isEmpty())
		{

			String[] attributes=arg_attributes.split("~");
			if(attributes!=null && attributes.length>0)
			{
				for(int i=0;i<attributes.length;i++)
				{
					String action_details=attributes[i];
					String strAction=action_details.substring(0, action_details.indexOf("-"));
					action_details=action_details.substring(action_details.indexOf("-")+1,action_details.length());
					String strTarAttrName=action_details.substring(0, action_details.indexOf("-"));
					action_details=action_details.substring(action_details.indexOf("-")+1,action_details.length());
					String strSrcValue=action_details;

					String[] action_attrs_arr=new String[3];
					action_attrs_arr[0]=strAction;
					action_attrs_arr[1]=strTarAttrName;
					action_attrs_arr[2]=strSrcValue;

					if(!action_attrs_arr[0].isEmpty() && !action_attrs_arr[1].isEmpty() && !action_attrs_arr[2].isEmpty())
					{
						action_attributes_list.add(action_attrs_arr);
					}
					else
					{
						DfLogger.error(this," parameter against argument "+ARG_ATTRIBUTES+" is not defined properly",null,null);
						swyBeanArray=new SWYTargetObjectsBean [1] ;
						swyBeanArray[0]=new SWYTargetObjectsBean();
						return swyBeanArray;
					}

					/*String[] action_attrs=attributes[i].split("-");
					if(action_attrs.length>0 && action_attrs!=null)
					{
						action_attributes_list.add(action_attrs);
					}
					else
					{
						DfLogger.error(this," parameter against argument "+ARG_ATTRIBUTES+" is not defined properly",null,null);
						return null;
					}*/
				}
			}
			else
			{
				DfLogger.error(this,ARG_ATTRIBUTES + " parameter is not defined properly",null,null);
				swyBeanArray=new SWYTargetObjectsBean [1] ;
				swyBeanArray[0]=new SWYTargetObjectsBean();
				return swyBeanArray;
			}		
		}
		else
		{
			DfLogger.error(this,ARG_ATTRIBUTES + " param is not defined properly",null,null);
			swyBeanArray=new SWYTargetObjectsBean [1] ;
			swyBeanArray[0]=new SWYTargetObjectsBean();
			return swyBeanArray;
		}

		SWYAttributeInheritanceBean attrInheritBean=new SWYAttributeInheritanceBean();

		for(int i=0;i<action_attributes_list.size();i++)
		{
			String[] act_src_tar_list=action_attributes_list.get(i);
			String action=act_src_tar_list[0];
			String srcAttr=act_src_tar_list[2];
			String tarAttr=act_src_tar_list[1];

			attrInheritBean.setAction(action);
			attrInheritBean.setTargetAttribute(tarAttr);
			attrInheritBean.setSourceAttribute(srcAttr);

			if(srcAttr.startsWith("@")) // Represting source attribute will from target object itself	
			{
				attrInheritBean.setSourceAttrValue(null);	// Representing source attribute will from target object itself			
			}
			else if (srcAttr.startsWith("#execdql")) // Representing source will be the DQL
			{
				attrInheritBean.setSourceAttrValue(new String[]{srcAttr});
			}
			else if (srcAttr.startsWith("[")) // Representing instead of source attribute there is static value , enclosed between []	
			{

				String str=srcAttr.substring(1, srcAttr.length()-1).trim();

				String[] tmpArr=str.split(",");
				attrInheritBean.setSourceAttrValue(tmpArr);
				//attrInheritBean.setSourceAttrValue(new String[]{srcAttr.substring(1, srcAttr.length()-1).trim()});
			}
			else if(sourceObject.hasAttr(srcAttr) && !srcAttr.startsWith("[") && !srcAttr.startsWith("@")) // retrieving value from source attribute
			{ 
				ArrayList<String> valueList=inheritUtil.getAttributeValue(sourceObject, srcAttr);
				String[] valArr=new String[valueList.size()];
				valueList.toArray(valArr);

				attrInheritBean.setSourceAttrValue(valArr);
			}
			else
			{
				DfLogger.info(this,ARG_ATTRIBUTES + " parameter is not defined properly for source Attribute["+srcAttr+"]",null,null);
			}

		}

		/** 
		 * End of Retrieving source object data based on sourced attributes 
		 * 
		 */

		/** 
		 * start of Retrieving target objects 
		 * 
		 */
		DfLogger.debug(this,"Passed Target DQL=["+targetQuery+"]",null, null);
		targetQuery=AttributeExpression.resolve(targetQuery, sourceObject, paramIDfSession.getLoginUserName());
		DfLogger.info(this,"Resolved Target DQL=["+targetQuery+"]",null, null);
		if(targetQuery!=null && !targetQuery.equalsIgnoreCase(""))
		{
			targetIds=QueryUtils.getAllQueryResultsAsStrings(targetQuery,paramIDfSession) ;
		}

		if (targetIds==null || targetIds.length==0)
		{
			DfLogger.warn(this, "No objectss to process where Attribute Inheritance needs to applyy", null, null);
			swyBeanArray=new SWYTargetObjectsBean [1] ;
			swyBeanArray[0]=new SWYTargetObjectsBean();
			return swyBeanArray;
		}
		else
		{
			swyBeanArray=new SWYTargetObjectsBean[targetIds.length];

			for(int i=0;i<swyBeanArray.length;i++)
			{
				swyBeanArray[i]=new SWYTargetObjectsBean();
				swyBeanArray[i].setTargetObjectId(targetIds[i]);
				swyBeanArray[i].setSourceObjectId(srcObjectId);
				swyBeanArray[i].setAttributeInheritanceData(attrInheritBean);
			}
		}
		/** 
		 * End of Retrieving target objects 
		 * 
		 */

		if( swyBeanArray!=null)
		{
			DfLogger.warn(this, "No. of objects to be processed  " + swyBeanArray.length +" where Attribute Inheritance needs to apply", null, null);
		}

		return swyBeanArray;
	}



	@Override
	public Map<String, String> getSlaveMethodArgs() throws DfException 
	{
		DfLogger.warn(this,"****************Starting getSlaveMethodArgs()*******************************************",null, null);
		Map<String, String> methodArgs = new HashMap<>();

		methodArgs.put(ARG_ATTRIBUTES,attributes);
		methodArgs.put(ARG_ENABLED_AUDIT,String.valueOf(enabledAudit));
		methodArgs.put(ARG_AUDIT_EVENT_NAME,auditEvent);
		methodArgs.put(ARG_AUDIT_EVENT_MSG,auditEventMsg);
		methodArgs.put(ARG_ENABLED_AUDIT,String.valueOf(enabledAudit));
		methodArgs.put(ARG_BYPASS_LOCKS,String.valueOf(byPassLocks));
		methodArgs.put(ARG_UPDATE_versions,String.valueOf(updateVersions));
		methodArgs.put(ARG_SECURITY,String.valueOf(applySecurity));
		methodArgs.put(ARG_ACL_THRESHOLD,aclThreshold);

		if(context_user!=null)
			methodArgs.put(ARG_CONTEXT_USER, context_user);

		argParser=new ArgumentParser(methodArgs);
		DfLogger.warn(this,"****************End of getSlaveMethodArgs()*******************************************",null, null);
		return methodArgs;
	}

	@Override
	public void initSlaveProcess(IDfSession session, IDfSysObject job, Locale locale, ArgumentParser argumentParser)
			throws DfException 
	{
		DfLogger.warn(this,"****************Starting initSlaveProcess()*******************************************",null, null);
		argParser=argumentParser;
		DfLogger.warn(this,"****************Completing initSlaveProcess()*******************************************",null, null);

	}

	@Override
	public Serializable performTask(int arg0, String arg1, Serializable arg2, IDfSession session) 
			throws DfException 
	{
		DfLogger.warn(this,"****************Starting performTask()*******************************************",null, null);

		if(arg2!=null)
		{
			SWYTargetObjectsBean beanObj=(SWYTargetObjectsBean)arg2;
			String targetObjId=beanObj.getTargetObjectId();
			String sourceObjId=beanObj.getSourceObjectId();
			SWYAttributeInheritanceBean attrBeanObj=beanObj.getAttributeInheritanceData();

			if(targetObjId!=null && sourceObjId!=null && attrBeanObj!=null)
			{
				DfLogger.info(this,"In performTask() :: Processing Object "+targetObjId,null,null);

				//return setSecurityRegistrationForm(session,objId);
				return setAttributeInheritance(session,targetObjId,sourceObjId,attrBeanObj);
			}
			else
			{
				SWYResultBean errorObj=new SWYResultBean();
				errorObj.setProcessStatus("Failed");
				errorObj.setProcessMsg("No onjects to process");
				return errorObj;
			}
		}
		else
		{
			DfLogger.warn(this,"****************Completing performTask(Serializable Object is null)*******************************************",null, null);

			SWYResultBean errorObj=new SWYResultBean();
			errorObj.setProcessStatus("Failed");
			errorObj.setProcessMsg("Task Object is null");
			return errorObj;
		}
	}

	private SWYResultBean setAttributeInheritance(IDfSession session, String targetId, String sourceObjID,SWYAttributeInheritanceBean attrInheritData)  throws DfException
	{
		/**
		 * -attributes "merge-tar1-src1~replace-tar2-src2~replace-tar3-src3~replace-tar5-@tar4~replace-tar4-[staticvalue]"
		 */

		String ctxUsr=argParser.getStringArgument(ARG_CONTEXT_USER, null);
		DfLogger.warn(this, "::: setAttributeInheritance targetId==> ("+targetId+")  sourceId==> ("+sourceObjID+")::: context user  >> " + ctxUsr, null, null);

		IDfSysObject sourceObject=(IDfSysObject)session.getObject(new DfId(sourceObjID));
		IDfSysObject targetObject=(IDfSysObject)session.getObject(new DfId(targetId));

		String arg_attributes=argParser.getStringArgument(ARG_ATTRIBUTES, null);
		Boolean arg_enabledAudit=argParser.getBooleanArgument(ARG_ENABLED_AUDIT, false);
		String arg_auditEvent=argParser.getStringArgument(ARG_AUDIT_EVENT_NAME, null);
		String arg_auditEventMsg=argParser.getStringArgument(ARG_AUDIT_EVENT_MSG, null);
		Boolean arg_byPassLocks=argParser.getBooleanArgument(ARG_BYPASS_LOCKS, false); // true means unlock , process and relock. False means skip the object 
		Boolean arg_updateVersions=argParser.getBooleanArgument(ARG_UPDATE_versions, false);
		Boolean arg_applySecurity=argParser.getBooleanArgument(ARG_SECURITY, false);
		String arg_aclThreshold=argParser.getStringArgument(ARG_ACL_THRESHOLD, null);

		DfLogger.debug(this, "arg_attributes["+arg_attributes+"]", null, null);
		DfLogger.debug(this, "arg_enabledAudit["+arg_enabledAudit+"]", null, null);
		DfLogger.debug(this, "arg_auditEvent["+arg_auditEvent+"]", null, null);
		DfLogger.debug(this, "arg_auditEventMsg["+arg_auditEventMsg+"]", null, null);
		DfLogger.debug(this, "arg_updateVersions["+arg_updateVersions+"]", null, null);
		DfLogger.debug(this, "arg_applySecurity["+arg_applySecurity+"]", null, null);
		DfLogger.debug(this, "arg_aclThreshold["+arg_aclThreshold+"]", null, null);
		DfLogger.debug(this, "arg_byPassLocks["+arg_byPassLocks+"]", null, null);

		SWYResultBean resultBeanObj=new SWYResultBean();

		/****
		 * if(arg_attributes!=null && !arg_attributes.isEmpty())
		{

			String[] attributes=arg_attributes.split("~");
			if(attributes!=null && attributes.length>0)
			{
				for(int i=0;i<attributes.length;i++)
				{
					String[] action_attrs=attributes[i].split("-");
					if(action_attrs.length>0 && action_attrs!=null)
					{
						action_attributes_list.add(action_attrs);
					}
					else
					{
						DfLogger.error(this," parameter against argument "+ARG_ATTRIBUTES+" is not defined properly",null,null);
						return null;
					}
				}
			}
			else
			{
				DfLogger.error(this,ARG_ATTRIBUTES + " parameter is not defined properly",null,null);
				return null;
			}		
		}
		else
		{
			DfLogger.error(this,ARG_ATTRIBUTES + " param is not defined properly",null,null);
			return null;
		}*/

		ArrayList<String> actionList=attrInheritData.getAction();
		ArrayList<String> srcAttrlist= attrInheritData.getSourceAttribute();
		ArrayList<String> tarAttrList=attrInheritData.getTargetAttribute();
		ArrayList<String[]> srcValList=attrInheritData.getSourceAttrValue();
		boolean isObjUpdated=false;
		String auditAttrList=null;
		String auditAttrListOld=null;

		DfLogger.info(this,"Processing starts ::: actionList="+actionList.size()+" srcAttrlist="+srcAttrlist.size()+" tarAttrList="+tarAttrList.size()+" srcValList="+srcValList.size()+"",null,null);

		if(actionList.size()==srcAttrlist.size() && srcAttrlist.size()==tarAttrList.size() && tarAttrList.size()==srcValList.size())
		{

		}
		else
		{
			DfLogger.error(this,ARG_ATTRIBUTES + " params are not defined properly and not in sync",null,null);
			return null;
		}

		// Generating Audit trail entry for target object with their existing value, before they get updated with new values
		auditAttrListOld=inheritUtil.generateAttributesAuditEntry(targetId,session,tarAttrList);
		DfLogger.info(this, "TargetObjectId:::"+targetId+" auditAttrListOld=["+auditAttrListOld+"]", null, null);

		/** Code to canceling checkout in target object
		 * 
		 */
		Map<java.lang.String,java.lang.String[]> checkedoutObjInfo=null;
		boolean isChkOutAborted=false;
		if((targetObject.isCheckedOut() && arg_byPassLocks))
		{
			DfLogger.debug(this, "Target Object ["+targetId+"] cancel checkout start ", null, null);
			checkedoutObjInfo=inheritUtil.getCheckoutInfo(targetId,session);
			isChkOutAborted=inheritUtil.isCheckOutAborted(targetId,session);

			DfcObjectUtils.fetchObjectIfRequired(targetObject);
			DfLogger.info(this, "Target Object ["+targetId+"] cancel checkout done ", null, null);
		}

		for(int i=0;i<actionList.size();i++)
		{
			String action=actionList.get(i);
			String srcAttr=srcAttrlist.get(i);
			String tarAttr=tarAttrList.get(i);
			String[] srcValArr=srcValList.get(i);

			ArrayList<String> targetValueList=inheritUtil.getAttributeValue(targetObject, tarAttr);
			String[] tarCurValArr=new String[targetValueList.size()];
			targetValueList.toArray(tarCurValArr);

			if(srcAttr.startsWith("@")) // if the source attribute is from target object itself
			{
				srcAttr=srcAttr.substring(1, srcAttr.length());
				DfLogger.debug(this,"Source attribute is from the target object itself i.e. "+srcAttr,null,null);

				if(targetObject.hasAttr(srcAttr) && targetObject.hasAttr(tarAttr) && !srcAttr.startsWith("["))
				{
					ArrayList<String> valueList=inheritUtil.getAttributeValue(targetObject, srcAttr);
					srcValArr=new String[valueList.size()];
					valueList.toArray(srcValArr);
				}

			}
			//replace-swy_lotus_divisions-#execdql(select name from dm_dbo.cmndicdivisions where name in (select  swy_divisions from cd_quality where r_object_id='@value(r_object_id)'))
			if(srcAttr.startsWith("#execdql")) // if source attribute is from DQL
			{
				DfLogger.debug(this, "The source is DQL: for the target attribute: originally passed DQL ["+srcAttr+"]", null, null);

				srcAttr=srcAttr.substring(srcAttr.indexOf("(")+1,srcAttr.lastIndexOf(")"));
				DfLogger.debug(this, " The source is DQL: for the target attribute: before expression resolved ["+srcAttr+"]", null, null);

				//srcAttr=AttributeExpression.resolve(srcAttr, sourceObject, targetObject, session.getLoginUserName(), argParser);

				srcAttr=srcAttr.replace("$", "#");
				DfLogger.debug(this,"++++ "+srcAttr,null,null);
				srcAttr= AttributeExpression.resolve(AttributeExpression.convertDelayedFunctionRefs(srcAttr, '@'), targetObject,  session.getLoginUserName(), argParser, null);
				DfLogger.debug(this, " The source is DQL: for the target attribute: after expression resolved against target object ["+srcAttr+"]", null, null);
				srcAttr=srcAttr.replace("#", "$");
				DfLogger.debug(this,"==== "+srcAttr,null,null);
				srcAttr = AttributeExpression.resolve(srcAttr, sourceObject, targetObject,  session.getLoginUserName(), null);

				DfLogger.info(this, " The source is DQL: for the target attribute: after expression resolved against source object ["+srcAttr+"]", null, null);

				srcValArr=QueryUtils.getAllQueryResultsAsStrings(srcAttr, session);

			}

			/** Code to update retrieved values in target object
			 * 
			 */

			if(srcValArr!=null && srcValArr.length>0)
			{
				if(!targetObject.isAttrRepeating(tarAttr) || action.trim().equalsIgnoreCase("replace"))
				{
					if (targetObject.isAttrRepeating(tarAttr))
					{
						inheritUtil.updateRepeatedAttribute(srcValArr, tarAttr, targetObject, false, true);
					}			    
					else
					{
						inheritUtil.updateSingleValueAttribute(srcValArr[0], tarAttr, targetObject);
					}
					isObjUpdated=true;
				}			
				else if(action.trim().equalsIgnoreCase("merge") && targetObject.isAttrRepeating(tarAttr) )
				{
					inheritUtil.updateRepeatedAttribute(srcValArr, tarAttr, targetObject, true, false);
					isObjUpdated=true;
				}
				else 
				{
					DfLogger.info(this,"Not able to perform merge/replace operations",null,null);
				}
				/** End of Code to update values in target object
				 * 
				 */
			}
		}

		if(isObjUpdated)
		{
			if((isChkOutAborted && arg_byPassLocks) || !targetObject.isCheckedOut())
			{
				DfcObjectUtils.saveChangesToObjectIfRequired(targetObject, false, true, false, ctxUsr, session);
				DfLogger.info(this, "Target Object ["+targetId+"] updated", null, null);
				resultBeanObj.setSourceObjectId(sourceObjID);
				resultBeanObj.setTargetObjectId(targetId);
				resultBeanObj.setTypeName(targetObject.getTypeName());
				resultBeanObj.setProcessStatus("Success");

				DfcObjectUtils.fetchObjectIfRequired(targetObject);

				if(isChkOutAborted)
				{
					inheritUtil.isAbortcheckoutCancelled(targetId,session, checkedoutObjInfo);
					DfcObjectUtils.fetchObjectIfRequired(targetObject);
				}

				if(arg_enabledAudit)
				{
					// Generating Audit trail entry for target object with their new value, after they get updated with new values
					auditAttrList=inheritUtil.generateAttributesAuditEntry(targetId,session,tarAttrList);
					DfLogger.info(this, "TargetObjectId:::"+targetId+" auditAttrList=["+auditAttrList+"]", null, null);

					if (!auditAttrListOld.isEmpty() && !auditAttrList.isEmpty())
					{
						inheritUtil.createAuditObject(targetId,session,arg_auditEvent,arg_auditEventMsg,auditAttrList,auditAttrListOld);
						resultBeanObj.setIsAudited(true);
					}
				}

			}
		}
		if(arg_updateVersions)
		{
			inheritUtil.applyChangesToDocAllVersions(targetId,session,tarAttrList,arg_enabledAudit,arg_auditEvent,arg_auditEventMsg);
			resultBeanObj.setIsVersionUpdated(true);
		}

		if(arg_applySecurity)
		{
			resultBeanObj.setIsACLUpdateNeeded(arg_applySecurity);
		}

		return resultBeanObj;
	}

	@Override
	public void handleResults(IDfSession session, TaskResult[] taskResults)
	{
		DfLogger.warn(this,"*****************Processing done of "+ISWYApplyInheritanceConstants.DM_METHOD_NAME+" *****************************************************************",null,null);
		DfLogger.warn(this, "Start of Handle Results No. of task results need to process["+taskResults.length+"]", null, null);


		Boolean isSecurityUpdateNeeded=false;

		IDfSysObject sourceObject=null;
		try
		{
			for(int i=0;i<taskResults.length;i++)
			{
				SWYResultBean beanObj=(SWYResultBean) taskResults[i].getTaskResult();

				if(beanObj==null)
					continue;
				
				String taskStatus=beanObj.getProcessStatus();
				
				if (taskStatus!=null && taskStatus.equalsIgnoreCase("Success"))
				{
					DfLogger.debug(this, "Success handleResults()", null, null);
					isSecurityUpdateNeeded=beanObj.isACLUpdateNeeded();
					String sourceObjID=beanObj.getSourceObjectId();
					if(sourceObjID!=null && !sourceObjID.isEmpty())
					{
						DfLogger.debug(this, "Success handleResults() sourceObjID "+sourceObjID, null, null);
						sourceObject=(IDfSysObject)session.getObject(new DfId(sourceObjID));
					}
					break;
				}
				else
				{
					String sourceObjID=beanObj.getSourceObjectId();

					if (sourceObjID==null)
					{
						DfLogger.debug(this, "Nothing to process in handleResults()", null, null);

						return;
					}
				}
			}

			DfLogger.warn(this, "Apply security with value ["+isSecurityUpdateNeeded+"] on target Qualification ["+updateACLQual+"]", null, null);

			/*HashMap<String, ArrayList<String>> resultData=new HashMap<String, ArrayList<String>>();

			for(int i=0;i<taskResults.length;i++)
			{
				SWYResultBean beanObj=(SWYResultBean) taskResults[i].getTaskResult();
				String objId=beanObj.getObjectId();

				String object_type=beanObj.getTypeName();

				if(resultData.containsKey(object_type))
				{
					if (beanObj.isACLUpdateNeeded() )
					{
						ArrayList<String> arrObjIdList=resultData.get(object_type);
						arrObjIdList.add(objId);
						resultData.put(object_type, arrObjIdList);
					}
				}
				else
				{
					if (beanObj.isACLUpdateNeeded() )
					{
						ArrayList<String> arrObjIdList=new ArrayList<String> ();
						arrObjIdList.add(objId);
						resultData.put(object_type, arrObjIdList);
					}
				}			
			}

			if(resultData.size()>0)
			{
				Set<String> set= resultData.keySet();
				Iterator<String> iterator= set.iterator();

				while(iterator.hasNext())
				{
					String typeName_key=iterator.next();
					ArrayList<String> arrObjIdList=resultData.get(typeName_key);

					if(arrObjIdList!=null && arrObjIdList.size()>0)
					{
						int totalRecords= arrObjIdList.size();
						int batchSize=100;
						int no_of_batch=totalRecords/batchSize;
						int doc_count_outside_batch=totalRecords % batchSize;
						//System.out.println("Total objects available ["+totalRecords+"] No. Of batch["+no_of_batch+"] Documents count outside batch ["+doc_count_outside_batch+"] BatchSize["+batchSize+"]");
						DfLogger.debug(this, "Total objects available ["+totalRecords+"] No. Of batch["+no_of_batch+"] Documents count outside batch ["+doc_count_outside_batch+"] BatchSize["+batchSize+"]", null, null);

						int counter=0;
						String objectIdsAsPredicate=null;
						int total_batch=doc_count_outside_batch>0?no_of_batch+1:no_of_batch;

						for (int batchCounter=0;batchCounter<total_batch;batchCounter++)
						{
							objectIdsAsPredicate=null;
							if(batchCounter==no_of_batch)
								batchSize=doc_count_outside_batch;
							for(int j=0;j<batchSize;j++)
							{
								if(objectIdsAsPredicate==null || objectIdsAsPredicate.trim().equalsIgnoreCase(""))
								{
									objectIdsAsPredicate="'"+arrObjIdList.get(counter)+"'";
								}
								else
								{
									objectIdsAsPredicate=objectIdsAsPredicate+ " , '"+arrObjIdList.get(counter)+"'";
								}
								counter=counter+1;
							}

							//System.out.println("Batch ["+(batchCounter+1)+"] Processed records ["+counter+"] Version Object Ids ["+versionIdsAsPredicate+"]");
							DfLogger.debug(this, "Processing Object Ids to apply Security Batch ["+(batchCounter+1)+"] Processed records ["+counter+"] Versions Object IDs as predicate ["+objectIdsAsPredicate+"]", null, null);

							String dqlQualificationToExecute=null;
							dqlQualificationToExecute=typeName_key+"(all) where r_object_id in ("+objectIdsAsPredicate+")";
							//System.out.println("[dqlToExecute=="+dqlToExecute+"]");
							DfLogger.info(this, "Processing Object Ids to apply Security Batch  qulification to update version ["+dqlQualificationToExecute+"]", null, null);

							if(dqlQualificationToExecute!=null && !dqlQualificationToExecute.trim().equalsIgnoreCase(""))
							{
								inheritUtil.applyingSecurity(dqlQualificationToExecute,session,true);

								DfLogger.info(this, "Request sent to update security", null, null);
							}
						}
					}
				}
			}*/

			/*String dqlQualificationToExecute=updateACLQual.substring(updateACLQual.toLowerCase().indexOf("from")+4);

			String type=dqlQualificationToExecute.substring(0,dqlQualificationToExecute.indexOf("where"));
			dqlQualificationToExecute=dqlQualificationToExecute.substring(dqlQualificationToExecute.indexOf("where"));

			dqlQualificationToExecute=type.trim() +"(all) " +dqlQualificationToExecute;*/

			String dqlQualificationToExecute=updateACLQual;
			if(sourceObject!=null)
			{// Resolve only against source object ($)
				dqlQualificationToExecute=AttributeExpression.resolve(dqlQualificationToExecute, sourceObject, session.getLoginUserName());
			}
			DfLogger.info(this, " The source is DQL: for the target attribute: after expression resolved against source object ["+dqlQualificationToExecute+"]", null, null);

			if(dqlQualificationToExecute!=null && !dqlQualificationToExecute.isEmpty())
			{
				if(dqlQualificationToExecute!=null && !dqlQualificationToExecute.trim().equalsIgnoreCase(""))
				{
					inheritUtil.applyingSecurity(dqlQualificationToExecute,session,isSecurityUpdateNeeded,aclThreshold);

					DfLogger.info(this, "Request sent to update security", null, null);
				}
			}
			else
			{
				DfLogger.debug(this, "No DQL Qualification to apply security", null, null);
			}

			if (updateStatusDQL!=null && !updateStatusDQL.isEmpty())
			{
				if(sourceObject!=null)
				{// Resolve only against source object ($)
					updateStatusDQL=AttributeExpression.resolve(updateStatusDQL, sourceObject, session.getLoginUserName());
				}
				DfLogger.debug(this, "Updating  status with query ["+updateStatusDQL+"]", null, null);
				String processedResult= QueryUtils.execQuery(updateStatusDQL, session);
				DfLogger.warn(this, "Updating  status with query ["+updateStatusDQL+"] processed result["+processedResult+"]", null, null);
			}
		}
		catch (Exception ex)
		{
			DfLogger.error(this, ex.getLocalizedMessage(), null, null);
		}

		DfLogger.warn(this, "End of Handle Results", null, null);

	}

}
