package com.novartis.swy.security.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Vector;

import com.documentum.cdf.methods.WorkflowManager;
import com.documentum.d2.model.D2Dictionary;
import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.DfTime;
import com.documentum.fc.common.IDfId;
import com.documentum.ls.audit.AuditTrailItem;
import com.documentum.utils.QueryUtils;
import com.documentum.utils.StringUtils;
import com.emc.common.dctm.utils.DfSessionUtil;
import com.emc.common.java.utils.ArgumentParser;
import com.emc.d2.api.methods.D2LifecycleChangeStateMethod;
import com.emc.d2.api.methods.D2Method;
/**
 * *************JIRA 2959*******************************************
 * Date : 21-Dec-2020 , Author : SHUBHKU1, SUKANRA1
 * Re-factored code, handled collection leak issue (JIRA# 2959)
 * *****************************************************************
 *
 */	
public class SWYApplySecRFHelper {

	public IDfSession dgSession;

	public SWYApplySecRFHelper()
	{

	}
	public SWYApplySecRFHelper(IDfSession dlSession) {

		this.dgSession = dlSession;
	}

	private boolean isSecRFUnMappedAttrsHaveValue(IDfSysObject secRFObj,String secRFAttr ) throws DfException
	{
		boolean isExist=false;

		int docAttrDataType = secRFObj.getAttrDataType(secRFAttr);
		String value=getSecRFValue(docAttrDataType,secRFObj,secRFAttr);

		if(value!=null && !value.trim().equalsIgnoreCase("nulldate") && !value.trim().equalsIgnoreCase(""))
		{
			isExist=true;
			DfLogger.debug(this, "isSecRFUnMappedAttrsHaveValue():::: Value ["+value+"] does exist in UnMapped Attribute ["+secRFAttr+"]", null, null);
			return isExist;
		}
		else
		{
			isExist=false;
			DfLogger.debug(this, "isSecRFUnMappedAttrsHaveValue():::: Value doesnot exist in UnMapped Attribute ["+secRFAttr+"]", null, null);
		}
		return isExist;
	}


	private String getSecRFValue(int docAttrDataType ,IDfSysObject secRFObj,String secRFAttr) throws DfException
	{
		String value=null;

		if (docAttrDataType == 2 || docAttrDataType == 3) // String || ID
		{
			value=String.valueOf(secRFObj.getString(secRFAttr));
		}
		else
		{
			if (docAttrDataType == 4) // Time
			{
				value=secRFObj.getTime(secRFAttr).asString(ISWYApplySECRFConstants.DCTM_DATE_ATTR_FORMAT);
			} 
			else if (docAttrDataType == 0) // Boolean
			{
				value=String.valueOf(secRFObj.getBoolean(secRFAttr));
			} 
			else if (docAttrDataType == 1 ) // Number 
			{
				value=String.valueOf(secRFObj.getInt(secRFAttr));
			}
			else if ( docAttrDataType == 5) //  DOUBLE
			{
				value=String.valueOf(secRFObj.getDouble(secRFAttr));
			}
		}
		return value;
	}

	private String getAttrStringValues(IDfSysObject docObject,String docAttr ,IDfSysObject secRFObj,String secRFAttr ) throws DfException
	{
		String value=null;
		//System.out.println(docAttr );
		if (docObject.hasAttr(docAttr)) {
			int docAttrDataType = docObject.getAttrDataType(docAttr);
			value=getSecRFValue(docAttrDataType,secRFObj,secRFAttr);			
		}
		return value;
	}
	/**
	 * This method generate more predicates (Few predicates are coming from application as DQL qualifier) based on the filter attributes selected in SecRF, to retrieve documents' object.
	 * @param dqlQualifier : DQL qualifier coming from application , to fetch document objects
	 * @param secRFObj : SecRF object
	 * @param docObjType : Documents object type 
	 * @return : String value having more predicates that application doesn't sends.
	 * @throws DfException
	 */
	D2Dictionary dAttr =null;
	public String generateMorePredicates(String dqlQualifier, IDfSysObject secRFObj, String docObjType) throws DfException
	{
		String dictionary_name = ISWYApplySECRFConstants.SRF_FILTER_ATTR_DICTIOANRY_NAME;
		String domain = secRFObj.getString("domain").trim();
		IDfSession session = secRFObj.getSession();
		IDfSysObject docObject= (IDfSysObject)session.newObject(docObjType);
		String dqlPredicate="";
		int secAttrIncr=0;
		boolean isNewPredicatesFound=false;
		boolean isSecRFAttrHaveVal=false;
		boolean isSecAttrCounterIncrmtd=false;
		if (dAttr==null)
			dAttr = D2Dictionary.getDictionary(dictionary_name, session, null, null, true, false);
		Map<String, String> m_attr_map = dAttr.getKeyToAliasValueMap(domain);

		Set<String> att_keys = m_attr_map.keySet();
		Iterator<String> att_iterator = att_keys.iterator();

		while (att_iterator.hasNext()) {
			isSecRFAttrHaveVal=false;
			String secRFAttr = att_iterator.next(); // name of the column,
			// corresponding to SecRF
			String c_value = m_attr_map.get(secRFAttr); // value (Yes/No),
			// corresponding to SecRF , required in specific domain
			isSecAttrCounterIncrmtd=false;

			if ((c_value != null && !c_value.equalsIgnoreCase("")
					&& (c_value.toUpperCase().trim().startsWith("N") || c_value.toUpperCase().trim().startsWith("F")) )
					&& !secRFAttr.equalsIgnoreCase(ISWYApplySECRFConstants.SRF_DIVISION_ATTR_NAME)) 
			{
				String doc_attr_name = D2Dictionary.getAliasValue(dictionary_name, secRFAttr,
						ISWYApplySECRFConstants.SRF_FILTER_VALUE_LOOKUP_ATTR, session, null, null, true, false);

				//System.out.println("[["+doc_attr_name+"]]");
				if (doc_attr_name !=null && !doc_attr_name.trim().equalsIgnoreCase("") && !doc_attr_name.trim().toLowerCase().equalsIgnoreCase("nulldate"))
				{
					String [] docAttrs=doc_attr_name.split(",");

					boolean isUnMappedAttrValueExist=isSecRFUnMappedAttrsHaveValue(secRFObj,secRFAttr);

					if (isUnMappedAttrValueExist)
					{
						return "error";
					}
					else
					{

					}

				}
			}
			else if ((c_value != null && !c_value.equalsIgnoreCase("")
					&& (c_value.toUpperCase().trim().startsWith("Y") || c_value.toUpperCase().trim().startsWith("T")))
					|| secRFAttr.equalsIgnoreCase(ISWYApplySECRFConstants.SRF_DIVISION_ATTR_NAME) ) 
			{
				String doc_attr_name = D2Dictionary.getAliasValue(dictionary_name, secRFAttr,
						ISWYApplySECRFConstants.SRF_FILTER_VALUE_LOOKUP_ATTR, session, null, null, true, false);

				//System.out.println("[["+doc_attr_name+"]]");
				if (doc_attr_name !=null && !doc_attr_name.trim().equalsIgnoreCase("") && !doc_attr_name.trim().toLowerCase().equalsIgnoreCase("nulldate"))
				{
					String [] docAttrs=doc_attr_name.split(",");

					int docAttrIncr=0;
					for (int i=0;i<docAttrs.length;i++)
					{
						String docAttr=docAttrs[i];

						if(!dqlQualifier.contains(docAttr) )
						{
							String value=getAttrStringValues(docObject,docAttr,secRFObj,secRFAttr);
							if (docObject.hasAttr(docAttr)) 
							{
								//System.out.println("[["+value+"]]");

								if (value!=null && !value.trim().equalsIgnoreCase("")  && !value.trim().toLowerCase().equalsIgnoreCase("nulldate"))
								{
									if (secAttrIncr==0)
									{
										dqlPredicate = dqlPredicate +" ( ";
										secAttrIncr=secAttrIncr+1;
										isSecRFAttrHaveVal=true;
										isSecAttrCounterIncrmtd=true;

										//System.out.println("AAA ["+secAttrIncr+"] docAttr["+docAttr+"] isSecRFAttrHaveVal["+isSecRFAttrHaveVal+"] isSecAttrCounterIncrmtd["+isSecAttrCounterIncrmtd+"] dqlPredicate["+dqlPredicate+"]" );
									}
									else if (secAttrIncr>0 && !isSecAttrCounterIncrmtd)
									{
										dqlPredicate = dqlPredicate +" and ( ";
										secAttrIncr=secAttrIncr+1;
										isSecRFAttrHaveVal=true;
										isSecAttrCounterIncrmtd=true;
										//System.out.println("BBB ["+secAttrIncr+"] docAttr["+docAttr+"] isSecRFAttrHaveVal["+isSecRFAttrHaveVal+"] NAisSecAttrCounterIncrmtd["+isSecAttrCounterIncrmtd+"] dqlPredicate["+dqlPredicate+"]" );
									}

									/*if (!isSecAttrCounterIncrmtd)
									{
										dqlPredicate = dqlPredicate +" and ( ";
										//secAttrIncr=secAttrIncr+1;
										isSecRFAttrHaveVal=true;
										System.out.println("BBB ["+secAttrIncr+"] docAttr["+docAttr+"] isSecRFAttrHaveVal["+isSecRFAttrHaveVal+"] NAisSecAttrCounterIncrmtd["+isSecAttrCounterIncrmtd+"] dqlPredicate["+dqlPredicate+"]" );
									}*/

									if(docAttrIncr>0)
									{
										dqlPredicate = dqlPredicate +" or ( ";
										docAttrIncr=docAttrIncr+1;
										//System.out.println("CCC ["+secAttrIncr+"] docAttr["+docAttr+"] docAttrIncr ["+docAttrIncr+"] NAisSecRFAttrHaveVal["+isSecRFAttrHaveVal+"] NAisSecAttrCounterIncrmtd["+isSecAttrCounterIncrmtd+"] dqlPredicate["+dqlPredicate+"]" );

									}
									else if (docAttrIncr==0)
									{
										dqlPredicate = dqlPredicate +" ( ";
										docAttrIncr=docAttrIncr+1;
										//System.out.println("DD ["+secAttrIncr+"] docAttr["+docAttr+"] docAttrIncr["+docAttrIncr+"] NAisSecRFAttrHaveVal["+isSecRFAttrHaveVal+"] NAisSecAttrCounterIncrmtd["+isSecAttrCounterIncrmtd+"] dqlPredicate["+dqlPredicate+"]" );

									}


									int docAttrDataType = docObject.getAttrDataType(docAttr);
									boolean isDocAttrMulti=docObject.isAttrRepeating(docAttr);

									if (docAttrDataType == 2 || docAttrDataType == 3) // String || ID
									{

										if(value!=null && !value.trim().equalsIgnoreCase(""))
										{
											if(isDocAttrMulti)
												dqlPredicate = dqlPredicate +" any "+docAttr +" ='"+value+"'";
											else
												dqlPredicate = dqlPredicate +" "+docAttr +" ='"+value+"'";

											isNewPredicatesFound=true;
										}
									}
									else
									{
										boolean isDocValueExist=false;
										if (docAttrDataType == 4) // Time
										{
											if(value!=null && !value.trim().equalsIgnoreCase("nulldate") && !value.trim().equalsIgnoreCase(""))
											{
												value = "date('" + value + " utc','"
														+ ISWYApplySECRFConstants.DCTM_DATE_ATTR_FORMAT + "')";
												isDocValueExist=true;
											}
										} 
										else if (docAttrDataType == 0) // Boolean
										{
											if (value.equalsIgnoreCase("true") || value.equalsIgnoreCase("t")
													|| value.equalsIgnoreCase("1")) {
												value = "1";
											} else if (value.equalsIgnoreCase("false")
													|| value.equalsIgnoreCase("f") || value.equalsIgnoreCase("0")) {
												value = "0";
											}
											isDocValueExist=true;
										} 
										else if (docAttrDataType == 1 ) // Number 
										{
											isDocValueExist=true;
										}
										else if ( docAttrDataType == 5) //  DOUBLE
										{
											isDocValueExist=true;
										}

										if(isDocValueExist)
										{
											if(isDocAttrMulti)
												dqlPredicate = dqlPredicate +" any "+docAttr +" ="+value;
											else
												dqlPredicate = dqlPredicate +" "+docAttr +" ="+value;

											isNewPredicatesFound=true;
										}
									}

									if(docAttrIncr>0)
									{
										dqlPredicate = dqlPredicate +" ) ";
									}
								}

							}

						}
					}
				}
			}

			if(isSecRFAttrHaveVal)
			{
				dqlPredicate = dqlPredicate +" ) ";
			}
		}

		if(isNewPredicatesFound)
			return dqlPredicate;
		else
			return "";
	}

	/**
	 * It will process all Active SecRF objects based on the all selected
	 * divisions and domains. It will also process those SecRF which has defined
	 * as cross domain. After processing , it will return a map of string as key
	 * and string [] as value, where key will be selected column name and
	 * string[] will have corresponding rows. The map will have 3 entries, since
	 * retrieving 3 columns only . One column will be r_object_ids another would
	 * be attribute which holds name of all empty attributes and last one will
	 * be attributes which hold non-empty attributes and their value in each
	 * SecRF objects.
	 * 
	 * @param srfType
	 * @param docObject
	 * @return Map, of string as key and string [] as value, where key will be
	 *         selected column name and string[] will have their corresponding
	 *         rows.
	 * @throws DfException
	 */

	public Map<String, String[]> getSecRFDataDetails(String srfType, IDfSysObject docObject,
			HashMap<String, String> secFiltersMap, boolean find_secrf_statistics) throws Exception {
		DfLogger.debug(this, "Date July 30, 2017 :: Version 2.0 :: calling getDivisionBasedSecRF() ::::: ", null, null);

		Map<String, String[]> secRFInfoMap = null; // column name as key and
		// string[] as value

		// String
		// docConfidentiality=docObject.getString(ISWYApplySECRFConstants.SRF_CONFIDENTIALITY_ATTR_NAME);
		// //RSTD OR BUO
		// String
		// docDataPrivacy=docObject.getString(ISWYApplySECRFConstants.SRF_DATA_PRIVACY_ATTR_NAME);
		// // it is not mandatory, not considering for 1st level of separation
		String docDomainValue = docObject.getString(ISWYApplySECRFConstants.SRF_DOMAIN_ATTR_NAME);
		int docDivisionCount = docObject.getValueCount(ISWYApplySECRFConstants.DIVISIONS_ATTR_NAME);
		String docArtifactNameValue = docObject.getString(ISWYApplySECRFConstants.DOC_ARTIFACT_NAME_ATTR);

		String getSRFsDQL = null;

		String selectionAttrs = ISWYApplySECRFConstants.SRF_R_OBJECT_ID_ATTR;

		Iterator<String> valueColl = secFiltersMap.values().iterator();

		while (valueColl.hasNext()) {
			String secRFAttrName = valueColl.next();

			if (selectionAttrs == null || selectionAttrs.trim().equalsIgnoreCase("")) {
				selectionAttrs = secRFAttrName;
			} else {
				selectionAttrs = selectionAttrs + "," + secRFAttrName;
			}
		}

		if (find_secrf_statistics) {
			getSRFsDQL = "select " + selectionAttrs + " from " + srfType + " where  " + "lower(a_status) in ('"
					+ ISWYApplySECRFConstants.SRF_STATUS_ACTIVE_VALUE.toLowerCase() + "', '"
					+ ISWYApplySECRFConstants.SRF_STATUS_INACTIVE_VALUE.toLowerCase() + "' ) ";
		} else {
			getSRFsDQL = "select " + selectionAttrs + " from " + srfType + " where  " + "lower(a_status)=lower('"
					+ ISWYApplySECRFConstants.SRF_STATUS_ACTIVE_VALUE.toLowerCase() + "') ";
		}

		getSRFsDQL = getSRFsDQL + " and ("+ISWYApplySECRFConstants.SRF_DIVISION_ATTR_NAME+" is nullstring ";
		if (docDivisionCount > 0) {			
			for (int divCounter = 0; divCounter < docDivisionCount; divCounter++) {
				String docDivision = docObject
						.getRepeatingString(ISWYApplySECRFConstants.DIVISIONS_ATTR_NAME, divCounter).toLowerCase()
						.trim();
				getSRFsDQL = getSRFsDQL + " or lower("+ISWYApplySECRFConstants.SRF_DIVISION_ATTR_NAME+")='" + docDivision + "'";

				/*if (divCounter > 0) {
					getSRFsDQL = getSRFsDQL + " or lower(swy_division)='" + docDivision + "'";
				} else {
					getSRFsDQL = getSRFsDQL + " lower(swy_division)='" + docDivision + "'";
				}*/
			}
		}
		getSRFsDQL = getSRFsDQL + " )";
		getSRFsDQL = getSRFsDQL + " and (domain='' or domain is nullstring";

		List<String> domainList= getClineCrossOverDomains(docObject.getSession(),docArtifactNameValue,docDomainValue);

		if(domainList!=null && domainList.size()>0)
		{
			DfLogger.debug(this, "adding doamins fro Crossover documents",null, null);
			for(int i=0;i<domainList.size();i++)
			{
				getSRFsDQL = getSRFsDQL + " or lower(domain)=lower('" + domainList.get(i) + "')";
			}
		}
		else if (docDomainValue != null && !docDomainValue.trim().equalsIgnoreCase("")) {
			getSRFsDQL = getSRFsDQL + " or lower(domain)=lower('" + docDomainValue + "')";
		}

		getSRFsDQL = getSRFsDQL + " )";

		DfLogger.debug(this, "Fetching SecRF Attributes based on division and domian, also checking cross domain data ["
				+ getSRFsDQL + "] ", null, null);

		secRFInfoMap = QueryUtils.getAllQueryResultColumnValues(getSRFsDQL, false, docObject.getSession()); // column
		// name
		// as
		// key
		// and
		// string[]
		// as
		// value

		HashMap<String, String[]> emptyNonEmptyMap = null;
		if (secRFInfoMap != null && secRFInfoMap.size() > 0) {
			Iterator<String> keyColl = secRFInfoMap.keySet().iterator();
			int initSize = 0;
			int maxSize = 0;
			ArrayList<String> keyList = null;

			while (keyColl.hasNext()) {
				String key = keyColl.next();
				String[] value = secRFInfoMap.get(key);

				if (keyList == null) {
					if (value != null) {
						keyList = new ArrayList<String>();
						initSize = value.length;
					}
				}
				if (value != null && maxSize <= value.length) {
					maxSize = value.length;
					keyList.add(key);
				}
			}

			if (maxSize == initSize) {
				ArrayList<String> nonEmptyList = null;
				ArrayList<String> emptyList = null;

				for (int outLoop = 0; outLoop < maxSize; outLoop++) {
					String nonEmptyAttr = null;
					String emptyAttr = null;
					for (int inLoop = 0; inLoop < keyList.size(); inLoop++) {
						String key = keyList.get(inLoop);
						String value[] = secRFInfoMap.get(key);

						if (key != null && !key.equalsIgnoreCase(ISWYApplySECRFConstants.SRF_R_OBJECT_ID_ATTR)) {
							String keyVal = value[outLoop];

							if (keyVal != null && !keyVal.equalsIgnoreCase("")
									&& !keyVal.trim().equalsIgnoreCase("nulldate")) {
								Object[] processData = chkSwyAttrExistInDocModel(key, secFiltersMap, docObject); // size will be null or 3, 0= true or false, 1=atribute name from document object, 2=Attributes data Type from doc object

								if (processData != null && processData.length == 3 && (Boolean) processData[0]) {
									int attrDataType = (Integer) processData[2];

									if (attrDataType == 4) // Time
									{
										keyVal = "date('" + keyVal + " utc','"
												+ ISWYApplySECRFConstants.DCTM_DATE_ATTR_FORMAT + "')";
									} else if (attrDataType == 0) // Boolean
									{
										if (keyVal.equalsIgnoreCase("true") || keyVal.equalsIgnoreCase("t")
												|| keyVal.equalsIgnoreCase("1")) {
											keyVal = "1";
										} else if (keyVal.equalsIgnoreCase("false") || keyVal.equalsIgnoreCase("f")
												|| keyVal.equalsIgnoreCase("0")) {
											keyVal = "0";
										}
									} else if (attrDataType == 1 || attrDataType == 5) // Number
										// ||
										// Double
									{

									} else if (attrDataType == 2 || attrDataType == 3) // String
										// ||
										// Id
									{
										keyVal = "'" + keyVal + "'";
									}

									if (nonEmptyAttr == null || nonEmptyAttr.equalsIgnoreCase("")) {
										nonEmptyAttr = key + ISWYApplySECRFConstants.NON_EMPTY_ATTR_VAL_SEPARATOR + keyVal;
									} else {
										nonEmptyAttr = nonEmptyAttr + ISWYApplySECRFConstants.DEFAULT_SEPARATOR + key + ISWYApplySECRFConstants.NON_EMPTY_ATTR_VAL_SEPARATOR + keyVal;
									}
								} else if (processData != null && processData.length == 1
										&& !(Boolean) processData[0]) {
									IDfSession session = docObject.getSession();
									IDfSysObject secRfObj = (IDfSysObject) session
											.newObject(ISWYApplySECRFConstants.SRF_TYPE);

									if (secRfObj.hasAttr(key)) {
										int attrDataType = secRfObj.getAttrDataType(key);

										if (attrDataType == 4) // Time
										{
											keyVal = "date('" + keyVal + " utc','"
													+ ISWYApplySECRFConstants.DCTM_DATE_ATTR_FORMAT + "')";
										} else if (attrDataType == 0) // Boolean
										{
											if (keyVal.equalsIgnoreCase("true") || keyVal.equalsIgnoreCase("t")
													|| keyVal.equalsIgnoreCase("1")) {
												keyVal = "1";
											} else if (keyVal.equalsIgnoreCase("false") || keyVal.equalsIgnoreCase("f")
													|| keyVal.equalsIgnoreCase("0")) {
												keyVal = "0";
											}
										} else if (attrDataType == 1 || attrDataType == 5) // Number
											// ||
											// Double
										{

										} else if (attrDataType == 2 || attrDataType == 3) // String
											// ||
											// Id
										{
											keyVal = "'" + keyVal + "'";
										}

										if (nonEmptyAttr == null || nonEmptyAttr.equalsIgnoreCase("")) {
											nonEmptyAttr = key + ISWYApplySECRFConstants.NON_EMPTY_ATTR_VAL_SEPARATOR + keyVal;
										} else {
											nonEmptyAttr = nonEmptyAttr + ISWYApplySECRFConstants.DEFAULT_SEPARATOR + key + ISWYApplySECRFConstants.NON_EMPTY_ATTR_VAL_SEPARATOR + keyVal;
										}
									}
								}
							} else {
								if (emptyAttr == null || emptyAttr.equalsIgnoreCase("")) {
									emptyAttr = key;
								} else {
									emptyAttr = emptyAttr + ISWYApplySECRFConstants.DEFAULT_SEPARATOR + key;
								}
							}
						}
					}

					if (nonEmptyList == null)
						nonEmptyList = new ArrayList<String>();

					// DfLogger.debug(this, "nonEmptyAttr ["+nonEmptyAttr+"] ",
					// null, null);
					nonEmptyList.add(nonEmptyAttr);

					if (emptyList == null)
						emptyList = new ArrayList<String>();

					// DfLogger.debug(this, "emptyAttr ["+emptyAttr+"] ", null,
					// null);
					emptyList.add(emptyAttr);
				}

				if (emptyNonEmptyMap == null) {
					emptyNonEmptyMap = new HashMap<String, String[]>();
				}
				emptyNonEmptyMap.put(ISWYApplySECRFConstants.SRF_R_OBJECT_ID_ATTR,
						secRFInfoMap.get(ISWYApplySECRFConstants.SRF_R_OBJECT_ID_ATTR));
				emptyNonEmptyMap.put(ISWYApplySECRFConstants.TMP_SRF_NON_EMPTY_ATTR_LIST_ATTR,
						nonEmptyList.toArray(new String[nonEmptyList.size()]));
				emptyNonEmptyMap.put(ISWYApplySECRFConstants.TMP_SRF_EMPTY_ATTR_LIST_ATTR,
						emptyList.toArray(new String[emptyList.size()]));
			}
		}
		return emptyNonEmptyMap;
	}


	/**
	 * it will process SecRF data , retrieved in previous steps and return Map
	 * The returned Map holds Object Ids (of SecRF objects) as key and non-empty
	 * attributes data (of SecRF objects)as value in arraylist. The arraylist
	 * (of resultant map) holds value as docAttr=Corresponding secRF attribute's
	 * value . Since SecRF filter map may have multiple key with same value
	 * (value will be secRF Attribute), that's why this arraylist may also have
	 * same value corresponding to different doc attributes. e.g.
	 * product_code=prod1, others_product_code=prod1. Here product_code and
	 * others_product_code both are defined as key in SecRF Filter Map, but both
	 * these attributes are common value i.e.syw_filter_product_code, which is
	 * defined in SecRF object model. e.g.
	 * {090f452780487162=[product_code,product_codes='AMN107', project_name='AMN107-Project', 
	 * artifact_name='Final Subject Data', domain='Clinical TMF', clinical_trial_id='CAMN107A2203', submission_numbers='0010'], 
	 * 090f45278047f6c2=[product_code,product_codes='ABL001', domain='Clinical TMF', clinical_trial_id='CKDU731X2201'], 
	 * 090f452780487163=[product_code,product_codes='LDK378', project_name='LDK378-Project', 
	 * artifact_name='Meeting Material (IP and Trial Supplies) [Agenda]', domain='Clinical TMF', clinical_trial_id='CLDK378A2301']}
	 * 
	 * @param secRFInfoMap
	 *            , attribute name as key(String) and attributes value as value
	 *            (String[]) from corresponding SecRF objects.
	 * @param secFiltersMap,
	 *            SecRF filter map, where document's attribute is key and SecRF
	 *            attribute is value. Different key (documents attribute) may
	 *            have same value (or SecRF attribute)
	 * @return Map holds Object Ids (of SecRF objects) as key and non-empty
	 *         attributes data (of SecRF objects)as value in arraylist.
	 */
	public HashMap<String, ArrayList<String>> getNonEmptySecRFDataInArray(Map<String, String[]> secRFInfoMap,
			HashMap<String, String> secFiltersMap, IDfSysObject docObj) throws Exception {
		HashMap<String, ArrayList<String>> secRFDataMap = null;

		if (secRFInfoMap != null && secRFInfoMap.size() > 0) {
			String[] objIdArr = secRFInfoMap.get(ISWYApplySECRFConstants.SRF_R_OBJECT_ID_ATTR);
			String[] nonEmptyAttrArr = secRFInfoMap.get(ISWYApplySECRFConstants.TMP_SRF_NON_EMPTY_ATTR_LIST_ATTR);

			if (nonEmptyAttrArr != null && objIdArr != null && objIdArr.length > 0 && nonEmptyAttrArr.length > 0) {
				for (int i = 0; i < objIdArr.length; i++) {
					String objId = objIdArr[i].trim();

					String tmpNonEmptyAttr = nonEmptyAttrArr[i];
					if (tmpNonEmptyAttr != null && !tmpNonEmptyAttr.equalsIgnoreCase("")) {
						String[] nonEmptyData = tmpNonEmptyAttr
								.split("\\s*" + ISWYApplySECRFConstants.DEFAULT_SEPARATOR + "\\s*");
						ArrayList<String> list = new ArrayList<String>();
						for (int incr = 0; incr < nonEmptyData.length; incr++) {
							String[] attrVal = nonEmptyData[incr]
									.split(ISWYApplySECRFConstants.NON_EMPTY_ATTR_VAL_SEPARATOR);

							ArrayList<String> docAttrList = getMapKeyFromValue(secFiltersMap, attrVal[0]);

							for (int j = 0; j < docAttrList.size(); j++) {
								list.add(docAttrList.get(j) + "=" + attrVal[1] + "");
							}
						}
						if (secRFDataMap == null)
							secRFDataMap = new HashMap<String, ArrayList<String>>();
						
						String additionalPredicates=chkSelectedSecrfHasUnMappedAttributesValue(docObj.getSession(),objId);
						if(additionalPredicates.trim().equalsIgnoreCase("error"))
						{
							DfLogger.debug(this, "Return from method chkSelectedSecrfHasUnMappedAttributesValue::: Error as SecRF ["+objId+"]have few filters defined which is not needed", null, null);							
						}
						else if(additionalPredicates==null || additionalPredicates.equals(""))
						{
							secRFDataMap.put(objId, list);
							DfLogger.debug(this, "Return from method chkSelectedSecrfHasUnMappedAttributesValue::: SecRF ["+objId+"] added", null, null);							
						}
					}
				}
			}
		}
		return secRFDataMap;
	}

	private String chkSelectedSecrfHasUnMappedAttributesValue(IDfSession session,String srfObjID) throws Exception
	{
		IDfSysObject secRFObj= (IDfSysObject)session.getObject(new DfId(srfObjID));
		String dictionary_name = ISWYApplySECRFConstants.SRF_FILTER_ATTR_DICTIOANRY_NAME;
		String domain = secRFObj.getString("domain").trim();
		
		if (dAttr==null)
			dAttr = D2Dictionary.getDictionary(dictionary_name, session, null, null, true, false);
		Map<String, String> m_attr_map = dAttr.getKeyToAliasValueMap(domain);

		Set<String> att_keys = m_attr_map.keySet();
		Iterator<String> att_iterator = att_keys.iterator();

		while (att_iterator.hasNext()) {
			String secRFAttr = att_iterator.next(); // name of the column,
			// corresponding to SecRF
			String c_value = m_attr_map.get(secRFAttr); // value (Yes/No),
			// corresponding to SecRF , required in specific domain

			if ((c_value != null && !c_value.equalsIgnoreCase("")
					&& (c_value.toUpperCase().trim().startsWith("N") || c_value.toUpperCase().trim().startsWith("F")) )
					&& !secRFAttr.equalsIgnoreCase(ISWYApplySECRFConstants.SRF_DIVISION_ATTR_NAME)) 
			{
				String doc_attr_name = D2Dictionary.getAliasValue(dictionary_name, secRFAttr,
						ISWYApplySECRFConstants.SRF_FILTER_VALUE_LOOKUP_ATTR, session, null, null, true, false);

				//System.out.println("[["+doc_attr_name+"]]");
				if (doc_attr_name !=null && !doc_attr_name.trim().equalsIgnoreCase("") && !doc_attr_name.trim().toLowerCase().equalsIgnoreCase("nulldate"))
				{
					boolean isUnMappedAttrValueExist=isSecRFUnMappedAttrsHaveValue(secRFObj,secRFAttr);

					if (isUnMappedAttrValueExist)
					{
						return "error";
					}
					else
					{

					}

				}
			}
		}
		return "";
	}
	public HashMap<String, String> getEmptySecRFAttrNames(Map<String, String[]> secRFInfoMap) {
		HashMap<String, String> secRFDataMap = new HashMap<String, String>();

		String[] objIdArr = secRFInfoMap.get(ISWYApplySECRFConstants.SRF_R_OBJECT_ID_ATTR);
		String[] emptyAttrArr = secRFInfoMap.get(ISWYApplySECRFConstants.TMP_SRF_EMPTY_ATTR_LIST_ATTR);

		for (int i = 0; i < objIdArr.length; i++) {
			String objId = objIdArr[i].trim();
			String emptyAttrNames = null;
			if (emptyAttrArr[i] != null && !emptyAttrArr[i].trim().equalsIgnoreCase("")) {
				emptyAttrNames = emptyAttrArr[i].trim();
			}
			secRFDataMap.put(objId, emptyAttrNames);
		}
		return secRFDataMap;
	}

	public List<Entry<String, String[]>> chkSelectedSecRFReturnsSameDocObject(
			List<Entry<String, String[]>> matchedSRFormsData, IDfSysObject sysObj) throws Exception {
		List<Entry<String, String[]>> newMatchedSRFormsData = new ArrayList<Entry<String, String[]>>();

		String docArtifactNameValue = sysObj.getString(ISWYApplySECRFConstants.DOC_ARTIFACT_NAME_ATTR);
		String domainValue = sysObj.getString(ISWYApplySECRFConstants.SRF_DOMAIN_ATTR_NAME);
		List<String> domainList= getClineCrossOverDomains(sysObj.getSession(),docArtifactNameValue,domainValue);
		String doc_obj_type=sysObj.getTypeName() ;
		IDfId sysObjId=sysObj.getObjectId();
		
		
		if(sysObjId.isObjectId())
		{
			String sysObjIdStr=sysObjId.getId();
		for (Entry<String, String[]> entry : matchedSRFormsData) {
			String[] tmpArr = entry.getValue();
			
			String tmpDQL = "Select r_object_id from " + doc_obj_type+ " where";
			int counter = 0;

			for (String str : tmpArr) {
				String[] attrNameVal = str.split("=");

				String attName = attrNameVal[0];
				String attrValue = attrNameVal[1]; /* Doc Attr Value in single quotes*/

				String[] attrNameArr = attName.split(",");

				if (attrNameArr != null && attrNameArr.length > 1) {
					if (counter == 0) {
						tmpDQL = tmpDQL + " (";
					} else if (counter > 0) {
						tmpDQL = tmpDQL + " and (";
					}
					boolean isFirstQueryFilter = true;
					for (int i = 0; i < attrNameArr.length; i++) {
						String attrName = attrNameArr[i];

						if(attrName.trim().equalsIgnoreCase("domain") )
						{
							if(domainList!=null && domainList.size()>0)
							{
								DfLogger.debug(this, "chkSelectedSecRFReturnsSameDocObject()::: adding doamins for Crossover documents",null, null);
								for(int cnt=0;cnt<domainList.size();cnt++)
								{
									if (isFirstQueryFilter) {
										tmpDQL = tmpDQL + " " + attrName + "='" + domainList.get(cnt)+"'";
									} else {
										tmpDQL = tmpDQL + " or " + attrName + "='" + domainList.get(cnt)+"'";
									}
									isFirstQueryFilter = false;
								}						

								continue;
							}
						}

						if (sysObj.hasAttr(attrName)) {

							if (sysObj.isAttrRepeating(attrName)) {
								if (i > 0) {
									tmpDQL = tmpDQL + " or any " + attrName + "=" + attrValue;
								} else {
									tmpDQL = tmpDQL + " any " + attrName + "=" + attrValue;
								}
							} else {
								if (isFirstQueryFilter) {
									tmpDQL = tmpDQL + " " + attrName + "=" + attrValue;
								} else {
									tmpDQL = tmpDQL + " or " + attrName + "=" + attrValue;
								}

							}
							isFirstQueryFilter = false;
						}
					}
					tmpDQL = tmpDQL + ") ";
				} else if (attrNameArr != null && attrNameArr.length == 1) {
					String attrName = attrNameArr[0];

					if(attrName.trim().equalsIgnoreCase("domain") )
					{
						if(domainList!=null && domainList.size()>0)
						{
							DfLogger.debug(this, "chkSelectedSecRFReturnsSameDocObject():::: adding doamins for Crossover documents",null, null);
							if (counter > 0)
								tmpDQL = tmpDQL + " and (";
							else
								tmpDQL = tmpDQL + "  (";
							for(int cnt=0;cnt<domainList.size();cnt++)
							{
								if (cnt==0) {
									tmpDQL = tmpDQL + " " + attrName + "='" + domainList.get(cnt)+"'";
								} else {
									tmpDQL = tmpDQL + " or " + attrName + "='" + domainList.get(cnt)+"'";
								}

							}	
							tmpDQL = tmpDQL + " ) ";
							counter = counter + 1;
							continue;
						}
					}

					if (sysObj.hasAttr(attrName)) {
						if (sysObj.isAttrRepeating(attrName)) {
							if (counter > 0) {
								tmpDQL = tmpDQL + " and any " + attrName + "=" + attrValue;
							} else {
								tmpDQL = tmpDQL + " any " + attrName + "=" + attrValue;
							}
						} else {
							if (counter > 0) {
								tmpDQL = tmpDQL + " and " + attrName + "=" + attrValue;
							} else {
								tmpDQL = tmpDQL + " " + attrName + "=" + attrValue;
							}
						}
					}
				}
				counter = counter + 1;

			}

			if(doc_obj_type.trim().equalsIgnoreCase(ISWYApplySECRFConstants.TMF_DOC_TYPE) || doc_obj_type.trim().equalsIgnoreCase(ISWYApplySECRFConstants.CLINICAL_DOC_TYPE))
			{
				tmpDQL= tmpDQL + " and is_placeholder=0" ;
			}
			
			tmpDQL= tmpDQL + " and r_object_id='"+sysObjIdStr+"'" ;
			DfLogger.info(this, "chkSelectedSecRFReturnsSameDocObject() :::: " + tmpDQL, null, null);
			String objArr[] = QueryUtils.getAllQueryResultsAsStrings(tmpDQL, sysObj.getSession());

			ArrayList<String> alist = new ArrayList<String>(Arrays.asList(objArr));

			if (alist.contains(sysObj.getObjectId().getId())) {
				newMatchedSRFormsData.add(entry);
			}

		}
	}
		return newMatchedSRFormsData;
	}

	/**
	 * Return all map keys in array list , based on value which is passed as
	 * argument.
	 * 
	 * @param secFiltersMap
	 *            : Documents attribute as Key and SecRF attributes as value.
	 *            Multiple key (Document's attribute) may mapped with same secRF
	 *            attribute
	 * @param value
	 *            : SecRF attribute name
	 * @return list, holds all map keys , based on map value which is passed as
	 *         argument.
	 */
	public ArrayList<String> getMapKeyFromValue(HashMap<String, String> secFiltersMap, String value) {
		ArrayList<String> aList = new ArrayList<String>();
		for (String key : secFiltersMap.keySet()) {
			if (secFiltersMap.get(key).equalsIgnoreCase(value)) {
				aList.add(key);
			}
		}
		return aList;
	}

	/**
	 * This method will process the dictionary "CMN-DIC-Security Registration
	 * Form Filter" and returned documents attribute as key and SecRF attributes
	 * as value. The comma separated value in dictionary will be returned as
	 * separate row in the map. The commas separated value (of dictionary i.e.
	 * documents attributes) will be treated as different key and their value
	 * will SecRF attribute (which is actually key in the respective dictionary
	 * i.e. "CMN-DIC-Security Registration Form Filter"), which might be same
	 * for different key (documents attribute)
	 * 
	 * @param sysObject
	 * @return Map, which will have documents attributes as key and SecRF
	 *         attributes as value
	 * @throws Exception
	 */
	public Map<String, String> getSecRFFilterMap(IDfSysObject sysObject) throws Exception {
		DfLogger.debug(this,
				"Date July 18, 2017 :: Version 2.1 :: Updated the code to get filter data for all domains from single dictioanry,  ",
				null, null);
		String dictionary_name = ISWYApplySECRFConstants.SRF_FILTER_ATTR_DICTIOANRY_NAME;
		String domain = sysObject.getString("domain").trim();
		Map<String, String> secFiltersMap = null;
		IDfSession session = sysObject.getSession();
		if (dAttr==null)
			dAttr = D2Dictionary.getDictionary(dictionary_name, session, null, null, true, false);
		Map<String, String> m_attr_map = dAttr.getKeyToAliasValueMap(domain);

		Set<String> att_keys = m_attr_map.keySet();
		Iterator<String> att_iterator = att_keys.iterator();

		while (att_iterator.hasNext()) {
			String secRFAttr = att_iterator.next(); // name of the column,
			// corresponding to SecRF
			String c_value = m_attr_map.get(secRFAttr); // value (Yes/No),
			// corresponding to
			// SecRF , required in
			// specific domain

			if (c_value != null && !c_value.equalsIgnoreCase("")
					&& (c_value.toUpperCase().trim().startsWith("Y") || c_value.toUpperCase().trim().startsWith("T"))) {
				String doc_attr_value = D2Dictionary.getAliasValue(dictionary_name, secRFAttr,
						ISWYApplySECRFConstants.SRF_FILTER_VALUE_LOOKUP_ATTR, session, null, null, true, false);

				if (secFiltersMap == null)
					secFiltersMap = new HashMap<String, String>();
				secFiltersMap.put(doc_attr_value, secRFAttr);

			}
		}
		if(secFiltersMap!=null)
			DfLogger.debug(this, "SWYApplySecRFHelper: Returning available list fo filters, based on domain [" + domain
					+ "]  " + secFiltersMap.values(), null, null);
		else
			DfLogger.debug(this, "SWYApplySecRFHelper: Returning available list fo filters, based on domain [" + domain
					+ "]  " + secFiltersMap, null, null);
		return secFiltersMap;
	}

	/**
	 * This method will process dictionary "CMN-DIC-Security Registration Form
	 * Filter" and return only those Doc object attributes which is multiple
	 * (comma separtaed ) but mapped with one SecRF attribute in the dictionary
	 * 
	 * @param sysObject
	 * @return
	 * @throws Exception
	 */
	public Map<String, ArrayList<String>> getMultipleDocAttrMappedWithSameSecRFAttr(IDfSysObject sysObject)
			throws Exception {
		DfLogger.debug(this,
				"Date July 18, 2017 :: Version 2.1 :: Updated the code to get filter data for all domains from single dictioanry,  ",
				null, null);
		String dictionary_name = ISWYApplySECRFConstants.SRF_FILTER_ATTR_DICTIOANRY_NAME;
		String domain = sysObject.getString("domain").trim();
		Map<String, ArrayList<String>> secFiltersMap = null;

		IDfSession session = sysObject.getSession();
		if (dAttr==null)
			dAttr = D2Dictionary.getDictionary(dictionary_name, session, null, null, true, false);
		Map<String, String> m_attr_map = dAttr.getKeyToAliasValueMap(domain);

		Set<String> att_keys = m_attr_map.keySet();
		Iterator<String> att_iterator = att_keys.iterator();

		while (att_iterator.hasNext()) {
			String c_att = att_iterator.next(); // name of the column,
			// corresponding to SecRF
			String c_value = m_attr_map.get(c_att); // value (Yes/No),
			// corresponding to SecRF , required in specific domain

			if (c_value.toUpperCase().trim().startsWith("Y") || c_value.toUpperCase().trim().startsWith("T")) {
				String doc_attr_value = D2Dictionary.getAliasValue(dictionary_name, c_att,
						ISWYApplySECRFConstants.SRF_FILTER_VALUE_LOOKUP_ATTR, session, null, null, true, false);

				if (doc_attr_value != null && !doc_attr_value.trim().equalsIgnoreCase("")) {
					String[] doc_attr_arr = doc_attr_value.split(",");

					if (doc_attr_arr != null && doc_attr_arr.length > 1) {
						ArrayList<String> tmpList = new ArrayList<>(Arrays.asList(doc_attr_arr));

						if (secFiltersMap == null)
							secFiltersMap = new HashMap<String, ArrayList<String>>();
						secFiltersMap.put(c_att, tmpList);
					}
				}
			}
		}
		DfLogger.debug(this,
				"getMultipleDocAttrMappedWithSameSecRFAttr(): Returning available list fo filters, based on domain ["
						+ domain + "]  " + secFiltersMap.values(),
						null, null);
		return secFiltersMap;
	}

	/**
	 * Map, no.of non-null attributes (from document object based on SecRF
	 * filter Map's key , which holds attribute from doc object.) as key and
	 * string arraylist as value. The arraylist holds non-null attributes and
	 * their value as docAttrName=docAttrValue.
	 * 
	 * @param docObject
	 * @param secFiltersMap
	 * @return Map, no.of non-null attributes (from document object based on
	 *         SecRF filter Map's key , which holds attribute from doc object.)
	 *         as key and string arraylist as value. The arraylist holds
	 *         non-null attributes and their value as docAttrName=docAttrValue.
	 *         There will be different multiple indexes for repeating
	 *         attributes. e.g . docRepeatingAttr1= docRepeatingAttrVal1,
	 *         docRepeatingAttr1= docRepeatingAttrVal2, docRepeatingAttr1=
	 *         docRepeatingAttrVal3.
	 * @throws DfException
	 */
	public Map<String, ArrayList<String>> getDocumentData(IDfSysObject docObject, Map<String, String> secFiltersMap)
			throws Exception {
		int attrCounter = 0;
		Map<String, ArrayList<String>> docDataMap = new HashMap<String, ArrayList<String>>();

		Iterator<String> secFilterMapIterator = secFiltersMap.keySet().iterator();

		ArrayList<String> docDataList = new ArrayList<String>();

		while (secFilterMapIterator.hasNext()) {
			String docAttr = (String) secFilterMapIterator.next();

			boolean attributesValueFound = false;

			if (docAttr != null && !docAttr.equalsIgnoreCase("")) {
				String[] docAttrArr = docAttr.split(",");

				if (docAttrArr != null && docAttrArr.length > 0) {
					String key = docAttr;
					for (int j = 0; j < docAttrArr.length; j++) {
						String docAttribute = docAttrArr[j];
						if (docObject.hasAttr(docAttribute)) {
							// String key=docAttribute;
							String value = "";
							if (docObject.isAttrRepeating(docAttribute)) {
								int attrDataType = docObject.getAttrDataType(docAttribute);
								int valcount = docObject.getValueCount(docAttribute);
								if (valcount > 0) {
									for (int i = 0; i < valcount; i++) {
										value = docObject.getRepeatingString(docAttribute, i);
										if (value != null && !value.equalsIgnoreCase("")
												&& !value.trim().equalsIgnoreCase("nulldate")) {
											if (attrDataType == 4) // Time
											{
												value = "date('" + value + " utc','"
														+ ISWYApplySECRFConstants.DCTM_DATE_ATTR_FORMAT + "')";
												docDataList.add(key + "=" + value + "");
											} else if (attrDataType == 0) // Boolean
											{
												if (value.equalsIgnoreCase("true") || value.equalsIgnoreCase("t")
														|| value.equalsIgnoreCase("1")) {
													value = "1";
												} else if (value.equalsIgnoreCase("false")
														|| value.equalsIgnoreCase("f") || value.equalsIgnoreCase("0")) {
													value = "0";
												}
												docDataList.add(key + "=" + value + "");
											} 
											else if (attrDataType == 1 || attrDataType == 5) // Number  ||  Double
											{
												docDataList.add(key + "=" + value + "");
											} 
											else if (attrDataType == 2 || attrDataType == 3) // String  || Id
											{
												docDataList.add(key + "='" + value + "'");
											}
											attributesValueFound = true;
										}
									}
								}
							} else {
								value = docObject.getString(docAttribute);
								if (value != null && !value.equalsIgnoreCase("")
										&& !value.trim().equalsIgnoreCase("nulldate")) {
									int attrDataType = docObject.getAttrDataType(docAttribute);

									if (attrDataType == 4) // Time
									{
										value = "date('" + value + " utc','"
												+ ISWYApplySECRFConstants.DCTM_DATE_ATTR_FORMAT + "')";
										docDataList.add(key + "=" + value + "");
									} else if (attrDataType == 0) // Boolean
									{
										if (value.equalsIgnoreCase("true") || value.equalsIgnoreCase("t")
												|| value.equalsIgnoreCase("1")) {
											value = "1";
										} else if (value.equalsIgnoreCase("false") || value.equalsIgnoreCase("f")
												|| value.equalsIgnoreCase("0")) {
											value = "0";
										}
										docDataList.add(key + "=" + value + "");
									} else if (attrDataType == 1 || attrDataType == 5) // Number
										// ||
										// Double
									{
										docDataList.add(key + "=" + value + "");
									} else if (attrDataType == 2 || attrDataType == 3) // String
										// ||
										// Id
									{
										docDataList.add(key + "='" + value + "'");
									}
									attributesValueFound = true;
								}

								if(docAttribute.trim().equals(ISWYApplySECRFConstants.DOC_ARTIFACT_NAME_ATTR))
								{
									String domainStr=docObject.getString(ISWYApplySECRFConstants.SRF_DOMAIN_ATTR_NAME);
									List<String> domainList= getClineCrossOverDomains(docObject.getSession(),value,domainStr);

									for(int incr=0;incr<domainList.size();incr++)
									{
										docDataList.add("domain" + "='" + domainList.get(incr) + "'");
									}
								}




							}
							if (attributesValueFound) {
								attrCounter = attrCounter + 1;
							}
						}
					}
				}
			}
		}
		docDataMap.put(String.valueOf(attrCounter), docDataList);
		return docDataMap;
	}

	/**
	 * 
	 * @param secRFDataMap
	 *            : Security registration form's data , relevant ones
	 * @param docDataMap
	 *            , Document object data list
	 * @return list, which contains most restricted registration form data
	 */
	public List<Entry<String, String[]>> getMatchedAndMostRestrictiveSecRF(Map<String, ArrayList<String>> secRFDataMap,
			Map<String, ArrayList<String>> docDataMap, Map<String, String[]> secRFInfoMap) throws Exception {
		Map<String, String[]> mostRestrictiveRegFormsList = new HashMap<String, String[]>();
		List<Entry<String, String[]>> largestList = new ArrayList<Entry<String, String[]>>();
		int docAttributeCounter = 0;

		Map<String, String> emptySecRFAttrMap = getEmptySecRFAttrNames(secRFInfoMap);

		Iterator<String> iterator = docDataMap.keySet().iterator();
		while (iterator.hasNext()) {
			docAttributeCounter = Integer.parseInt(iterator.next()); // it will
			// always have only one row
		}

		ArrayList<String> docList = docDataMap.get(String.valueOf(docAttributeCounter));
		// first filter out all the reg forms that matches either 1 or more
		// applicable filter attributes of the document

		int maxAttrMatchingCounter = 0;
		for (Map.Entry<String, ArrayList<String>> entry : secRFDataMap.entrySet()) {
			String keyObjId = entry.getKey();
			Set<String> registrationFormSet = new HashSet<String>(entry.getValue());
			Set<String> documentSet = new HashSet<String>(docList);
			registrationFormSet.retainAll(documentSet);

			if (registrationFormSet.size() == entry.getValue().size()) /* All SecRF attribute are subset of Document object*/
			{
				// String[] valueArr= registrationFormSet.toArray(new
				// String[registrationFormSet.size()]);

				/*
				 * int matchedAttrSize=registrationFormSet.size(); String
				 * empty_data_attr_names=emptySecRFAttrMap.get(keyObjId); //Is
				 * cross domain true if(empty_data_attr_names!=null &&
				 * empty_data_attr_names.toLowerCase().trim().contains("domain")
				 * ) { matchedAttrSize=matchedAttrSize+1; }
				 * 
				 * if(matchedAttrSize>maxAttrMatchingCounter) {
				 * mostRestrictiveRegFormsList = new HashMap<String,
				 * String[]>(); String[] valueArr=
				 * registrationFormSet.toArray(new
				 * String[registrationFormSet.size()]);
				 * mostRestrictiveRegFormsList.put(keyObjId, valueArr);
				 * maxAttrMatchingCounter=matchedAttrSize; } else
				 * if(matchedAttrSize==maxAttrMatchingCounter) { String[]
				 * valueArr= registrationFormSet.toArray(new
				 * String[registrationFormSet.size()]);
				 * if(mostRestrictiveRegFormsList.containsKey(keyObjId)) {
				 * String[] tmpArr=mostRestrictiveRegFormsList.get(keyObjId);
				 * if(valueArr.length>tmpArr.length) {
				 * mostRestrictiveRegFormsList.put(keyObjId, valueArr); } } else
				 * { mostRestrictiveRegFormsList.put(keyObjId, valueArr); } }
				 */
				String[] valueArr = registrationFormSet.toArray(new String[registrationFormSet.size()]);
				if (mostRestrictiveRegFormsList == null) {
					mostRestrictiveRegFormsList = new HashMap<String, String[]>();
				}
				mostRestrictiveRegFormsList.put(keyObjId, valueArr);
			}
		}

		// Now get the most restrictive or the list of restrictive reg forms.
		// There can more than 1
		for (Entry<String, String[]> i : mostRestrictiveRegFormsList.entrySet()) {
			largestList.add(i);
		}

		return largestList;
	}

	/**
	 * 
	 * @param secrf_object_name
	 * @param r_creator_name
	 * @param session
	 * @return
	 * @throws DfException
	 */
	public boolean checkAuthorExistInSelectedSecRF(String secrf_object_name, String r_creator_name, IDfSession session)
			throws DfException {
		DfLogger.debug(this,
				"Date May 03, 2017 :: Version 2.1 :: Updated the code and added the DQLs to check whether the author are part of Selected SecRF or not recursively::::: ",
				null, null);
		boolean isAuthorExist = false;
		// String chkAuthorDql="select count(r_object_id) from
		// swy_sec_registration_form where object_name='"+secrf_object_name+"'
		// and any authors='"+r_creator_name+"'";

		String newChkAuthorDql = "select count(" + ISWYApplySECRFConstants.RETRIEVE_AUTHORS_RECORD_ATTR
				+ ") from swy_sec_registration_form where '" + r_creator_name + "' in " + "(select "
				+ ISWYApplySECRFConstants.RETRIEVE_AUTHORS_RECORD_ATTR
				+ " from swy_sec_registration_form where object_name='" + secrf_object_name + "') or '" + r_creator_name
				+ "' in " + "(select i_all_users_names from dm_group where group_name in (select "
				+ ISWYApplySECRFConstants.RETRIEVE_AUTHORS_RECORD_ATTR
				+ " from swy_sec_registration_form where object_name='" + secrf_object_name + "'))";

		DfLogger.debug(this, "Check author is part of SecRF or not [" + newChkAuthorDql + "]", null, null);
		String authorOccuranceCount = QueryUtils.execQuery(newChkAuthorDql, session);
		int authorOccurance = Integer.parseInt(authorOccuranceCount);

		if (authorOccuranceCount != null && !authorOccuranceCount.trim().equalsIgnoreCase("") && authorOccurance > 0) {
			isAuthorExist = true;
		}

		return isAuthorExist;
	}

	/**
	 * 
	 * @param restrictiveRFormsData
	 *            : list, which will have most restricted security registration
	 *            form data
	 * @param srFilters
	 *            : Security Registration Filters, values are coming from the
	 *            dictionary named "CMN-DIC-Security Registration Form Filter".
	 * @return : Qualification to fetch security registration forms
	 * @throws DfException
	 */
	public String getQualificationToFetchSRF(List<Entry<String, String[]>> restrictiveSRFormsData,
			Map<String, String> srFilters) throws DfException {
		DfLogger.debug(this, "::getQualificationToFetchSRF-----srFilters" + srFilters.values(), null, null);
		String qualificationStr = "";
		int counter = 0;
		for (Entry<String, String[]> entry : restrictiveSRFormsData) {
			String[] restrictiveRFormData = entry.getValue();
			String key = entry.getKey();
			if (counter > 0) {
				qualificationStr = qualificationStr + " or ( ";
			}
			String innerQualificationstr = "";
			for (int index = 0; index < restrictiveRFormData.length; index++) {
				String[] attr_val_data = restrictiveRFormData[index].split("=");
				String secRFAttrName = srFilters.get(attr_val_data[0]);

				if (counter == 0 && index == 0) {
					innerQualificationstr = secRFAttrName + "=" + attr_val_data[1];
				} else if (counter > 0 && index == 0) {
					innerQualificationstr = innerQualificationstr + "  " + secRFAttrName + "=" + attr_val_data[1];
				} else {
					innerQualificationstr = innerQualificationstr + " and " + secRFAttrName + "=" + attr_val_data[1];
				}
			}
			if (!innerQualificationstr.trim().contains("domain")) {
				innerQualificationstr = innerQualificationstr + " and (domain='' or domain is nullstring)  ";
			}
			innerQualificationstr = innerQualificationstr + " and r_object_id='" + key + "' ";
			qualificationStr = qualificationStr + innerQualificationstr;
			if (counter > 0) {
				qualificationStr = qualificationStr + " ) ";
			}
			counter = counter + 1;
		}
		return qualificationStr;
	}

	public String replaceChar(String str, String charToReplace, String Separator) {
		String returnStr = "";

		// returnStr=str.replaceAll("(?<!\\w)-(?!\\w)", "~");
		// Search space in string surrounded with some other character, except space, from both end and then replace - with ~.
		returnStr = str.replaceAll("(?<=\\S)" + charToReplace + "(?=\\S)", Separator); 
		return returnStr.trim();
	}

	public List<String> split(String text, String separator) {
		List<String> result = new ArrayList<String>();

		if (text != null) {
			if ((separator == null) || (separator.length() == 0)) {
				result.add(text.trim());
				System.out.println("texttt=[" + text + "]");
			} else {
				int posStart = 0;
				int posEnd = text.indexOf(separator);

				while (posEnd != -1) {
					String token = text.substring(posStart, posEnd).trim();
					result.add(token);
					System.out.println("tokennn=[" + token + "]");
					posStart = posEnd + separator.length();
					posEnd = text.indexOf(separator, posStart);
				}

				if (posStart <= text.length()) {
					String token = text.substring(posStart).trim();
					result.add(token);
					System.out.println("token=[" + token + "]");
				}
			}
		}

		return result;
	}

	public HashMap<String, String> getMapFromArguments(String argumentVal) {
		HashMap<String, String> parserMap = new HashMap<String, String>();

		String replacedStr = replaceChar(argumentVal, "-", ISWYApplySECRFConstants.DEFAULT_SEPARATOR);
		DfLogger.debug(this,
				" ~~~~~~~~ Notification Scenario / Performers Mapping Scenario Params  [" + replacedStr + "] ~~~~~~~~ ",
				null, null);

		List<String> noti_list = split(replacedStr, "-");

		for (int cntr = 0; cntr < noti_list.size(); cntr++) {
			String argParam = noti_list.get(cntr);

			if (argParam != null && !argParam.trim().equalsIgnoreCase("")) {
				String argParserKey = "-" + (argParam.substring(0, argParam.indexOf(" ")).trim());
				String argParserValue = (argParam.substring(argParam.indexOf(" "), argParam.length()).trim())
						.replaceAll(ISWYApplySECRFConstants.DEFAULT_SEPARATOR, "-");

				parserMap.put(argParserKey, argParserValue);
				DfLogger.debug(this, "Parser Key [" + argParserKey + "] Parser Value [" + argParserValue + "]", null,
						null);
			}
		}

		return parserMap;
	}

	public static String countToString(int paramInt, String paramString1, String paramString2) {
		if (paramInt == 1) {
			return Integer.toString(paramInt) + " " + paramString1;
		}
		return Integer.toString(paramInt) + " " + paramString2;
	}

	public static String countToString(int paramInt, String paramString) {
		if ((paramString == null) || (paramString.length() == 0)) {
			return Integer.toString(paramInt);
		}
		int i = paramString.length() - 1;
		if (paramString.charAt(i) == 'y') {
			return countToString(paramInt, paramString, paramString.substring(0, i) + "ies");
		}
		return countToString(paramInt, paramString, paramString + "s");
	}

	// secFiltersMap : DocAttr as Key, SecRF_Attr as Value.
	public Object[] chkSwyAttrExistInDocModel(String swyAttr, HashMap<String, String> secFiltersMap,
			IDfSysObject docObj) throws Exception {
		String docAttrNames = null;

		Object[] processData = null;

		if (swyAttr != null && !swyAttr.trim().equalsIgnoreCase("")) {
			Iterator<Entry<String, String>> entrySetIterator = secFiltersMap.entrySet().iterator();
			while (entrySetIterator.hasNext()) {
				Entry<String, String> entry = entrySetIterator.next();
				if (entry.getValue().trim().equals(swyAttr)) {
					docAttrNames = entry.getKey();
					break;
				}
			}
		}

		if (docAttrNames != null && !docAttrNames.trim().equalsIgnoreCase("")) {
			String[] docAttrs = docAttrNames.split(",");
			for (int i = 0; i < docAttrs.length; i++) {
				String docAttr = docAttrs[i];
				if (docAttr != null) {
					if (docObj.hasAttr(docAttr)) {
						processData = new Object[3];
						processData[0] = Boolean.valueOf(true);
						processData[1] = docAttr;
						processData[2] = docObj.getAttrDataType(docAttr);
						break;
					}
				}
			}
			if (processData == null) {
				processData = new Object[1];
				processData[0] = Boolean.valueOf(false);
			}
		}

		return processData;
	}

	public String getAllApplicableFormMgrs(IDfSysObject docObject) {
		String formMgrs = null;
		try {
			String objectId = docObject.getObjectId().getId();
			DfLogger.debug(this, " Object id [" + objectId + "]  Fetching All Appllicable Form Managers ", null, null);

			String formMgrsDQL = "select user_name as " + ISWYApplySECRFConstants.RETRIEVE_FORM_MANAGERS_RECORD_ATTR
					+ " from dm_user where user_name in (select distinct "
					+ ISWYApplySECRFConstants.RETRIEVE_FORM_MANAGERS_RECORD_ATTR
					+ " from swy_sec_registration_form where " + " object_name in (select distinct "
					+ ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME
					+ " from cd_controlled_doc where r_object_id='" + objectId + "')) and user_state=0 " + " union "
					+ " select i_all_users_names as " + ISWYApplySECRFConstants.RETRIEVE_FORM_MANAGERS_RECORD_ATTR
					+ " from dm_group where group_name in (select distinct "
					+ ISWYApplySECRFConstants.RETRIEVE_FORM_MANAGERS_RECORD_ATTR + " from swy_sec_registration_form "
					+ "where object_name in (select distinct " + ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME
					+ " from cd_controlled_doc where r_object_id='" + objectId + "'))";

			DfLogger.debug(this, "Fetching All Appllicable Form Managers [" + formMgrsDQL + "]", null, null);
			String[] form_mgrs = QueryUtils.getAllQueryResultsAsStrings(formMgrsDQL, docObject.getSession());

			formMgrs = form_mgrs != null && form_mgrs.length > 0
					? concatString(ISWYApplySECRFConstants.DEFAULT_SEPARATOR, form_mgrs) : null;

		} catch (Exception ex) {
			DfLogger.error(this, ex.getLocalizedMessage(), null, ex);
		}
		return formMgrs;
	}

	public String getAllExistingAuthors(IDfSysObject docObject) {
		String authors_str = null;
		try {
			String objectId = docObject.getObjectId().getId();
			DfLogger.debug(this, " Object id [" + objectId + "]  Fetching All Authors ", null, null);

			String authorsDQL = "select user_name as " + ISWYApplySECRFConstants.RETRIEVE_AUTHORS_RECORD_ATTR
					+ " from dm_user where user_name in (select distinct "
					+ ISWYApplySECRFConstants.RETRIEVE_AUTHORS_RECORD_ATTR + " from cd_controlled_doc "
					+ " where r_object_id='" + objectId + "') and user_state=0" + " union "
					+ " select i_all_users_names as " + ISWYApplySECRFConstants.RETRIEVE_AUTHORS_RECORD_ATTR
					+ " from dm_group where group_name in (select distinct "
					+ ISWYApplySECRFConstants.RETRIEVE_AUTHORS_RECORD_ATTR + " from cd_controlled_doc "
					+ "where r_object_id='" + objectId + "')";

			DfLogger.debug(this, "Fetching All Authors [" + authorsDQL + "]", null, null);
			String[] authors = QueryUtils.getAllQueryResultsAsStrings(authorsDQL, docObject.getSession());

			authors_str = authors != null && authors.length > 0
					? concatString(ISWYApplySECRFConstants.DEFAULT_SEPARATOR, authors) : null;
		} catch (Exception ex) {
			DfLogger.error(this, ex.getLocalizedMessage(), null, ex);
		}
		return authors_str;
	}

	public String getAllApplicableAuthors(IDfSysObject docObject) {
		String formMgrs = null;
		try {
			String objectId = docObject.getObjectId().getId();
			DfLogger.debug(this, " Object id [" + objectId + "]  Fetching All Appllicable Authors ", null, null);

			String formMgrsDQL = "select user_name as " + ISWYApplySECRFConstants.RETRIEVE_AUTHORS_RECORD_ATTR
					+ " from dm_user where user_name in (select distinct "
					+ ISWYApplySECRFConstants.RETRIEVE_AUTHORS_RECORD_ATTR + " from swy_sec_registration_form where "
					+ " object_name in (select distinct " + ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME
					+ " from cd_controlled_doc where r_object_id='" + objectId + "')) and user_state=0 " + " union "
					+ " select i_all_users_names as " + ISWYApplySECRFConstants.RETRIEVE_AUTHORS_RECORD_ATTR
					+ " from dm_group where group_name in (select distinct "
					+ ISWYApplySECRFConstants.RETRIEVE_AUTHORS_RECORD_ATTR + " from swy_sec_registration_form "
					+ "where object_name in (select distinct " + ISWYApplySECRFConstants.ALL_AVAILABLE_SRFS_ATTR_NAME
					+ " from cd_controlled_doc where r_object_id='" + objectId + "'))";

			DfLogger.debug(this, "Fetching All Appllicable Authors [" + formMgrsDQL + "]", null, null);
			String[] form_mgrs = QueryUtils.getAllQueryResultsAsStrings(formMgrsDQL, docObject.getSession());

			formMgrs = form_mgrs != null && form_mgrs.length > 0
					? concatString(ISWYApplySECRFConstants.DEFAULT_SEPARATOR, form_mgrs) : null;
		} catch (Exception ex) {
			DfLogger.error(this, ex.getLocalizedMessage(), null, ex);
		}
		return formMgrs;
	}

	public void updateBAsWithFormMgrs(IDfSysObject docObject, String[] srfObjNames, IDfSession session,
			boolean isApplyToPreviousVersions) {
		try {
			// String
			// docsApplicableSecRFMgrs=getAllApplicableFormMgrs(docObject);
			String secRFDql = "select user_name as form_managers from dm_user where user_name in (select distinct form_managers from swy_sec_registration_form "
					+ "where  object_name in ("; // +srfObjName+"') and
			// user_state=0 ";

			for (int i = 0; i < srfObjNames.length; i++) {
				if (i == 0)
					secRFDql = secRFDql + " '" + srfObjNames[i] + "'";
				else
					secRFDql = secRFDql + " , '" + srfObjNames[i] + "'";
			}
			secRFDql = secRFDql + ") ) and user_state=0 ";

			DfLogger.debug(this, "Fetching All Appllicable Form managers from SecRF object [" + secRFDql + "]", null,
					null);
			String[] secrf_form_mgrs = QueryUtils.getAllQueryResultsAsStrings(secRFDql, session);
			String docsApplicableSecRFMgrs = concatString(ISWYApplySECRFConstants.DEFAULT_SEPARATOR, secrf_form_mgrs);

			DfLogger.debug(this, "updating BAs with [" + docsApplicableSecRFMgrs + "] values", null, null);
			String formMgrs[] = (docsApplicableSecRFMgrs != null && !docsApplicableSecRFMgrs.trim().equalsIgnoreCase("")
					? docsApplicableSecRFMgrs.split(ISWYApplySECRFConstants.DEFAULT_SEPARATOR) : null);

			if (formMgrs != null && formMgrs.length > 0) {
				ArrayList<String> formMgrsToUpdate = new ArrayList<>();
				for (int i = 0; i < formMgrs.length; i++) {
					if (formMgrs[i] != null && formMgrs[i].trim().length() > 0) {
						String form_mgrs = formMgrs[i].trim();
						if (docObject.findString(ISWYApplySECRFConstants.APPEND_FORM_MANAGERS_TO_ATTR, form_mgrs) == -1) // not
							// found
						{
							docObject.appendString(ISWYApplySECRFConstants.APPEND_FORM_MANAGERS_TO_ATTR, form_mgrs);
							formMgrsToUpdate.add(form_mgrs);

						}
					}
				}

				DfLogger.debug(this, "updating BAs with [" + docsApplicableSecRFMgrs + "] values done", null, null);
			}

		} catch (Exception ex) {
			DfLogger.error(this, ex.getLocalizedMessage(), null, ex);
		}
		// return docObject;
	}

	public Map<java.lang.String,java.lang.String[]> getCheckoutInfo(String objId,IDfSession session)  throws DfException
	{
		String dql_get_checkedOutInfo="select r_lock_owner,r_lock_machine,datetostring(r_lock_date,'"+ISWYApplySECRFConstants.DQL_DATE_ATTR_YYYYMMDDHHMISS_FORMAT+"') as r_lock_date,r_modifier,i_vstamp from dm_document  where r_object_id='"+objId+"'";
		Map<java.lang.String,java.lang.String[]> coll_Checked_Out=QueryUtils.getAllQueryResultColumnValues(dql_get_checkedOutInfo,true,session);

		return coll_Checked_Out;
	}

	public boolean documnetReCheckinWithOldDetails(String objId,IDfSession session, Map<java.lang.String,java.lang.String[]> coll_Checked_Out,boolean calculate_sec_statistics) throws DfException
	{
		//boolean calculate_sec_statistics=argParser.getBooleanArgument(ARG_CALCULATE_SECRF_STATISTICS, false);
		IDfSysObject sysTmpObject=(IDfSysObject)session.getObject(new DfId(objId));
		sysTmpObject.fetch(null);

		boolean isCheckin=false;
		DfLogger.info(this, "::: documnetReCheckinWithOldDetails () ::: calculate_secrf_statistics  >> " + calculate_sec_statistics, null, null);
		String lock_time=coll_Checked_Out.get("r_lock_date")[0];
		DfLogger.debug(this,"lock_time   ["+lock_time+"]",null,null);
		String lock_owner=coll_Checked_Out.get("r_lock_owner")[0];
		String lock_machine=coll_Checked_Out.get("r_lock_machine")[0];
		String doc_last_modifier=coll_Checked_Out.get("r_modifier")[0];
		int count_vstamp=sysTmpObject.getVStamp();

		String empty_val=" ";

		if(!calculate_sec_statistics)
		{
			String tmpDQL="EXECUTE exec_sql WITH query='update dm_sysobject_s set r_modifier=''"+doc_last_modifier+"'' , r_lock_owner=''"+lock_owner+"'' "
					+ ", r_lock_machine=''"+lock_machine+"'' , r_lock_date=TO_DATE(''"+lock_time+"'' ,''"+ISWYApplySECRFConstants.ORACLE_DATE_ATTR_FORMAT+"'' ) , i_vstamp=''"+(count_vstamp+1)+"'' "
					+ "where r_object_id=''"+objId+"'' ';";
			DfLogger.info(this,"DQL to put lock owner after applying SecRF ["+tmpDQL+"]",null,null);
			System.out.println("DQL to put lock owner after applying SecRF ["+tmpDQL+"]");
			QueryUtils.execQuery(tmpDQL,session);

			AuditTrailItem auditItem=new AuditTrailItem(session,"dm_lock");            
			auditItem.setAuditedId(new DfId(objId));
			auditItem.setTimeStamp(new DfTime());
			auditItem.setAttributeListOld("r_lock_owner="+lock_owner+", i_vstamp="+(count_vstamp)+",r_lock_machine="+empty_val);
			auditItem.setAttributeList("r_lock_owner="+empty_val+", i_vstamp="+(count_vstamp+1)+",r_lock_machine="+lock_machine+",r_lock_date="+lock_time+",r_modifier="+doc_last_modifier);

			auditItem.setEventSource(this.getClass().getName());// max 64 chars.
			auditItem.setString1("Update attributes to relock object");
			auditItem.save();

			isCheckin=true;
		}
		else
		{
			isCheckin=true;
		}

		DfLogger.debug(this, "Document Checkin status ["+isCheckin+"]", null, null);
		return isCheckin;
	}

	/**
	 * This method cancel the checkout operation by releasing the lock from document.
	 * @param objId : Object Id of the document for which performing cancel checkout
	 * @param session : session
	 * @param calculate_sec_statistics: True or False. If true, means checkout operation needs to check only for statistics. If false, checkout operation needs to perform on document. 
	 * @return
	 * @throws DfException
	 */
	public boolean isCheckOutAborted(String objId,IDfSession session, boolean calculate_sec_statistics) throws DfException
	{
		//boolean calculate_sec_statistics=argParser.getBooleanArgument(ARG_CALCULATE_SECRF_STATISTICS, false);
		boolean isCheckOutCancel=false;
		DfLogger.info(this, "::: isCheckOutAborted () ::: calculate_secrf_statistics  >> " + calculate_sec_statistics, null, null);

		Map<java.lang.String,java.lang.String[]> coll_Checked_Out=getCheckoutInfo(objId,session);
		String lock_owner=coll_Checked_Out.get("r_lock_owner")[0];

		//DfLogger.info(this,"Validating Document["+objId+"] is Checked-out or not r_lock_date["+lock_time+"] r_lock_owner["+lock_owner+"] r_lock_machine["+lock_machine+"] r_modifier["+doc_last_modifier+"] i_vstamp["+count_vstamp+"]",null,null);

		//if(!StringUtils.isNullOrEmpty(lock_owner) )	//Document is checked-out
		if(!lock_owner.trim().equalsIgnoreCase("") )	//Document is checked-out
		{
			DfLogger.info(this,"Document ["+objId+"] is checked out",null,null);
			String empty_val=" ";

			String lock_machine=coll_Checked_Out.get("r_lock_machine")[0];
			int count_vstamp=Integer.parseInt(coll_Checked_Out.get("i_vstamp")[0]);

			if(!calculate_sec_statistics)
			{
				String tmpDQL="EXECUTE exec_sql WITH query='update dm_sysobject_s set r_lock_owner=''"+empty_val+"'' , i_vstamp=''"+(count_vstamp+1)+"'' where r_object_id=''"+objId+"'' ';";
				DfLogger.info(this,"DQL to remove lock owner for applying SecRF ["+tmpDQL+"]",null,null);
				System.out.println("DQL to remove lock owner for applying SecRF ["+tmpDQL+"]");
				QueryUtils.execQuery(tmpDQL,session);

				AuditTrailItem auditItem=new AuditTrailItem(session,"dm_unlock");            
				auditItem.setAuditedId(new DfId(objId));
				auditItem.setTimeStamp(new DfTime());
				auditItem.setAttributeListOld("r_lock_owner="+lock_owner+", i_vstamp="+(count_vstamp)+",r_lock_machine="+lock_machine);
				auditItem.setAttributeList("r_lock_owner="+empty_val+", i_vstamp="+(count_vstamp+1)+",r_lock_machine="+empty_val);
				auditItem.setEventSource(this.getClass().getName());// max 64 chars.
				auditItem.setString1("Update attributes to unlock object before applying SecRF");
				auditItem.save();

				isCheckOutCancel=true;
			}
			else
			{
				isCheckOutCancel=true;
			}

			DfLogger.debug(this, "Document Checkout cancellation status ["+isCheckOutCancel+"]", null, null);
		}
		return isCheckOutCancel;
	}

	public boolean isWorkflowOrQcAborted(IDfSysObject documentObj, IDfSession session, boolean is_secrf_stat) throws Exception
	{
		//IDfSysObject documentObj = (IDfSysObject) session.getObject(new DfId(dfId));

		if(documentObj.getTypeName().equalsIgnoreCase(ISWYApplySECRFConstants.TMF_DOC_TYPE))
		{
			if(documentObj.getBoolean(ISWYApplySECRFConstants.DOC_IS_IN_WF_ATTR_NAME))
			{
				return isWorkflowAborted(documentObj,session,is_secrf_stat);
			}
			else
			{
				return isQCAborted(documentObj,is_secrf_stat);
			}
		}
		else
		{
			return isWorkflowAborted(documentObj,session,is_secrf_stat);
		}
	}

	public boolean isQCAborted(IDfSysObject  documentObj, boolean is_secrf_stat)throws Exception
	{
		String qc_user_value=documentObj.getString(ISWYApplySECRFConstants.TMF_QC_USER_ATTR);

		if(qc_user_value!=null && !qc_user_value.trim().equalsIgnoreCase("") && !qc_user_value.trim().equalsIgnoreCase("none")) // Already Acquired
		{
			DfLogger.debug(this,"Document is already acquired for QC",null,null);
			if (!is_secrf_stat) // if request is not for SecRF statistics, in this case need to perform abort operation also
			{
				documentObj.setString(ISWYApplySECRFConstants.TMF_QC_USER_ATTR, ISWYApplySECRFConstants.TMF_QC_USER_DEFAULT_VAL);
				DfLogger.debug(this,"Removing Document's acquition for QC",null,null);
				return true;
			}
			else
			{
				return true;
			}
		}
		else
		{
			return false;	// Document is not in QC
		}
	}

	public boolean isWorkflowAborted(IDfSysObject docObject, IDfSession session, boolean is_secrf_stat) throws DfException{
		String dfId=docObject.getObjectId().getId();
		DfLogger.info(this, "Object Ids [" + dfId + "] Aborting Workflows method ::: isWorkflowAborted() start ", null,
				null);
		boolean bool = false;
		try {
			DfId docId = new DfId(dfId);
			//IDfSysObject docObject = (IDfSysObject) session.getObject(docId);

			if (docObject != null && docObject.getBoolean(ISWYApplySECRFConstants.DOC_IS_IN_WF_ATTR_NAME)) {
				if (!is_secrf_stat) // if request is not for SecRF statistics,
					// in this case need to perform operation
					// also
				{

					String method_args = "-id " + dfId + " -package_item true -operation \"stop\" -event \"d2_workflow_abort\" -audit true -if "+"select '1' as result from dm_dbo.single_result_row_view where '"+docObject.getValue("a_status")+"'='"+docObject.getValue("a_status")+"'";

					HashMap<String, String> argMap = new HashMap<String, String>();
					argMap.put("-id", dfId);
					argMap.put("-package_item", "true");
					argMap.put("-operation", "stop");
					argMap.put("-event", "d2_workflow_abort");
					//argMap.put("-audit", "true");
					//Added below parameter seems it is mandatory in LS 16.6.1
					argMap.put("-if", "select '1' as result from dm_dbo.single_result_row_view where '"+docObject.getValue("a_status")+"'='"+docObject.getValue("a_status")+"'");

					ArgumentParser argParser = new ArgumentParser(argMap);

					WorkflowManager wfMgr = new WorkflowManager();
					//System.out.println("C");						
					DfLogger.debug(this,
							"In isWorkflowAborted::: , Abort WF request: method name {0} with arguments {1}",
							new String[] { ISWYApplySECRFConstants.WF_ABORT_WF_METHOD_NAME, method_args }, null);

					wfMgr.execute(session, null, null, argParser);
					bool = true;

					AuditTrailItem auditItem=new AuditTrailItem(session,"d2_workflow_abort");            
					auditItem.setAuditedId(new DfId(dfId));
					auditItem.setTimeStamp(new DfTime());

					auditItem.setEventSource(this.getClass().getName());// max 64 chars.
					auditItem.setString1("secrf_workflow_abort");
					auditItem.save();

					DfLogger.debug(this,
							"In isWorkflowAborted::: , Abort WF request fulfilled, Audit entry created: method name {0} with arguments {1}",
							new String[] { ISWYApplySECRFConstants.WF_ABORT_WF_METHOD_NAME, method_args }, null);

				} else // if request is for SecRF statistics, in this case do
					// not need to perform operation , only check workflow
					// is associated or not
				{
					bool = true;
					DfLogger.debug(this, "Object Ids [" + dfId
							+ "] Request is for abort WF but for SecRF statistics only, returning value - " + bool,
							null, null);
				}
			} else {
				bool = false;
				DfLogger.debug(this, "Object Ids [" + dfId + "] Document is not associated with any WF - " + bool, null,
						null);
			}
		} catch (Exception ex) {
			bool = false;
			//DfLogger.error(this, ex.getLocalizedMessage(), null, ex);
			ex.printStackTrace();
		}
		DfLogger.info(this, "Object Ids [" + dfId + "] Aborting Workflows method ::: isWorkflowAborted() done " + bool,
				null, null);
		return bool;
	}

	public boolean callLifecycleState(String documentId, IDfSession session, String lcState) {
		boolean bool = false;
		try {
			DfLogger.info(this, "Object Ids [" + documentId + "] Calling LC state [" + lcState
					+ "] to complete the task :::  start ", null, null);
			IDfId docId = new DfId(documentId);
			String lcTransitionState = lcState;
			Map<String, Object> arguments = new HashMap<String, Object>();
			arguments.put(D2Method.ARG_ID, docId);
			arguments.put(D2Method.ARG_CALLER_LOGIN, session.getLoginUserName());
			arguments.put(D2LifecycleChangeStateMethod.ARG_TARGET_STATE, lcTransitionState);
			arguments.put(D2LifecycleChangeStateMethod.ARG_TRANSITION_TYPE, "promote");
			arguments.put(D2Method.ARG_CLIENT_LOCALE, DfSessionUtil.getLocale(session).getLanguage());

			D2Method.start(session, D2LifecycleChangeStateMethod.class, arguments);
			bool = true;
			DfLogger.debug(this, "====> Promoting to transition state -> " + lcTransitionState, null, null);
		} catch (Exception ex) {
			bool = false;
		}
		DfLogger.info(this, "Object Ids [" + documentId + "] Calling LC state [" + lcState
				+ "] to complete the task :::  done with status [" + bool + "]", null, null);
		return bool;
	}

	public void updateWFAttributesAfterAbort(IDfSysObject sysObj) {
		try {
			DfLogger.debug(this, "updateWFAttributesAfterAbort() Returned start", null, null);

			sysObj.setString("a_status", "Draft");
			sysObj.setBoolean("is_placeholder", false);
			sysObj.setBoolean("wf_is_in_workflow", false);
			sysObj.setString("wf_workflow_name", null);

			sysObj.setTime("sent_for_approval_date", null);
			sysObj.setTime("approved_date", null);
			sysObj.setTime("effective_date", null);
			sysObj.setTime("expiration_date", null);
			sysObj.setTime("review_date", null);
			sysObj.setTime("last_expiry_review_date", null);
			sysObj.setTime("expiry_review_date", null);

			DfLogger.debug(this, "updateWFAttributesAfterAbort() Returned done", null, null);
		} catch (Exception ex) {
			DfLogger.error(this, ex.getLocalizedMessage(), null, ex);
		}
	}

	/**
	 * This method will rollback the changes (removing -SECRF) related with existing assigned value (of TMF QC and external participants)m where we added -SECRF while assining the secrf.
	 * @param docobject
	 * @param attrNames
	 * @param suffix
	 */
	public void rollbackTMFPerformersChange(IDfSysObject docobject, String[] attrNames, String suffix) throws Exception
	{
		suffix="-"+suffix;
		if(docobject!=null)
		{
			String docObjId=docobject.getObjectId().getId();
			for (int i=0;i<attrNames.length;i++)
			{
				String attrName=attrNames[i];

				if(docobject.hasAttr(attrName))
				{
					int exisingValCount=docobject.getValueCount(attrName);
					if(docobject.isAttrRepeating(attrName))
					{
						if(exisingValCount>0)
						{
							for(int j=0;j<exisingValCount;j++)
							{
								String tmpStr=docobject.getRepeatingString(attrName,j);
								if(tmpStr.endsWith(suffix))
								{

									tmpStr=tmpStr.substring(0,tmpStr.lastIndexOf(suffix));
									DfLogger.debug(this,"Document Object ["+docObjId+"] Have suffix in repeating Attribute ["+attrName+"] value, removed",null,null);
								}
								docobject.setRepeatingString(attrName, j,tmpStr);
							}
						}
					}
					else
					{
						if(exisingValCount>0)
						{
							String tmpStr=docobject.getString(attrName);

							if(tmpStr.endsWith(suffix))
							{

								tmpStr=tmpStr.substring(0,tmpStr.lastIndexOf(suffix));
								DfLogger.debug(this,"Document Object ["+docObjId+"] Have suffix, Single Attr Name["+attrName+"], removed",null,null);
							}

							docobject.setString(attrName, tmpStr);
						}
					}
				}
			}
		}
	}

	public void chkAppliedQcUsersIsPartOfQcgroup(IDfSysObject docObject, IDfSession session) throws Exception
	{

		if(docObject!=null && docObject.getTypeName().equalsIgnoreCase(ISWYApplySECRFConstants.TMF_DOC_TYPE))
		{
			String group_name=docObject.getString(ISWYApplySECRFConstants.TMF_QC_GROUP_ATTR);
			String user_name=docObject.getString(ISWYApplySECRFConstants.TMF_QC_USER_ATTR); 

			if(user_name!=null && !user_name.trim().equalsIgnoreCase("") && !user_name.trim().equalsIgnoreCase(ISWYApplySECRFConstants.TMF_QC_USER_DEFAULT_VAL)
					&& group_name!=null && !group_name.trim().equalsIgnoreCase("")
					)
			{
				String dql="select count(group_name) from dm_group where lower(group_name)=lower('"+group_name+"') and any lower(i_all_users_names)=lower('"+user_name+"')";
				int usrCount=QueryUtils.getQueryResultAsInteger(dql,0,session); 

				if(usrCount<1)
				{
					docObject.setString(ISWYApplySECRFConstants.TMF_QC_USER_ATTR, ISWYApplySECRFConstants.TMF_QC_USER_DEFAULT_VAL);
				}
			}
		}
	}

	/**
	 * This method will apply the changes (adding suffix -SECRF) in existing assigned value (of TMF QC and external participants) where we will add -SECRF while assigning the secrf.
	 * @param docobject
	 * @param attrNames
	 * @param suffix
	 */
	public void applyTMFPerformersChange(IDfSysObject docobject, String[] attrNames, String suffix) throws Exception
	{
		suffix="-"+suffix;
		if(docobject!=null)
		{
			String docObjId=docobject.getObjectId().getId();
			for (int i=0;i<attrNames.length;i++)
			{
				String attrName=attrNames[i];

				if(docobject.hasAttr(attrName))
				{
					int exisingValCount=docobject.getValueCount(attrName);
					if(docobject.isAttrRepeating(attrName))
					{
						if(exisingValCount>0)
						{
							for(int j=0;j<exisingValCount;j++)
							{
								String tmpStr=docobject.getRepeatingString(attrName,j);
								if(!tmpStr.endsWith(suffix))
								{
									docobject.setRepeatingString(attrName, j,tmpStr+suffix);
								}
								DfLogger.debug(this, "Document Object ["+docObjId+"] Attr Name ["+attrName+"] value Updated",null,null);
							}
						}
					}
					else
					{
						if(exisingValCount>0)
						{
							String tmpStr=docobject.getString(attrName);
							if(!tmpStr.endsWith(suffix))
							{
								docobject.setString(attrName, tmpStr+suffix);
							}
							DfLogger.debug(this, "Document Object ["+docObjId+"] Attr Name ["+attrName+"] value Updated",null,null);
						}
					}
				}
			}
		}
	}

	public void applyD2CoreMethod(ArgumentParser aParser) throws Exception {
		DfLogger.info(this, "Applying Security:::: processing applyD2CoreMethod()", null, null);

		try {
			D2Method.main(aParser);
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			DfLogger.error(this, "Applying Security:::: processing applyD2CoreMethod() " + e.getLocalizedMessage(),
					null, e);
		}
	}

	public void applyingSecurity(String docObjectId, IDfSession session,boolean needToapplysecurity,boolean is_migrated_document) {

		if (!is_migrated_document) {
			try {
				DfLogger.debug(this, "session.getDocbaseName() "+ session.getDocbaseName()+ "  session.getLoginUserName()  "+session.getLoginUserName(), null, null);
				HashMap<String, String> aParserMap = new HashMap<String, String>();
				aParserMap.put("-class_name", "com.emc.d2.api.methods.D2CoreMethod");
				aParserMap.put("-docbase_name", session.getDocbaseName());
				aParserMap.put("-user_name", session.getLoginUserName());
				aParserMap.put("-password", "");
				aParserMap.put("-id", docObjectId);
				aParserMap.put("-create", Boolean.toString(false));
				aParserMap.put("-naming", Boolean.toString(false));
				aParserMap.put("-autolink", Boolean.toString(false));
				aParserMap.put("-security", Boolean.toString(needToapplysecurity));
				aParserMap.put("-force_security", Boolean.toString(false));
				aParserMap.put("-apply_for_vd", Boolean.toString(false));
				//aParserMap.put("-transaction", Boolean.toString(false));

				ArgumentParser aParser = new ArgumentParser(aParserMap);

				applyD2CoreMethod(aParser);
			}
			catch (Exception e) {
				DfLogger.error(this, e.getLocalizedMessage(), null, e);
			}
		}
	}

	public Vector<String> getPreviousVersionsIds(String docObjId, IDfSession session) throws DfException
	{
		IDfSysObject sysObject	=(IDfSysObject)session.getObject(new DfId(docObjId));
		Vector<String> objIdsVector=new Vector<String>();
		IDfCollection versionColl=null;
		try
		{
			versionColl=sysObject.getVersions("r_modify_date ,"+ISWYApplySECRFConstants.DOC_R_OBJECT_ID_ATTR);

			while(versionColl.next())
			{
				String versionObjId=versionColl.getString(ISWYApplySECRFConstants.DOC_R_OBJECT_ID_ATTR);
				if(!docObjId.equalsIgnoreCase(versionObjId))
				{
					objIdsVector.addElement(versionObjId);
				}
			}
		}
		finally
		{
			if(versionColl!=null)
			{
				versionColl.close();
				DfLogger.debug(this, "::: getPreviousVersionsIds() ::: Collection Closed" , null, null);

			}
		}
		return objIdsVector;
	}

	public void applyChangesToDocAllVersions(String docObjId, IDfSession session,boolean needToapplysecurity,boolean is_migrated_document) 
	{
		try {

			IDfSysObject sysObject	=(IDfSysObject)session.getObject(new DfId(docObjId));
			Vector<String> objIdsVector=getPreviousVersionsIds(docObjId,session);
			int versionCount=objIdsVector.size();
			DfLogger.debug(this, "Processing Object Id ["+docObjId+"] No of Versions ["+versionCount+"] and Ids["+objIdsVector.toString()+"]" , null, null);

			if(versionCount>0)
			{
				String[] get_single_multi_attr=ISWYApplySECRFConstants.ATTR_TO_BE_UPDATE_ON_VERSION_OBJ; 

				ArrayList<String> singleAttrList=new ArrayList<String>(); 
				ArrayList<String> multiAttrList=new ArrayList<String>();


				for(int i=0;i<get_single_multi_attr.length;i++)
				{
					String attr_name=get_single_multi_attr[i];
					if(sysObject.hasAttr(attr_name))
					{
						if(sysObject.isAttrRepeating(attr_name))
						{
							multiAttrList.add(attr_name);
						}
						else
						{
							singleAttrList.add(attr_name);
						}
					}
				}

				int versionUpdateResult=0;	
				boolean isUpdateVersionPerformed=false;

				/**
				 * Start : Added on June 12, 2020
				 */
				if ((multiAttrList.size()>0 || singleAttrList.size() >0) && versionCount>0)
				{
					disableObjectsImmutability(true,session,docObjId,versionCount, objIdsVector);
				}
				/**
				 * End : Added on June 12, 2020
				 */

				DfLogger.debug(this, "Processing Object Id ["+docObjId+"]  Updating repeating attributes for older version Start....", null, null);
				for (int i=0; i<multiAttrList.size();i++)
				{
					versionUpdateResult=updateRepeatingAttributeOnVersionedDoc( docObjId, sysObject,  session, multiAttrList.get(i), versionCount,  objIdsVector) ;
					if(versionUpdateResult>0)
					{
						isUpdateVersionPerformed=true;
					}
				}
				DfLogger.debug(this, "Processing Object Id ["+docObjId+"]  Updating repeating attributes for older version Done.... Is any attribute updated ["+isUpdateVersionPerformed+"]", null, null);

				DfLogger.debug(this, "Processing Object Id ["+docObjId+"]  Updating Single attributes for older version Start....", null, null);
				String singleAttrArr[]=new String[singleAttrList.size()];
				for (int i=0; i<singleAttrList.size();i++)
				{

					singleAttrArr[i]=singleAttrList.get(i);
				}
				versionUpdateResult=updateSingleAttributeOnVersionedDoc( docObjId, sysObject,  session, singleAttrArr, versionCount,  objIdsVector) ;
				if(versionUpdateResult>0)
				{
					isUpdateVersionPerformed=true;
				}
				DfLogger.debug(this, "Processing Object Id ["+docObjId+"]  Updating single attributes for older version Done.... Is any attribute updated ["+isUpdateVersionPerformed+"]", null, null);		

				if(isUpdateVersionPerformed)
				{

					DfLogger.debug(this, "Processing Object Id ["+docObjId+"]  Applying Security on Versioned documents", null, null);
					if (!is_migrated_document) 
					{
						HashMap<String, String> aParserMap = new HashMap<String, String>();
						ArgumentParser aParser = null;
						for (String versionId : objIdsVector) {
							aParserMap = new HashMap<String, String>();
							aParserMap.put("-class_name", "com.emc.d2.api.methods.D2CoreMethod");
							aParserMap.put("-docbase_name", session.getDocbaseName());
							aParserMap.put("-user_name", session.getLoginUserName());
							aParserMap.put("-password", "");
							aParserMap.put("-id", versionId);
							//aParserMap.put("-dql_filter", " select r_object_id from dm_document(all) where r_object_id in ("+versionIdsAsPredicate+")");
							aParserMap.put("-create", Boolean.toString(false));
							aParserMap.put("-naming", Boolean.toString(false));
							aParserMap.put("-autolink", Boolean.toString(false));
							aParserMap.put("-security", Boolean.toString(needToapplysecurity));
							aParserMap.put("-force_security", Boolean.toString(false));
							aParserMap.put("-apply_for_vd", Boolean.toString(false));

							aParser = new ArgumentParser(aParserMap);

							applyD2CoreMethod(aParser);

						}

						DfLogger.debug(this, "Processing Object Id ["+docObjId+"]  Document is not migrated document thus applied security (request sent) on its versions", null, null);
					}
					else
					{
						DfLogger.debug(this, "Processing Object Id ["+docObjId+"]  Document is migrated document thus not applying security on its versions", null, null);
					}
				}

				/**
				 * Start : Added on June 12, 2020
				 */
				if ((multiAttrList.size()>0 || singleAttrList.size() >0) && versionCount>0)
				{
					disableObjectsImmutability(false,session,docObjId,versionCount,  objIdsVector);
				}
				/**
				 * End : Added on June 12, 2020
				 */
			}
		}

		catch (Exception e) {
			DfLogger.error(this, e.getLocalizedMessage(), null, e);
		}
	}

	public void disableObjectsImmutability(boolean disableImmutability,IDfSession sessionObj,String docObjId,int versionCount, 
			Vector<String> objectIdsVector) throws DfException
	{
		
		DfLogger.debug(this,"Processing All Versions for Id ["+docObjId+"]  Total Versions available ["+versionCount+"]",null,null);

		String immutableDql="";
		if(disableImmutability) // Disabling Immutability : Ready for update on old version documents
		{
			immutableDql="EXECUTE exec_sql WITH QUERY='update dm_sysobject_s set r_immutable_flag=0 where r_object_id  in (select distinct r.r_object_id from dm_sysobject_r r, dm_sysobject_s s where r.r_object_id=s.r_object_id and r.r_version_label!=''CURRENT'' and r.r_object_id!=''"+docObjId+"'' and s.i_chronicle_id=(select i_chronicle_id from dm_sysobject_s where r_object_id=''"+docObjId+"''))'";
			DfLogger.debug(this,"Processing Object Id ["+docObjId+"] Object Immutability False ["+immutableDql+"]",null,null);
		}
		else // Enabling Immutability : Locking for any update on old version documents
		{
			immutableDql="EXECUTE exec_sql WITH QUERY='update dm_sysobject_s set r_immutable_flag=1 where r_object_id  in (select distinct r.r_object_id from dm_sysobject_r r, dm_sysobject_s s where r.r_object_id=s.r_object_id and r.r_version_label!=''CURRENT'' and r.r_object_id!=''"+docObjId+"'' and s.i_chronicle_id=(select i_chronicle_id from dm_sysobject_s where r_object_id=''"+docObjId+"''))'";
			DfLogger.debug(this,"Processing Object Id ["+docObjId+"]  Object Immutability False ["+immutableDql+"]",null,null);

		}
		String immutableTrueDqlResultStr=QueryUtils.execQuery(immutableDql, sessionObj);

		DfLogger.debug(this, "Processing Object Id ["+docObjId+"]  Object Immutability Disable Request ["+disableImmutability+"] with DQL ["+immutableDql+"] and result  ["+immutableTrueDqlResultStr+"]", null, null);

	}


	public int updateRepeatingAttributeOnVersionedDoc(String docObjId,IDfSysObject sysObject, IDfSession session, String attr_name, int versionCount, Vector<String> objVector) throws Exception
	{

		String dqlPredicate=null;

		int versionUpdateResult=0;
		if(dqlPredicate==null || dqlPredicate.trim().equalsIgnoreCase(""))
		{
			dqlPredicate="";
		}

		dqlPredicate= dqlPredicate+ " truncate "+attr_name + " ";

		int attrValCnt=sysObject.getValueCount(attr_name);

		if(attrValCnt>0)
		{
			int attrDataType=sysObject.getAttrDataType(attr_name);

			int attrValBatchSize=100;
			int no_of_attr_val_batch=attrValCnt/attrValBatchSize;
			int attr_val_count_outside_batch=attrValCnt%attrValBatchSize;
			DfLogger.debug(this,"Attribute Name ["+attr_name+"] Total Attribute Value available ["+attrValCnt+"] No. Of batch["+no_of_attr_val_batch+"] Attribute Value count outside batch ["+attr_val_count_outside_batch+"] BatchSize["+attrValBatchSize+"]",null,null);

			int attrValCounter=0;
			int attr_val_total_batch=attr_val_count_outside_batch>0?no_of_attr_val_batch+1:no_of_attr_val_batch;


			for (int attrValBatchCounter=0;attrValBatchCounter<attr_val_total_batch;attrValBatchCounter++)
			{
				versionUpdateResult=0;

				if(attrValBatchCounter>0)
					dqlPredicate="";

				if(attrValBatchCounter==no_of_attr_val_batch)
					attrValBatchSize=attr_val_count_outside_batch;

				for(int incr=0;incr<attrValBatchSize;incr++)
				{

					String value=null;
					if (attrDataType == 4) // Time
					{
						value=sysObject.getRepeatingTime(attr_name,attrValCounter).asString(ISWYApplySECRFConstants.DCTM_DATE_ATTR_FORMAT);
						if(value!=null && !value.trim().equalsIgnoreCase("nulldate") && !value.trim().equalsIgnoreCase(""))
						{
							value = "date('" + value + " utc','"
									+ ISWYApplySECRFConstants.DCTM_DATE_ATTR_FORMAT + "')";
						}
						else
						{
							value ="date('nulldate')";
						}

						if(attrValBatchCounter==0)
							dqlPredicate = dqlPredicate +" , append "+attr_name +" ="+value;
						else
						{
							if(incr==0)
								dqlPredicate = dqlPredicate +"  append "+attr_name +" ="+value;
							else
								dqlPredicate = dqlPredicate +" , append "+attr_name +" ="+value;
						}
					} 
					else if (attrDataType == 0) // Boolean
					{
						value=String.valueOf(sysObject.getRepeatingBoolean(attr_name,attrValCounter));
						if (value.equalsIgnoreCase("true") || value.equalsIgnoreCase("t")
								|| value.equalsIgnoreCase("1")) {
							value = "1";
						} else if (value.equalsIgnoreCase("false")
								|| value.equalsIgnoreCase("f") || value.equalsIgnoreCase("0")) {
							value = "0";
						}
						if(attrValBatchCounter==0)
							dqlPredicate = dqlPredicate +" , append "+attr_name +" ="+value;
						else
						{
							if(incr==0)
								dqlPredicate = dqlPredicate +"  append "+attr_name +" ="+value;
							else
								dqlPredicate = dqlPredicate +" , append "+attr_name +" ="+value;
						}
					} 
					else if (attrDataType == 1 ) // Number 

					{
						value=String.valueOf(sysObject.getRepeatingInt(attr_name,attrValCounter));
						if(attrValBatchCounter==0)
							dqlPredicate = dqlPredicate +" , append "+attr_name +" ="+value;
						else
						{
							if(incr==0)
								dqlPredicate = dqlPredicate +"  append "+attr_name +" ="+value;
							else
								dqlPredicate = dqlPredicate +" , append "+attr_name +" ="+value;
						}
					}
					else if ( attrDataType == 5) //  DOUBLE

					{
						value=String.valueOf(sysObject.getRepeatingDouble(attr_name,attrValCounter));
						if(attrValBatchCounter==0)
							dqlPredicate = dqlPredicate +" , append "+attr_name +" ="+value;
						else
						{
							if(incr==0)
								dqlPredicate = dqlPredicate +"  append "+attr_name +" ="+value;
							else
								dqlPredicate = dqlPredicate +" , append "+attr_name +" ="+value;
						}
					}
					else if (attrDataType == 2 || attrDataType == 3) // String || ID
					{
						value=String.valueOf(sysObject.getRepeatingString(attr_name,attrValCounter));
						if(attrValBatchCounter==0)
							dqlPredicate = dqlPredicate +" , append "+attr_name +" ='"+value+"'";
						else
						{
							if(incr==0)
								dqlPredicate = dqlPredicate +"  append "+attr_name +" ='"+value+"'";
							else
								dqlPredicate = dqlPredicate +" , append "+attr_name +" ='"+value+"'";
						}
					}

					attrValCounter=attrValCounter+1;
				}


				DfLogger.debug(this, "Processing Object Id ["+docObjId+"]  DQL Syntax to update ["+dqlPredicate+"]", null, null);

				if(dqlPredicate!=null && !dqlPredicate.trim().equalsIgnoreCase(""))
				{
					versionUpdateResult=updateAttributeOnVersionDoc( dqlPredicate,docObjId, sysObject,  session, versionCount,  objVector) ;
				}

			}
		}
		else
		{
			versionUpdateResult=updateAttributeOnVersionDoc( dqlPredicate,docObjId, sysObject,  session, versionCount,  objVector) ;
		}

		return versionUpdateResult;

	}

	private int updateAttributeOnVersionDoc(String dqlPredicate,String docObjId,IDfSysObject sysObject, IDfSession session, int versionCount, Vector<String> objVector) throws Exception
	{
		int versionUpdateResult=0;
		if(dqlPredicate!=null && !dqlPredicate.trim().equalsIgnoreCase(""))
		{

			int batchSize=100;
			int no_of_batch=versionCount/batchSize;
			int doc_count_outside_batch=versionCount%batchSize;
			System.out.println("Total Versions available ["+versionCount+"] No. Of batch["+no_of_batch+"] Documents count outside batch ["+doc_count_outside_batch+"] BatchSize["+batchSize+"]");

			int counter=0;
			String versionIdsAsPredicate=null;
			int total_batch=doc_count_outside_batch>0?no_of_batch+1:no_of_batch;


			for (int batchCounter=0;batchCounter<total_batch;batchCounter++)
			{
				versionIdsAsPredicate=null;
				if(batchCounter==no_of_batch)
					batchSize=doc_count_outside_batch;
				for(int j=0;j<batchSize;j++)
				{
					if(versionIdsAsPredicate==null || versionIdsAsPredicate.trim().equalsIgnoreCase(""))
					{
						versionIdsAsPredicate="'"+objVector.get(counter)+"'";
					}
					else
					{
						versionIdsAsPredicate=versionIdsAsPredicate+ " , '"+objVector.get(counter)+"'";
					}
					counter=counter+1;
				}

				//System.out.println("Batch ["+(batchCounter+1)+"] Processed records ["+counter+"] Version Object Ids ["+versionIdsAsPredicate+"]");
				DfLogger.debug(this, "Processing Object Id ["+docObjId+"] Batch ["+(batchCounter+1)+"] Processed records ["+counter+"] Versions Object IDs as predicate ["+versionIdsAsPredicate+"]", null, null);

				String dqlToExecute=null;
				if(dqlPredicate!=null && !dqlPredicate.trim().equalsIgnoreCase("") && versionIdsAsPredicate!=null && !versionIdsAsPredicate.trim().equalsIgnoreCase(""))
				{
					dqlToExecute="Update "+sysObject.getTypeName()+"(all) objects "+ dqlPredicate +" where r_object_id in ("+versionIdsAsPredicate+")";
					//System.out.println("[dqlToExecute=="+dqlToExecute+"]");
					DfLogger.debug(this, "Processing Object Id ["+docObjId+"]  DQL to update version ["+dqlToExecute+"]", null, null);
				}


				if(dqlToExecute!=null && !dqlToExecute.trim().equalsIgnoreCase(""))
				{
					String versionUpdateResultStr=QueryUtils.execQuery(dqlToExecute, session);
					versionUpdateResult=versionUpdateResult+Integer.parseInt(versionUpdateResultStr);
					DfLogger.debug(this, "Processing Object Id ["+docObjId+"]  No. of Version Obects Updated ["+versionUpdateResult+"]", null, null);
				}
			}

		}
		return versionUpdateResult;
	}
	public int updateSingleAttributeOnVersionedDoc(String docObjId,IDfSysObject sysObject, IDfSession session, String[] attr_to_be_update, int versionCount, Vector<String> objVector) throws Exception
	{
		DfLogger.debug(this, "Updating Single Attributes....", null, null);

		String dqlPredicate=null;
		for(int i=0;i<attr_to_be_update.length;i++)
		{
			String attr_name=attr_to_be_update[i];
			int attrDataType=sysObject.getAttrDataType(attr_name);
			String value=null;
			if (attrDataType == 4) // Time
			{
				value=sysObject.getTime(attr_name).asString(ISWYApplySECRFConstants.DCTM_DATE_ATTR_FORMAT);

				if(value!=null && !value.trim().equalsIgnoreCase("nulldate") && !value.trim().equalsIgnoreCase(""))
				{
					value = "date('" + value + " utc','"
							+ ISWYApplySECRFConstants.DCTM_DATE_ATTR_FORMAT + "')";
				}
				else
				{
					value ="date('nulldate')";
				}
				if(dqlPredicate==null || dqlPredicate.trim().equalsIgnoreCase(""))
				{
					dqlPredicate = " set "+attr_name +" ="+value;
				}
				else
				{
					dqlPredicate=dqlPredicate + " , set "+attr_name +" ="+value;;
				}

			} 
			else if (attrDataType == 0) // Boolean
			{
				value=String.valueOf(sysObject.getBoolean(attr_name));
				if (value.equalsIgnoreCase("true") || value.equalsIgnoreCase("t")
						|| value.equalsIgnoreCase("1")) {
					value = "1";
				} else if (value.equalsIgnoreCase("false")
						|| value.equalsIgnoreCase("f") || value.equalsIgnoreCase("0")) {
					value = "0";
				}

				if(dqlPredicate==null || dqlPredicate.trim().equalsIgnoreCase(""))
				{
					dqlPredicate = " set "+attr_name +" ="+value;
				}
				else
				{
					dqlPredicate=dqlPredicate + " , set "+attr_name +" ="+value;;
				}
			} 
			else if (attrDataType == 1 ) // Number 

			{
				value=String.valueOf(sysObject.getInt(attr_name));
				if(dqlPredicate==null || dqlPredicate.trim().equalsIgnoreCase(""))
				{
					dqlPredicate = " set "+attr_name +" ="+value;
				}
				else
				{
					dqlPredicate=dqlPredicate + " , set "+attr_name +" ="+value;;
				}
			}
			else if ( attrDataType == 5) //  DOUBLE

			{
				value=String.valueOf(sysObject.getDouble(attr_name));
				if(dqlPredicate==null || dqlPredicate.trim().equalsIgnoreCase(""))
				{
					dqlPredicate = " set "+attr_name +" ="+value;
				}
				else
				{
					dqlPredicate=dqlPredicate + " , set "+attr_name +" ="+value;;
				}
			}
			else if (attrDataType == 2 || attrDataType == 3) // String || ID
			{
				value=String.valueOf(sysObject.getString(attr_name));
				if(dqlPredicate==null || dqlPredicate.trim().equalsIgnoreCase(""))
				{
					dqlPredicate = " set "+attr_name +" ='"+value+"'";
				}
				else
				{
					dqlPredicate=dqlPredicate + " , set "+attr_name +" ='"+value+"'";
				}
			}
		}

		DfLogger.debug(this, "Processing Object Id ["+docObjId+"]  DQL Syntax to update ["+dqlPredicate+"]", null, null);

		int versionUpdateResult=0;

		if(dqlPredicate!=null && !dqlPredicate.trim().equalsIgnoreCase(""))
		{

			int batchSize=100;
			int no_of_batch=versionCount/batchSize;
			int doc_count_outside_batch=versionCount%batchSize;
			System.out.println("Total Versions available ["+versionCount+"] No. Of batch["+no_of_batch+"] Documents count outside batch ["+doc_count_outside_batch+"] BatchSize["+batchSize+"]");

			int counter=0;
			String versionIdsAsPredicate=null;
			int total_batch=doc_count_outside_batch>0?no_of_batch+1:no_of_batch;


			for (int batchCounter=0;batchCounter<total_batch;batchCounter++)
			{
				versionIdsAsPredicate=null;
				if(batchCounter==no_of_batch)
					batchSize=doc_count_outside_batch;
				for(int j=0;j<batchSize;j++)
				{
					if(versionIdsAsPredicate==null || versionIdsAsPredicate.trim().equalsIgnoreCase(""))
					{
						versionIdsAsPredicate="'"+objVector.get(counter)+"'";
					}
					else
					{
						versionIdsAsPredicate=versionIdsAsPredicate+ " , '"+objVector.get(counter)+"'";
					}
					counter=counter+1;
				}

				//System.out.println("Batch ["+(batchCounter+1)+"] Processed records ["+counter+"] Version Object Ids ["+versionIdsAsPredicate+"]");
				DfLogger.debug(this, "Processing Object Id ["+docObjId+"] Batch ["+(batchCounter+1)+"] Processed records ["+counter+"] Versions Object IDs as predicate ["+versionIdsAsPredicate+"]", null, null);

				String dqlToExecute=null;
				if(dqlPredicate!=null && !dqlPredicate.trim().equalsIgnoreCase("") && versionIdsAsPredicate!=null && !versionIdsAsPredicate.trim().equalsIgnoreCase(""))
				{
					dqlToExecute="Update "+sysObject.getTypeName()+"(all) objects "+ dqlPredicate +" where r_object_id in ("+versionIdsAsPredicate+")";
					DfLogger.debug(this, "Processing Object Id ["+docObjId+"]  DQL to update version ["+dqlToExecute+"]", null, null);
				}


				if(dqlToExecute!=null && !dqlToExecute.trim().equalsIgnoreCase(""))
				{
					String versionUpdateResultStr=QueryUtils.execQuery(dqlToExecute, session);
					versionUpdateResult=versionUpdateResult+Integer.parseInt(versionUpdateResultStr);
					DfLogger.debug(this, "Processing Object Id ["+docObjId+"]  No. of Version Obects Updated ["+versionUpdateResult+"]", null, null);
				}
			}

		}
		DfLogger.debug(this, "Updating Single Attributes....END", null, null);
		return versionUpdateResult;
	}

	public void updateStatisticsData( String secrf_obj_id, IDfSession session, int doc_affected_count, int doc_conflicted_cnt, int wf_qc_abort_cnt , int doc_checkout_count) throws DfException
	{
		DfId secrf_id=new DfId(secrf_obj_id);
		if(secrf_id!=null && secrf_id.isObjectId())
		{
			IDfSysObject secRFObject=(IDfSysObject)session.getObject(secrf_id);
			String doaminStr=secRFObject.getString(ISWYApplySECRFConstants.SRF_DOMAIN_ATTR_NAME);
			String dqlToUpdateStatisticsData=null;
			if(doaminStr!=null && doaminStr.trim().equalsIgnoreCase(ISWYApplySECRFConstants.TMF_DOMAIN))
			{
				String secrf_artifact_name=secRFObject.getString(ISWYApplySECRFConstants.SRF_ARTIFACT_NAME_ATTR);

				boolean isSecRFDomainCrossover=chkDocDomainCrossOver(session,secrf_artifact_name,doaminStr);
				if(isSecRFDomainCrossover)
				{
					ArrayList<String> domainList=getListOfCrossOverDomains(session,secrf_artifact_name);

					if(domainList!=null && domainList.size()==1 && domainList.contains(ISWYApplySECRFConstants.TMF_DOMAIN))	// Crossover A
					{	
						dqlToUpdateStatisticsData="update swy_sec_registration_form objects set swy_secrf_stat_info[0]='"+ISWYApplySECRFConstants.SECRF_STATS_INFO_TEXT_ALL_AFFECTED_DOC
								+"' ,set swy_secrf_stat_info[1]='"+ISWYApplySECRFConstants.SECRF_STATS_INFO_TEXT_CONFLICTED_DOC+"', "
								+ " set swy_secrf_stat_info[2]='"+ISWYApplySECRFConstants.SECRF_STATS_INFO_TEXT_QC_ABORTED_DOC+"',  "
								+ " set swy_secrf_stat_info[3]='"+ISWYApplySECRFConstants.SECRF_STATS_INFO_TEXT_CHECKED_OUT_DOC+"',  "
								+ "set swy_secrf_stat_count[0]='"+String.valueOf(doc_affected_count)+"' ,set swy_secrf_stat_count[1]='"+String.valueOf(doc_conflicted_cnt)+"', "
								+ "set swy_secrf_stat_count[2]='"+String.valueOf(wf_qc_abort_cnt)+"', "
								+ "set swy_secrf_stat_count[3]='"+String.valueOf(doc_checkout_count)+"' "
								+" where r_object_id='"+secrf_obj_id+"'";
					}
					else	//Crossover B
					{
						dqlToUpdateStatisticsData="update swy_sec_registration_form objects set swy_secrf_stat_info[0]='"+ISWYApplySECRFConstants.SECRF_STATS_INFO_TEXT_ALL_AFFECTED_DOC
								+"' ,set swy_secrf_stat_info[1]='"+ISWYApplySECRFConstants.SECRF_STATS_INFO_TEXT_CONFLICTED_DOC+"', "
								+ " set swy_secrf_stat_info[2]='"+ISWYApplySECRFConstants.SECRF_STATS_INFO_TEXT_WF_ABORTED_DOC+"',  "
								+ " set swy_secrf_stat_info[3]='"+ISWYApplySECRFConstants.SECRF_STATS_INFO_TEXT_CHECKED_OUT_DOC+"',  "
								+ "set swy_secrf_stat_count[0]='"+String.valueOf(doc_affected_count)+"' ,set swy_secrf_stat_count[1]='"+String.valueOf(doc_conflicted_cnt)+"', "
								+ "set swy_secrf_stat_count[2]='"+String.valueOf(wf_qc_abort_cnt)+"', "
								+ "set swy_secrf_stat_count[3]='"+String.valueOf(doc_checkout_count)+"' "
								+" where r_object_id='"+secrf_obj_id+"'";
					}

				}
				else
				{
					dqlToUpdateStatisticsData="update swy_sec_registration_form objects set swy_secrf_stat_info[0]='"+ISWYApplySECRFConstants.SECRF_STATS_INFO_TEXT_ALL_AFFECTED_DOC
							+"' ,set swy_secrf_stat_info[1]='"+ISWYApplySECRFConstants.SECRF_STATS_INFO_TEXT_CONFLICTED_DOC+"', "
							+ " set swy_secrf_stat_info[2]='"+ISWYApplySECRFConstants.SECRF_STATS_INFO_TEXT_QC_ABORTED_DOC+"',  "
							+ " set swy_secrf_stat_info[3]='"+ISWYApplySECRFConstants.SECRF_STATS_INFO_TEXT_CHECKED_OUT_DOC+"',  "
							+ "set swy_secrf_stat_count[0]='"+String.valueOf(doc_affected_count)+"' ,set swy_secrf_stat_count[1]='"+String.valueOf(doc_conflicted_cnt)+"', "
							+ "set swy_secrf_stat_count[2]='"+String.valueOf(wf_qc_abort_cnt)+"', "
							+ "set swy_secrf_stat_count[3]='"+String.valueOf(doc_checkout_count)+"' "
							+" where r_object_id='"+secrf_obj_id+"'";
				}

			}
			else
			{
				dqlToUpdateStatisticsData="update swy_sec_registration_form objects set swy_secrf_stat_info[0]='"+ISWYApplySECRFConstants.SECRF_STATS_INFO_TEXT_ALL_AFFECTED_DOC
						+"' ,set swy_secrf_stat_info[1]='"+ISWYApplySECRFConstants.SECRF_STATS_INFO_TEXT_CONFLICTED_DOC+"', "
						+ " set swy_secrf_stat_info[2]='"+ISWYApplySECRFConstants.SECRF_STATS_INFO_TEXT_WF_ABORTED_DOC+"',  "
						+ " set swy_secrf_stat_info[3]='"+ISWYApplySECRFConstants.SECRF_STATS_INFO_TEXT_CHECKED_OUT_DOC+"',  "
						+ "set swy_secrf_stat_count[0]='"+String.valueOf(doc_affected_count)+"' ,set swy_secrf_stat_count[1]='"+String.valueOf(doc_conflicted_cnt)+"', "
						+ "set swy_secrf_stat_count[2]='"+String.valueOf(wf_qc_abort_cnt)+"', "
						+ "set swy_secrf_stat_count[3]='"+String.valueOf(doc_checkout_count)+"' "
						+" where r_object_id='"+secrf_obj_id+"'";
			}
			DfLogger.debug(this, "DQL to update SecRF Statistics {0}", new String[]{dqlToUpdateStatisticsData}, null);
			String recordsUpdated=QueryUtils.execQuery(dqlToUpdateStatisticsData, session);
			DfLogger.debug(this, "DQL to update SecRF Statistics {0} - updated {1} row ", new String[]{dqlToUpdateStatisticsData,recordsUpdated}, null);
		}
	}

	public String concatString(String separator, String[] data) {
		String val = null;
		if (data != null && data.length > 0) {
			for (int i = 0; i < data.length; i++) {
				String tmpStr = data[i];

				if (tmpStr != null && !tmpStr.trim().equals("")) {

				} else {
					tmpStr = "";
				}
				if (val == null) {
					val = tmpStr;
				} else {
					val = val + separator + tmpStr;
				}
			}
		}
		return val;
	}

	private String[] removeDuplicatesFromArray(String[] arr) throws Exception {
		if (arr.length > 0) {

			Set<String> set = new HashSet<String>(Arrays.asList(arr));
			arr = set.toArray(new String[set.size()]);

			return arr;
		}
		return null;
	}

	String tmfArtifactCrossOverStatus=null;
	ArrayList<String> tmfCODomainList=new ArrayList<String>();

	private void retrieveTMFArtifactInfo(IDfSession session, String artifact_name) throws DfException
	{
		if(artifact_name!=null && !artifact_name.trim().equalsIgnoreCase(""))
		{
			/*String dql_fetchDomain_crossoverStatus="select  v.alias_value from d2_dictionary d, d2_dictionary_value v where d.object_name = v.dictionary_name and "
					+ "d.object_name ='"+ISWYApplySECRFConstants.DOCUMENT_TMF_UNIQUE_DIC+"' and (d.alias_name ='Domain' or d.alias_name ='Is Crossover') and d.i_position=v.i_position and "
					+ "v.object_name='"+artifact_name+"' enable(ROW_BASED)";*/

			String dql_fetchDomain_crossoverStatus="select alias_value from dm_dbo.d2_dictionary_alias_view where dictionary_name = '"+ISWYApplySECRFConstants.DOCUMENT_TMF_UNIQUE_DIC+
					"' and (alias_name ='Domain' or alias_name ='Is Crossover') and dictionary_key='"+artifact_name+"'";

			String[] arr=getAllCachedQueryResultsAsStrings(dql_fetchDomain_crossoverStatus, session);


			if(arr!=null && arr.length>0)
			{
				for(int i=0;i<arr.length;i++)
				{
					if(arr[i]!=null && !arr[i].equalsIgnoreCase("") && 
							(arr[i].trim().equalsIgnoreCase("T")|| arr[i].trim().equalsIgnoreCase("True") ||
									arr[i].trim().equalsIgnoreCase("F")|| arr[i].trim().equalsIgnoreCase("False")))
					{
						tmfArtifactCrossOverStatus=(arr[i]);
					}
					else if(arr[i]!=null && !arr[i].equalsIgnoreCase("") && 
							(!arr[i].trim().equalsIgnoreCase("T") && !arr[i].trim().equalsIgnoreCase("True") &&
									!arr[i].trim().equalsIgnoreCase("F") && !arr[i].trim().equalsIgnoreCase("False")))
					{
						tmfCODomainList.add(arr[i]);
					}
				}
			}
		}
	}



	public boolean chkDocDomainCrossOver(IDfSession session, String artifact_name,String domain)throws DfException
	{
		boolean is_crossover=false;

		DfLogger.debug(this,"SUB-2781 of R4.1 ::: Nov 30, 2020 ::: chkDocDomainCrossOver "+domain,null,null);
		if(ISWYApplySECRFConstants.C_LINE_DOMAINS.trim().toLowerCase().contains(domain.toLowerCase()))
		{
			DfLogger.debug(this,"SUB-2781 of R4.1 ::: Nov 30, 2020 ::: chkDocDomainCrossOver ::: Domain is C-line "+domain,null,null);
			if(artifact_name!=null && !artifact_name.trim().equalsIgnoreCase(""))
			{
				if(tmfArtifactCrossOverStatus==null)
				{
					retrieveTMFArtifactInfo(session,artifact_name);
				}
				String res_is_crossover=tmfArtifactCrossOverStatus;


				if(res_is_crossover!=null && !res_is_crossover.equalsIgnoreCase("") && 
						(res_is_crossover.trim().equalsIgnoreCase("T")|| res_is_crossover.trim().equalsIgnoreCase("True")))
				{
					is_crossover=true;
				}
			}
		}
		return is_crossover;
	}

	public ArrayList<String> getListOfCrossOverDomains(IDfSession session, String artifact_name) throws DfException
	{
		ArrayList<String> domainList=new ArrayList<String>();
		if(artifact_name!=null && !artifact_name.trim().equalsIgnoreCase(""))
		{
			if(tmfCODomainList.size()==0)
			{
				retrieveTMFArtifactInfo(session,artifact_name);
			}
			domainList=tmfCODomainList;

			if(!domainList.contains(ISWYApplySECRFConstants.TMF_DOMAIN))
			{
				domainList.add(ISWYApplySECRFConstants.TMF_DOMAIN);
			}
		}
		DfLogger.debug(this, "List of available domains ["+domainList+"] for crossover artifact ["+artifact_name+"]", null, null);
		return domainList;
	}

	public ArrayList<String> getClineCrossOverDomains(IDfSession session, String artifact_name,String domain) throws Exception
	{
		ArrayList<String> domainList=new ArrayList<String>();

		if(artifact_name!=null && !artifact_name.trim().equalsIgnoreCase(""))
		{

			boolean is_crossover=chkDocDomainCrossOver(session,artifact_name,domain);

			if(is_crossover)
			{
				domainList=getListOfCrossOverDomains( session,  artifact_name);
			}
		}

		return domainList;
	}

	private Map<String,String> domain_type_attr_map = null;

	public void getObjtypeCollectionFromDomain(IDfSession paramIDfSession, String domain) throws DfException
	{
		if (domain_type_attr_map==null)
		{
			DfLogger.debug(this, "Retrieving "+ISWYApplySECRFConstants.DOCUMENT_DOMAINS_DIC+" Dictionary as part of Performance Issues", null, null);
			//D2Dictionary dAttr = D2Dictionary.getDictionary(ISWYApplySECRFConstants.DOCUMENT_DOMAINS_DIC, paramIDfSession, null, null, true, false);
			//domain_type_attr_map =dAttr.getKeyToAliasValueMap(ISWYApplySECRFConstants.DOCUMENT_DOMAINS_DIC_OBJ_TYPE_ALIAS);
			String dql="select dictionary_key,alias_value  from dm_dbo.d2_dictionary_alias_view where dictionary_name = '"+ISWYApplySECRFConstants.DOCUMENT_DOMAINS_DIC+"' and alias_name ='cd_object_type'";
			domain_type_attr_map=getCachedQueryResultMap(dql,"dictionary_key","alias_value",paramIDfSession);
		}
	}

	public String getObjtypeFromDomain(IDfSession paramIDfSession, String domain) throws DfException
	{
		getObjtypeCollectionFromDomain(paramIDfSession,domain);
		String doc_obj_type=null;
		Set<String> att_keys = domain_type_attr_map.keySet();
		Iterator<String> att_iterator = att_keys.iterator();

		while (att_iterator.hasNext())
		{
			String domainName = att_iterator.next(); 

			if(domain.trim().toLowerCase().equalsIgnoreCase(domainName.trim()))
			{

				String c_value = domain_type_attr_map.get(domainName);  
				doc_obj_type=c_value;
				break;
			}

		}
		return doc_obj_type;
	}

	public  Map<String, String> getCachedQueryResultMap(String dql, String keyAttribute, String valueAttribute, IDfSession session)
			throws DfException
	{
		DfLogger.debug(QueryUtils.class, "getCachedQueryResultMap: Running query: {0}", new String[] { dql }, null);
		Map results = new HashMap();
		DfQuery query = new DfQuery();
		IDfCollection coll = null;
		try {
			query.setDQL(dql);
			coll = query.execute(session, 2);
			while (coll.next()) {
				String key = coll.getString(keyAttribute);
				String value = coll.getString(valueAttribute);
				if ((!StringUtils.isNullOrEmpty(key)) && ((!results.containsKey(key)) || (StringUtils.isNullOrEmpty((String)results.get(key)))))
					results.put(key, value);
			}
		}
		finally {
			if (coll != null) {
				coll.close();
			}
		}

		DfLogger.debug(QueryUtils.class, "getCachedQueryResultMap: Query: {0} returned {1}.", new String[] { dql, 
				StringUtils.countToString(results
						.size(), "result") }, null);

		return results;
	}

	public  String[] getAllCachedQueryResultsAsStrings(String dql, IDfSession session)
			throws DfException
	{
		DfLogger.debug(this, "getAllCachedQueryResultsAsStrings: Running query: {0}", new String[] { dql }, null);
		ArrayList results = new ArrayList(20);
		DfQuery query = new DfQuery();
		IDfCollection coll = null;
		try {
			query.setDQL(dql);
			coll = query.execute(session, IDfQuery.CACHE_QUERY); //2
			while (coll.next()) {
				String resultColumn = coll.getRepeatingString("_names", 0);
				String result = coll.getString(resultColumn);
				results.add(result);
			}
		} finally {
			if (coll != null) {
				coll.close();
			}
		}

		DfLogger.debug(this, "getAllCachedQueryResultsAsStrings: Query: {0} returned: {1}.", new String[] { dql, 
				StringUtils.countToString(results
						.size(), "row") }, null);

		return (String[])results.toArray(new String[0]);
	}

	public  String execCachedQuery(String dql, IDfSession session)
			throws DfException
	{
		DfLogger.debug(this, "execCachedQuery: Running query: " + dql, null, null);
		DfQuery query = new DfQuery();
		query.setDQL(dql);
		IDfCollection coll = null;
		String result = null;
		try {
			coll = query.execute(session, IDfQuery.CACHE_QUERY); //2
			String resultColumn;
			if (coll.next()) {
				resultColumn = coll.getRepeatingString("_names", 0);
				result = coll.getString(resultColumn);
			}
			DfLogger.debug(this, "execCachedQuery: Query: {0} returned: {1}", new String[] { dql, result }, null);
			return result;
		} finally {
			if (coll != null)
				coll.close();
		}
	}
	public ArrayList<String> secRFOnCrossoverDocuments(IDfSysObject sysObj, ArrayList<String> automaticList) throws Exception
	{
		DfLogger.info(this, "secRFOnCrossoverDocuments::: SUB-3077 @ March 18th, 2022 ", null, null);
		ArrayList<String> returnList=new ArrayList<String>();
		String docsDomain=sysObj.getString(ISWYApplySECRFConstants.SRF_DOMAIN_ATTR_NAME);

		if(ISWYApplySECRFConstants.C_LINE_DOMAINS.trim().toLowerCase().contains(docsDomain.toLowerCase()))
		{
			IDfSession session=sysObj.getSession();

			String doc_artifact_name=sysObj.getString(ISWYApplySECRFConstants.DOC_ARTIFACT_NAME_ATTR);

			boolean isDocsDomainCrossover=chkDocDomainCrossOver(session,doc_artifact_name,docsDomain);
			if(isDocsDomainCrossover)
			{
				DfLogger.debug(this, "secRFOnCrossoverDocuments::: SUB-3077 @ March 18th, 2022::: Doc is crossover ", null, null);
				ArrayList<String> domainList=getListOfCrossOverDomains(session,doc_artifact_name);
				HashMap<String, ArrayList<String>> domainNcountMap=new HashMap<String, ArrayList<String>>();

				for(int i=0;i<automaticList.size();i++)
				{ 
					String secRFName=automaticList.get(i);

					String qual_to_secRf=ISWYApplySECRFConstants.SRF_TYPE +" where object_name='"+secRFName+"'";
					IDfSysObject secRFObj=(IDfSysObject)session.getObjectByQualification(qual_to_secRf);
					String secRfDomain=secRFObj.getString(ISWYApplySECRFConstants.SRF_DOMAIN_ATTR_NAME);

					if(!domainNcountMap.containsKey(secRfDomain))
					{
						ArrayList<String> tmpValList= new ArrayList<String>();
						tmpValList.add("1");
						tmpValList.add(secRFName);
						domainNcountMap.put(secRfDomain, tmpValList);
					}
					else
					{
						ArrayList<String> tmpValList=domainNcountMap.get(secRfDomain);
						int existCnt=Integer.parseInt(tmpValList.get(0));
						existCnt=existCnt+1;
						tmpValList.set(0, String.valueOf(existCnt));
						tmpValList.add(secRFName);
						domainNcountMap.put(secRfDomain, tmpValList);
					}

				}

				if(domainNcountMap.size()<=2 && domainNcountMap.size()>0)
				{
					if(domainList!=null && domainList.size()==1 && domainList.contains(ISWYApplySECRFConstants.TMF_DOMAIN))	// Crossover A
					{	
						//ISWYApplySECRFConstants.SECRF_STATS_INFO_TEXT_QC_ABORTED_DOC
						if(domainNcountMap.containsKey(ISWYApplySECRFConstants.TMF_DOMAIN) && domainNcountMap.get(ISWYApplySECRFConstants.TMF_DOMAIN).get(0).equalsIgnoreCase("1"))
						{
							returnList.add("True");
							returnList.add(domainNcountMap.get(ISWYApplySECRFConstants.TMF_DOMAIN).get(1));
							DfLogger.debug(this, "secRFOnCrossoverDocuments::: SUB-3077 @ March 18th, 2022::: Doc is TMF crossover(A) ", null, null);
						}
					}
					else	//Crossover B
					{
						//ISWYApplySECRFConstants.SECRF_STATS_INFO_TEXT_WF_ABORTED_DOC
						Iterator<String> iterator=domainNcountMap.keySet().iterator();	
						String domainStr=null;

						while(iterator.hasNext())
						{
							String tmpdomain=iterator.next();

							if(!tmpdomain.equalsIgnoreCase(ISWYApplySECRFConstants.TMF_DOMAIN))
							{
								domainStr=tmpdomain;
							}

						}

						if(domainStr!=null )
						{
							if(domainNcountMap.get(domainStr).get(0).equalsIgnoreCase("1"))
							{
								// For crossover B document where WF in used

								returnList.add("True");
								returnList.add(domainNcountMap.get(domainStr).get(1));
								DfLogger.debug(this, "secRFOnCrossoverDocuments::: SUB-3077 @ March 18th, 2022::: Doc is Safety / Clinical crossover (B)", null, null);
							}
						}
					}
				}
			}
			else
			{
				// Some issue since for crossover documents, maximum 2 domains are allowed
				DfLogger.debug(this, "secRFOnCrossoverDocuments::: SUB-3077 @ March 18th, 2022::: Doc is not crossover ", null, null);
			}


		}
		
		return returnList;
	}
}