package com.novartis.swy.utility.removeusers;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.documentum.cdf.methods.DistributedD2Method;
import com.documentum.cdf.methods.IDistributedD2Method;
import com.documentum.cdf.methods.TaskResult;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.client.IDfTypedObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfId;
import com.documentum.utils.AttributeExpression;
import com.documentum.utils.DfcObjectUtils;
import com.documentum.utils.QueryUtils;
import com.emc.common.java.utils.ArgumentParser;
import com.novartis.swy.utility.removeusers.utils.ISWYRemoveUsersConstants;
import com.novartis.swy.utility.removeusers.utils.SWYRemoveUsersBean;
import com.novartis.swy.utility.removeusers.utils.SWYRemoveUsersUtil;
import com.novartis.swy.utility.removeusers.utils.SWYRemoveUsersResultBean;
import com.novartis.swy.utility.removeusers.utils.SWYRemoveUsersTargetObjectsBean;


public class SWYRemoveUsers extends DistributedD2Method implements IDistributedD2Method
{

	public static final String ARG_CONTEXT_USER = "-context_user";
	public static final String ARG_SELECTED_OBJECT_ID = "-id";
	public static final String ARG_TARGET_OBJECT_DQL= "-target"; 
	// if target is null, product_code should be mandatory(higher Precedence is with product code) . 
	//-target DQL to retrieve objects which needs to process, med device needs to avoid.
	// -targets should have 2 columns for selection i.e. r_object_id,r_object_type

	public static final String ARG_ATTRIBUTES= "-attributes";  // attributes against which users need to remove
	/**
	 * -attributes "format_reviewers,approvers,qo_approvers,authors,auditors,reviewers,readers,doc_coordinators,
	 * review_notif_recipients, form_users,qc_group,qc_user"
	 */
	public static final String ARG_ENABLED_AUDIT= "-audit_enabled";  // true or false
	public static final String ARG_AUDIT_EVENT_NAME="-audited_event_name"; // optional
	public static final String ARG_AUDIT_EVENT_MSG="-audited_event_msg"; // optional
	public static final String ARG_BYPASS_LOCKS="-bypass_locks"; // true or false -->Default . // true means unlock , process and relock. False means skip the object 
	public static final String ARG_UPDATE_versions="-update_versions"; // true or false -->Default

	public static final String ARG_CSV_FILE_REMOVE_USERS = "-csv_file_path_users_to_be_removed"; // filepath of a file which contains the list of users that needs to remove from the object
	public static final String ARG_EXCLUDE_OBJ_TYPES = "-exclude_object_types";  //separated with , (comma)
	public static final String ARG_USERS_TO_BE_REMOVED = "-users_to_be_removed"; //separated with #, not mandatory if filepath mentioned
	public static final String ARG_PRODUCT_CODE = "-product_code"; // if null, then target should be mandatory. (higher Precedence is with product code) 

	private ArgumentParser argParser=null;
	private String attributes=null;
	private Boolean enabledAudit=false;
	private String auditEvent=null;
	private String auditEventMsg=null;
	private Boolean byPassLocks=false; // true means unlock , process and relock. False means skip the object 
	private Boolean updateVersions=false;
	String context_user=null;

	private String csv_file_path=null;
	private String exclude_obj_types=null;
	private String users_to_be_removed=null;

	SWYRemoveUsersUtil removeUserUtil=new SWYRemoveUsersUtil();

	@Override
	public String getMethodName() {
		return ISWYRemoveUsersConstants.DM_METHOD_NAME;
	}

	public Serializable[] getTaskData(IDfSession paramIDfSession, IDfSysObject paramIDfSysObject, Locale paramLocale, 
			ArgumentParser paramArgumentParser) throws DfException {

		DfLogger.warn(this,"************************************** "+ISWYRemoveUsersConstants.DM_METHOD_NAME+" *****************************************************************",null,null);

		//IDfId  objId 	  = paramArgumentParser.getIdArgument(ARG_SELECTED_OBJECT_ID, null); // current context object
		String targetQuery=paramArgumentParser.getStringArgument(ARG_TARGET_OBJECT_DQL, null); // Complete DQL to retrieve target objects
		//String source=paramArgumentParser.getStringArgument(ARG_SOURCE_OBJECT_ID, null);  // Single r_object_id or complete DQL which returns single r_object_id only
		attributes=paramArgumentParser.getStringArgument(ARG_ATTRIBUTES, null);
		enabledAudit=paramArgumentParser.getBooleanArgument(ARG_ENABLED_AUDIT, false);
		auditEvent=paramArgumentParser.getStringArgument(ARG_AUDIT_EVENT_NAME, null);
		auditEventMsg=paramArgumentParser.getStringArgument(ARG_AUDIT_EVENT_MSG, null);
		byPassLocks=paramArgumentParser.getBooleanArgument(ARG_BYPASS_LOCKS, false);
		updateVersions=paramArgumentParser.getBooleanArgument(ARG_UPDATE_versions, false);
		context_user=paramArgumentParser.getStringArgument(ARG_CONTEXT_USER, null);

		exclude_obj_types=paramArgumentParser.getStringArgument(ARG_EXCLUDE_OBJ_TYPES, null); //separated with , (comma)
		csv_file_path=paramArgumentParser.getStringArgument(ARG_CSV_FILE_REMOVE_USERS, null);
		users_to_be_removed=paramArgumentParser.getStringArgument(ARG_USERS_TO_BE_REMOVED, null); //separated with #
		String product_code=paramArgumentParser.getStringArgument(ARG_PRODUCT_CODE, null);

		String local_users_list_str=null;

		SWYRemoveUsersUtil utilObj=new SWYRemoveUsersUtil();
		SWYRemoveUsersTargetObjectsBean [] swyBeanArray=null;

		if(csv_file_path!=null && !csv_file_path.isEmpty())
		{
			ArrayList<String> usersList= utilObj.getUserListFromCSV(csv_file_path); 
			if(usersList!=null && usersList.size()>0)
			{
				local_users_list_str=StringUtils.join(usersList, ISWYRemoveUsersConstants.CSV_READ_USERS_DELIMITER); //separated with #
			}
		}

		if(local_users_list_str==null || local_users_list_str.isEmpty())
		{
			if(users_to_be_removed!=null && !users_to_be_removed.isEmpty())
			{

			}
			else
			{
				DfLogger.warn(this," parameter against argument "+ARG_CSV_FILE_REMOVE_USERS+" or "+ARG_USERS_TO_BE_REMOVED+" not defined properly",null,null);
				swyBeanArray=new SWYRemoveUsersTargetObjectsBean [1] ;
				swyBeanArray[0]=new SWYRemoveUsersTargetObjectsBean();
				return swyBeanArray;
			}
		}
		else
		{
			users_to_be_removed=local_users_list_str;
		}

		IDfTypedObject[]  targetIds=null;		

		/** 
		 * start of forming DQL to retrieve target objects
		 * 
		 */

		if (product_code!=null && !product_code.isEmpty())
		{
			String exclude_types=ISWYRemoveUsersConstants.EXCLUDE_TYPES;
			exclude_types=exclude_types.trim();

			String[] hard_coded_exclude_types_arr=exclude_types.split(ISWYRemoveUsersConstants.EXIST_ATTR_COMMA_DELIMITER);
			String[] param_exclude_obj_types_arr=null;
			if(exclude_obj_types!=null && !exclude_obj_types.isEmpty())
			{
				param_exclude_obj_types_arr=exclude_obj_types.split(ISWYRemoveUsersConstants.EXIST_ATTR_COMMA_DELIMITER);
			}

			ArrayList<String> obj_types_excluded_list=new ArrayList<String>();
			if(hard_coded_exclude_types_arr!=null && hard_coded_exclude_types_arr.length>0)
			{
				for(int i=0;i<hard_coded_exclude_types_arr.length;i++)
				{
					obj_types_excluded_list.add(hard_coded_exclude_types_arr[i]);
				}
			}
			if(param_exclude_obj_types_arr!=null && param_exclude_obj_types_arr.length>0)
			{
				for(int i=0;i<param_exclude_obj_types_arr.length;i++)
				{
					obj_types_excluded_list.add(param_exclude_obj_types_arr[i]);
				}
			}

			String exclude_types_result=null;
			for(int i=0;i<obj_types_excluded_list.size();i++)
			{
				if(i==0)
				{
					exclude_types_result="'"+obj_types_excluded_list.get(i) +"'";
				}
				else
				{
					exclude_types_result=exclude_types_result+",'"+obj_types_excluded_list.get(i)+"'";
				}
			}

			exclude_types_result="and r_object_type not in ("+exclude_types_result+")";

			product_code = product_code.trim();
			product_code = "'" + product_code.replace("#", "','") + "'";	

			String dql = "select r_object_id,r_object_type from cd_common_ref_model where (lower(product_code) in (" + product_code.toLowerCase()  + ") or any lower(product_codes) in (" + product_code.toLowerCase() + ") or any lower(other_product_codes) in (" + product_code.toLowerCase() + ")) and domain!='Non-Clinical' and domain!='Quality' and swy_confidentiality !='RSTD' "+exclude_types_result
					+ " union select r_object_id,r_object_type from cd_common_ref_model where (lower(product_code) in (" + product_code.toLowerCase() + ") or any lower(product_codes) in (" + product_code.toLowerCase() + ") or any lower(other_product_codes) in (" + product_code.toLowerCase() + ")) and domain='Non-Clinical' and any swy_divisions not in ('SZ') and swy_confidentiality !='RSTD' "+exclude_types_result
					+ " union select r_object_id,r_object_type from cd_common_ref_model where (lower(product_code) in (" + product_code.toLowerCase() + ") or any lower(product_codes) in (" + product_code.toLowerCase() + ") or any lower(other_product_codes) in (" + product_code.toLowerCase() + ") or any lower(drug_substance_name) in ( select lower(drug_substance_name) from cd_product_info where lower(product_code)=" + product_code.toLowerCase() + ")) and domain='Quality' and swy_confidentiality !='RSTD' " +exclude_types_result
					+ " union select r_object_id,r_object_type from swy_topic_container where lower(product_code) in (" + product_code.toLowerCase() + ") "
					+ " union select r_object_id,r_object_type from swy_sec_registration_form where lower(swy_filter_product_code) in (" + product_code.toLowerCase() + ") and domain!='Med Device' and domain!='Non-Clinical' "
					+ " union select r_object_id,r_object_type from swy_sec_registration_form where lower(swy_filter_product_code) in (" + product_code.toLowerCase() + ") and domain='Non-Clinical' and swy_division not in ('SZ') "
					+ " union select r_object_id,r_object_type from swy_sec_registration_form where (lower(swy_filter_product_code) in (" + product_code.toLowerCase() + ") or lower(swy_filter_ds_name) in ( select lower(drug_substance_name) from cd_product_info where lower(product_code)="+ product_code.toLowerCase() +")) and domain='Quality' " + 
					"";
			targetQuery=dql;
		}
		else
		{
			if(targetQuery!=null && !targetQuery.isEmpty())
			{

			}
			else
			{
				DfLogger.warn(this," parameter against argument "+ARG_PRODUCT_CODE+" or "+ARG_TARGET_OBJECT_DQL+" not defined properly",null,null);
				swyBeanArray=new SWYRemoveUsersTargetObjectsBean [1] ;
				swyBeanArray[0]=new SWYRemoveUsersTargetObjectsBean();
				return swyBeanArray;
			}
		}

		/** 
		 * start of Retrieving target objects 
		 * 
		 */
		DfLogger.info(this,"Resolved Target DQL=["+targetQuery+"]",null, null);
		if(targetQuery!=null && !targetQuery.equalsIgnoreCase(""))
		{
			targetIds=QueryUtils.getAllQueryResults(targetQuery,paramIDfSession) ;
		}

		if (targetIds==null || targetIds.length==0)
		{
			DfLogger.warn(this, "No objectss to process from where users need to remove", null, null);
			swyBeanArray=new SWYRemoveUsersTargetObjectsBean [1] ;
			swyBeanArray[0]=new SWYRemoveUsersTargetObjectsBean();
			return swyBeanArray;
		}
		else
		{
			swyBeanArray=new SWYRemoveUsersTargetObjectsBean[targetIds.length];

			for(int i=0;i<swyBeanArray.length;i++)
			{
				swyBeanArray[i]=new SWYRemoveUsersTargetObjectsBean();
				swyBeanArray[i].setTargetObjectId(targetIds[i].getString("r_object_id"));
				swyBeanArray[i].setTargetObjectType(targetIds[i].getString("r_object_type"));
			}
		}
		/** 
		 * End of Retrieving target objects 
		 * 
		 */

		if( swyBeanArray!=null)
		{
			DfLogger.warn(this, "No. of objects to be processed  " + swyBeanArray.length +" where Restricted Country users needs to apply", null, null);
		}

		return swyBeanArray;
	}



	@Override
	public Map<String, String> getSlaveMethodArgs() throws DfException 
	{
		DfLogger.warn(this,"****************Starting getSlaveMethodArgs()*******************************************",null, null);
		Map<String, String> methodArgs = new HashMap<>();

		methodArgs.put(ARG_ATTRIBUTES,attributes);
		methodArgs.put(ARG_ENABLED_AUDIT,String.valueOf(enabledAudit));
		methodArgs.put(ARG_AUDIT_EVENT_NAME,auditEvent);
		methodArgs.put(ARG_AUDIT_EVENT_MSG,auditEventMsg);
		methodArgs.put(ARG_ENABLED_AUDIT,String.valueOf(enabledAudit));
		methodArgs.put(ARG_BYPASS_LOCKS,String.valueOf(byPassLocks));
		methodArgs.put(ARG_UPDATE_versions,String.valueOf(updateVersions));
		methodArgs.put(ARG_USERS_TO_BE_REMOVED,users_to_be_removed); //separated with #

		if(context_user!=null)
			methodArgs.put(ARG_CONTEXT_USER, context_user);

		argParser=new ArgumentParser(methodArgs);
		DfLogger.warn(this,"****************End of getSlaveMethodArgs()*******************************************",null, null);
		return methodArgs;
	}

	@Override
	public void initSlaveProcess(IDfSession session, IDfSysObject job, Locale locale, ArgumentParser argumentParser)
			throws DfException 
	{
		DfLogger.warn(this,"****************Starting initSlaveProcess()*******************************************",null, null);
		argParser=argumentParser;
		DfLogger.warn(this,"****************Completing initSlaveProcess()*******************************************",null, null);

	}

	@Override
	public Serializable performTask(int arg0, String arg1, Serializable arg2, IDfSession session) 
			throws DfException 
	{
		DfLogger.warn(this,"****************Starting performTask()*******************************************",null, null);

		if(arg2!=null)
		{
			SWYRemoveUsersTargetObjectsBean beanObj=(SWYRemoveUsersTargetObjectsBean)arg2;
			String targetObjId=beanObj.getTargetObjectId();
			String targetObjType=beanObj.getTargetObjectType();
			SWYRemoveUsersBean attrBeanObj=beanObj.getAttributeInheritanceData();

			if(targetObjId!=null && !targetObjId.isEmpty())
			{
				DfLogger.info(this,"In performTask() :: Processing Object "+targetObjId,null,null);

				//return setSecurityRegistrationForm(session,objId);
				return removeUsers(session,targetObjId,targetObjType);
			}
			else
			{
				SWYRemoveUsersResultBean errorObj=new SWYRemoveUsersResultBean();
				errorObj.setFailedProcessStatus("Failed");
				errorObj.setProcessMsg("No onjects to process");
				return errorObj;
			}
		}
		else
		{
			DfLogger.warn(this,"****************Completing performTask(Serializable Object is null)*******************************************",null, null);

			SWYRemoveUsersResultBean errorObj=new SWYRemoveUsersResultBean();
			errorObj.setFailedProcessStatus("Failed");
			errorObj.setProcessMsg("Task Object is null");
			return errorObj;
		}
	}

	private SWYRemoveUsersResultBean removeUsers(IDfSession session, String targetId,String targetObjType)  throws DfException
	{
		/**
		 * -attributes "merge-tar1-src1~replace-tar2-src2~replace-tar3-src3~replace-tar5-@tar4~replace-tar4-[staticvalue]"
		 */

		String ctxUsr=argParser.getStringArgument(ARG_CONTEXT_USER, null);
		DfLogger.warn(this, "::: Remove users targetId==> ("+targetId+") targetObjType "+targetObjType+" context user  >> " + ctxUsr, null, null);

		IDfSysObject targetObject=(IDfSysObject)session.getObject(new DfId(targetId));

		String arg_attributes=argParser.getStringArgument(ARG_ATTRIBUTES, null);
		Boolean arg_enabledAudit=argParser.getBooleanArgument(ARG_ENABLED_AUDIT, false);
		String arg_auditEvent=argParser.getStringArgument(ARG_AUDIT_EVENT_NAME, null);
		String arg_auditEventMsg=argParser.getStringArgument(ARG_AUDIT_EVENT_MSG, null);
		Boolean arg_byPassLocks=argParser.getBooleanArgument(ARG_BYPASS_LOCKS, false); // true means unlock , process and relock. False means skip the object 
		Boolean arg_updateVersions=argParser.getBooleanArgument(ARG_UPDATE_versions, false);
		String arg_users_to_be_removed=argParser.getStringArgument(ARG_USERS_TO_BE_REMOVED, null); //separated with #

		DfLogger.info(this, "arg_attributes["+arg_attributes+"]", null, null);
		DfLogger.info(this, "arg_enabledAudit["+arg_enabledAudit+"]", null, null);
		DfLogger.info(this, "arg_auditEvent["+arg_auditEvent+"]", null, null);
		DfLogger.info(this, "arg_auditEventMsg["+arg_auditEventMsg+"]", null, null);
		DfLogger.info(this, "arg_updateVersions["+arg_updateVersions+"]", null, null);
		DfLogger.info(this, "arg_byPassLocks["+arg_byPassLocks+"]", null, null);

		SWYRemoveUsersResultBean resultBeanObj=new SWYRemoveUsersResultBean();

		boolean isObjUpdated=false;
		String auditAttrList=null;
		String auditAttrListOld=null;

		String[] existing_attr=ISWYRemoveUsersConstants.ATTRIBUTES.split(ISWYRemoveUsersConstants.EXIST_ATTR_COMMA_DELIMITER );

		List<String> existAttrarraylist=Arrays.asList(existing_attr);

		List<String> existing_attrList = new ArrayList<>(existAttrarraylist);

		if(arg_attributes!=null && !arg_attributes.isEmpty())
		{
			existing_attr=arg_attributes.split(ISWYRemoveUsersConstants.EXIST_ATTR_COMMA_DELIMITER );

			if (existing_attr!=null && existing_attr.length>0)
			{
				for(int i=0;i<existing_attr.length;i++)
				{
					if(!existing_attrList.contains(existing_attr[i]))
					{
						existing_attrList.add(existing_attr[i]);
					}
				}
			}
		}

		/** Code to canceling checkout in target object
		 * 
		 */
		Map<java.lang.String,java.lang.String[]> checkedoutObjInfo=null;
		boolean isChkOutAborted=false;

		DfLogger.info(this, "Target Object ["+targetId+"] arg_users_to_be_removed=["+arg_users_to_be_removed+"]", null, null);
		String[] users_to_be_removed_list_str= arg_users_to_be_removed.split(ISWYRemoveUsersConstants.CSV_STR_READ_USERS_DELIMITER);

		List<String> users_to_be_removed_list=Arrays.asList(users_to_be_removed_list_str);
		resultBeanObj= removeUserUtil.getUsersDataToBeRemoved(targetObject,existing_attrList,users_to_be_removed_list,resultBeanObj);

		/*if(resultBeanObj.getProcessStatus().equalsIgnoreCase(ISWYRemoveUsersConstants.PROCESS_REQUIRED)||
				resultBeanObj.getProcessStatus().equalsIgnoreCase(ISWYRemoveUsersConstants.INFORM_BUSINESS))*/
		DfLogger.info(this, "TargetObjectId:::"+targetId+" Processing Success Status=["+resultBeanObj.getSuccessProcessStatus()+"]  Processing Failed Status=["+resultBeanObj.getFailedProcessStatus()+"]", null, null);
		if(resultBeanObj.getSuccessProcessStatus()!=null && resultBeanObj.getSuccessProcessStatus().toUpperCase().startsWith("SUCCESS"))
		{
			// Generating Audit trail entry for target object with their existing value, before they get updated with new values
			auditAttrListOld=removeUserUtil.generateAttributesAuditEntry(targetId,session,existing_attrList);
			DfLogger.info(this, "TargetObjectId:::"+targetId+" auditAttrListOld=["+auditAttrListOld+"]", null, null);

			if((targetObject.isCheckedOut() && arg_byPassLocks))
			{
				DfLogger.info(this, "Target Object ["+targetId+"] cancel checkout start ", null, null);
				checkedoutObjInfo=removeUserUtil.getCheckoutInfo(targetId,session);
				isChkOutAborted=removeUserUtil.isCheckOutAborted(targetId,session);

				DfcObjectUtils.fetchObjectIfRequired(targetObject);
				DfLogger.info(this, "Target Object ["+targetId+"] cancel checkout done ", null, null);
			}

			Map<java.lang.String,ArrayList<String>> tmpValMAp=resultBeanObj.getUpdateValueMap();

			if(tmpValMAp!=null && tmpValMAp.size()>0)
			{

				for (Map.Entry<String, ArrayList<String>> entry : tmpValMAp.entrySet()) 
				{
					String key = entry.getKey(); //attrname
					ArrayList<String> value = entry.getValue(); //values

					String listString = String.join(", ", value);
					String srcValArr[]=value.toArray(new String[value.size()]);
					DfLogger.info(this, "Target Object ["+targetId+"] key=["+key+"] value=["+listString+"]", null, null);
					removeUserUtil.updateRepeatedAttribute(srcValArr, key, targetObject, false, true);
					isObjUpdated=true;
				}
			}

			if(isObjUpdated)
			{
				if((isChkOutAborted && arg_byPassLocks) || !targetObject.isCheckedOut())
				{
					DfcObjectUtils.saveChangesToObjectIfRequired(targetObject, false, true, false, ctxUsr, session);
					DfLogger.info(this, "Target Object ["+targetId+"] updated and Restricted Country users removed", null, null);
					resultBeanObj.setTargetObjectId(targetId);
					resultBeanObj.setTypeName(targetObject.getTypeName());
					resultBeanObj.setSuccessProcessStatus("Success");

					DfcObjectUtils.fetchObjectIfRequired(targetObject);

					if(isChkOutAborted)
					{
						removeUserUtil.isAbortcheckoutCancelled(targetId,session, checkedoutObjInfo);
						DfcObjectUtils.fetchObjectIfRequired(targetObject);
					}

					if(arg_enabledAudit)
					{
						// Generating Audit trail entry for target object with their new value, after they get updated with new values
						auditAttrList=removeUserUtil.generateAttributesAuditEntry(targetId,session,existing_attrList);
						DfLogger.info(this, "TargetObjectId:::"+targetId+" auditAttrList=["+auditAttrList+"]", null, null);

						if (!auditAttrListOld.isEmpty() && !auditAttrList.isEmpty())
						{
							removeUserUtil.createAuditObject(targetId,session,arg_auditEvent,arg_auditEventMsg,auditAttrList,auditAttrListOld);
							resultBeanObj.setIsAudited(true);
						}
					}
				}
			}
		}
		if(arg_updateVersions)
		{
			removeUserUtil.applyChangesToDocAllVersions(targetId,session,existing_attrList,users_to_be_removed_list,arg_enabledAudit,ctxUsr,arg_auditEvent,arg_auditEventMsg,arg_byPassLocks);
			resultBeanObj.setIsVersionUpdated(true);
		}

		return resultBeanObj;
	}

	@Override
	public void handleResults(IDfSession session, TaskResult[] taskResults)
	{
		DfLogger.warn(this,"*****************Processing done of "+ISWYRemoveUsersConstants.DM_METHOD_NAME+" *****************************************************************",null,null);
		if(taskResults!=null)
			DfLogger.info(this, "Start of Handle Results No. of task results need to process["+taskResults.length+"]", null, null);

		DfLogger.warn(this, "There is nothing defined to process as part of post processer --- End of Handle Results", null, null);

	}

}
