package com.novartis.swy.inheritance.utils;

public class ISWYApplyInheritanceConstants {

	final public static String DM_METHOD_NAME = "SWYApplyInheritance";
	
	final public static String DCTM_DATE_ATTR_FORMAT="mm/dd/yyyy hh:mi:ss a";
	
	final public static String DQL_DATE_ATTR_YYYYMMDDHHMISS_FORMAT=	"yyyy/mm/dd hh:mi:ss";
	
	final public static String ORACLE_DATE_ATTR_FORMAT="yyyy/mm/dd hh24:mi:ss";
	
	final public static String DOC_R_OBJECT_ID_ATTR="r_object_id";
	
	//final public static String MTHD_DISTRIBUTED_PROCESSING_THRESHOLD="99";
	
	final public static String MTHD_AD2C_NAME="CDFApplyD2ConfigurationsAsyncMethod";
	
}
