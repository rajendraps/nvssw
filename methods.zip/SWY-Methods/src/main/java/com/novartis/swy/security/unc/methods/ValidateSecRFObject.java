package com.novartis.swy.security.unc.methods;

import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import com.documentum.cdf.methods.CDFD2Method;
import com.documentum.d2.model.D2Dictionary;
import com.documentum.fc.client.IDfModule;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfId;
import com.documentum.utils.QueryUtils;
import com.emc.common.java.utils.ArgumentParser;
import com.emc.d2.api.methods.D2Method;
import com.emc.d2.api.methods.D2methodBean;
import com.emc.d2.api.methods.ID2Method;
import com.novartis.swy.security.utils.ISWYApplySECRFConstants;

public class ValidateSecRFObject implements ID2Method, IDfModule
{

	public static final String ARG_PRECONDITION = "-if";
	public static final String ARG_CONTEXT_USER = "-context_user";
	public static final String ARG_QUALIFICATION = "-dql_qualifier";	//DQL qualification to validate any SecRF object does exist or not, id is optional in this case

	public static final String ARG_SELECTED_OBJECT_ID = "-id";	// object id of SecRF object
	public static final String ARG_ATTR_LIST = "-predicate_attrs";	// optional, either attrs_dictionary or predicate_attrs are required,comma separated list of attributes, to validate any SecRF object does exist or not
	public static final String ARG_ATTR_DICTIONARY = "-attrs_dictionary";	//optional, either attrs_dictionary or predicate_attrs are required, in case list of attribute(to validate any SecRF object does exist or not) are defined in dictionary 

	String precondition=null;
	String context_user=null;
	String targetSecRFQualification=null;
	String attrListStr=null;
	String attrsDictionary=null;

	String srfObjType =null;	

	
	@Override
	public D2methodBean execute(IDfSession paramIDfSession, IDfSysObject paramIDfSysObject, Locale paramLocale, ArgumentParser paramArgumentParser) throws DfException
	{
		String result=null;
		String resultType=null;

		DfLogger.debug(this,"************************************** ValidateSecRFObject *****************************************************************",null,null);
		IDfId  objId 	  = paramArgumentParser.getIdArgument(ARG_SELECTED_OBJECT_ID, null);

		precondition = paramArgumentParser.getStringArgument(ARG_PRECONDITION, null);
		context_user=paramArgumentParser.getStringArgument(ARG_CONTEXT_USER, null);
		targetSecRFQualification=paramArgumentParser.getStringArgument(ARG_QUALIFICATION, null);
		attrsDictionary=paramArgumentParser.getStringArgument(ARG_ATTR_DICTIONARY, null);
		attrListStr=paramArgumentParser.getStringArgument(ARG_ATTR_LIST, null);

		DfLogger.info(this, "Object ID of the SecRF Context object > " + objId.getId(), null, null);
		DfLogger.debug(this,"**********************************************************************************************************************",null, null);
		DfLogger.debug(this, "DQL Qualitifcation to validate existing SecRF objects  > " + targetSecRFQualification, null, null);
		DfLogger.debug(this,"**********************************************************************************************************************",null, null);
		DfLogger.debug(this, "Pre-condition  > " + precondition, null, null);
		DfLogger.debug(this,"**********************************************************************************************************************",null, null);
		DfLogger.debug(this, "Attributes Dictionary Name > " + attrsDictionary, null, null);
		DfLogger.debug(this,"**********************************************************************************************************************",null, null);
		DfLogger.debug(this, "Attributes List for validating SecRF object exist  > " + attrListStr, null, null);
		DfLogger.debug(this,"**********************************************************************************************************************",null, null);
		DfLogger.debug(this, "Context User  > " + context_user, null, null);
		DfLogger.debug(this,"**********************************************************************************************************************",null, null);
		DfLogger.debug(this, "Session Intialized from the user> " + paramIDfSession.getLoginUserName(), null, null);
		DfLogger.debug(this,"**********************************************************************************************************************",null, null);

		try
		{
			
			if(attrsDictionary==null || attrsDictionary.trim().equalsIgnoreCase(""))
			{
				attrsDictionary="CMN-DIC-Security Registration Form Filter";
			}
			
			if(targetSecRFQualification==null || targetSecRFQualification.trim().equalsIgnoreCase(""))
			{
				if(objId!=null && objId.isObjectId())
				{
					IDfSysObject secRFObj=(IDfSysObject) paramIDfSession.getObject(objId);
					srfObjType=secRFObj.getTypeName().toLowerCase().trim();

					if(attrListStr==null || attrListStr.trim().equalsIgnoreCase(""))
					{
						attrListStr=getSecRFFilterAtrtsList(secRFObj,attrsDictionary);
					}
					targetSecRFQualification=getSecRFObjectValidateDql(attrListStr,srfObjType,secRFObj);
				}
			}
			targetSecRFQualification=applyPrecondition(targetSecRFQualification,precondition);

			DfLogger.debug(this, "Attributes Dictionary Name > " + attrsDictionary, null, null);
			DfLogger.debug(this,"**********************************************************************************************************************",null, null);
			DfLogger.info(this, "DQL Qualitifcation to validate existing SecRF objects  > " + targetSecRFQualification, null, null);
			DfLogger.debug(this,"**********************************************************************************************************************",null, null);
			DfLogger.debug(this, "Attributes List for validating SecRF object exist  > " + attrListStr, null, null);
			DfLogger.debug(this,"**********************************************************************************************************************",null, null);

			Map<String, String[]> secRFInfoMap=QueryUtils.getAllQueryResultColumnValues(targetSecRFQualification, false, paramIDfSession);	//column name as key and string[] as value
			DfLogger.debug(this,"Validation DQL Processed...",null, null);

			
			if(secRFInfoMap!=null && secRFInfoMap.size()>0)
			{
				result="Record Already Exist";
				resultType=D2Method.RETURN_FATAL_STR;
				
				DfLogger.debug(this,"Validation Processed... "+result +" # of Result ["+secRFInfoMap.get("r_object_id").length+"] "+resultType,null, null);
			}
			else
			{
				result="Record Doesn't Exist";
				resultType=D2Method.RETURN_SUCCESS_STR;
				DfLogger.debug(this,"Validation Processed... "+"  "+resultType,null, null);
			}
		}
		catch(Exception ex)
		{
			DfLogger.error(this, ex.getMessage(), null, ex);
		}
		
		DfLogger.debug(this,"Validation Processed... "+"  "+resultType,null, null);
		return new D2methodBean(resultType, result);		
	}

	private String applyPrecondition(String dqlqualification,String precond) throws Exception
	{
		String finalDql="Select r_object_id from "+dqlqualification;
		if(precond!=null && !precond.trim().equalsIgnoreCase(""))
		{
			DfLogger.debug(this,"Precondition can be apply",null,null);
			finalDql=finalDql+" AND "+precond;
		}
		return finalDql;
	}

	private String getSecRFObjectValidateDql(String attrListStr, String type, IDfSysObject secRFObj) throws Exception
	{
		boolean is_cross_domain=secRFObj.getBoolean(ISWYApplySECRFConstants.SRF_IS_CROSS_DOMAIN_ATTR_NAME);
		String dqlFromAttrList=" "+type+" where (swy_secrf_mode='"+secRFObj.getString(ISWYApplySECRFConstants.SECURITY_MODE)+"' )";
		String attrArray[]=attrListStr.split(",");
		for(int i=0;i<attrArray.length;i++)
		{
			String attrName=attrArray[i];


			if(secRFObj.hasAttr(attrName))
			{
				int attrDataType=secRFObj.getAttrDataType(attrName);
				String value=secRFObj.getString(attrName);
				if(attrDataType==4)   // Time
				{

					if(value!=null && !value.equalsIgnoreCase("") && !value.trim().equalsIgnoreCase("nulldate"))
					{
						dqlFromAttrList=dqlFromAttrList+" AND "+attrName+" = "+ "date('"+value+" utc','"+ISWYApplySECRFConstants.DCTM_DATE_ATTR_FORMAT+"')" ;
					}
					else
					{
						dqlFromAttrList=dqlFromAttrList+" AND "+attrName+" is nulldate ";
					}
				}
				else if (attrDataType==0 )	//Boolean
				{
					if(value.equalsIgnoreCase("true") || value.equalsIgnoreCase("t") || value.equalsIgnoreCase("1"))
					{
						dqlFromAttrList=dqlFromAttrList+" AND "+attrName+" =1 ";
					}
					else if(value.equalsIgnoreCase("false") || value.equalsIgnoreCase("f") || value.equalsIgnoreCase("0"))
					{
						dqlFromAttrList=dqlFromAttrList+" AND "+attrName+" =0 ";
					} 
				}
				else if (attrDataType==1 || attrDataType==5) // Number || Double
				{
					dqlFromAttrList=dqlFromAttrList+" AND "+attrName+" = "+value;
				}
				else if (attrDataType==2 || attrDataType==3)	//String || Id
				{
					if(value!=null && !value.trim().equalsIgnoreCase(""))
					{					
					dqlFromAttrList=dqlFromAttrList+" AND "+attrName+" = '"+value+"'";
					}
					else
					{
						dqlFromAttrList=dqlFromAttrList+" AND "+attrName+" is nullstring";
					}
				}

			}
		}
		dqlFromAttrList=dqlFromAttrList+" AND r_object_id!='"+secRFObj.getObjectId().getId()+"'";
		
		if(is_cross_domain)
		{
			dqlFromAttrList=dqlFromAttrList+" AND "+"('"+String.valueOf(secRFObj.getBoolean(ISWYApplySECRFConstants.SRF_IS_CROSS_DOMAIN_ATTR_NAME)).toLowerCase()+"' in ('true','t') and swy_is_cross_domain=True)";
		}
		return dqlFromAttrList;
	}

	private String getSecRFFilterAtrtsList(IDfSysObject secRFObj,String attrsDictionary) throws Exception
	{
		String attrListStr=null;
		String domain=secRFObj.getString("domain").trim();
		boolean is_cross_domain=secRFObj.getBoolean(ISWYApplySECRFConstants.SRF_IS_CROSS_DOMAIN_ATTR_NAME);

		IDfSession session=secRFObj.getSession();

		D2Dictionary dAttr = D2Dictionary.getDictionary(attrsDictionary, session, null, null, true, false);
		if(!is_cross_domain)
		{
			Map<String,String> m_attr_map =dAttr.getKeyToAliasValueMap(domain);

			Set<String> att_keys = m_attr_map.keySet();
			Iterator<String> att_iterator = att_keys.iterator();

			while (att_iterator.hasNext())
			{
				String secRFAttr = att_iterator.next(); // name of the column, corresponding to SecRF 
				String c_value = m_attr_map.get(secRFAttr);  // value (Yes/No), corresponding to SecRF , required in specific domain

				if(c_value.toUpperCase().trim().startsWith("Y") || c_value.toUpperCase().trim().startsWith("T"))
				{
					if(attrListStr==null || attrListStr.trim().equalsIgnoreCase(""))
					{
						attrListStr=secRFAttr;
					}
					else
					{
						attrListStr=attrListStr+","+secRFAttr;
					}
				}
			}
		}
		else if (is_cross_domain)
		{
			attrListStr=concatString(",", dAttr.getKeys());
		}

		return attrListStr;
	}
	
	public String concatString(String separator, String[] data)
	{
		String val=null;
		if(data!=null && data.length>0)
		{
			for(int i=0;i<data.length;i++)
			{
				String tmpStr=data[i];

				if(tmpStr!=null && !tmpStr.trim().equals(""))
				{

				}
				else
				{
					tmpStr="";
				}
				if(val==null)
				{
					val=tmpStr;
				}
				else
				{
					val=val+separator+tmpStr;
				}
			}
		}
		return val;
	}
}
