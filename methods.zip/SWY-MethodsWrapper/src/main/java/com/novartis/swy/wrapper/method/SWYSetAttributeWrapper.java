package com.novartis.swy.wrapper.method;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import com.documentum.cdf.methods.SetAttribute;
import com.documentum.d2.model.D2Dictionary;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfId;
import com.documentum.utils.AttributeExpression;
import com.documentum.utils.QueryUtils;
import com.emc.common.java.utils.ArgumentParser;
import com.emc.d2.api.methods.D2Method;
import com.emc.d2.api.methods.D2methodBean;

public class SWYSetAttributeWrapper implements IActionWrapper {
	private static final String STR_DIC_SET_ATTRIBUTES = "CMN-DIC-Set Attributes";
	private String strAliasValue = null;
	private SWYInitializeArtifactHelper SWY_IA_HELPER_OBJ = new SWYInitializeArtifactHelper();
	private Map<String, String> hmAliasNamesAliasValues = null;
	private static String STR_COL_NAME_OBJECT_TYPE = "object_type";
	private static String STR_COL_NAME_IF = "if";
	private static String STR_COL_NAME_TARGET = "target";
	private static String STR_COL_NAME_ATTR = "attr";
	private static String STR_COL_NAME_VALUE = "value";
	private static String STR_COL_NAME_APPEND = "append";
	private static String STR_COL_NAME_IGNORE_NULL_VALUES = "ignore_null_values";
	private static String STR_COL_NAME_DICTIONARY = "dictionary";	
	private static String STR_COL_NAME_APPLY_D2_CONFIGS = "apply_d2_configs";
	private static String STR_COL_NAME_ALIAS = "alias";
	private static String STR_BLANK_VALUE_IN_DICTIONARY = "Blank";
	private static String STR_ARG_NAME_TARGET = "-target";
	private static String STR_ARG_NAME_ATTR = "-attr";
	private static String STR_ARG_NAME_VALUE = "-value";
	private static String STR_ARG_NAME_APPEND = "-append";
	private static String STR_ARG_NAME_IGNORE_NULL_VALUES = "-ignore_null_values";
	private static String STR_ARG_NAME_DICTIONARY = "-dictionary";	
	private static String STR_ARG_NAME_APPLY_D2_CONFIGS = "-apply_d2_configs";
	private static String STR_ARG_NAME_ALIAS = "-alias";

	/**
	 * Method to fetch the arguments from dictionary , and calls CDFSetAttribute method if the condition satisfies
	 * @param pSession
	 * @param sysObject
	 * @param pStrActionKey
	 * @param locale
	 * @param argumentParser
	 * @return
	 * @throws Exception
	 */
	public D2methodBean execute(IDfSession pSession, IDfId pObjectId,IDfSysObject pSysObject, String pStrActionKey,Locale locale, ArgumentParser argumentParser) throws Exception {
		DfLogger.info(this,"************************************** execute() of SWYSetAttributeWrapper class started ********************************",null,null);
		boolean bIsCondition = true;
		boolean bIsSetAttributeFailed = false;
		List<String> listFailedSetAttributes = new ArrayList<String>();		
		String strLoggedInUser = pSession.getLoginUserName();
		D2methodBean methodBeanResponse = null;

		//Set Standard Arguments in the HasMap
		IDfSysObject sysObject = (IDfSysObject)pSession.getObject(pObjectId);
		hmAliasNamesAliasValues = SWY_IA_HELPER_OBJ.addStdArgumentsToHashMap(pSession, pObjectId, sysObject);		
		DfLogger.info(this,"Hashmap after initializing standard arguments:" + hmAliasNamesAliasValues + " and attributes to be set in the lifecycle and state: " + pStrActionKey,null,null);

		try {
			//Call CDFSetAttribute() method based on the condition fetched from ArgumentParser		
			String[] strArrKeyAttributeNames = pStrActionKey.split(",");
			for(int index=0; index<strArrKeyAttributeNames.length;index++) {
				DfLogger.debug(this,"Set Attributes Dictionary Key Name:" + strArrKeyAttributeNames[index],null,null);
				strAliasValue = D2Dictionary.getAliasValue(STR_DIC_SET_ATTRIBUTES,strArrKeyAttributeNames[index] ,STR_COL_NAME_OBJECT_TYPE, pSession, sysObject, strLoggedInUser, true, true);

				if(strAliasValue == null || ("".equalsIgnoreCase(strAliasValue))) {				
					//Check the condition mentioned for the setAttribute method, if the if condition satisfies, the CDFSetAttribute method will be called					    
					strAliasValue = D2Dictionary.getAliasValue(STR_DIC_SET_ATTRIBUTES,strArrKeyAttributeNames[index], STR_COL_NAME_IF, pSession, sysObject, strLoggedInUser, true, true);
					if(strAliasValue != null) {
						strAliasValue = AttributeExpression.resolve(strAliasValue, sysObject, strLoggedInUser);
						bIsCondition = QueryUtils.checkObjectConditionExpression(sysObject, strAliasValue, pSession);
						DfLogger.debug(this,"Is the condition " + strAliasValue +" for setting the attribute" + strArrKeyAttributeNames[index]  + " satisfied: " + bIsCondition,null,null);					
					}
					if(bIsCondition) {
						methodBeanResponse = setAttribute(strArrKeyAttributeNames[index],pSession,sysObject,locale);
						if(methodBeanResponse.getCode().equals(D2Method.RETURN_FATAL_STR)) {					
							DfLogger.error(this,"Error while setting attribute:" + strArrKeyAttributeNames[index] + " is " + methodBeanResponse.getMessage(),null,null);	
							bIsSetAttributeFailed = true;
							listFailedSetAttributes.add(strArrKeyAttributeNames[index]);
						}
					}
				} else if(strAliasValue != null && (sysObject.getTypeName().equalsIgnoreCase(strAliasValue) || sysObject.getType().getSuperName().equalsIgnoreCase(strAliasValue))) {					
					//Check the object_type mentioned for the setAttribute method, if the object_type matches then verify whether the condition satisfies, then CDFSetAttribute method will be called				
					strAliasValue = D2Dictionary.getAliasValue(STR_DIC_SET_ATTRIBUTES,strArrKeyAttributeNames[index] , STR_COL_NAME_IF, pSession, sysObject, strLoggedInUser, true, true);	
					if(strAliasValue != null) {
						strAliasValue = AttributeExpression.resolve(strAliasValue, sysObject, strLoggedInUser);
						bIsCondition = QueryUtils.checkObjectConditionExpression(sysObject, strAliasValue, pSession);
						DfLogger.debug(this,"Is the condition " + strAliasValue +" for setting the attribute" + strArrKeyAttributeNames[index]  + " satisfied: " + bIsCondition,null,null);					
					}							
					if(bIsCondition) {
						methodBeanResponse = setAttribute(strArrKeyAttributeNames[index],pSession,sysObject,locale);
						if(methodBeanResponse.getCode().equals(D2Method.RETURN_FATAL_STR)) {					
							DfLogger.error(this,"Error while setting attribute:" + strArrKeyAttributeNames[index] + " is " + methodBeanResponse.getMessage(),null,null);	
							bIsSetAttributeFailed = true;
							listFailedSetAttributes.add(strArrKeyAttributeNames[index]);
						}
					}					
				} else {
					DfLogger.debug(this,"Document's  object type :" + sysObject.getTypeName() +" does not match with " + strAliasValue + " Hence no property to be set",null,null);				
				}							
			}
			DfLogger.info(this,"************************************** execute() of SWYSetAttributeWrapper class Ended *****************************************************************",null,null);
			StringBuilder strBldMessage = new StringBuilder();			
			if (bIsSetAttributeFailed) {
				strBldMessage.append("Setting attribute(s) failed for: ");
				for(String strAttribute:listFailedSetAttributes) {
					strBldMessage.append(strAttribute);
					strBldMessage.append(",");
				}			
				DfLogger.info(this,"Error while setting attribute(s):" + strBldMessage.toString(),null,null);
				return new D2methodBean(D2Method.RETURN_FATAL_STR,strBldMessage.toString());			
			} 
			return new D2methodBean(D2Method.RETURN_SUCCESS_STR,null);			
		} catch (Exception ex) {
			DfLogger.error(this,"Error while setting attribute:" + ex.getMessage(),null,ex);
			throw new Exception("Error while setting attribute:" + ex.getMessage());	
		}	
	}

	/**
	 * Fetch alias values from the "CMN-DIC-Set Attributes" dictionary, 
	 * and call CDFSetAttributes method with the details of the attribute to be set
	 * @param pStrKey
	 * @param pSession
	 * @param pSysobj
	 * @param locale
	 */
	private D2methodBean setAttribute(String pStrKey, IDfSession pSession,IDfSysObject pSysobj,Locale locale) throws Exception {
		SetAttribute setAttrObj = new SetAttribute();
		DfLogger.info(this,"Attributes to be set for the specific object" + pStrKey,null,null);

		strAliasValue = SWY_IA_HELPER_OBJ.getAliasValueFromDictionary(STR_DIC_SET_ATTRIBUTES, pStrKey, STR_COL_NAME_TARGET, pSession);
		if (strAliasValue != null) {
			hmAliasNamesAliasValues.put(STR_ARG_NAME_TARGET, strAliasValue);
		}
		strAliasValue = SWY_IA_HELPER_OBJ.getAliasValueFromDictionary(STR_DIC_SET_ATTRIBUTES, pStrKey, STR_COL_NAME_ATTR, pSession);
		if (strAliasValue != null) {
			hmAliasNamesAliasValues.put(STR_ARG_NAME_ATTR, strAliasValue);
		}
		strAliasValue = SWY_IA_HELPER_OBJ.getAliasValueFromDictionary(STR_DIC_SET_ATTRIBUTES, pStrKey, STR_COL_NAME_VALUE, pSession);
		if(strAliasValue != null) {
			if(strAliasValue.equalsIgnoreCase(STR_BLANK_VALUE_IN_DICTIONARY)){
				strAliasValue = " "; 
			}			
			hmAliasNamesAliasValues.put(STR_ARG_NAME_VALUE, strAliasValue);
		}
		strAliasValue = SWY_IA_HELPER_OBJ.getAliasValueFromDictionary(STR_DIC_SET_ATTRIBUTES, pStrKey, STR_COL_NAME_APPEND, pSession);
		if (strAliasValue != null) {
			hmAliasNamesAliasValues.put(STR_ARG_NAME_APPEND, strAliasValue);
		}
		strAliasValue = SWY_IA_HELPER_OBJ.getAliasValueFromDictionary(STR_DIC_SET_ATTRIBUTES, pStrKey, STR_COL_NAME_IGNORE_NULL_VALUES, pSession);
		if (strAliasValue != null) {
			hmAliasNamesAliasValues.put(STR_ARG_NAME_IGNORE_NULL_VALUES, strAliasValue);
		}
		strAliasValue = SWY_IA_HELPER_OBJ.getAliasValueFromDictionary(STR_DIC_SET_ATTRIBUTES, pStrKey, STR_COL_NAME_DICTIONARY, pSession);
		if (strAliasValue != null) {
			hmAliasNamesAliasValues.put(STR_ARG_NAME_DICTIONARY, strAliasValue);
		}
		strAliasValue = SWY_IA_HELPER_OBJ.getAliasValueFromDictionary(STR_DIC_SET_ATTRIBUTES, pStrKey, STR_COL_NAME_ALIAS, pSession);
		if (strAliasValue != null) {
			hmAliasNamesAliasValues.put(STR_ARG_NAME_ALIAS, strAliasValue);
		}
		strAliasValue = SWY_IA_HELPER_OBJ.getAliasValueFromDictionary(STR_DIC_SET_ATTRIBUTES, pStrKey, STR_COL_NAME_APPLY_D2_CONFIGS, pSession);
		if (strAliasValue != null) {
			hmAliasNamesAliasValues.put(STR_ARG_NAME_APPLY_D2_CONFIGS, strAliasValue);
		}
		ArgumentParser argParserObj = new ArgumentParser(hmAliasNamesAliasValues);
		DfLogger.debug(this,"Argument parser object with the hashmap: " + argParserObj,null,null);
		try {
			return setAttrObj.execute(pSession, pSysobj, locale, argParserObj);
		} catch (Exception e) {
			DfLogger.error(this,"Unable to set attribute: " + pStrKey + ".Error message(if any) "+ e.getLocalizedMessage(),null, e);
			throw e;
		}		
	}	
}
