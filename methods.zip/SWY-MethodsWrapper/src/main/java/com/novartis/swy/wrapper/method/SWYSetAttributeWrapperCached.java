package com.novartis.swy.wrapper.method;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import com.documentum.cdf.methods.SetAttribute;
import com.documentum.d2.exceptions.ConfigurationException;
import com.documentum.d2.model.D2Dictionary;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfId;
import com.documentum.utils.AttributeExpression;
import com.documentum.utils.QueryUtils;
import com.documentum.utils.StringUtils;
import com.emc.common.java.utils.ArgumentParser;
import com.emc.d2.api.methods.D2Method;
import com.emc.d2.api.methods.D2methodBean;

public class SWYSetAttributeWrapperCached implements IActionWrapper {
	private static final String STR_DIC_SET_ATTRIBUTES = "CMN-DIC-Set Attributes";

	private static String STR_COL_NAME_OBJECT_TYPE = "object_type";
	private static String STR_COL_NAME_IF ="if";
	private static String STR_COL_NAME_TARGET = "target";
	private static String STR_COL_NAME_ATTR = "attr";
	private static String STR_COL_NAME_VALUE = "value";
	private static String STR_COL_NAME_APPEND = "append";
	private static String STR_COL_NAME_IGNORE_NULL_VALUES = "ignore_null_values";
	private static String STR_COL_NAME_DICTIONARY = "dictionary";	
	private static String STR_COL_NAME_APPLY_D2_CONFIGS = "apply_d2_configs";
	private static String STR_COL_NAME_ALIAS = "alias";
	private static String STR_BLANK_VALUE_IN_DICTIONARY = "Blank";
	private static String STR_BLANK_VALUE_IN_ARGS = " ";
	
	private static String STR_ARG_NAME_TARGET = SetAttribute.ARG_TARGET_OBJECT_QUERY;//"-target";
	private static String STR_ARG_NAME_ATTR = SetAttribute.ARG_ATTR;//"-attr";
	private static String STR_ARG_NAME_VALUE = SetAttribute.ARG_VALUE;//"-value";
	private static String STR_ARG_NAME_APPEND = SetAttribute.ARG_APPEND;//"-append";
	private static String STR_ARG_NAME_IGNORE_NULL_VALUES = SetAttribute.ARG_IGNORE_NULL_VALUES;//"-ignore_null_values";
	private static String STR_ARG_NAME_DICTIONARY = SetAttribute.ARG_DICTIONARY;//"-dictionary";	
	private static String STR_ARG_NAME_APPLY_D2_CONFIGS = SetAttribute.ARG_APPLY_D2_CONFIGS;//"-apply_d2_configs";
	private static String STR_ARG_NAME_ALIAS = SetAttribute.ARG_ALIAS;//"-alias";
	
	private static Map<String, String> objectTypes = null;
	private static Map<String, String> ifs = null;
	private static Map<String, Map<String, String>> setAttributesDictCached = null;
	
	private synchronized void initializeCaches(IDfSession pSession, IDfSysObject sysObject)
			throws DfException, ConfigurationException {
		D2Dictionary setAttributeDictionary = D2Dictionary.getDictionary(STR_DIC_SET_ATTRIBUTES, pSession, sysObject,
				pSession.getLoginUserName(), true, true);
		
		objectTypes = Collections.unmodifiableMap(setAttributeDictionary.getKeyToAliasValueMap(STR_COL_NAME_OBJECT_TYPE));
		ifs = Collections.unmodifiableMap(setAttributeDictionary.getKeyToAliasValueMap(STR_COL_NAME_IF));
		
		
		Map<String, String> targets = setAttributeDictionary.getKeyToAliasValueMap(STR_COL_NAME_TARGET);
		Map<String, String> attrs = setAttributeDictionary.getKeyToAliasValueMap(STR_COL_NAME_ATTR);
		Map<String, String> values = setAttributeDictionary.getKeyToAliasValueMap(STR_COL_NAME_VALUE);
		Map<String, String> appends = setAttributeDictionary.getKeyToAliasValueMap(STR_COL_NAME_APPEND);
		Map<String, String> ignoreNullValues = setAttributeDictionary.getKeyToAliasValueMap(STR_COL_NAME_IGNORE_NULL_VALUES);
		Map<String, String> dictionaries = setAttributeDictionary.getKeyToAliasValueMap(STR_COL_NAME_DICTIONARY);
		Map<String, String> applyD2Configs = setAttributeDictionary.getKeyToAliasValueMap(STR_COL_NAME_APPLY_D2_CONFIGS);
		Map<String, String> aliases = setAttributeDictionary.getKeyToAliasValueMap(STR_COL_NAME_ALIAS);
		Map<String, Map<String, String>> crArgumentParserCachedVals= new HashMap<String, Map<String,String>>(); 
		
		String[] keys = setAttributeDictionary.getKeys();
		for(int i =0; i < keys.length; i++) {
			Map<String, String> parseArgs = new HashMap<String, String>();
			String key = keys[i];
			parseArgs.put(STR_ARG_NAME_TARGET, targets.get(key));
			parseArgs.put(STR_ARG_NAME_ATTR, attrs.get(key));
			
			String parsedValue = values.get(key); 
			if(STR_BLANK_VALUE_IN_DICTIONARY.contentEquals(parsedValue)) {
				parsedValue = STR_BLANK_VALUE_IN_ARGS;
			}
			parseArgs.put(STR_ARG_NAME_VALUE, parsedValue);
			
			parseArgs.put(STR_ARG_NAME_APPEND, appends.get(key));
			parseArgs.put(STR_ARG_NAME_IGNORE_NULL_VALUES, ignoreNullValues.get(key));
			parseArgs.put(STR_ARG_NAME_DICTIONARY, dictionaries.get(key));
			parseArgs.put(STR_ARG_NAME_APPLY_D2_CONFIGS, applyD2Configs.get(key));
			parseArgs.put(STR_ARG_NAME_ALIAS, aliases.get(key));

			crArgumentParserCachedVals.put(key, Collections.unmodifiableMap(parseArgs));
		}
		setAttributesDictCached = Collections.unmodifiableMap(crArgumentParserCachedVals);
		
	}
	

	/**
	 * Method to fetch the arguments from dictionary , and calls CDFSetAttribute method if the condition satisfies
	 * @param pSession
	 * @param sysObject
	 * @param pStrActionKey
	 * @param locale
	 * @param argumentParser
	 * @return
	 * @throws Exception
	 */
	public D2methodBean execute(IDfSession pSession, IDfId pObjectId,IDfSysObject pSysObject, String pStrActionKey,Locale locale, ArgumentParser argumentParser) throws Exception {
		DfLogger.info(this,"************************************** execute() of SWYSetAttributeWrapperCached class started ********************************",null,null);
		boolean bIsCondition = true;
		boolean bIsSetAttributeFailed = false;
		List<String> listFailedSetAttributes = new ArrayList<String>();		
		String strLoggedInUser = pSession.getLoginUserName();
		D2methodBean methodBeanResponse = null;

		
		//Set Standard Arguments in the HasMap
		IDfSysObject sysObject = (IDfSysObject)pSession.getObject(pObjectId);
		Map<String, String> parserArguments = new SWYInitializeArtifactHelper().addStdArgumentsToHashMap(pSession, pObjectId, sysObject);		
		DfLogger.info(this,"Hashmap after initializing standard arguments:" + parserArguments + " and attributes to be set in the lifecycle and state: " + pStrActionKey,null,null);

		if(objectTypes==null || ifs == null || setAttributesDictCached == null) {
			initializeCaches(pSession,sysObject);
		}
		String strAliasValue = null;
		try {
			//Call CDFSetAttribute() method based on the condition fetched from ArgumentParser		
			String[] strArrKeyAttributeNames = pStrActionKey.split(",");
			for(int index=0; index<strArrKeyAttributeNames.length;index++) {
				String attributeName = strArrKeyAttributeNames[index];
				DfLogger.debug(this,"Set Attributes Dictionary Key Name:" + attributeName,null,null);
				strAliasValue = objectTypes.get(attributeName);

				DfLogger.error(this,"Alias value is: [" + strAliasValue + "]",null,null);
				if(StringUtils.isNullOrEmpty(strAliasValue)) {
					//Check the condition mentioned for the setAttribute method, if the if condition satisfies, the CDFSetAttribute method will be called					    
					strAliasValue = ifs.get(attributeName);
					if(strAliasValue != null) {
						strAliasValue = AttributeExpression.resolve(strAliasValue, sysObject, strLoggedInUser);
						bIsCondition = QueryUtils.checkObjectConditionExpression(sysObject, strAliasValue, pSession);
						DfLogger.debug(this,"Is the condition " + strAliasValue +" for setting the attribute" + attributeName + " satisfied: " + bIsCondition,null,null);					
					}
					if(bIsCondition) {
						methodBeanResponse = setAttribute(attributeName,pSession,sysObject, parserArguments, locale);
						if(methodBeanResponse.getCode().equals(D2Method.RETURN_FATAL_STR)) {					
							DfLogger.error(this,"Error while setting attribute:" + attributeName + " is " + methodBeanResponse.getMessage(),null,null);	
							bIsSetAttributeFailed = true;
							listFailedSetAttributes.add(attributeName);
						}
					}
				} else if(strAliasValue != null && (sysObject.getTypeName().equalsIgnoreCase(strAliasValue) || sysObject.getType().getSuperName().equalsIgnoreCase(strAliasValue))) {					
					//Check the object_type mentioned for the setAttribute method, if the object_type matches then verify whether the condition satisfies, then CDFSetAttribute method will be called				
					strAliasValue = ifs.get(attributeName);

					if (strAliasValue != null) {
						strAliasValue = AttributeExpression.resolve(strAliasValue, sysObject, strLoggedInUser);
						bIsCondition = QueryUtils.checkObjectConditionExpression(sysObject, strAliasValue, pSession);
						DfLogger.debug(this,"Is the condition " + strAliasValue +" for setting the attribute" + attributeName  + " satisfied: " + bIsCondition,null,null);					
					}							
					if(bIsCondition) {
						methodBeanResponse = setAttribute(attributeName,pSession,sysObject, parserArguments, locale);
						if(methodBeanResponse.getCode().equals(D2Method.RETURN_FATAL_STR)) {					
							DfLogger.error(this,"Error while setting attribute:" + attributeName + " is " + methodBeanResponse.getMessage(),null,null);	
							bIsSetAttributeFailed = true;
							listFailedSetAttributes.add(attributeName);
						}
					}					
				} else {
					DfLogger.debug(this,"Document's  object type :" + sysObject.getTypeName() +" does not match with " + strAliasValue + " Hence no property to be set",null,null);				
				}							
			}
			DfLogger.info(this,"************************************** execute() of SWYSetAttributeWrapperCached class Ended *****************************************************************",null,null);
			StringBuilder strBldMessage = new StringBuilder();			
			if (bIsSetAttributeFailed) {
				strBldMessage.append("Setting attribute(s) failed for: ");
				for(String strAttribute:listFailedSetAttributes) {
					strBldMessage.append(strAttribute);
					strBldMessage.append(",");
				}			
				DfLogger.info(this,"Error while setting attribute(s):" + strBldMessage.toString(),null,null);
				return new D2methodBean(D2Method.RETURN_FATAL_STR,strBldMessage.toString());			
			} 
			return new D2methodBean(D2Method.RETURN_SUCCESS_STR,null);			
		} catch (Exception ex) {
			String errMsg = "Error while setting attribute:" + ex.getMessage();
			DfLogger.error(this,errMsg,null,ex);
			throw new Exception(errMsg);	
		}	
	}

	/**
	 * Fetch alias values from the "CMN-DIC-Set Attributes" dictionary, 
	 * and call CDFSetAttributes method with the details of the attribute to be set
	 * @param pStrKey
	 * @param pSession
	 * @param pSysobj
	 * @param locale
	 */
	private D2methodBean setAttribute(String pStrKey, IDfSession pSession,IDfSysObject pSysobj, Map<String, String> parserArguments, Locale locale) throws Exception {
		SetAttribute setAttrObj = new SetAttribute();
		DfLogger.info(this,"Attributes to be set for the specific object" + pStrKey,null,null);
		parserArguments.putAll(setAttributesDictCached.get(pStrKey));
		ArgumentParser argParserObj = new ArgumentParser(parserArguments);
		DfLogger.debug(this,"Argument parser object with the hashmap: " + argParserObj,null,null);
		try {
			return setAttrObj.execute(pSession, pSysobj, locale, argParserObj);
		} catch (Exception e) {
			DfLogger.error(this,"Unable to set attribute: " + pStrKey + ".Error message(if any) "+ e.getLocalizedMessage(),null, e);
			throw e;
		}		
	}	
}
