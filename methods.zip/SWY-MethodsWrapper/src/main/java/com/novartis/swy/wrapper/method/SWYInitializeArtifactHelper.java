package com.novartis.swy.wrapper.method;

import java.util.HashMap;
import java.util.Map;

import com.documentum.d2.exceptions.ConfigurationException;
import com.documentum.d2.model.D2Dictionary;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfId;

public class SWYInitializeArtifactHelper {

	private Map<String, String> hmArgNameArgValue = new HashMap<String, String>();
	private String strObjId = null;

	/**
	 * Initialize the map with standard method arguments
	 * @param pSession
	 * @param pObjectId
	 * @param pSysObject
	 * @return
	 */	
	public Map<String, String> addStdArgumentsToHashMap(IDfSession pSession, IDfId pObjectId,IDfSysObject pSysObject) throws DfException{
		try {
			strObjId = pObjectId.getId();
			hmArgNameArgValue.put("-id",strObjId);
			hmArgNameArgValue.put("-docbase_name", pSession.getDocbaseName());
			hmArgNameArgValue.put("-user_name", pSession.getServerConfig().getString("r_install_owner"));
			hmArgNameArgValue.put("-method_return_id", pSysObject.getObjectId().getId());
		} 	 catch (DfException e) {
			DfLogger.error(this,"Exception while adding standard arguments to Hashmap: "+e.getLocalizedMessage(),null, e);
			throw new DfException("Unable to add arguments to hashmap: " + e.getMessage() );
		}
		return hmArgNameArgValue;
	}

	public String getAliasValueFromDictionary(String pStrDictionaryName,String pStrKey,String pstrAliasName,IDfSession pSession) {
		String strAliasValue = null;
		try {
			IDfSysObject sysObj = (IDfSysObject)pSession.getObject(new DfId(strObjId));
			strAliasValue = D2Dictionary.getAliasValue(pStrDictionaryName, pStrKey, pstrAliasName, pSession,sysObj, pSession.getLoginUserName(), true, true);
		} catch (DfException | ConfigurationException e) {
			DfLogger.error(this,"Unable to fetch alias value for " + pStrKey + " key."+e.getLocalizedMessage(),null, e);
		}
		return strAliasValue;
	}
}
