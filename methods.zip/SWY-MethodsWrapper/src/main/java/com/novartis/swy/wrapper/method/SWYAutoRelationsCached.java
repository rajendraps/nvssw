package com.novartis.swy.wrapper.method;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import com.documentum.cdf.methods.CreateRelation;
import com.documentum.d2.exceptions.ConfigurationException;
import com.documentum.d2.model.D2Dictionary;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfId;
import com.documentum.utils.QueryUtils;
import com.emc.common.java.utils.ArgumentParser;
import com.emc.d2.api.methods.D2Method;
import com.emc.d2.api.methods.D2methodBean;

public class SWYAutoRelationsCached implements IActionWrapper {
	private static final String STR_DIC_AUTO_RELATIONS = "CMN-DIC-Auto Relations";
	private static String STR_COL_NAME_OBJECT_TYPE = "Object Type";
	private static String STR_COL_NAME_CONDITION = "Condition";
	private static String STR_COL_NAME_RELATION_TYPE = "Relation Type";
	private static String STR_COL_NAME_PARENT = "Parent";
	private static String STR_COL_NAME_TARGETS = "Targets";
	private static String STR_COL_NAME_PERMANENT_LINK = "Permanent Link";
	private static String STR_COL_NAME_CHILD_VERSION = "Child Version";
	private static String STR_COL_NAME_RESET_RELATION = "Reset Relations";

	private static String STR_ARG_NAME_RELATION_TYPE = CreateRelation.ARG_RELATION_TYPE; //"-relation_type";
	private static String STR_ARG_NAME_PARENT = CreateRelation.ARG_PARENT;//"-parent";
	private static String STR_ARG_NAME_TARGETS = CreateRelation.ARG_TARGET_OBJECT_QUERY;//"-target_objects";
	private static String STR_ARG_NAME_PERMANENT_LINK = CreateRelation.ARG_PERMANENT_LINK;//"-permanent_link";
	private static String STR_ARG_NAME_CHILD_VERSION = CreateRelation.ARG_CHILD_VERSION;//"-child_version";
	private static String STR_ARG_NAME_RESET_RELATION = CreateRelation.ARG_RESET_EXISTING_RELATIONS;//"-reset_relations";	
	
	private static Map<String, Map<String, String>> autoRelationDictCached = null;
	private static Map<String, String> objectTypes = null;
	private static Map<String, String> conditions = null;
	
	/**
	 * Method to fetch the arguments from dictionary , and calls create relation
	 * method if the condition satisfies
	 * 
	 * @param pSession
	 * @param sysObject
	 * @param pStrRelationNames
	 * @param locale
	 * @param argumentParser
	 * @return
	 * @throws Exception
	 */
	public D2methodBean execute(IDfSession pSession, IDfId pObjectId, IDfSysObject pSysObject, String pStrRelationNames,
			Locale locale, ArgumentParser argumentParser) throws Exception {
		DfLogger.info(this,
				"************************************** execute() of SWYAutoRelationsCached class started ********************************",
				null, null);
		boolean bIsCondition = true;
		boolean bIsCreateRelationFailed = false;
		D2methodBean methodBeanResponse = null;
		List<String> listFailedRelationNames = new ArrayList<String>();

		// Set Standard Arguments in the HasMap
		IDfSysObject sysObject = (IDfSysObject) pSession.getObject(pObjectId);
		Map<String, String> parserArguments = new SWYInitializeArtifactHelper().addStdArgumentsToHashMap(pSession, pObjectId, pSysObject);
		DfLogger.info(this,
				"Hashmap after initializing standard arguments:" + parserArguments
						+ " and relation names applicable for the lifecycle and state: " + pStrRelationNames,
				null, null);

		if (autoRelationDictCached == null || objectTypes == null || conditions == null) {
			initializeCaches(pSession, sysObject);
		}
		String strAliasValue = null;
		try {
			// Call createRelation() method based on the condition fetched from
			// ArgumentParser
			String[] strArrKeyRelationNames = pStrRelationNames.split(",");

			for (int index = 0; index < strArrKeyRelationNames.length; index++) {
				String relationName = strArrKeyRelationNames[index];
				DfLogger.debug(this, "Auto relation Dictionary Key Name:" + relationName
						+ " Object Type of the document:" + sysObject.getTypeName(), null, null);
				strAliasValue = objectTypes.get(relationName);

				// Check the object type of the document, to verify object type specific
				// relations
				if (strAliasValue.equals(sysObject.getTypeName())) {
					strAliasValue = conditions.get(relationName);
					if (strAliasValue != null) {
						bIsCondition = QueryUtils.checkObjectConditionExpression(sysObject, strAliasValue, pSession);
						DfLogger.debug(this, "Is the condition  " + strAliasValue + " for creating the relation "
								+ relationName + " satisfied: " + bIsCondition, null, null);
					}
					if (bIsCondition) {
						methodBeanResponse = createRelation(relationName, pSession, pSysObject, parserArguments, locale);
						if (methodBeanResponse.getCode().equals(D2Method.RETURN_FATAL_STR)) {
							DfLogger.error(this, "Error while creating relation:" + relationName + " is "
									+ methodBeanResponse.getMessage(), null, null);
							bIsCreateRelationFailed = true;
							listFailedRelationNames.add(relationName);
						}
					}
				}
			}
			DfLogger.info(this,
					"************************************** execute() of SWYAutoRelationsCached class Ended *****************************************************************",
					null, null);
			StringBuilder strBldMessage = new StringBuilder();
			if (bIsCreateRelationFailed) {
				strBldMessage.append("Create Relation failed for: ");
				for (String relation : listFailedRelationNames) {
					strBldMessage.append(relation);
					strBldMessage.append(",");
				}
				DfLogger.info(this, "Error while creating relation(s):" + strBldMessage.toString(), null, null);
				return new D2methodBean(D2Method.RETURN_FATAL_STR, strBldMessage.toString());
			}
			return new D2methodBean(D2Method.RETURN_SUCCESS_STR, null);
		} catch (Exception ex) {
			DfLogger.error(this, "Error while creating relation:" + ex.getMessage(), null, ex);
			throw new Exception("Error while creating relation:" + ex.getMessage());
		}
	}

	/**
	 * Fetch alias values from the "CMN-DIC Auto Relations" dictionary, and call
	 * CDFCreateRelations method with the details of the relations to be created for
	 * specific type
	 * 
	 * @param pStrKey
	 * @param pSession
	 * @param pSysobj
	 * @param locale
	 */
	private D2methodBean createRelation(String pStrKey, IDfSession pSession, IDfSysObject pSysobj, Map<String, String> parserArguments, Locale locale)
			throws Exception {
		CreateRelation createRelnObj = new CreateRelation();
		DfLogger.info(this, "Relation to be created for the specific object type:" + pStrKey, null, null);
		parserArguments.putAll(autoRelationDictCached.get(pStrKey)); 
		ArgumentParser argParserObj = new ArgumentParser(parserArguments);
		
		DfLogger.debug(this, "Argument parser object with the hashmap: " + argParserObj, null, null);
		try {
			return createRelnObj.execute(pSession, pSysobj, locale, argParserObj);
		} catch (Exception e) {
			DfLogger.error(this,
					"Unable to create relation " + pStrKey + ".Error message(if any) " + e.getLocalizedMessage(), null,
					e);
			throw e;
		}
	}

	private synchronized void initializeCaches(IDfSession pSession, IDfSysObject sysObject)
			throws DfException, ConfigurationException {
		D2Dictionary autoRelationsDictionary = D2Dictionary.getDictionary(STR_DIC_AUTO_RELATIONS, pSession, sysObject,
				pSession.getLoginUserName(), true, true);
		
		objectTypes = Collections.unmodifiableMap(autoRelationsDictionary.getKeyToAliasValueMap(STR_COL_NAME_OBJECT_TYPE));
		conditions = Collections.unmodifiableMap(autoRelationsDictionary.getKeyToAliasValueMap(STR_COL_NAME_CONDITION));

		Map<String, String> relTypes = autoRelationsDictionary.getKeyToAliasValueMap(STR_COL_NAME_RELATION_TYPE);
		Map<String, String> parents = autoRelationsDictionary.getKeyToAliasValueMap(STR_COL_NAME_PARENT);
		Map<String, String> targets = autoRelationsDictionary.getKeyToAliasValueMap(STR_COL_NAME_TARGETS);
		Map<String, String> permLinks = autoRelationsDictionary.getKeyToAliasValueMap(STR_COL_NAME_PERMANENT_LINK);
		Map<String, String> childVersions = autoRelationsDictionary.getKeyToAliasValueMap(STR_COL_NAME_CHILD_VERSION);
		Map<String, String> resetRelations = autoRelationsDictionary.getKeyToAliasValueMap(STR_COL_NAME_RESET_RELATION);
		Map<String, Map<String, String>> crArgumentParserCachedVals= new HashMap<String, Map<String,String>>(); 
		
		String[] keys = autoRelationsDictionary.getKeys();
		for(int i =0; i < keys.length; i++) {
			Map<String, String> parseArgs = new HashMap<String, String>();
			String key = keys[i];
			parseArgs.put(STR_ARG_NAME_RELATION_TYPE, relTypes.get(key));
			parseArgs.put(STR_ARG_NAME_PARENT, parents.get(key));
			parseArgs.put(STR_ARG_NAME_TARGETS, targets.get(key));
			parseArgs.put(STR_ARG_NAME_PERMANENT_LINK, permLinks.get(key));
			parseArgs.put(STR_ARG_NAME_CHILD_VERSION, childVersions.get(key));
			parseArgs.put(STR_ARG_NAME_RESET_RELATION, resetRelations.get(key));
			crArgumentParserCachedVals.put(key, Collections.unmodifiableMap(parseArgs));
		}
		autoRelationDictCached = Collections.unmodifiableMap(crArgumentParserCachedVals);
	}

}
