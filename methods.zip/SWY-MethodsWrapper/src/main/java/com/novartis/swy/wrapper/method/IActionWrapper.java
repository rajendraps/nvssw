package com.novartis.swy.wrapper.method;

import java.util.Locale;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.IDfId;
import com.emc.common.java.utils.ArgumentParser;
import com.emc.d2.api.methods.D2methodBean;

public abstract interface IActionWrapper {
	
	public abstract D2methodBean execute(IDfSession pSession, IDfId pObjectId,IDfSysObject pSysObject, String pStrActionValue,Locale locale, ArgumentParser argumentParser) throws Exception;
}
