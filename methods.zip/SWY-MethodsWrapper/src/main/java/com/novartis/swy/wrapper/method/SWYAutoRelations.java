package com.novartis.swy.wrapper.method;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import com.documentum.cdf.methods.CreateRelation;
import com.documentum.d2.model.D2Dictionary;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfId;
import com.documentum.utils.QueryUtils;
import com.emc.common.java.utils.ArgumentParser;
import com.emc.d2.api.methods.D2Method;
import com.emc.d2.api.methods.D2methodBean;

public class SWYAutoRelations implements IActionWrapper {
	private static final String STR_DIC_AUTO_RELATIONS = "CMN-DIC-Auto Relations";
	private String strAliasValue = null;
	private SWYInitializeArtifactHelper SWY_IA_HELPER_OBJ = new SWYInitializeArtifactHelper();
	private Map<String, String> hmAliasNamesAliasValues = null;
	private static String STR_COL_NAME_OBJECT_TYPE = "Object Type";
	private static String STR_COL_NAME_CONDITION = "Condition";	
	private static String STR_COL_NAME_RELATION_TYPE = "Relation Type";
	private static String STR_COL_NAME_PARENT = "Parent";
	private static String STR_COL_NAME_TARGETS = "Targets";
	private static String STR_COL_NAME_PERMANENT_LINK = "Permanent Link";
	private static String STR_COL_NAME_CHILD_VERSION = "Child Version";
	private static String STR_COL_NAME_RESET_RELATION = "Reset Relations";
	private static String STR_ARG_NAME_RELATION_TYPE = "-relation_type";
	private static String STR_ARG_NAME_PARENT = "-parent";
	private static String STR_ARG_NAME_TARGETS = "-target_objects";
	private static String STR_ARG_NAME_PERMANENT_LINK = "-permanent_link";
	private static String STR_ARG_NAME_CHILD_VERSION = "-child_version";
	private static String STR_ARG_NAME_RESET_RELATION = "-reset_relations";	

	/**
	 * Method to fetch the arguments from dictionary , and calls create relation method if the condition satisfies
	 * @param pSession
	 * @param sysObject
	 * @param pStrRelationNames
	 * @param locale
	 * @param argumentParser
	 * @return
	 * @throws Exception
	 */
	public D2methodBean execute(IDfSession pSession, IDfId pObjectId,IDfSysObject pSysObject, String pStrRelationNames,Locale locale, ArgumentParser argumentParser) throws Exception {
		DfLogger.info(this,"************************************** execute() of SWYAutoRelations class started ********************************",null,null);
		boolean bIsCondition = true;
		boolean bIsCreateRelationFailed = false;
		D2methodBean methodBeanResponse = null;
		List<String> listFailedRelationNames = new ArrayList<String>();
		
		//Set Standard Arguments in the HasMap
		IDfSysObject sysObject = (IDfSysObject)pSession.getObject(pObjectId);
		hmAliasNamesAliasValues = SWY_IA_HELPER_OBJ.addStdArgumentsToHashMap(pSession, pObjectId, pSysObject);		
		DfLogger.info(this,"Hashmap after initializing standard arguments:" + hmAliasNamesAliasValues + " and relation names applicable for the lifecycle and state: " + pStrRelationNames,null,null);
	
		try {
			//Call createRelation() method based on the condition fetched from ArgumentParser		
			String[] strArrKeyRelationNames = pStrRelationNames.split(",");
			for(int index=0; index<strArrKeyRelationNames.length;index++) {
				DfLogger.debug(this,"Auto relation Dictionary Key Name:" + strArrKeyRelationNames[index] + " Object Type of the document:" + sysObject.getTypeName(),null,null);
				strAliasValue = D2Dictionary.getAliasValue(STR_DIC_AUTO_RELATIONS,strArrKeyRelationNames[index] , STR_COL_NAME_OBJECT_TYPE, pSession, sysObject, pSession.getLoginUserName(), true, true);
				
				//Check the object type of the document, to verify object type specific relations
				if(strAliasValue.equals(sysObject.getTypeName())) {
					strAliasValue = D2Dictionary.getAliasValue(STR_DIC_AUTO_RELATIONS,strArrKeyRelationNames[index] , STR_COL_NAME_CONDITION, pSession, sysObject, pSession.getLoginUserName(), true, true);
					if(strAliasValue != null) {
						bIsCondition = QueryUtils.checkObjectConditionExpression(sysObject, strAliasValue, pSession);
						DfLogger.debug(this,"Is the condition  " + strAliasValue +" for creating the relation " + strArrKeyRelationNames[index]  + " satisfied: " + bIsCondition,null,null);
					}	
					if(bIsCondition) {
						methodBeanResponse = createRelation(strArrKeyRelationNames[index],pSession,pSysObject,locale);
						if(methodBeanResponse.getCode().equals(D2Method.RETURN_FATAL_STR)) {					
							DfLogger.error(this,"Error while creating relation:" + strArrKeyRelationNames[index] + " is " + methodBeanResponse.getMessage(),null,null);	
							bIsCreateRelationFailed = true;
							listFailedRelationNames.add(strArrKeyRelationNames[index]);
						}
					}
				}			
			}
			DfLogger.info(this,"************************************** execute() of SWYAutoRelations class Ended *****************************************************************",null,null);
			StringBuilder strBldMessage = new StringBuilder();			
			if (bIsCreateRelationFailed) {
				strBldMessage.append("Create Relation failed for: ");
				for(String relation:listFailedRelationNames) {
					strBldMessage.append(relation);
					strBldMessage.append(",");
				}			
				DfLogger.info(this,"Error while creating relation(s):" + strBldMessage.toString(),null,null);
				return new D2methodBean(D2Method.RETURN_FATAL_STR,strBldMessage.toString());			
			} 
			return new D2methodBean(D2Method.RETURN_SUCCESS_STR,null);			
		} catch (Exception ex) {
			DfLogger.error(this,"Error while creating relation:" + ex.getMessage(),null,ex);
			throw new Exception("Error while creating relation:" + ex.getMessage());			
		}		
	}

	/**
	 * Fetch alias values from the "CMN-DIC Auto Relations" dictionary, 
	 * and call CDFCreateRelations method with the details of the relations to be created for specific type
	 * @param pStrKey
	 * @param pSession
	 * @param pSysobj
	 * @param locale
	 */
	private D2methodBean createRelation(String pStrKey, IDfSession pSession,IDfSysObject pSysobj,Locale locale) throws Exception{
		CreateRelation createRelnObj = new CreateRelation();
		DfLogger.info(this,"Relation to be created for the specific object type:" + pStrKey,null,null);
		strAliasValue = SWY_IA_HELPER_OBJ.getAliasValueFromDictionary(STR_DIC_AUTO_RELATIONS, pStrKey, STR_COL_NAME_RELATION_TYPE, pSession);
		if (strAliasValue != null) {
			hmAliasNamesAliasValues.put(STR_ARG_NAME_RELATION_TYPE, strAliasValue);
		}
		strAliasValue = SWY_IA_HELPER_OBJ.getAliasValueFromDictionary(STR_DIC_AUTO_RELATIONS, pStrKey, STR_COL_NAME_PARENT, pSession);
		if (strAliasValue != null) {
			hmAliasNamesAliasValues.put(STR_ARG_NAME_PARENT, strAliasValue);
		}
		strAliasValue = SWY_IA_HELPER_OBJ.getAliasValueFromDictionary(STR_DIC_AUTO_RELATIONS, pStrKey, STR_COL_NAME_TARGETS, pSession);
		if(strAliasValue != null) {
			hmAliasNamesAliasValues.put(STR_ARG_NAME_TARGETS, strAliasValue);
		}
		strAliasValue = SWY_IA_HELPER_OBJ.getAliasValueFromDictionary(STR_DIC_AUTO_RELATIONS, pStrKey, STR_COL_NAME_PERMANENT_LINK, pSession);
		if (strAliasValue != null) {
			hmAliasNamesAliasValues.put(STR_ARG_NAME_PERMANENT_LINK, strAliasValue);
		}
		strAliasValue = SWY_IA_HELPER_OBJ.getAliasValueFromDictionary(STR_DIC_AUTO_RELATIONS, pStrKey, STR_COL_NAME_CHILD_VERSION, pSession);
		if (strAliasValue != null) {
			hmAliasNamesAliasValues.put(STR_ARG_NAME_CHILD_VERSION, strAliasValue);
		}
		strAliasValue = SWY_IA_HELPER_OBJ.getAliasValueFromDictionary(STR_DIC_AUTO_RELATIONS, pStrKey, STR_COL_NAME_RESET_RELATION, pSession);
		if (strAliasValue != null) {
			hmAliasNamesAliasValues.put(STR_ARG_NAME_RESET_RELATION, strAliasValue);
		}
		ArgumentParser argParserObj = new ArgumentParser(hmAliasNamesAliasValues);
		DfLogger.debug(this,"Argument parser object with the hashmap: " + argParserObj,null,null);
		try {
			return createRelnObj.execute(pSession, pSysobj, locale, argParserObj);
		} catch (Exception e) {
			DfLogger.error(this,"Unable to create relation " + pStrKey + ".Error message(if any) "+ e.getLocalizedMessage(),null, e);
			throw e;
		}		
	}	
}
