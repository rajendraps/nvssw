package com.novartis.swy.wrapper.method;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import com.documentum.cdf.methods.UpdateAttrsViaQuery;
import com.documentum.d2.exceptions.ConfigurationException;
import com.documentum.d2.model.D2Dictionary;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfId;
import com.documentum.utils.AttributeExpression;
import com.documentum.utils.QueryUtils;
import com.emc.common.java.utils.ArgumentParser;
import com.emc.d2.api.methods.D2Method;
import com.emc.d2.api.methods.D2methodBean;

public class SWYUpdateAttributeViaQueryWrapperCached implements IActionWrapper {
	private static final String STR_DIC_UPDATE_ATTR_VIA_QUERY = "CMN-DIC-Update Attrs Via Query";

	private static String STR_COL_NAME_OBJECT_TYPE = "object_type";
	private static String STR_COL_NAME_IF = "if";
	private static String STR_COL_NAME_QUERY = "query";
	private static String STR_COL_NAME_OVERRIDE = "override";
	private static String STR_COL_NAME_ALL_ROWS = "all_rows";
	private static String STR_COL_NAME_TRUNCATE = "truncate";
	private static String STR_COL_NAME_IGNORE_NULL_VALUES = "ignore_null_values";
	private static String STR_COL_NAME_IGNORE_DUPL_VALUES = "ignore_duplicate_values";
	private static String STR_COL_NAME_IF_NO_ROWS_RESET = "if_no_rows_reset";

	private static String STR_ARG_NAME_QUERY = UpdateAttrsViaQuery.ARG_QUERY;// "-query";
	private static String STR_ARG_NAME_OVERRIDE = UpdateAttrsViaQuery.ARG_OVERRIDE;// "-override";
	private static String STR_ARG_NAME_ALL_ROWS = UpdateAttrsViaQuery.ARG_ALL_ROWS;// "-all_rows";
	private static String STR_ARG_NAME_TRUNCATE = UpdateAttrsViaQuery.ARG_TRUNCATE;// "-truncate";
	private static String STR_ARG_NAME_IGNORE_NULL_VALUES = UpdateAttrsViaQuery.ARG_IGNORE_NULL_VALUES;// "-ignore_null_values";
	private static String STR_ARG_NAME_IGNORE_DUPL_VALUES = UpdateAttrsViaQuery.ARG_IGNORE_DUPLICATE_VALUES;// "-ignore_duplicate_values";
	private static String STR_ARG_NAME_IF_NO_ROWS_RESET = UpdateAttrsViaQuery.ARG_IF_NO_ROWS_RESET;// "-if_no_rows_reset";

	private static Map<String, String> objectTypes = null;
	private static Map<String, String> ifs = null;
	private static Map<String, Map<String, String>> updateAttrsViaDqlDictCached = null;

	private synchronized void initializeCaches(IDfSession pSession, IDfSysObject sysObject)
			throws DfException, ConfigurationException {
		
		D2Dictionary updateAttrsViaDqlDictionary = D2Dictionary.getDictionary(STR_DIC_UPDATE_ATTR_VIA_QUERY, pSession,
				sysObject, pSession.getLoginUserName(), true, true);
		
		objectTypes = Collections
				.unmodifiableMap(updateAttrsViaDqlDictionary.getKeyToAliasValueMap(STR_COL_NAME_OBJECT_TYPE));
		ifs = Collections.unmodifiableMap(updateAttrsViaDqlDictionary.getKeyToAliasValueMap(STR_COL_NAME_IF));
		
		Map<String, String> queries = updateAttrsViaDqlDictionary.getKeyToAliasValueMap(STR_COL_NAME_QUERY);
		Map<String, String> overrides = updateAttrsViaDqlDictionary.getKeyToAliasValueMap(STR_COL_NAME_OVERRIDE);
		Map<String, String> allRows = updateAttrsViaDqlDictionary.getKeyToAliasValueMap(STR_COL_NAME_ALL_ROWS);
		Map<String, String> truncates = updateAttrsViaDqlDictionary.getKeyToAliasValueMap(STR_COL_NAME_TRUNCATE);
		Map<String, String> ignoreNullValues = updateAttrsViaDqlDictionary
				.getKeyToAliasValueMap(STR_COL_NAME_IGNORE_NULL_VALUES);
		Map<String, String> ignoreDuplicateValues = updateAttrsViaDqlDictionary
				.getKeyToAliasValueMap(STR_COL_NAME_IGNORE_DUPL_VALUES);
		Map<String, String> noRowsResets = updateAttrsViaDqlDictionary
				.getKeyToAliasValueMap(STR_COL_NAME_IF_NO_ROWS_RESET);

		Map<String, Map<String, String>> crArgumentParserCachedVals = new HashMap<String, Map<String, String>>();

		String[] keys = updateAttrsViaDqlDictionary.getKeys();
		for (int i = 0; i < keys.length; i++) {
			Map<String, String> parseArgs = new HashMap<String, String>();
			String key = keys[i];
			parseArgs.put(STR_ARG_NAME_QUERY, queries.get(key));
			parseArgs.put(STR_ARG_NAME_OVERRIDE, overrides.get(key));
			parseArgs.put(STR_ARG_NAME_ALL_ROWS, allRows.get(key));
			parseArgs.put(STR_ARG_NAME_TRUNCATE, truncates.get(key));

			parseArgs.put(STR_ARG_NAME_IGNORE_NULL_VALUES, ignoreNullValues.get(key));
			parseArgs.put(STR_ARG_NAME_IGNORE_DUPL_VALUES, ignoreDuplicateValues.get(key));
			parseArgs.put(STR_ARG_NAME_IF_NO_ROWS_RESET, noRowsResets.get(key));

			crArgumentParserCachedVals.put(key, Collections.unmodifiableMap(parseArgs));
		}
		updateAttrsViaDqlDictCached = Collections.unmodifiableMap(crArgumentParserCachedVals);

	}

	/**
	 * Method to fetch the arguments from dictionary , and calls
	 * CDFUpdateAttrsViaQuery method if the condition satisfies
	 * 
	 * @param pSession
	 * @param sysObject
	 * @param pStrActionKey
	 * @param locale
	 * @param argumentParser
	 * @return
	 * @throws Exception
	 */
	public D2methodBean execute(IDfSession pSession, IDfId pObjectId, IDfSysObject pSysObject, String pStrActionKey,
			Locale locale, ArgumentParser argumentParser) throws Exception {
		
//		InitializeArtifact
//		CDFInitializeArtifactMethod
//		select * from dm_method where object_name
		DfLogger.info(this,
				"************************************** execute() of SWYUpdateAttributeViaQueryWrapperCached class started ********************************",
				null, null);
		boolean bIsCondition = true;
		D2methodBean methodBeanResponse = null;
		boolean bIsUpdateAttributeFailed = false;
		List<String> listFailedUpdateAttributes = new ArrayList<String>();
		String strLoggedInUser = pSession.getLoginUserName();

		// Set Standard Arguments in the HasMap
		IDfSysObject sysObject = (IDfSysObject) pSession.getObject(pObjectId);
		Map<String, String> parserArguments = new SWYInitializeArtifactHelper().addStdArgumentsToHashMap(pSession,
				pObjectId, pSysObject);
		DfLogger.info(this, "Hashmap after initializing standard arguments:" + parserArguments
				+ " and attributes to be set in the lifecycle and state: " + pStrActionKey, null, null);

		if (objectTypes == null || ifs == null || updateAttrsViaDqlDictCached == null) {
			initializeCaches(pSession, sysObject);
		}
		try {
			// Call CDFUpdateAttrsViaQuery() method based on the condition fetched from
			// ArgumentParser
			String[] keysToInvestigate = pStrActionKey.split(",");
			for (int index = 0; index < keysToInvestigate.length; index++) {
				String key = keysToInvestigate[index];
				DfLogger.debug(this, "UpdateAttributes Dictionary Key Name:" + key, null, null);

				String strAliasValue = objectTypes.get(key);
				if (strAliasValue == null || "".equalsIgnoreCase(strAliasValue)) {
					// Check the condition mentioned for the updateAttributeViaQuery method, if the
					// if condition satisfies, the CDFUpdateAttrsViaQuery method will be called
					strAliasValue = ifs.get(key);
					if (strAliasValue != null) {
						strAliasValue = AttributeExpression.resolve(strAliasValue, sysObject, strLoggedInUser);
						bIsCondition = QueryUtils.checkObjectConditionExpression(sysObject, strAliasValue, pSession);
						DfLogger.debug(this, "Is the condition " + strAliasValue + " for updating the attribute" + key
								+ " satisfied: " + bIsCondition, null, null);
					}
					if (bIsCondition) {
						methodBeanResponse = updateAttrsViaQuery(key, pSession, pSysObject, parserArguments, locale);
						if (methodBeanResponse.getCode().equals(D2Method.RETURN_FATAL_STR)) {
							DfLogger.error(this,
									"Error while updating attribute:" + key + " is " + methodBeanResponse.getMessage(),
									null, null);
							bIsUpdateAttributeFailed = true;
							listFailedUpdateAttributes.add(key);
						}
					}
				} else if (strAliasValue != null && (sysObject.getTypeName().equalsIgnoreCase(strAliasValue)
						|| sysObject.getType().getSuperName().equalsIgnoreCase(strAliasValue))) {
					// Check the object_type mentioned for the updateAttributeViaQuery method, if
					// the object_type matches then verify whether the condition satisfies, then
					// CDFUpdateAttrsViaQuery method will be called
					strAliasValue = ifs.get(key);
					if (strAliasValue != null) {
						strAliasValue = AttributeExpression.resolve(strAliasValue, sysObject, strLoggedInUser);
						bIsCondition = QueryUtils.checkObjectConditionExpression(sysObject, strAliasValue, pSession);
						DfLogger.debug(this, "Is the condition " + strAliasValue + " for updating the attribute" + key
								+ " satisfied: " + bIsCondition, null, null);
					}
					if (bIsCondition) {
						methodBeanResponse = updateAttrsViaQuery(key, pSession, pSysObject, parserArguments, locale);
						if (methodBeanResponse.getCode().equals(D2Method.RETURN_FATAL_STR)) {
							DfLogger.error(this,
									"Error while updating attribute:" + key + " is " + methodBeanResponse.getMessage(),
									null, null);
							bIsUpdateAttributeFailed = true;
							listFailedUpdateAttributes.add(key);
						}
					}
				} else {
					DfLogger.debug(this, "Document's  object type :" + sysObject.getTypeName() + " does not match with "
							+ strAliasValue + " Hence no property to be set", null, null);
				}
			}
			DfLogger.info(this,
					"************************************** execute() of SWYUpdateAttributeViaQueryWrapperCached class Ended *****************************************************************",
					null, null);
			StringBuilder strBldMessage = new StringBuilder();
			if (bIsUpdateAttributeFailed) {
				strBldMessage.append("Updating attribute(s) failed for: ");
				for (String strAttribute : listFailedUpdateAttributes) {
					strBldMessage.append(strAttribute).append(",");
				}
				DfLogger.info(this, "Error while updating attribute(s):" + strBldMessage.toString(), null, null);
				return new D2methodBean(D2Method.RETURN_FATAL_STR, strBldMessage.toString());
			}
			return new D2methodBean(D2Method.RETURN_SUCCESS_STR, null);
		} catch (Exception ex) {
			String errorMsg = "Error while updating attribute:" + ex.getMessage();
			DfLogger.error(this, errorMsg, null, ex);
			throw new Exception(errorMsg);
		}
	}

	/**
	 * Fetch alias values from the "CMN-DIC-Update Attrs Via Query" dictionary, and
	 * call CDFUpdateAttrsViaQuery method with the details of the attribute to be
	 * set
	 * 
	 * @param pStrKey
	 * @param pSession
	 * @param pSysobj
	 * @param locale
	 */
	private D2methodBean updateAttrsViaQuery(String pStrKey, IDfSession pSession, IDfSysObject pSysobj,
			Map<String, String> parserArguments, Locale locale) throws Exception {
		UpdateAttrsViaQuery updateAtrrsObj = new UpdateAttrsViaQuery();
		DfLogger.info(this, "Attributes to be set for the specific object" + pStrKey, null, null);
		parserArguments.putAll(updateAttrsViaDqlDictCached.get(pStrKey));

		ArgumentParser argParserObj = new ArgumentParser(parserArguments);
		DfLogger.debug(this, "Argument parser object with the hashmap: " + argParserObj, null, null);

		try {
			return updateAtrrsObj.execute(pSession, null, locale, argParserObj);
		} catch (Exception e) {
			DfLogger.error(this, "Unable to update attribute via query: " + pStrKey + ".Error message(if any) "
					+ e.getLocalizedMessage(), null, e);
			throw e;
		}
	}
}
