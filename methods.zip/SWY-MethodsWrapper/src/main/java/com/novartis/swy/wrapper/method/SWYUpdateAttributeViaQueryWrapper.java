package com.novartis.swy.wrapper.method;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import com.documentum.cdf.methods.UpdateAttrsViaQuery;
import com.documentum.d2.model.D2Dictionary;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfId;
import com.documentum.utils.AttributeExpression;
import com.documentum.utils.QueryUtils;
import com.emc.common.java.utils.ArgumentParser;
import com.emc.d2.api.methods.D2Method;
import com.emc.d2.api.methods.D2methodBean;

public class SWYUpdateAttributeViaQueryWrapper implements IActionWrapper {
	private static final String STR_DIC_UPDATE_ATTR_VIA_QUERY = "CMN-DIC-Update Attrs Via Query";
	private String strAliasValue = null;
	private SWYInitializeArtifactHelper SWY_IA_HELPER_OBJ = new SWYInitializeArtifactHelper();
	private Map<String, String> hmAliasNamesAliasValues = null;
	private static String STR_COL_NAME_OBJECT_TYPE = "object_type";
	private static String STR_COL_NAME_IF = "if";
	private static String STR_COL_NAME_QUERY = "query";
	private static String STR_COL_NAME_OVERRIDE = "override";
	private static String STR_COL_NAME_ALL_ROWS = "all_rows";
	private static String STR_COL_NAME_TRUNCATE = "truncate";
	private static String STR_COL_NAME_IGNORE_NULL_VALUES = "ignore_null_values";
	private static String STR_COL_NAME_IGNORE_DUPL_VALUES = "ignore_duplicate_values";	
	private static String STR_COL_NAME_IF_NO_ROWS_RESET = "if_no_rows_reset";
	private static String STR_ARG_NAME_QUERY = "-query";
	private static String STR_ARG_NAME_OVERRIDE = "-override";
	private static String STR_ARG_NAME_TRUNCATE = "-truncate";
	private static String STR_ARG_NAME_ALL_ROWS = "-all_rows";
	private static String STR_ARG_NAME_IGNORE_NULL_VALUES = "-ignore_null_values";
	private static String STR_ARG_NAME_IGNORE_DUPL_VALUES = "-ignore_duplicate_values";	
	private static String STR_ARG_NAME_IF_NO_ROWS_RESET = "-if_no_rows_reset";
	
	/**
	 * Method to fetch the arguments from dictionary , and calls CDFUpdateAttrsViaQuery method if the condition satisfies
	 * @param pSession
	 * @param sysObject
	 * @param pStrActionKey
	 * @param locale
	 * @param argumentParser
	 * @return
	 * @throws Exception
	 */
	public D2methodBean execute(IDfSession pSession, IDfId pObjectId,IDfSysObject pSysObject, String pStrActionKey,Locale locale, ArgumentParser argumentParser) throws Exception {
		DfLogger.info(this,"************************************** execute() of SWYUpdateAttributeViaQueryWrapper class started ********************************",null,null);
		boolean bIsCondition = true;
		D2methodBean methodBeanResponse = null;
		boolean bIsUpdateAttributeFailed = false;
		List<String> listFailedUpdateAttributes = new ArrayList<String>();	
		String strLoggedInUser = pSession.getLoginUserName();

		//Set Standard Arguments in the HasMap
		IDfSysObject sysObject = (IDfSysObject)pSession.getObject(pObjectId);
		hmAliasNamesAliasValues = SWY_IA_HELPER_OBJ.addStdArgumentsToHashMap(pSession, pObjectId, pSysObject);		
		DfLogger.info(this,"Hashmap after initializing standard arguments:" + hmAliasNamesAliasValues + " and attributes to be set in the lifecycle and state: " + pStrActionKey,null,null);
		
		try {
			//Call CDFUpdateAttrsViaQuery() method based on the condition fetched from ArgumentParser		
			String[] strArrKeyAttributeNames = pStrActionKey.split(",");
			for(int index=0; index<strArrKeyAttributeNames.length;index++) {
				DfLogger.debug(this,"UpdateAttributes Dictionary Key Name:" + strArrKeyAttributeNames[index],null,null);
							
				strAliasValue = D2Dictionary.getAliasValue(STR_DIC_UPDATE_ATTR_VIA_QUERY,strArrKeyAttributeNames[index] , STR_COL_NAME_OBJECT_TYPE, pSession, sysObject, strLoggedInUser, true, true);
				if(strAliasValue == null || "".equalsIgnoreCase(strAliasValue)) {				
					//Check the condition mentioned for the updateAttributeViaQuery method, if the if condition satisfies, the CDFUpdateAttrsViaQuery method will be called
					strAliasValue = D2Dictionary.getAliasValue(STR_DIC_UPDATE_ATTR_VIA_QUERY,strArrKeyAttributeNames[index] , STR_COL_NAME_IF, pSession, sysObject, strLoggedInUser, true, true);								
					if(strAliasValue != null) {
						strAliasValue = AttributeExpression.resolve(strAliasValue, sysObject, strLoggedInUser);
						bIsCondition = QueryUtils.checkObjectConditionExpression(sysObject, strAliasValue, pSession);
						DfLogger.debug(this,"Is the condition " + strAliasValue +" for updating the attribute" + strArrKeyAttributeNames[index]  + " satisfied: " + bIsCondition,null,null);
					}
					if(bIsCondition) {
						methodBeanResponse = updateAttrsViaQuery(strArrKeyAttributeNames[index],pSession,pSysObject,locale);
						if(methodBeanResponse.getCode().equals(D2Method.RETURN_FATAL_STR)) {					
							DfLogger.error(this,"Error while updating attribute:" + strArrKeyAttributeNames[index] + " is " + methodBeanResponse.getMessage(),null,null);	
							bIsUpdateAttributeFailed = true;
							listFailedUpdateAttributes.add(strArrKeyAttributeNames[index]);
						}
					}
				} else if(strAliasValue != null && (sysObject.getTypeName().equalsIgnoreCase(strAliasValue) || sysObject.getType().getSuperName().equalsIgnoreCase(strAliasValue))) {	
					//Check the object_type mentioned for the updateAttributeViaQuery method, if the object_type matches then verify whether the condition satisfies, then CDFUpdateAttrsViaQuery method will be called
					strAliasValue = D2Dictionary.getAliasValue(STR_DIC_UPDATE_ATTR_VIA_QUERY,strArrKeyAttributeNames[index] , STR_COL_NAME_IF, pSession, sysObject, strLoggedInUser, true, true);				
					if(strAliasValue != null) {
						strAliasValue = AttributeExpression.resolve(strAliasValue, sysObject, strLoggedInUser);
						bIsCondition = QueryUtils.checkObjectConditionExpression(sysObject, strAliasValue, pSession);
						DfLogger.debug(this,"Is the condition " + strAliasValue +" for updating the attribute" + strArrKeyAttributeNames[index]  + " satisfied: " + bIsCondition,null,null);
					}
					if(bIsCondition) {
						methodBeanResponse = updateAttrsViaQuery(strArrKeyAttributeNames[index],pSession,pSysObject,locale);
						if(methodBeanResponse.getCode().equals(D2Method.RETURN_FATAL_STR)) {					
							DfLogger.error(this,"Error while updating attribute:" + strArrKeyAttributeNames[index] + " is " + methodBeanResponse.getMessage(),null,null);	
							bIsUpdateAttributeFailed = true;
							listFailedUpdateAttributes.add(strArrKeyAttributeNames[index]);
						}
					}				
				} else {
					DfLogger.debug(this,"Document's  object type :" + sysObject.getTypeName() +" does not match with " + strAliasValue + " Hence no property to be set",null,null);				
				}			
			}
			DfLogger.info(this,"************************************** execute() of SWYUpdateAttributeViaQueryWrapper class Ended *****************************************************************",null,null);
			StringBuilder strBldMessage = new StringBuilder();			
			if (bIsUpdateAttributeFailed) {
				strBldMessage.append("Updating attribute(s) failed for: ");
				for(String strAttribute:listFailedUpdateAttributes) {
					strBldMessage.append(strAttribute);
					strBldMessage.append(",");
				}			
				DfLogger.info(this,"Error while updating attribute(s):" + strBldMessage.toString(),null,null);
				return new D2methodBean(D2Method.RETURN_FATAL_STR,strBldMessage.toString());			
			} 
			return new D2methodBean(D2Method.RETURN_SUCCESS_STR,null);			
		} catch (Exception ex) {
			DfLogger.error(this,"Error while updating attribute:" + ex.getMessage(),null,ex);
			throw new Exception("Error while updating attribute:" + ex.getMessage());
		}					
	}

	/**
	 * Fetch alias values from the "CMN-DIC-Update Attrs Via Query" dictionary, 
	 * and call CDFUpdateAttrsViaQuery method with the details of the attribute to be set
	 * @param pStrKey
	 * @param pSession
	 * @param pSysobj
	 * @param locale
	 */
	private D2methodBean updateAttrsViaQuery(String pStrKey, IDfSession pSession,IDfSysObject pSysobj,Locale locale) throws Exception {
		UpdateAttrsViaQuery updateAtrrsObj = new UpdateAttrsViaQuery();
		DfLogger.info(this,"Attributes to be set for the specific object" + pStrKey,null,null);
		
		//Fetch alias values from dictionary, "-context_user" column is not fetched from dictionary, as in the OOB code, it gets replaced by the logged in user name.
		strAliasValue = SWY_IA_HELPER_OBJ.getAliasValueFromDictionary(STR_DIC_UPDATE_ATTR_VIA_QUERY, pStrKey, STR_COL_NAME_QUERY, pSession);
		if (strAliasValue != null) {
			hmAliasNamesAliasValues.put(STR_ARG_NAME_QUERY, strAliasValue);
		}						
		strAliasValue = SWY_IA_HELPER_OBJ.getAliasValueFromDictionary(STR_DIC_UPDATE_ATTR_VIA_QUERY, pStrKey, STR_COL_NAME_OVERRIDE, pSession);
		if (strAliasValue != null) {
			hmAliasNamesAliasValues.put(STR_ARG_NAME_OVERRIDE, strAliasValue);
		}
		strAliasValue = SWY_IA_HELPER_OBJ.getAliasValueFromDictionary(STR_DIC_UPDATE_ATTR_VIA_QUERY, pStrKey, STR_COL_NAME_ALL_ROWS, pSession);
		if (strAliasValue != null) {
			hmAliasNamesAliasValues.put(STR_ARG_NAME_ALL_ROWS, strAliasValue);
		}
		strAliasValue = SWY_IA_HELPER_OBJ.getAliasValueFromDictionary(STR_DIC_UPDATE_ATTR_VIA_QUERY, pStrKey, STR_COL_NAME_TRUNCATE, pSession);
		if (strAliasValue != null) {
			hmAliasNamesAliasValues.put(STR_ARG_NAME_TRUNCATE, strAliasValue);
		}
		strAliasValue = SWY_IA_HELPER_OBJ.getAliasValueFromDictionary(STR_DIC_UPDATE_ATTR_VIA_QUERY, pStrKey, STR_COL_NAME_IGNORE_DUPL_VALUES, pSession);
		if (strAliasValue != null) {
			hmAliasNamesAliasValues.put(STR_ARG_NAME_IGNORE_DUPL_VALUES, strAliasValue);
		}
		strAliasValue = SWY_IA_HELPER_OBJ.getAliasValueFromDictionary(STR_DIC_UPDATE_ATTR_VIA_QUERY, pStrKey, STR_COL_NAME_IGNORE_NULL_VALUES, pSession);
		if (strAliasValue != null) {
			hmAliasNamesAliasValues.put(STR_ARG_NAME_IGNORE_NULL_VALUES, strAliasValue);
		}
		strAliasValue = SWY_IA_HELPER_OBJ.getAliasValueFromDictionary(STR_DIC_UPDATE_ATTR_VIA_QUERY, pStrKey, STR_COL_NAME_IF_NO_ROWS_RESET, pSession);
		if (strAliasValue != null) {
			hmAliasNamesAliasValues.put(STR_ARG_NAME_IF_NO_ROWS_RESET, strAliasValue);
		}
		ArgumentParser argParserObj = new ArgumentParser(hmAliasNamesAliasValues);
		DfLogger.debug(this,"Argument parser object with the hashmap: " + argParserObj,null,null);		
		
		try {
			return updateAtrrsObj.execute(pSession, null, locale, argParserObj);
		} catch (Exception e) {
			DfLogger.error(this,"Unable to update attribute via query: " + pStrKey + ".Error message(if any) "+ e.getLocalizedMessage(),null, e);
			throw e;
		}	
	}	
}
