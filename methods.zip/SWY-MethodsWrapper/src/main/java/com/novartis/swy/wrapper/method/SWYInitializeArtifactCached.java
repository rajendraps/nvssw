package com.novartis.swy.wrapper.method;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import com.documentum.cdf.methods.InitializeArtifact;
import com.documentum.d2.exceptions.ConfigurationException;
import com.documentum.d2.model.D2Dictionary;
import com.documentum.fc.client.IDfModule;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfId;
import com.emc.common.java.utils.ArgumentParser;
import com.emc.d2.api.methods.D2Method;
import com.emc.d2.api.methods.D2methodBean;
import com.emc.d2.api.methods.ID2Method;

public class SWYInitializeArtifactCached
		implements ID2Method, IDfModule {

	private static final String STR_DIC_LIFECYCLE_ACTION_MAPPING_NAME = "CMN-DIC-Lifecycle Actions Mapping";
	private static final String STR_ACTION_CLASS_ALIAS_NAME = "Action Class";
	private static final String STR_ACTION_VALUE_ALIAS_NAME = "Action Values";
	private static final String STR_ARGUMENT_ID = InitializeArtifact.ARG_CONTEXT_OBJECT_ID;//ARG_SELECTED_OBJECT_ID;// "-id";
	private static final String STR_ARGUMENT_ACTION_KEY = "-action_key";

	private final static Map<String, String> lifecycleActionClasses = new HashMap<String, String>();
	private final static Map<String, String> lifecycleActionValues = new HashMap<String, String>();

	@Override
	public D2methodBean execute(IDfSession pSession, IDfSysObject job, Locale locale, ArgumentParser pArgumentParser)
			throws Exception {
		DfLogger.info(this,
				"************************************** SWYInitializeArtifactCached *****************************************************************",
				null, null);
		D2methodBean methodBeanResponse = null;
		DfLogger.debug(this, "********************Start execute method***********************", null, null);
		DfLogger.debug(this, "Session Intialized for the user: " + pSession.getLoginUserName(), null, null);

		// Fetch r_object_id of the document from Argument Parser
		IDfId selectedObjectId = pArgumentParser.getIdArgument(STR_ARGUMENT_ID, null);
		if ((selectedObjectId == null) || (selectedObjectId.isNull())) {
			throw new IllegalArgumentException("Missing argument: " + STR_ARGUMENT_ID);
		}
		DfLogger.debug(this, "Object ID of the Document: " + selectedObjectId.toString(), null, null);

		IDfSysObject sysObject = (IDfSysObject) pSession.getObject(selectedObjectId);
		if (sysObject == null) {
			throw new IllegalArgumentException("The specified object " + selectedObjectId.getId() + " does not exist.");
		}

		// Fetch action_key from method arguments, and fetch action class name and
		// action values from lifecycle_actions_mapping class
		String strArgActionKey = pArgumentParser.getStringArgument(STR_ARGUMENT_ACTION_KEY);
		if ((strArgActionKey == null) || (strArgActionKey.isEmpty())) {
			throw new IllegalArgumentException("Missing argument: " + STR_ARGUMENT_ACTION_KEY);
		}

		if (lifecycleActionClasses.size() == 0 || lifecycleActionValues.size() == 0) {
			populateDictionaryCache(pSession, sysObject);
		}

		String strClassName = lifecycleActionClasses.get(strArgActionKey);
		String strActionValue = lifecycleActionValues.get(strArgActionKey); 

		if (strClassName == null) {
			throw new DfException("Missing value from dictionary for key: " + STR_ACTION_CLASS_ALIAS_NAME);
		}
		if (strActionValue == null) {
			throw new DfException("Missing value from dictionary for key: " + STR_ACTION_VALUE_ALIAS_NAME);
		}

		try {
			// Calls the wrapper class and execute the business logic
			IActionWrapper actionWrapperObj = getWrapperInstance(strClassName);
			methodBeanResponse = actionWrapperObj.execute(pSession, selectedObjectId, sysObject, strActionValue, locale,
					pArgumentParser);

			if (methodBeanResponse.getCode().equals(D2Method.RETURN_FATAL_STR)) {
				DfLogger.error(this, "Error while initializing artifact:" + methodBeanResponse.getMessage(), null,
						null);
			}
			return methodBeanResponse;
		} catch (Exception ex) {
			DfLogger.error(this, "Error while initializing artifact:" + ex.getMessage(), null, ex);
			methodBeanResponse = new D2methodBean(D2Method.RETURN_FATAL_STR, ex.getMessage());
			return methodBeanResponse;
		}
	}

	private synchronized void populateDictionaryCache(IDfSession pSession, IDfSysObject sysObject)
			throws DfException, ConfigurationException {
		D2Dictionary lifecycleActonMapping = D2Dictionary.getDictionary(STR_DIC_LIFECYCLE_ACTION_MAPPING_NAME, pSession,
				sysObject, pSession.getLoginUserName(), true, true);
		lifecycleActionClasses.clear();
		lifecycleActionClasses.putAll(lifecycleActonMapping.getKeyToAliasValueMap(STR_ACTION_CLASS_ALIAS_NAME));
		lifecycleActionValues.clear();
		lifecycleActionValues.putAll(lifecycleActonMapping.getKeyToAliasValueMap(STR_ACTION_VALUE_ALIAS_NAME));
	}

	/**
	 * Instantiate the Wrapper class
	 * 
	 * @param pStrClassName
	 * @return
	 */
	private IActionWrapper getWrapperInstance(String pStrClassName)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		IActionWrapper implementationClass = null;
		
		if (SWYAutoRelationsCached.class.getSimpleName().equals(pStrClassName)) {
			implementationClass = new SWYAutoRelationsCached();
		} else if (SWYAutoRelations.class.getSimpleName().equals(pStrClassName)) {
			implementationClass = new SWYAutoRelations();
	
		} else if (SWYUpdateAttributeViaQueryWrapperCached.class.getSimpleName().equals(pStrClassName)) {
			implementationClass = new SWYUpdateAttributeViaQueryWrapperCached();
		} else if (SWYUpdateAttributeViaQueryWrapper.class.getSimpleName().equals(pStrClassName)) {
			implementationClass = new SWYUpdateAttributeViaQueryWrapper();
		
		} else if (SWYSetAttributeWrapperCached.class.getSimpleName().equals(pStrClassName)) {
				implementationClass = new SWYSetAttributeWrapperCached();
		} else if (SWYSetAttributeWrapper.class.getSimpleName().equals(pStrClassName)) {
			implementationClass = new SWYSetAttributeWrapper();
		}

		if (implementationClass == null) {
			String errorNoMappeInstantiation = "Exception: No mapped class found when instatiating implementation class for: "
					+ pStrClassName;
			DfLogger.error(this, errorNoMappeInstantiation, null, null);
			throw new IllegalArgumentException(errorNoMappeInstantiation);
		}
		DfLogger.info(this, "Instantiated Class Name in SWYInitializeArtifactCached:" + pStrClassName, null, null);
		return implementationClass;
	}
}
