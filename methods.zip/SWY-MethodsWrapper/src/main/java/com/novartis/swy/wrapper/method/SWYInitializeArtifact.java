package com.novartis.swy.wrapper.method;

import java.util.Locale;

import com.documentum.d2.model.D2Dictionary;
import com.documentum.fc.client.IDfModule;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfId;
import com.emc.common.java.utils.ArgumentParser;
import com.emc.d2.api.methods.D2Method;
import com.emc.d2.api.methods.D2methodBean;
import com.emc.d2.api.methods.ID2Method;

public class SWYInitializeArtifact implements ID2Method,IDfModule {

	private static final String STR_DIC_LIFECYCLE_ACTION_MAPPING_NAME ="CMN-DIC-Lifecycle Actions Mapping";
	private static final String STR_ACTION_CLASS_ALIAS_NAME ="Action Class";
	private static final String STR_ACTION_VALUE_ALIAS_NAME="Action Values";
	private static final String STR_CLASS_PACKAGE_NAME = "com.novartis.swy.wrapper.method.";
	private static final String STR_ARGUMENT_ID = "-id";
	private static final String STR_ARGUMENT_ACTION_KEY = "-action_key";

	@Override
	public D2methodBean execute(IDfSession pSession, IDfSysObject job, Locale locale, ArgumentParser pArgumentParser) throws Exception {
		DfLogger.info(this,"************************************** SWYInitializeArtifact *****************************************************************",null,null);
		D2methodBean methodBeanResponse=null;
		DfLogger.debug(this,"********************Start execute method***********************",null, null);
		DfLogger.debug(this, "Session Intialized for the user: " + pSession.getLoginUserName(), null, null);
				
		//Fetch r_object_id of the document from Argument Parser
		IDfId  selectedObjectId = pArgumentParser.getIdArgument(STR_ARGUMENT_ID, null);
		if ((selectedObjectId == null) || (selectedObjectId.isNull())) {
			throw new IllegalArgumentException("Missing argument: " + STR_ARGUMENT_ID);
		}
		DfLogger.debug(this, "Object ID of the Document: " + selectedObjectId.toString(), null, null);
		
		IDfSysObject sysObject = (IDfSysObject)pSession.getObject(selectedObjectId);
		if (sysObject == null) {
			throw new IllegalArgumentException("The specified object "+ selectedObjectId.getId() +" does not exist.");
		}
		
		//Fetch action_key from method arguments, and fetch action class name and action values from lifecycle_actions_mapping class
		String strArgActionKey = pArgumentParser.getStringArgument(STR_ARGUMENT_ACTION_KEY);
		if ((strArgActionKey == null) || (strArgActionKey.isEmpty())) {
			throw new IllegalArgumentException("Missing argument: " + STR_ARGUMENT_ACTION_KEY);
		}
		
		String strClassName = D2Dictionary.getAliasValue(STR_DIC_LIFECYCLE_ACTION_MAPPING_NAME,strArgActionKey , STR_ACTION_CLASS_ALIAS_NAME, pSession, sysObject, pSession.getLoginUserName(), true, true);
		String strActionValue = D2Dictionary.getAliasValue(STR_DIC_LIFECYCLE_ACTION_MAPPING_NAME,strArgActionKey , STR_ACTION_VALUE_ALIAS_NAME, pSession, sysObject, pSession.getLoginUserName(), true, true);
		if(strClassName == null) {
			throw new DfException("Missing value from dictionary for key: " + STR_ACTION_CLASS_ALIAS_NAME);
		}		
		if(strActionValue == null) {
			throw new DfException("Missing value from dictionary for key: " + STR_ACTION_VALUE_ALIAS_NAME);
		}
		
		try {
			//Calls the wrapper class and execute the business logic
			IActionWrapper actionWrapperObj = getWrapperInstance(strClassName);		
			methodBeanResponse = actionWrapperObj.execute(pSession, selectedObjectId,sysObject,strActionValue,locale, pArgumentParser);
					
			if(methodBeanResponse.getCode().equals(D2Method.RETURN_FATAL_STR)) {
				DfLogger.error(this,"Error while initializing artifact:" + methodBeanResponse.getMessage(),null,null);				
			}	
			return methodBeanResponse;
		} catch(Exception ex) {
			DfLogger.error(this,"Error while initializing artifact:" + ex.getMessage(),null,ex);
			methodBeanResponse = new D2methodBean(D2Method.RETURN_FATAL_STR, ex.getMessage()); 
			return methodBeanResponse;
		}					
	}

	/**
	 * Instantiate the Wrapper class 
	 * @param pStrClassName
	 * @return
	 */
	private IActionWrapper getWrapperInstance(String pStrClassName) throws ClassNotFoundException,InstantiationException,IllegalAccessException {
		Class<?> classObj = null;
		Object obj = null;
		String strFullClassName = null;
		strFullClassName = STR_CLASS_PACKAGE_NAME + pStrClassName;			
		try {
			classObj = Class.forName(strFullClassName);
			obj = classObj.newInstance();
		} catch (ClassNotFoundException cnfEx) {
			DfLogger.error(this,"Exception in instatiating class - Class not found: " + strFullClassName,null,null);
			throw new ClassNotFoundException(cnfEx.getMessage());
		} catch (InstantiationException ieEx) {
			DfLogger.error(this,"Exception in instatiating class - Unable to instantiate class " + strFullClassName,null,null);
			throw new InstantiationException(ieEx.getMessage());
		} catch (IllegalAccessException iAeEx) {
			DfLogger.error(this,"Exception in instatiating class - No access to the class:  " + strFullClassName,null,null);
			throw new InstantiationException(iAeEx.getMessage());
		}		
		DfLogger.info(this,"Instantiated Class Name in SWYInitializeArtifact:" + strFullClassName,null,null);
		return (IActionWrapper) obj;
	}
}
