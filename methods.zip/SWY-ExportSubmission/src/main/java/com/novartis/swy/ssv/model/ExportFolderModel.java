package com.novartis.swy.ssv.model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.emc.common.java.utils.ArrayUtil;
import com.emc.common.java.utils.StringUtil;

public class ExportFolderModel {
	private String objectId = null;
	private String exportPath = null;
	
	private static String s_filenameForWindowsBefore = "/\\:*?\"<>|";
	private static String s_filenameForWindowsAfter = "--_#!`()!`";
	
	public void setObjectId(String string) {
		this.objectId = string;
	}

	public void setExportPath(String path) {
		List<String> oldPathList = StringUtil.split(path, "/");
		List<String> newPathList = new ArrayList<>();
		Iterator<String> it = oldPathList.iterator();

		while (it.hasNext()) {
			String element = (String) it.next();
			//element = DfObjectUtil.getCompatibleFilenameForWindows(element);
			element = StringUtil.replaceCharByAnother(element,s_filenameForWindowsBefore, s_filenameForWindowsAfter);
			newPathList.add(element);
		}

		this.exportPath = ArrayUtil.join(newPathList, "/");
	}

	public String getObjectId() {
		return this.objectId;
	}

	public String getExportPath() {
		return this.exportPath;
	}

	public String toString() {
		return this.objectId + " => " + this.exportPath;
	}

}
