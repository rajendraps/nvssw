package com.novartis.swy.ssv.methods;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

import com.documentum.d2.model.D2Dictionary;
import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.client.IDfFormat;
import com.documentum.fc.client.IDfModule;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.client.IDfUser;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.DfUtil;
import com.documentum.fc.common.IDfId;
import com.documentum.utils.DfcUtils;
import com.documentum.utils.StringUtils;
import com.emc.common.dctm.objects.DfDocbaseConstantsEx;
import com.emc.common.dctm.utils.DfObjectUtil;
import com.emc.common.java.javamail.MailMessage;
import com.emc.common.java.javamail.MailSender;
import com.emc.common.java.utils.ArgumentParser;
import com.emc.common.java.utils.StringUtil;
import com.emc.d2.api.config.mail.D2MailConfig;
import com.emc.d2.api.config.mail.ID2MailConfig;
import com.emc.d2.api.methods.D2Method;
import com.emc.d2.api.methods.D2methodBean;
import com.emc.d2.api.methods.ID2Method;
import com.novartis.swy.ssv.model.ExportFolderModel;

/**
 * This D2 method is designed for Deep exporting folders while performing Deep
 * Export on the folder on the UI. this method exports the folders along with
 * its contents and also export empty folders if there are any to the specified
 * location mentioned in the Dictionary "Submission Export Filestore"
 * 
 * <strong>Method-specific arguments:</strong>
 * <ul>
 * <p>
 * <li><strong>id</strong> - Object ID of the selected Folder
 * <strong>(Mandatory)</strong></li>
 * </p>
 *
 * <p>
 * <li><strong>context_user</strong> - User name of the user through which
 * session method can be invoked.</li>
 * </p>
 * 
 * <p>
 * <li><strong>is_custom_notification_needed</strong> - If mail notification
 * required. <strong>(Optional) True by default</strong></li>
 * </p>
 *
 * @author pmse1
 *
 */

public class SWYExportSubmission implements ID2Method, IDfModule {

	public static final String ARG_CONTEXT_USER = "-context_user";
	public static final String ARG_SELECTED_OBJECT_ID = "-id";
	public static final String ARG_MAIL_NOTIFICATION_NEEDED = "-is_mail_notification_needed";

	public static final String DEFAULT_EXPORT_FOLDER_PATH = "output_folder_path";
	public static final String DICTIONARY_NAME = "Submission Export Filestore";

	public static final String FILE_SEPARATOR = "/";

	private String aliasName = "value";
	
	private static String s_filenameForWindowsBefore = "/\\:*?\"<>|";
	private static String s_filenameForWindowsAfter = "--_#!`()!`";

	/**
	 * D2 Method execute
	 */
	@Override
	public D2methodBean execute(IDfSession session, IDfSysObject sysObj, Locale locale, ArgumentParser argumentsParser)
			throws Exception {
		try {
			IDfId objID = argumentsParser.getIdArgument(ARG_SELECTED_OBJECT_ID, null);
			if ((objID == null) || (objID.isNull())) {
				throw new IllegalArgumentException("Missing argument: -id");
			}
			String contextUser = argumentsParser.getStringArgument(ARG_CONTEXT_USER, null);
			D2Dictionary dictionary = D2Dictionary.getDictionary(DICTIONARY_NAME, session, sysObj, contextUser, false,
					false);
			if (dictionary == null) {
				throw new IllegalArgumentException(
						"Specified Dictionary \"" + DICTIONARY_NAME + "\" does not exists in the system");
			}

			boolean isMailNotification = argumentsParser.getBooleanArgument(ARG_MAIL_NOTIFICATION_NEEDED, true);

			String exportPath = dictionary.getKeyToAliasValueMap(aliasName).get(DEFAULT_EXPORT_FOLDER_PATH);
			IDfSession userSession = DfcUtils.getUserSession(session, contextUser, null, locale, true);
			List<ExportFolderModel> exportList = getDownloadableObjects(userSession, objID);
			if (!exportPath.endsWith(FILE_SEPARATOR))
				exportPath += FILE_SEPARATOR;

			//String userFolder = DfObjectUtil.getCompatibleFilenameForWindows(contextUser) + "_"
			//		+ (new GregorianCalendar().getTime()).toString().replace(":", "-") + FILE_SEPARATOR;
			String userFolder = StringUtil.replaceCharByAnother(contextUser,s_filenameForWindowsBefore, s_filenameForWindowsAfter) + "_"
					+ (new GregorianCalendar().getTime()).toString().replace(":", "-") + FILE_SEPARATOR;
			exportPath = exportPath + userFolder + FILE_SEPARATOR;

			for (ExportFolderModel obj : exportList) {
				DfLogger.debug(this, "Exporting Objects" + obj.getObjectId() + " ---- " + obj.getExportPath(), null,
						null);
				String objectID = obj.getObjectId();

				String outputFolderPath = exportPath + obj.getExportPath();
				Path exportroot = new File(outputFolderPath).toPath();
				Path outputPath = exportroot.resolve(outputFolderPath);
				if (!Files.exists(outputPath)) {
					Files.createDirectories(outputPath);
				}

				if (objectID.startsWith("0b") || objectID.startsWith("0c")) {
					DfLogger.info(this, "Exporting Empty Folder - " + outputFolderPath, null, null);
				} else {
					IDfDocument doc = (IDfDocument) session.getObject(new DfId(objectID));

					String objectName = getObjectNameWithExtension(doc);

					doc.getFile(outputFolderPath + objectName);
				}

			}

			if (isMailNotification) {
				processMailNotification(session, contextUser, userFolder);
			}
			
			return new D2methodBean(D2Method.RETURN_SUCCESS_STR, "Export Successful");
		} catch (Exception e) {
			DfLogger.error(this, e.getMessage(), null, e);
			return new D2methodBean(D2Method.RETURN_FATAL_STR, e.getMessage());
		}
	}

	/**
	 * Checks if the folder is empty
	 * 
	 * @param sysObject Folder object
	 * @return Boolean True if folder is empty False otherwise
	 * @throws DfException
	 */
	protected boolean isEmpty(IDfSysObject sysObject) throws DfException {
		boolean isEmpty = true;

		IDfCollection itemColl = null;
		try {
			itemColl = ((IDfFolder) sysObject).getContents("r_object_id");
			if (itemColl.next()) {
				isEmpty = false;
			}
			return isEmpty;
		} finally {
			itemColl.close();
		}
	}

	/**
	 * Get the list of of all objects that needs to be exported to the file store
	 * @param session Documentum Session for the logged in user
	 * @param objID Folder object id
	 * @return List of ExportFolderModel objects which contains both object id to Folder path mapping
	 * @throws DfException
	 */
	protected List<ExportFolderModel> getDownloadableObjects(IDfSession session, IDfId objID) throws DfException {
		ArrayList<ExportFolderModel> result = new ArrayList<ExportFolderModel>();
		Map<String, String> folderPaths = new HashMap<String, String>();
		Map<String, String> emptyFolderPaths = new HashMap<String, String>();
		// Get the folder

		IDfFolder rootFolder = (IDfFolder) session.getObject(objID);

		String rootPath = rootFolder.getFolderPath(0);
		DfLogger.debug(this, "Root path : " + rootPath, null, null);

		String exportPath = rootFolder.getObjectName() + "/";
		folderPaths.put(rootFolder.getObjectId().getId(), exportPath);

		// List documents
		StringBuilder dql = new StringBuilder();
		dql.append("select FOR READ distinct r_object_id, i_folder_id from dm_sysobject where (folder(id('");
		dql.append(rootFolder.getObjectId());
		dql.append("'), descend)) and r_content_size > 0");

		// List of folders paths
		StringBuilder folderDql = new StringBuilder();
		folderDql.append(
				"select FOR READ distinct r_folder_path, r_object_id, i_folder_id, object_name from dm_folder where (folder(id('");
		folderDql.append(rootFolder.getObjectId());
		folderDql.append("'), descend))");

		IDfQuery query = new DfQuery();
		IDfCollection folderCol = null;
		IDfCollection col = null;

		try {

			// Get the list of the folders and store the paths that are children of the root
			// folder
			// Save the valid path to the root folder in the map so it can be used by the
			// document Folder Entry
			query.setDQL(folderDql.toString());
			folderCol = query.execute(session, IDfQuery.DF_READ_QUERY);
			while (folderCol.next()) {
				IDfId objectId = folderCol.getId(DfDocbaseConstantsEx.R_OBJECT_ID);
				String folderPath = "";
				int pathCount = folderCol.getValueCount("r_folder_path");
				for (int j = 0; j < pathCount; j++) {
					folderPath = folderCol.getRepeatingString("r_folder_path", j);
					// Only save the path to the root folder
					if (folderPath.startsWith(rootPath)) {
						if (folderPath.length() > rootPath.length()) {
							folderPath = folderPath.substring(rootPath.length() + 1);
							/* Below line would be required only for WINODWS as / would not be supported by Windows while creating folder
							While changing this below string or while enabling it we need to modify the SetPath method in Model class ExportFolderModel too
							otherwise winodws compatible names would not be exported from the system
							why we need this is even though the export happens in LINUX box the user will be copying it to WINDOWS system to view the files via filestore
							So the files and folders should contain names which are windows compatible. */
//							folderPath = StringUtil.replaceCharByAnother(folderPath, "/", "\\");
						} else
							folderPath = "";

						folderPath = exportPath + folderPath;

						String folderObjectId = objectId.getId();
						boolean isFolder = folderObjectId.startsWith("0b") || folderObjectId.startsWith("0c");
						IDfSysObject sysObject = (IDfSysObject) session.getObject(new DfId(objectId.getId()));
						boolean isEmptyFolderObject = !StringUtil.isNullOrEmpty(folderObjectId)
								&& DfUtil.isObjectId(folderObjectId) && isFolder && isEmpty(sysObject);

						if (!folderPath.endsWith(FILE_SEPARATOR))
							folderPath += FILE_SEPARATOR;
						DfLogger.debug(this, "Add id " + objectId.getId() + " folder path: " + folderPath, null, null);
						if (!folderPaths.containsKey(objectId.getId())) {
							if (isEmptyFolderObject) {
								ExportFolderModel folderEntry = new ExportFolderModel();
								folderEntry.setObjectId(DfUtil.toString(objectId));
								folderEntry.setExportPath(folderPath);
								result.add(folderEntry);
								emptyFolderPaths.put(objectId.getId(), folderPath);
							}
							folderPaths.put(objectId.getId(), folderPath);
						}

					}
				}
			}

			// Get the child documents and create a folder Entry for each one with the
			// object ID,
			// folder path (computed above) and the download URLS
			query.setDQL(dql.toString());
			col = query.execute(session, IDfQuery.DF_READ_QUERY);

			while (col.next()) {
				// calculate folder relative path with multi link management
				IDfId objectId = col.getId(DfDocbaseConstantsEx.R_OBJECT_ID);

				for (int i = 0; i < col.getValueCount(DfDocbaseConstantsEx.I_FOLDER_ID); i++) {
					IDfId folderId = col.getRepeatingId(DfDocbaseConstantsEx.I_FOLDER_ID, i);
					if (folderPaths.containsKey(folderId.getId())) {
						if (!emptyFolderPaths.containsKey(folderId.getId())) {
							String folderPath = folderPaths.get(folderId.getId());
							DfLogger.debug(this, " folder path: " + folderId.getId() + " - " + folderPath, null, null);
							if (folderPath != null) {
								ExportFolderModel folderEntry = new ExportFolderModel();
								folderEntry.setObjectId(DfUtil.toString(objectId));
								folderEntry.setExportPath(folderPath);
								result.add(folderEntry);
							} else {
								DfLogger.error(this, "Folder path not found " + folderId, null, null);
							}
						}
					}
				}
			}
		} finally {
			if (col != null)
				col.close();
			if (folderCol != null)
				folderCol.close();
		}
		DfcUtils.releaseSession(session);
		return result;
	}

	/**
	 * Returns the object name along with its extension. 
	 * Required for D2 solution as we have different auto naming rules stored without extensions
	 * @param sysObject Object
	 * @return String of object name with its extension
	 * @throws DfException
	 */
	protected String getObjectNameWithExtension(IDfSysObject sysObject) throws DfException {
		StringBuffer name = new StringBuffer(128);
		String objectName = sysObject.getObjectName().trim();
		IDfFormat format = sysObject.getFormat();
		if (format != null) {
			String extension = '.' + format.getDOSExtension();
			if (!objectName.toLowerCase().endsWith(extension.toLowerCase())) {
				objectName = objectName + extension;
			}
		}

		name.append(objectName);
		return name.toString();
	}

	/**
	 * Send mail notification to user
	 * @param session Documentum Super user session
	 * @param contextUser LoggedIn user
	 * @param userFolder Exported folder path
	 * @throws DfException
	 */
	protected void processMailNotification(IDfSession session, String contextUser, String userFolder)
			throws DfException {
		// Send message
		
		ID2MailConfig mailConfig = D2MailConfig.getInstance(session);
		MailSender mailSender = mailConfig.getMailSender();

		DfLogger.debug(this, "-------Sending Email With Details:------", null, null);
		DfLogger.debug(this, "Email Sent To User Names : " + contextUser, null, null);

		MailMessage msg = new MailMessage();
		msg.setFrom(mailConfig.getFromInternetAddress());

		try {
			InternetAddress listToAddress = getEmailAdressOfRecipients(contextUser, session);

			msg.setTo(listToAddress);

			String mailSubject = "Submission Export successfull";
			String mailBody = "Submission Export is successfull and the files should be available in the regional File Store Export locations under the Folder Name - "
					+ userFolder;
			DfLogger.debug(this, "Email Sent with Subject :  " + mailSubject, null, null);
			DfLogger.debug(this, "Email Sent with Body : " + mailBody, null, null);

			msg.setSubject(mailSubject);
			msg.setContent(mailBody, true);
			mailSender.sendMessage(msg);

		} catch (Exception e) {
			DfLogger.error(this, "-----Error sending Email------" + getClass() + ":sendMessage", null, e);
		}
	}

	/**
	 * Get the Internet Address based on email ID specified in user object in Documentum system
	 * @param userName DM User name
	 * @param session Documentum Super user session
	 * @return Internet Address of logged in user for sending emails.
	 * @throws DfException
	 * @throws AddressException
	 */
	protected InternetAddress getEmailAdressOfRecipients(String userName, IDfSession session)
			throws DfException, AddressException {
		IDfUser user = session.getUser(userName);
		if (!StringUtils.isNullOrEmpty(user.getUserAddress())) {
			return new InternetAddress(user.getUserAddress());
		} else {
			return null;
		}
	}

}
