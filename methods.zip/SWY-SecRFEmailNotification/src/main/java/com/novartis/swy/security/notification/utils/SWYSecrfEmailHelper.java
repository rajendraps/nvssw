/**
 * 
 */
package com.novartis.swy.security.notification.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

import com.documentum.d2.model.D2Dictionary;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfUser;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.services.config.util.StringUtil;
import com.documentum.utils.StringUtils;

/**
 * @author patilk
 */
public class SWYSecrfEmailHelper {
	
	public static final String[] DICTIONARY_COL_NAMES = { "message", "subject", "mail_to", "mail_cc" };
	
	/**
	 * This method will process the dictionary and retun a map with message,subject,to,cc
	 * 
	 * @param sysObject
	 * @return Map, which will have documents attributes as key and SecRF
	 *         attributes as value
	 * @throws Exception
	 */
	public Map<String, String> getDictionaryValues(IDfSession session, String dictionaryName, String templateName)
			throws Exception {

		DfLogger.debug(this, "Fetching the values from dictionary", null, null);
		// String
		// dictionary_name=ISWYApplySECRFConstants.SRF_FILTER_ATTR_DICTIOANRY_NAME;
		Map<String, String> secRFMailMap = null;
		D2Dictionary dAttr = D2Dictionary.getDictionary(dictionaryName, session, null, null, true, false);
		for (String colName : DICTIONARY_COL_NAMES) {
			Map<String, String> m_attr_map = dAttr.getKeyToAliasValueMap(colName);
			if (secRFMailMap == null)
				secRFMailMap = new HashMap<String, String>();
			secRFMailMap.put(colName, m_attr_map.get(templateName));
			DfLogger.debug(this, "Fetching Values from Dictionary. Key : "+colName+"--value:"+m_attr_map.get(templateName), null, null);

		}

		return secRFMailMap;
	}
	
	/**
	 * The Method Fetches user address from dm_user object and convert into Internet address
	 * @param listUser List of UserNames
	 * @param session Dctm Session
	 * @return List<InternetAddress>
	 * @throws DfException
	 */
	public List<InternetAddress> getEmailAdressOfRecipients(ArrayList<String> listUser, IDfSession session)
			throws Exception {
		List<InternetAddress> emailAdresses = null;
		if (listUser.size() > 0)
			emailAdresses = new ArrayList<>();
		for (String string : listUser) {
			IDfUser user = session.getUser(string);
			if (!StringUtils.isNullOrEmpty(user.getUserAddress())) {
				InternetAddress address = new InternetAddress(user.getUserAddress());
				emailAdresses.add(address);
			}

		}

		return emailAdresses;

	}

	/**
	 * This Method Removes Duplicates from the arrayList
	 * @param arr String ArrayList with duplicate Values
	 * @return String ArrayList without duplicate Values
	 * @throws
	 */
	public ArrayList<String> removeDuplicatesFromArrayList(ArrayList<String> list) throws Exception{
				
		
		Set<String> hs = new HashSet<>();
		hs.addAll(list);
		list.clear();
		list.addAll(hs);
		
		return list;
	}

	/**
	 * This Method Removes Duplicates from the array
	 * @param arr String Array with duplicate Values
	 * @return String Array without duplicate Values
	 * @throws
	 */
	public String[] removeDuplicatesFromArray(String[] arr)  throws Exception{
		if(arr.length>0){
			
		Set<String> set = new HashSet<String>(Arrays.asList(arr));
		arr = set.toArray(new String[set.size()]);
		
		return arr;
		}
		return null;
	}

	/**
	 * The method Replace $value(Attr_Name) in a string with values
	 * @param value Original String
	 * @param attributes attrNames to be replaced
	 * @param attributeValue Array of attrValues
	 * @return String String with replaced values
	 * @throws Exception
	 */
	public String replaceAttributeValues(String value, String[] attributes, String[] attributeValue)  throws Exception{
		
		for (int i = 0; i < attributes.length; i++) {
			if (value.contains(attributes[i]))
				value = value.replace("$value(" + attributes[i] + ")", attributeValue[i]);
		}
		
		return value;
	}
	
	/**
	 * The Method breaks the arguments to key pair hash map
	 * @param argumentVal The Dctm Method Arguments
	 * @return HashMap Return the Dctm Method Args to hashmap Key value pair
	 * @throws
	 */
	public HashMap<String , String>  getMapFromArguments(String argumentVal)
	{
		HashMap<String, String> parserMap=new HashMap<String , String>();

		String replacedStr=replaceChar(argumentVal,"-","~");
		DfLogger.debug(this," ~~~~~~~~ Notification Scenario  ["+replacedStr+"] ~~~~~~~~ ",null,null);

		List<String> noti_list=split(replacedStr, "-");

		for(int cntr=0;cntr<noti_list.size();cntr++)
		{
			String argParam=noti_list.get(cntr);

			if(argParam!=null && !argParam.trim().equalsIgnoreCase(""))
			{
				String argParserKey="-"+(argParam.substring(0, argParam.indexOf(" ")).trim());
				String argParserValue=(argParam.substring(argParam.indexOf(" "),argParam.length()).trim()).replaceAll("~", "-");

				parserMap.put(argParserKey, argParserValue);
				DfLogger.debug(this,"Parser Key ["+argParserKey+"] Parser Value ["+argParserValue+"]",null,null);
			}
		}

		return parserMap;
	}
	
	/**
	 * The Method replace the Characters in a String
	 * @param str input String
	 * @param charToReplace Characters to be replaced
	 * @param seperator 
	 * @return String
	 * @throws
	 */
	public String replaceChar(String str,String charToReplace ,String Separator)
	{
		String returnStr="";

		//returnStr=str.replaceAll("(?<!\\w)-(?!\\w)", "~");
		returnStr=str.replaceAll("(?<=\\S)"+charToReplace+"(?=\\S)", Separator);	//Search space in string surrounded with some other character, except space, from both end and then replace - with ~
		return returnStr.trim();
	}
	
	/**
	 * Split a String with a separator to a arrayList
	 * @param text Input text
	 * @param seperator The separator used to split
	 * @return ArrayList of Separated String
	 */
	public List<String> split(String text, String separator)
	{
		List<String> result = new ArrayList<String>();

		if (text != null)
		{
			if ((separator == null) || (separator.length() == 0)) {
				result.add(text.trim());
				System.out.println("texttt=["+text+"]");
			}
			else {
				int posStart = 0;
				int posEnd = text.indexOf(separator);

				while (posEnd != -1)
				{
					String token = text.substring(posStart, posEnd).trim();
					result.add(token);
					System.out.println("tokennn=["+token+"]");
					posStart = posEnd + separator.length();
					posEnd = text.indexOf(separator, posStart);
				}

				if (posStart <= text.length())
				{
					String token = text.substring(posStart).trim();
					result.add(token);
					System.out.println("token=["+token+"]");
				}
			}
		}

		return result;
	}
	/**
	 * This method gets email id of user from dm_user object
	 * @param arrList List of user names
	 * @param session Dctm Session
	 * @return List of email address
	 * @throws DfException
	 */
	public ArrayList<String> getEmailOfUserAsList(ArrayList<String> arrList,IDfSession session) throws DfException
	{
		DfLogger.debug(this, "----Get Email of Users--", null, null);
		
		ArrayList<String> email = new ArrayList<>();
		for (String user : arrList) {
			//DfLogger.debug(this, "Fetching Email of User--"+user, null,null);
			IDfUser tmpUser = session.getUser(user);
			//Get email address if tmp user is not Null;
			if(tmpUser!=null)
			{
				email.add(tmpUser.getUserAddress());
			//	DfLogger.debug(this, tmpUser.getUserAddress(), null,null);
			}
			else
				email.add("");
		}
		
		
		return email;
		
	}

}
