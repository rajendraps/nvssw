package com.novartis.swy.security.notification.method;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;

import javax.mail.internet.InternetAddress;

import com.documentum.d2.exceptions.ConfigurationException;
import com.documentum.d2.model.D2Dictionary;
import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfModule;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.impl.util.StringUtil;
import com.documentum.utils.StringUtils;
import com.emc.common.java.javamail.MailMessage;
import com.emc.common.java.javamail.MailSender;
import com.emc.common.java.utils.ArgumentNotFoundException;
import com.emc.common.java.utils.ArgumentParser;
import com.emc.common.java.utils.ArrayUtil;
import com.emc.d2.api.config.mail.D2MailConfig;
import com.emc.d2.api.config.mail.ID2MailConfig;
import com.emc.d2.api.methods.D2Method;
import com.emc.d2.api.methods.D2methodBean;
import com.emc.d2.api.methods.ID2Method;
import com.novartis.swy.security.notification.utils.SWYSecrfEmailHelper;

/**
 * * * <br>
 * Comments: Method to send email Notification related to documents for which
 * secrf is applied or updated<br>
 * 
 * @author kpatil(Karthik Patil)
 * 
 * *************JIRA 2959*******************************************
 * Date : 21-Dec-2020 , Author : SHUBHKU1, SUKANRA1
 * Re-factored code, handled collection leak issue (JIRA# 2959)
 * *****************************************************************
 *
 */
public class SWYSecrfEmailNotification implements ID2Method, IDfModule {

	private String baseD2URL = null;
	public final static String SYSTEM_PARAMETERS_DICTIONARY = "System Parameters";
	public final static String D2_URL_PREFIX_SYSTEM_PARTAMETER = "d2_url";
	public final static String SYSTEM_PARTAMETER_ALIAS = "Value";
	public final static String SECRF_NOTIFICATION_DICTIONARY = "CMN-DIC-SecRF User Notification";
	public final static String NOTIFY_MESSAGE = "notify_message";
	public final static String MAIL_HEADER = "HEADER";
	public final static String MAIL_BODY = "BODY";
	public final static String MAIL_FOOTER = "FOOTER";
	public static final String ARG_TARGET_IDS = "-target_ids";
	public static final String ARG_TEMPLATE_NAME = "-template_name";

	public static final String ARG_SEPERATOR = "-seperator";
	public static final String[] DICTIONARY_COL_NAMES = { "message", "subject", "mail_to", "mail_cc" };
	public static final String[] VARIABLES_IN_MAIL = { "secrf_name", "document_name" };
	public static final String SECRF_NOTIFICATION_OBJECT_TYPE = "swy_secrf_mail_notification";
	public static final String ARG_MAIL_SCENARIO = "-mail_scenario";
	public static final String ARG_APPLIED_BY = "-applied_by";
	public static final String ARG_SECRF_ID = "-secrf_id";

	public static final String ATTR_VALUE_CONFLICT = "Conflict";
	public static final String ATTR_VALUE_NON_CONFLICT = "Non-Conflict";

	public static final String TEMPLATE_MANUAL_SECRF_NOT_FOUND = "MANUAL_SECRF_NOT_FOUND";
	public static final String TEMPLATE_SecRF_NEW_CONFLICTED_MANAGER_ONLY ="SecRF_NEW_CONFLICTED_MANAGER_ONLY";
	public static final String TEMPLATE_SecRF_EXISTING_ALL = "SecRF_EXISTING_ALL";
	public static final String TEMPLATE_SecRF_EXISTING_ACTION_REQUIRED = "SecRF_EXISTING_ACTION_REQUIRED";
	public static final String TEMPLATE_SecRF_NEW_CONFLICTED = "SecRF_NEW_CONFLICTED";
	public static final String TEMPLATE_SecRF_NEW_NON_CONFLICTED = "SecRF_NEW_NON_CONFLICTED";
	ArrayList<String> targetids = null;
	String templateName = null;
	//String secMngrName = null;
	String seperator = null;
	String appliedBy = null;
	String secrfName =null;

	/**
	 * Method to send email Notification related to documents for which secrf is
	 * applied or updated
	 * 
	 * @param session
	 *            Dctm Session
	 * @param job
	 *            r_object_id of the job
	 * @param local
	 *            locale
	 * @param argParser
	 *            This carries all the arguments passed to the method to execute
	 * @return D2MethodBean
	 * @throws Exception
	 */
	@Override
	public D2methodBean execute(IDfSession session, IDfSysObject job, Locale local, ArgumentParser argParser)
			throws Exception {
		boolean argAvailable = false;
		DfLogger.debug(this, "-----------Executing SecRF Notification Method----------", null, null);
		SWYSecrfEmailHelper swyHelper = new SWYSecrfEmailHelper();
		Iterator<Entry<String, String>> ArgParserIterator = argParser.iterator();

		while (ArgParserIterator.hasNext()) {
			Entry<String, String> tmpEntry = ArgParserIterator.next();
			String tmpNotiKey = tmpEntry.getKey().toLowerCase().trim();
			DfLogger.debug(this, "--Argument Name :" + tmpNotiKey + "--Value: " + tmpEntry.getValue(), null, null);
			if (tmpNotiKey.startsWith(ARG_MAIL_SCENARIO)) {
				argAvailable = true;

				String tmpNotiVal = tmpEntry.getValue();
				HashMap<String, String> parserMap = swyHelper.getMapFromArguments(tmpNotiVal);

				ArgumentParser argumentParser = new ArgumentParser(parserMap);

				try {
					DfLogger.debug(this, "--Executing Sending Emails for Arguments:", null, null);
					DfLogger.debug(this, ARG_TARGET_IDS + "--" + argumentParser.getStringArgument(ARG_TARGET_IDS), null,
							null);
					DfLogger.debug(this, ARG_TEMPLATE_NAME + "--" + argumentParser.getStringArgument(ARG_TEMPLATE_NAME),
							null, null);
					executeSendingEmails(session, argumentParser, swyHelper);
					DfLogger.debug(this, "Scenario of Notification ::" + tmpNotiKey + "", null, null);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					DfLogger.debug(this, "Exception in execute Send Email--"+e.getMessage(), null,e);
				}
			} 
		}
		if (!argAvailable) {
			throw new IllegalArgumentException("Missing Scenario Arguement: -mail_scenario");

		}
		return new D2methodBean(D2Method.RETURN_SUCCESS, null);
	}

	/**
	 * Process Template Name and send email
	 * 
	 * @param session
	 *            Dctm Session
	 * @param argumentParser
	 *            carries targetids, templateName, Appliedby and secrf_name
	 * @param swyhelper
	 *            Helper object
	 * @return
	 * @throws ArgumentNotFoundException 
	 * @throws DfException 
	 * @throws ConfigurationException 
	 * @throws Exception
	 */
	public void executeSendingEmails(IDfSession session, ArgumentParser argumentParser, SWYSecrfEmailHelper swyHelper) throws Exception
	{

		DfLogger.debug(this, "---Started Executing Sending Email Method-", null, null);

		templateName="";
		appliedBy ="";

		if (StringUtil.isEmptyOrNull(argumentParser.getStringArgument(ARG_SEPERATOR,null)))
			seperator = ",";
		else
			seperator = argumentParser.getStringArgument(ARG_SEPERATOR,",");



		if (!StringUtil.isEmptyOrNull(argumentParser.getStringArgument(ARG_TARGET_IDS,null))) {
			targetids = new ArrayList<String>(
					Arrays.asList(argumentParser.getStringArgument(ARG_TARGET_IDS).split(seperator)));

		}


		if (!StringUtil.isEmptyOrNull(argumentParser.getStringArgument(ARG_TEMPLATE_NAME,null))) {
			templateName = argumentParser.getStringArgument(ARG_TEMPLATE_NAME,null);

		}
		else
			templateName="";


		if (!StringUtil.isEmptyOrNull(argumentParser.getStringArgument(ARG_APPLIED_BY,null))) {
			appliedBy = argumentParser.getStringArgument(ARG_APPLIED_BY);

		}
		else
			appliedBy="";

		if (!StringUtil.isEmptyOrNull(argumentParser.getStringArgument(ARG_SECRF_ID,null))) {
			secrfName = getSecRFObjectName(argumentParser.getStringArgument(ARG_SECRF_ID),session);

		}
		else
			secrfName="";


		if (targetids != null && !StringUtil.isEmptyOrNull(templateName)) {
			baseD2URL = getBaseD2Url(session);
			String repoName = session.getDocbaseName();

			DfLogger.debug(this, "---start Processing Mail Notification---"+targetids+"--secrFName--"+secrfName+"--appliedBy--"+appliedBy, null, null);
			try{
				processMailNotification(session, baseD2URL, repoName, swyHelper);
			}
			catch (Exception e) {
				DfLogger.debug(this, "Exception in ProcessMail Notification--"+e.getMessage(), null,e);
			}
			DfLogger.debug(this, "---END Processing Mail Notification---"+targetids, null, null);

		} else {

			DfLogger.debug(this, "Email Not sent. Reason: Missing Paramters(targetids or templateName)", null, null);
			throw new IllegalArgumentException("Missing targetids and templateName arguments");
		}

	}

	/**
	 * Processing the SecRF Mail Notificaiton
	 * 
	 * @param session
	 *            Documentum Session
	 * @param baseD2Url
	 *            D2 Url
	 * @param repoName
	 *            Repository Name
	 * @throws Exception
	 */
	public void processMailNotification(IDfSession session, String baseD2Url, String repoName,
			SWYSecrfEmailHelper swyHelper) throws Exception {
		DfLogger.debug(this, "Processing Email Notification", null, null);

		StringBuilder mailSubject = null;
		StringBuilder mailBody = null;

		// Get email Subject,Body,recipients from D2 Dictionary based on
		// TemplateName

		// Send Email based on the TemplateName

		if (templateName.equalsIgnoreCase(TEMPLATE_SecRF_EXISTING_ALL)) {

			Map<String, String> dictionaryValues = swyHelper.getDictionaryValues(session, SECRF_NOTIFICATION_DICTIONARY,
					templateName);



			String locateUrl = null;
			String[] mail_to_attribute = null;
			String[] mail_cc_attribute = null;
			String[] tableColNames = new String[] { "Document Name", "Previous Authors", "New Authors","Restricted Status","Is Workflow Aborted?" };
			// ArrayList<String> sec_manager = new ArrayList<>();
			HashMap<String, HashMap<String, String>> mailDocItems = new HashMap<>();

			if (!StringUtil.isEmptyOrNull(dictionaryValues.get("mail_to")))
				mail_to_attribute = dictionaryValues.get("mail_to").split(";");
			if (!StringUtil.isEmptyOrNull(dictionaryValues.get("mail_cc")))
				mail_cc_attribute = dictionaryValues.get("mail_cc").split(";");
			ArrayList<String> mail_to = null;
			ArrayList<String> mail_cc = null;
			if (!StringUtils.isNullOrEmpty(mail_to_attribute))
				mail_to = new ArrayList<>();
			else if (!StringUtils.isNullOrEmpty(mail_cc_attribute))
				mail_cc = new ArrayList<>();

			for (int i = 0; i < targetids.size(); i++) {
				String notificationObjectQuery = "select r_object_id,swy_previous_authors,swy_new_authors,swy_form_managers,swy_doc_security_status,swy_comment,swy_is_workflow_aborted from "
						+ SECRF_NOTIFICATION_OBJECT_TYPE + " where swy_doc_object_id='" + targetids.get(i) + "'";
				IDfCollection coll=null;
				try
				{
					coll = new DfQuery(notificationObjectQuery).execute(session, IDfQuery.DF_EXEC_QUERY);
					while (coll.next()) {
						if (mail_to != null) {

							for (String attr : mail_to_attribute) {
								mail_to.addAll(new ArrayList<String>(
										Arrays.asList(coll.getAllRepeatingStrings(attr, seperator).split(seperator))));
							}

						}

						if (mail_cc != null) {

							for (String attr : mail_cc_attribute) {
								mail_cc.addAll(new ArrayList<String>(
										Arrays.asList(coll.getAllRepeatingStrings(attr, seperator).split(seperator))));
							}

						}

						IDfSysObject sysObject = (IDfSysObject) session.getObject(new DfId(targetids.get(i)));
						HashMap<String, String> attrValue = new HashMap<>();
						attrValue.put("Document Name", sysObject.getObjectName());
						if(!StringUtil.isEmptyOrNull(coll.getAllRepeatingStrings("swy_previous_authors", ";")))
						{
							attrValue.put("Previous Authors",
									ArrayUtil.join(
											swyHelper.removeDuplicatesFromArray(
													coll.getAllRepeatingStrings("swy_previous_authors", ";").split(";")),
											";"));
						}
						else
							attrValue.put("Previous Authors","");
						if(!StringUtil.isEmptyOrNull(coll.getAllRepeatingStrings("swy_new_authors", ";")))
						{	
							attrValue
							.put("New Authors",
									ArrayUtil.join(
											swyHelper.removeDuplicatesFromArray(
													coll.getAllRepeatingStrings("swy_new_authors", ";").split(";")),
											";"));
						}
						else
							attrValue.put("New Authors","");
						attrValue.put("Restricted Status", coll.getString("swy_comment"));
						attrValue.put("Is Workflow Aborted?", coll.getBoolean("swy_is_workflow_aborted")?"Yes":"No");
						mailDocItems.put(targetids.get(i), attrValue);

					}
				}
				finally
				{
					if (coll != null)
						coll.close();
				}
			}
			if(targetids.size()>0)
			{
				//IDfSysObject sysObject = (IDfSysObject) session.getObject(new DfId(targetids.get(0)));
				if(mail_to!=null)
					mail_to = swyHelper.removeDuplicatesFromArrayList(mail_to);
				if(mail_cc!=null)
					mail_cc = swyHelper.removeDuplicatesFromArrayList(mail_cc);
				if (mailSubject == null)
					mailSubject = new StringBuilder();
				mailSubject.append(swyHelper.replaceAttributeValues(dictionaryValues.get("subject"),
						new String[] { "secrf_name" }, new String[] {  "\""+secrfName+"\""}));

				if (mailBody == null)
					mailBody = new StringBuilder();
				mailBody.append("<table><tr>");
				mailBody.append(swyHelper.replaceAttributeValues(dictionaryValues.get("message"),
						new String[] { "secrf_manager" }, new String[] { "\""+appliedBy+"\""  }));
				mailBody.append("</tr></table></br>");

				mailBody.append("<table border='1'>");
				for (int j = 0; j < tableColNames.length; j++) {
					mailBody.append("<th>");
					mailBody.append(tableColNames[j]);
					mailBody.append("</th>");
				}

				Iterator iterAr = mailDocItems.entrySet().iterator();
				while (iterAr.hasNext()) {
					String docName = "";
					String preAuthor ="";
					String newAuthor ="";
					String restrictedStatus="";
					String isWorkflowAborted="";
					mailBody.append("<tr>");
					Map.Entry pair = (Map.Entry) iterAr.next();
					HashMap<String, String> colValues = new HashMap<>();
					colValues = (HashMap<String, String>) pair.getValue();
					Iterator it = colValues.entrySet().iterator();
					while (it.hasNext()) {
						Map.Entry pair1 = (Map.Entry) it.next();
						if (pair1.getKey().equals(tableColNames[0])) {
							if (baseD2Url != null) {
								locateUrl = getDocUrl(baseD2Url, pair.getKey().toString(), repoName);
							}
							docName = "<a href='" + locateUrl + "'>" + pair1.getValue() + "</a>";
						} else if (pair1.getKey().equals(tableColNames[1])) {
							preAuthor = (String) pair1.getValue();

						} else if (pair1.getKey().equals(tableColNames[2])) {
							newAuthor = (String) pair1.getValue();
						} else if (pair1.getKey().equals(tableColNames[3])) {
							restrictedStatus = (String) pair1.getValue();
						} else if (pair1.getKey().equals(tableColNames[4])) {
							isWorkflowAborted = (String) pair1.getValue();
						}

					}

					for(int tmp =0;tmp<tableColNames.length;tmp++)
					{
						mailBody.append("<td>");
						if(tmp==0)
							mailBody.append(docName);
						else if(tmp==1)
							mailBody.append(preAuthor);
						else if(tmp==2)
							mailBody.append(newAuthor);
						else if(tmp==3)
							mailBody.append(restrictedStatus);
						else if(tmp==4)
							mailBody.append(isWorkflowAborted);
						mailBody.append("</td>");
					}
					mailBody.append("</tr>");

				}
				mailBody.append("</table>");
				ID2MailConfig mailConfig = D2MailConfig.getInstance(session);
				MailSender mailSender = mailConfig.getMailSender();

				sendMessage(mailSender, mailSubject.toString(), mailBody.toString(), mail_to, mail_cc,
						mailConfig.getFromInternetAddress(), session, swyHelper);
			}





		} else if (templateName.equalsIgnoreCase(TEMPLATE_SecRF_EXISTING_ACTION_REQUIRED)) {
			Map<String, String> dictionaryValues = swyHelper.getDictionaryValues(session, SECRF_NOTIFICATION_DICTIONARY,
					templateName);
			String locateUrl = null;
			String[] mail_to_attribute = null;

			String[] tableColNames = new String[] { "Document Name", "Previous Authors", "New Authors",
					"Restricted Status","Is Workflow Aborted?" };
			// ArrayList<String> sec_manager = new ArrayList<>();
			HashMap<String, HashMap<String, String>> actionRequired = new HashMap<>();
			HashMap<String, HashMap<String, String>> actionNotRequired = new HashMap<>();

			if (!StringUtil.isEmptyOrNull(dictionaryValues.get("mail_to")))
				mail_to_attribute = dictionaryValues.get("mail_to").split(";");

			ArrayList<String> mail_to = null;
			if (!StringUtils.isNullOrEmpty(mail_to_attribute))
				mail_to = new ArrayList<>();

			for (int i = 0; i < targetids.size(); i++) {
				String notificationObjectQuery = "select r_object_id,swy_previous_authors,swy_new_authors,swy_form_managers,swy_doc_security_status,swy_comment,swy_is_workflow_aborted from "
						+ SECRF_NOTIFICATION_OBJECT_TYPE + " where swy_doc_object_id='" + targetids.get(i) + "'";
				IDfCollection coll=null;
				boolean idExists =false;
				try
				{
					coll = new DfQuery(notificationObjectQuery).execute(session, IDfQuery.DF_EXEC_QUERY);				
					while (coll.next()) {
						idExists =true;
						HashMap<String, String> attrMap = new HashMap<>();
						if (mail_to != null) {

							for (String attr : mail_to_attribute) {
								mail_to.addAll(new ArrayList<String>(
										Arrays.asList(coll.getAllRepeatingStrings(attr, seperator).split(seperator))));
							}

						}

						if (coll.getString("swy_doc_security_status").equals(ATTR_VALUE_CONFLICT)) {
							IDfSysObject sysObject = (IDfSysObject) session.getObject(new DfId(targetids.get(i)));
							HashMap<String, String> attrValue = new HashMap<>();
							attrValue.put("Document Name", sysObject.getObjectName());
							if(!StringUtil.isEmptyOrNull(coll.getAllRepeatingStrings("swy_previous_authors", ";")))
							{
								attrValue.put("Previous Authors",
										ArrayUtil.join(
												swyHelper.removeDuplicatesFromArray(
														coll.getAllRepeatingStrings("swy_previous_authors", ";").split(";")),
												";"));
							}
							else
								attrValue.put("Previous Authors","");
							if(!StringUtil.isEmptyOrNull(coll.getAllRepeatingStrings("swy_new_authors", ";")))
							{	
								attrValue
								.put("New Authors",
										ArrayUtil.join(
												swyHelper.removeDuplicatesFromArray(
														coll.getAllRepeatingStrings("swy_new_authors", ";").split(";")),
												";"));
							}
							else
								attrValue.put("New Authors","");
							attrValue.put("Restricted Status", coll.getString("swy_comment"));
							attrValue.put("Is Workflow Aborted?", coll.getBoolean("swy_is_workflow_aborted")?"Yes":"No");
							actionRequired.put(targetids.get(i), attrValue);
						}

						if (StringUtil.isEmptyOrNull(coll.getString("swy_doc_security_status"))
								|| coll.getString("swy_doc_security_status").equals(ATTR_VALUE_NON_CONFLICT)) {
							IDfSysObject sysObject = (IDfSysObject) session.getObject(new DfId(targetids.get(i)));
							HashMap<String, String> attrValue = new HashMap<>();

							attrValue.put("Document Name", sysObject.getObjectName());
							if(!StringUtil.isEmptyOrNull(coll.getAllRepeatingStrings("swy_previous_authors", ";")))
							{
								attrValue.put("Previous Authors",
										ArrayUtil.join(
												swyHelper.removeDuplicatesFromArray(
														coll.getAllRepeatingStrings("swy_previous_authors", ";").split(";")),
												";"));
							}
							else
								attrValue.put("Previous Authors","");
							if(!StringUtil.isEmptyOrNull(coll.getAllRepeatingStrings("swy_new_authors", ";")))
							{	
								attrValue
								.put("New Authors",
										ArrayUtil.join(
												swyHelper.removeDuplicatesFromArray(
														coll.getAllRepeatingStrings("swy_new_authors", ";").split(";")),
												";"));
							}
							else
								attrValue.put("New Authors","");
							attrValue.put("Restricted Status", coll.getString("swy_comment"));
							attrValue.put("Is Workflow Aborted?", coll.getBoolean("swy_is_workflow_aborted")?"Yes":"No");
							actionNotRequired.put(targetids.get(i), attrValue);
						}

					}
				}
				finally
				{
					if (coll != null)
						coll.close();
				}
				if(!idExists)
				{
					DfLogger.debug(this, "---ID :"+targetids.get(i)+" doesnt exist in Email Notification Object.Hence will be Ignored", null,null);
					targetids.remove(i);
				}

			}
			if(targetids.size()>0)
			{
				IDfSysObject sysObject = (IDfSysObject) session.getObject(new DfId(targetids.get(0)));
				if(mail_to!=null)
					mail_to = swyHelper.removeDuplicatesFromArrayList(mail_to);

				if (mailSubject == null)
					mailSubject = new StringBuilder();
				mailSubject.append(swyHelper.replaceAttributeValues(dictionaryValues.get("subject"),
						new String[] { "secrf_name" }, new String[] { "\""+secrfName+"\"" }));

				if (mailBody == null)
					mailBody = new StringBuilder();
				mailBody.append("<table><tr>");
				mailBody.append(swyHelper.replaceAttributeValues(dictionaryValues.get("message"),
						new String[] { "secrf_manager" }, new String[] { "\""+appliedBy+"\"" }));
				mailBody.append("</tr></table>");
				if(actionRequired.size()>0)
				{
					mailBody.append("</br><table><tr><b><u>Conflicts To Resolve</u></b></tr></table>");
					mailBody.append("<table border='1'>");
					for (int j = 0; j < tableColNames.length; j++) {
						mailBody.append("<th>");
						mailBody.append(tableColNames[j]);
						mailBody.append("</th>");
					}
					Iterator iterAr = actionRequired.entrySet().iterator();
					while (iterAr.hasNext()) {
						String docName = "";
						String preAuthor ="";
						String newAuthor ="";
						String restrictedStatus="";
						String isWorkflowAborted="";
						mailBody.append("<tr>");
						Map.Entry pair = (Map.Entry) iterAr.next();
						HashMap<String, String> colValues = new HashMap<>();
						colValues = (HashMap<String, String>) pair.getValue();
						Iterator it = colValues.entrySet().iterator();
						while (it.hasNext()) {
							Map.Entry pair1 = (Map.Entry) it.next();
							if (pair1.getKey().equals(tableColNames[0])) {
								if (baseD2Url != null) {
									locateUrl = getDocUrl(baseD2Url, pair.getKey().toString(), repoName);
								}
								docName = "<a href='" + locateUrl + "'>" + pair1.getValue() + "</a>";
							} else if (pair1.getKey().equals(tableColNames[1])) {
								preAuthor = (String) pair1.getValue();

							} else if (pair1.getKey().equals(tableColNames[2])) {
								newAuthor = (String) pair1.getValue();
							} else if (pair1.getKey().equals(tableColNames[3])) {
								restrictedStatus = (String) pair1.getValue();
							} else if (pair1.getKey().equals(tableColNames[4])) {
								isWorkflowAborted = (String) pair1.getValue();
							}

						}

						for(int tmp =0;tmp<tableColNames.length;tmp++)
						{
							mailBody.append("<td>");
							if(tmp==0)
								mailBody.append(docName);
							else if(tmp==1)
								mailBody.append(preAuthor);
							else if(tmp==2)
								mailBody.append(newAuthor);
							else if(tmp==3)
								mailBody.append(restrictedStatus);
							else if(tmp==4)
								mailBody.append(isWorkflowAborted);
							mailBody.append("</td>");
						}
						mailBody.append("</tr>");

					}
					mailBody.append("</table>");
				}
				if(actionNotRequired.size()>0)
				{	
					mailBody.append("</br><table><tr><td><b><u>Action Not Required</u></b></td><tr></table></br>");

					mailBody.append("<table border='1'>");
					for (int j = 0; j < tableColNames.length; j++) {
						mailBody.append("<th>");
						mailBody.append(tableColNames[j]);
						mailBody.append("</th>");
					}

					Iterator iterAnr = actionNotRequired.entrySet().iterator();

					while (iterAnr.hasNext()) {
						String docName = "";
						String preAuthor ="";
						String newAuthor ="";
						String restrictedStatus="";
						String isWorkflowAborted="";
						mailBody.append("<tr>");
						Map.Entry pair = (Map.Entry) iterAnr.next();
						HashMap<String, String> colValues = new HashMap<>();
						colValues = (HashMap<String, String>) pair.getValue();
						Iterator it = colValues.entrySet().iterator();
						while (it.hasNext()) {
							Map.Entry pair1 = (Map.Entry) it.next();
							if (pair1.getKey().equals(tableColNames[0])) {
								if (baseD2Url != null) {
									locateUrl = getDocUrl(baseD2Url, pair.getKey().toString(), repoName);
								}
								docName = "<a href='" + locateUrl + "'>" + pair1.getValue() + "</a>";
							} else if (pair1.getKey().equals(tableColNames[1])) {
								preAuthor = (String) pair1.getValue();

							} else if (pair1.getKey().equals(tableColNames[2])) {
								newAuthor = (String) pair1.getValue();
							} else if (pair1.getKey().equals(tableColNames[3])) {
								restrictedStatus = (String) pair1.getValue();
							} else if (pair1.getKey().equals(tableColNames[4])) {
								isWorkflowAborted = (String) pair1.getValue();
							}

						}

						for(int tmp =0;tmp<tableColNames.length;tmp++)
						{
							mailBody.append("<td>");
							if(tmp==0)
								mailBody.append(docName);
							else if(tmp==1)
								mailBody.append(preAuthor);
							else if(tmp==2)
								mailBody.append(newAuthor);
							else if(tmp==3)
								mailBody.append(restrictedStatus);
							else if(tmp==4)
								mailBody.append(isWorkflowAborted);
							mailBody.append("</td>");
						}
						mailBody.append("</tr>");

					}
					mailBody.append("</table>");
				}
				ID2MailConfig mailConfig = D2MailConfig.getInstance(session);
				MailSender mailSender = mailConfig.getMailSender();

				sendMessage(mailSender, mailSubject.toString(), mailBody.toString(), mail_to, null,
						mailConfig.getFromInternetAddress(), session, swyHelper);
			}
			else
			{
				DfLogger.debug(this,"----Ids Doesnt exist in Email Notification--------", null,null);
			}

		} else if (templateName.equalsIgnoreCase(TEMPLATE_SecRF_NEW_CONFLICTED)) {
			Map<String, String> dictionaryValues = swyHelper.getDictionaryValues(session, SECRF_NOTIFICATION_DICTIONARY,
					templateName);

			String locateUrl = null;
			String[] mail_to_attribute = null;
			ArrayList<String> sec_manager = new ArrayList<>();
			ArrayList<String> sec_manager_email = new ArrayList<>();
			if (!StringUtil.isEmptyOrNull(dictionaryValues.get("mail_to")))
				mail_to_attribute = dictionaryValues.get("mail_to").split(";");
			ArrayList<String> mail_to = null;

			if (!StringUtils.isNullOrEmpty(mail_to_attribute))
				mail_to = new ArrayList<>();

			for (int i = 0; i < targetids.size(); i++) {
				String notificationObjectQuery = "select r_object_id,swy_previous_authors,swy_new_authors,swy_form_managers,swy_doc_security_status from "
						+ SECRF_NOTIFICATION_OBJECT_TYPE + " where swy_doc_object_id='" + targetids.get(i) + "'";
				IDfCollection coll = null;
				boolean idExists =false;
				try
				{
					coll = new DfQuery(notificationObjectQuery).execute(session, IDfQuery.DF_EXEC_QUERY);
					while (coll.next()) {
						idExists = true;
						if (mail_to != null) {

							for (String attr : mail_to_attribute) {
								DfLogger.debug(this, "--mail_to_attribute:" + attr + "--value:"
										+ (String[]) (coll.getAllRepeatingStrings(attr, seperator).split(seperator)), null,
										null);

								mail_to.addAll(new ArrayList<String>(
										Arrays.asList(coll.getAllRepeatingStrings(attr, seperator).split(seperator))));
							}
						}
						sec_manager.addAll(new ArrayList<String>(Arrays
								.asList(coll.getAllRepeatingStrings("swy_form_managers", seperator).split(seperator))));
					}
				}
				finally
				{
					if (coll != null)
						coll.close();
				}
				if(!idExists)
				{

					DfLogger.debug(this, "---ID :"+targetids.get(i)+" doesnt exist in Email Notification Object.Hence will be Ignored", null,null);
					targetids.remove(i);
				}

			}
			if(targetids.size()>0)
			{

				mail_to = swyHelper.removeDuplicatesFromArrayList(mail_to);
				sec_manager = swyHelper.removeDuplicatesFromArrayList(sec_manager);
				sec_manager_email = swyHelper.getEmailOfUserAsList(sec_manager, session);
				IDfSysObject sysObject = (IDfSysObject) session.getObject(new DfId(targetids.get(0)));

				if (mailSubject == null)
					mailSubject = new StringBuilder();
				mailSubject.append(dictionaryValues.get("subject")+"-"+sysObject.getObjectName());

				String secMngrs = "";

				for(int i=0;i<sec_manager.size();i++)
				{
					if(!StringUtils.isNullOrEmpty(sec_manager.get(i)))
						secMngrs += "<a href='mailto:"+sec_manager_email.get(i)+"'>\""+ sec_manager.get(i)+"\"</a>" + "</br>";
					else
						secMngrs += sec_manager.get(i)+"\"</a>" + "</br>";	
				}

				if (mailBody == null)
					mailBody = new StringBuilder();

				if (baseD2Url != null) {
					locateUrl = getDocUrl(baseD2Url, targetids.get(0), repoName);
				}


				mailBody.append(swyHelper.replaceAttributeValues(dictionaryValues.get("message"),
						new String[] { "document_name", "form_managers" },
						new String[] {"<a href='" + locateUrl + "'>\""+ sysObject.getObjectName()+"\"</a>", secMngrs }));

				ID2MailConfig mailConfig = D2MailConfig.getInstance(session);
				MailSender mailSender = mailConfig.getMailSender();

				sendMessage(mailSender, mailSubject.toString(), mailBody.toString(), mail_to, null,
						mailConfig.getFromInternetAddress(), session, swyHelper);
			}
			else
			{
				DfLogger.debug(this,"----Ids Doesnt exist in Email Notification--------", null,null);
			}

		} else if (templateName.equalsIgnoreCase(TEMPLATE_SecRF_NEW_CONFLICTED_MANAGER_ONLY)) {
			Map<String, String> dictionaryValues = swyHelper.getDictionaryValues(session, SECRF_NOTIFICATION_DICTIONARY,
					templateName);
			String locateUrl = null;
			String[] mail_to_attribute = null;
			ArrayList<String> sec_manager = new ArrayList<>();
			ArrayList<String> sec_manager_email = new ArrayList<>();
			if (!StringUtil.isEmptyOrNull(dictionaryValues.get("mail_to")))
				mail_to_attribute = dictionaryValues.get("mail_to").split(";");

			ArrayList<String> mail_to = null;

			if (!StringUtils.isNullOrEmpty(mail_to_attribute))
				mail_to = new ArrayList<>();

			for (int i = 0; i < targetids.size(); i++) {
				String notificationObjectQuery = "select r_object_id,swy_previous_authors,swy_new_authors,swy_form_managers,swy_doc_security_status from "
						+ SECRF_NOTIFICATION_OBJECT_TYPE + " where swy_doc_object_id='" + targetids.get(i) + "'";
				IDfCollection coll = null;
				boolean idExists =false;
				try
				{
					coll = new DfQuery(notificationObjectQuery).execute(session, IDfQuery.DF_EXEC_QUERY);
					while (coll.next()) {
						idExists = true;
						if (mail_to != null) {

							for (String attr : mail_to_attribute) {
								mail_to.addAll(new ArrayList<String>(
										Arrays.asList(coll.getAllRepeatingStrings(attr, seperator).split(seperator))));
							}

						}
						sec_manager.addAll(new ArrayList<String>(Arrays
								.asList(coll.getAllRepeatingStrings("swy_form_managers", seperator).split(seperator))));
					}
				}
				finally
				{
					if (coll != null)
						coll.close();
				}
				if(!idExists)
				{

					DfLogger.debug(this, "---ID :"+targetids.get(i)+" doesnt exist in Email Notification Object.Hence will be Ignored", null,null);
					targetids.remove(i);
				}
			}
			if(targetids.size()>0)
			{
				mail_to = swyHelper.removeDuplicatesFromArrayList(mail_to);
				sec_manager = swyHelper.removeDuplicatesFromArrayList(sec_manager);
				sec_manager_email = swyHelper.getEmailOfUserAsList(sec_manager, session);
				IDfSysObject sysObject = (IDfSysObject) session.getObject(new DfId(targetids.get(0)));

				if (mailSubject == null)
					mailSubject = new StringBuilder();
				mailSubject.append(dictionaryValues.get("subject"));
				mailSubject.append("-"+sysObject.getObjectName());

				String secMngrs = "";

				for(int i=0;i<sec_manager.size();i++)
				{
					if(!StringUtils.isNullOrEmpty(sec_manager.get(i)))
						secMngrs += "<a href='mailto:"+sec_manager_email.get(i)+"'>\""+ sec_manager.get(i)+"\"</a>" + "</br>";
					else
						secMngrs += sec_manager.get(i)+"\"</a>" + "</br>";	
				}

				if (mailBody == null)
					mailBody = new StringBuilder();

				if (baseD2Url != null) {
					locateUrl = getDocUrl(baseD2Url, targetids.get(0), repoName);
				}

				mailBody.append(swyHelper.replaceAttributeValues(dictionaryValues.get("message"),
						new String[] { "document_name", "form_managers" },
						new String[] {"<a href='" + locateUrl + "'>\""+ sysObject.getObjectName()+"\"</a>", secMngrs }));
				ID2MailConfig mailConfig = D2MailConfig.getInstance(session);
				MailSender mailSender = mailConfig.getMailSender();

				sendMessage(mailSender, mailSubject.toString(), mailBody.toString(), mail_to, null,
						mailConfig.getFromInternetAddress(), session, swyHelper);
			}
			else
			{
				DfLogger.debug(this,"----Ids Doesnt exist in Email Notification--------", null,null);
			}

		} else if (templateName.equalsIgnoreCase(TEMPLATE_SecRF_NEW_NON_CONFLICTED)) {
			Map<String, String> dictionaryValues = swyHelper.getDictionaryValues(session, SECRF_NOTIFICATION_DICTIONARY,
					templateName);

			String locateUrl = null;
			String[] mail_to_attribute = null;
			// ArrayList<String> sec_manager = new ArrayList<>();
			if (!StringUtil.isEmptyOrNull(dictionaryValues.get("mail_to")))
				mail_to_attribute = dictionaryValues.get("mail_to").split(";");

			ArrayList<String> mail_to = null;

			if (!StringUtils.isNullOrEmpty(mail_to_attribute))
				mail_to = new ArrayList<>();

			for (int i = 0; i < targetids.size(); i++) {
				String notificationObjectQuery = "select r_object_id,swy_previous_authors,swy_new_authors,swy_form_managers,swy_doc_security_status from "
						+ SECRF_NOTIFICATION_OBJECT_TYPE + " where swy_doc_object_id='" + targetids.get(i) + "'";
				IDfCollection coll=null;
				boolean idExists =false;
				try
				{
					coll = new DfQuery(notificationObjectQuery).execute(session, IDfQuery.DF_EXEC_QUERY);

					while (coll.next()) {
						idExists =true;
						if (mail_to != null) {

							for (String attr : mail_to_attribute) {

								mail_to.addAll(new ArrayList<String>(
										Arrays.asList(coll.getAllRepeatingStrings(attr, seperator).split(seperator))));
							}
						}
					}
				}
				finally
				{
					if (coll != null)
						coll.close();
				}
				if(!idExists)
				{

					DfLogger.debug(this, "---ID :"+targetids.get(i)+" doesnt exist in Email Notification.Hence will be Ignored", null,null);
					targetids.remove(i);
				}
			}
			if(targetids.size()>0)
			{
				mail_to = swyHelper.removeDuplicatesFromArrayList(mail_to);

				IDfSysObject sysObject = (IDfSysObject) session.getObject(new DfId(targetids.get(0)));

				if (mailSubject == null)
					mailSubject = new StringBuilder();
				mailSubject.append(dictionaryValues.get("subject"));
				mailSubject.append("-"+sysObject.getObjectName());

				if (mailBody == null)
					mailBody = new StringBuilder();

				if (baseD2Url != null) {
					locateUrl = getDocUrl(baseD2Url, targetids.get(0), repoName);
				}
				mailBody.append(swyHelper.replaceAttributeValues(dictionaryValues.get("message"),
						new String[] { "document_name", "secrf_name" },
						new String[] {"<a href='" + locateUrl + "'>\""+ sysObject.getObjectName()+"\"</a>", "\""+sysObject.getString("swy_security_rest_form")+"\"" }));

				ID2MailConfig mailConfig = D2MailConfig.getInstance(session);
				MailSender mailSender = mailConfig.getMailSender();

				sendMessage(mailSender, mailSubject.toString(), mailBody.toString(), mail_to, null,
						mailConfig.getFromInternetAddress(), session, swyHelper);
			}
			else
			{
				DfLogger.debug(this,"----Ids Doesnt exist in Email Notification--------", null,null);
			}
		}else if (templateName.equalsIgnoreCase(TEMPLATE_MANUAL_SECRF_NOT_FOUND)) {
			Map<String, String> dictionaryValues = swyHelper.getDictionaryValues(session, SECRF_NOTIFICATION_DICTIONARY,
					templateName);

			String locateUrl = null;
			String[] mail_to_attribute = null;
			// ArrayList<String> sec_manager = new ArrayList<>();
			if (!StringUtil.isEmptyOrNull(dictionaryValues.get("mail_to")))
				mail_to_attribute = dictionaryValues.get("mail_to").split(";");

			ArrayList<String> mail_to = null;

			if (!StringUtils.isNullOrEmpty(mail_to_attribute))
				mail_to = new ArrayList<>();

			for (int i = 0; i < targetids.size(); i++) {
				String notificationObjectQuery = "select r_object_id,swy_previous_authors,swy_new_authors,swy_form_managers,swy_doc_security_status from "
						+ SECRF_NOTIFICATION_OBJECT_TYPE + " where swy_doc_object_id='" + targetids.get(i) + "'";
				IDfCollection coll = null;
				boolean idExists =false;
				try
				{
					coll = new DfQuery(notificationObjectQuery).execute(session, IDfQuery.DF_EXEC_QUERY);
					while (coll.next()) {
						idExists =true;
						if (mail_to != null) {

							for (String attr : mail_to_attribute) {

								mail_to.addAll(new ArrayList<String>(
										Arrays.asList(coll.getAllRepeatingStrings(attr, seperator).split(seperator))));
							}

						}

					}
				}
				finally
				{
					if (coll != null)
						coll.close();
				}
				if(!idExists)
				{
					DfLogger.debug(this, "---ID :"+targetids.get(i)+" doesnt exist in Email Notification.Hence will be Ignored", null,null);
					targetids.remove(i);
				}
			}
			if(targetids.size()>0)
			{
				mail_to = swyHelper.removeDuplicatesFromArrayList(mail_to);

				IDfSysObject sysObject = (IDfSysObject) session.getObject(new DfId(targetids.get(0)));

				if (mailSubject == null)
					mailSubject = new StringBuilder();
				mailSubject.append(dictionaryValues.get("subject"));
				mailSubject.append("-"+sysObject.getObjectName());

				if (mailBody == null)
					mailBody = new StringBuilder();

				if (baseD2Url != null) {
					locateUrl = getDocUrl(baseD2Url, targetids.get(0), repoName);
				}
				mailBody.append(swyHelper.replaceAttributeValues(dictionaryValues.get("message"),
						new String[] { "document_name" },
						new String[] {"<a href='" + locateUrl + "'>\""+ sysObject.getObjectName()+"\"</a>"}));

				ID2MailConfig mailConfig = D2MailConfig.getInstance(session);
				MailSender mailSender = mailConfig.getMailSender();

				sendMessage(mailSender, mailSubject.toString(), mailBody.toString(), mail_to, null,
						mailConfig.getFromInternetAddress(), session, swyHelper);
			}
			else
			{
				DfLogger.debug(this,"----Ids Doesnt exist in Email Notification--------", null,null);
			}
		}

	}

	/**
	 * Retrieve D2 URL
	 * 
	 * @param session
	 *            IDf Session
	 * @return D2 URL configured in the System Administrator Dictionary
	 * @throws DfException
	 * @throws ConfigurationException
	 */
	private String getBaseD2Url(IDfSession session) throws DfException, ConfigurationException {
		baseD2URL = D2Dictionary.getAliasValue(SYSTEM_PARAMETERS_DICTIONARY, D2_URL_PREFIX_SYSTEM_PARTAMETER,
				SYSTEM_PARTAMETER_ALIAS, session, null, null, true, false);
		if ((baseD2URL == null) || (baseD2URL.length() == 0)) {
			throw new ConfigurationException(
					"The base D2 client URL must be specified in the D2 \"" + SYSTEM_PARAMETERS_DICTIONARY
					+ "\" dictionary to enable links in the mail notification that are navigable within D2. Specify the relevant D2 client URL in the \""
					+ SYSTEM_PARTAMETER_ALIAS + "\" alias of the \"" + D2_URL_PREFIX_SYSTEM_PARTAMETER
					+ "\" parameter.");
		}
		DfLogger.debug(this, "Using base D2 client URL: {0}", new String[] { baseD2URL }, null);
		return baseD2URL;
	}

	/**
	 * Process the locate URL for document
	 * 
	 * @param baseD2Url
	 *            D2 URL
	 * @param objectId
	 *            r_object_id of document
	 * @param repoName
	 *            Docbase name
	 * @return
	 */
	private String getDocUrl(String baseD2Url, String objectId, String repoName) {
		DfLogger.debug(this, "Url After document processed {0}",
				new String[] { baseD2Url + "?locateId=" + objectId + "&docbase=" + repoName }, null);
		return baseD2Url + "?locateId=" + objectId + "&docbase=" + repoName;
	}

	public static boolean isStringExistinArray(String[] arr, String targetValue) {
		for (String s : arr) {
			if (s.equals(targetValue))
				return true;
		}
		return false;
	}

	/**
	 * Sending email
	 * 
	 * @param mailSender
	 * 
	 * @param mailSubject
	 *            Subject of the Email
	 * @param mailBody
	 *            Body of the Email
	 * @param addressTo
	 *            Internet address recepients
	 * @param addressFrom
	 *            Internet address of Sender
	 * 
	 * @throws DfException
	 **/
	private void sendMessage(MailSender mailSender, String mailSubject, String mailBody, ArrayList<String> addressTo,
			ArrayList<String> addressCC, InternetAddress addressFrom, IDfSession session, SWYSecrfEmailHelper helper)
					throws DfException {
		// Send message

		DfLogger.debug(this, "-------Sending Email With Details:------", null, null);
		DfLogger.debug(this, "Email Sent To User Names"+ArrayUtil.join(addressTo,";"),null, null);

		MailMessage msg = new MailMessage();
		msg.setFrom(addressFrom);

		List<InternetAddress> listToAddress = new ArrayList<InternetAddress>();
		List<InternetAddress> listccAddress = null;

		try {
			listToAddress = helper.getEmailAdressOfRecipients(addressTo, session);

			msg.setTo(listToAddress);

			if (addressCC != null) {
				DfLogger.debug(this, "Email Sent CC User Names :" + ArrayUtil.join(addressCC, ";"), null, null);

				listccAddress = new ArrayList<InternetAddress>();
				listccAddress = helper.getEmailAdressOfRecipients(addressCC, session);

				msg.setCc((InternetAddress[]) listccAddress.toArray());
			}
			DfLogger.debug(this, "Email Sent with Subject : " + mailSubject, null, null);
			DfLogger.debug(this, "Email Sent with Body : " + mailBody, null, null);

			msg.setSubject(mailSubject);
			msg.setContent(mailBody, true);
			mailSender.sendMessage(msg);
			// DfLogger.debug(this, "Send mail To : {}", addressTo, null);
			// LOG.info("Send mail To : {}", addressTo);

		} catch (Exception e) {
			DfLogger.error(this, "-----Error sending Email------" + getClass() + ":sendMessage", null, e);
		}
	}

	/**
	 * Get SecRF Name from SecRF object id
	 * 
	 * @param secrfID Object Id of Secrf
	 * 
	 * @param session
	 *            Dctm Session
	 * @throws DfException
	 **/
	private String getSecRFObjectName(String secrfID,IDfSession session) throws DfException
	{
		IDfSysObject secrfObj = (IDfSysObject) session.getObject(new DfId(secrfID));
		DfLogger.debug(this, "SecRF Name from Passed SecRF ID ::: {0}",
				new String[] { secrfObj.getObjectName()}, null);

		return secrfObj.getObjectName();
	}

}
