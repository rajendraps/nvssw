package com.novartis.swy.tmf.trial.methods;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import com.documentum.cdf.methods.CreateRelation;
import com.documentum.cdf.methods.DeleteRelation;
import com.documentum.fc.client.IDfModule;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.impl.util.StringUtil;
import com.documentum.utils.AttributeExpression;
import com.documentum.utils.QueryUtils;
import com.documentum.utils.StringUtils;
import com.emc.common.java.utils.ArgumentParser;
import com.emc.d2.api.methods.D2methodBean;
import com.emc.d2.api.methods.ID2Method;
import com.novartis.swy.tmf.trial.utils.ISWYTrialLockUnlockConstants;

/**
 * D2 server method that freeze "TMF Source File Link" relations to the version
 * there were linked to when a trial is locked and creates relation with current
 * version when trial is unlocked.
 * <p>
 * <strong>Method-specific arguments:</strong>
 * <ul>
 * <li><strong>-id</strong> -
 * <p style="text-indent :5em;">
 * This is a mandatory argument and it should be r_object_id of Clinical Trial
 * Registration Form
 * </p>
 * <li><strong>-action_type</strong> -
 * <p style="text-indent :5em;">
 * This is a mandatory argument and valid values to this are "Lock" when trial
 * is locked and "UnLock" when trial is Unlocked <strong></strong>.
 * </p>
 * </li>
 * <li><strong>-if</strong> -
 * <p style="text-indent :5em;">
 * This is an optional argument
 * </p>
 * </li>
 * </ul>
 *  
 * @author kpatil
 **/
public class SWYTrialLockUnlockUpdateRelation implements IDfModule, ID2Method {
	String preCondition = null;
	IDfId trialId = null;
	String actionType = null;
	String trialInfoObjectType = null;
	String crossOverRelationName = null;
	String crossOverCopyRelationName = null;
	String context_user = null;
	String relation_type_create=null;
	String relation_type_remove=null;
	String reset_relation="false";
	boolean preConditionPass = false;

	@Override
	public D2methodBean execute(IDfSession session, IDfSysObject paramIDfSysObject, Locale paramLocale,
			ArgumentParser paramArgumentParser) throws Exception {

		trialId = paramArgumentParser.getIdArgument(ISWYTrialLockUnlockConstants.PARAMETER_ID, null);
		actionType = paramArgumentParser.getStringArgument(ISWYTrialLockUnlockConstants.PARAMETER_ACTION, null);
		preCondition = paramArgumentParser.getStringArgument(ISWYTrialLockUnlockConstants.PARAMETER_PRE_CONDITION,
				null);
		context_user = paramArgumentParser.getStringArgument(ISWYTrialLockUnlockConstants.PARAMETER_CONTEXT_USER, null);
		relation_type_create = paramArgumentParser.getStringArgument(ISWYTrialLockUnlockConstants.PARAMETER_RELATION_TYPE_CREATE, null);
		relation_type_remove = paramArgumentParser.getStringArgument(ISWYTrialLockUnlockConstants.PARAMETER_RELATION_TYPE_REMOVE, null);
		reset_relation = paramArgumentParser.getStringArgument(ISWYTrialLockUnlockConstants.PARAMETER_RESET_RELATIONS, "false");
		
		if(relation_type_create==null)
		{
			if(actionType.equalsIgnoreCase(ISWYTrialLockUnlockConstants.ACTION_TYPE_LOCK))
			{
				relation_type_create=ISWYTrialLockUnlockConstants.CROSS_OVER_RELATION_NAME_COPY;
			}
			else if(actionType.equalsIgnoreCase(ISWYTrialLockUnlockConstants.ACTION_TYPE_UNLOCK))
			{
				relation_type_create=ISWYTrialLockUnlockConstants.CROSS_OVER_RELATION_NAME;
			}
		}
		
		if(relation_type_remove==null)
		{
			if(actionType.equalsIgnoreCase(ISWYTrialLockUnlockConstants.ACTION_TYPE_LOCK))
			{
				relation_type_remove=ISWYTrialLockUnlockConstants.CROSS_OVER_RELATION_NAME;
			}
			else if(actionType.equalsIgnoreCase(ISWYTrialLockUnlockConstants.ACTION_TYPE_UNLOCK))
			{
				relation_type_remove=ISWYTrialLockUnlockConstants.CROSS_OVER_RELATION_NAME_COPY;
			}
		}

		D2methodBean bean = null;
		DfLogger.info(this, "[INFO]:TRIAL ID :" + trialId.getId().toString(), null, null);
		DfLogger.debug(this,
				"**********************************************************************************************************************",
				null, null);
		DfLogger.info(this, "[INFO]: ACTION TYPE :" + actionType, null, null);
		DfLogger.debug(this,
				"**********************************************************************************************************************",
				null, null);
		DfLogger.info(this, "[INFO]:PRE-CONDITION : " + preCondition, null, null);
		DfLogger.debug(this,
				"**********************************************************************************************************************",
				null, null);
		DfLogger.info(this, "[INFO]: CONTEXT USER : " + context_user, null, null);
		DfLogger.debug(this,
				"**********************************************************************************************************************",
				null, null);
		DfLogger.warn(this, "[WARN]: RELATION TO CREATE : " + relation_type_create, null, null);
		DfLogger.warn(this, "[WARN]: RELATION TO DELETE : " + relation_type_remove, null, null);
		DfLogger.warn(this, "[WARN]: RESET RELATIONS : " + reset_relation, null, null);

		if (context_user == null || context_user.trim().equalsIgnoreCase("")) {
			context_user = session.getLoginUserName();
			DfLogger.debug(this, "Updated Context User as  " + context_user, null, null);
		}
		IDfSysObject trialObject = null;
		if (trialId != null && trialId.isObjectId()) {
			if (!StringUtil.isEmptyOrNull(actionType)) {
				if (actionType.equals(ISWYTrialLockUnlockConstants.ACTION_TYPE_LOCK)
						|| actionType.equals(ISWYTrialLockUnlockConstants.ACTION_TYPE_UNLOCK)) {

					trialObject = (IDfSysObject) session.getObject(trialId);
					DfLogger.info(this, "Precondition as passed from application  > " + preCondition, null, null);
					if (StringUtil.isEmptyOrNull(preCondition)) {
						if (trialObject.getTypeName().equals(ISWYTrialLockUnlockConstants.TRIAL_OBJECT_TYPE)) {
							preConditionPass = true;
						} else {
							DfLogger.info(this,
									"[INFO] : Object with id[" + trialId.getId().toString() + "] is not of type "
											+ ISWYTrialLockUnlockConstants.TRIAL_OBJECT_TYPE + ". Cannot be processed",
									null, null);
						}

					} else {

						if (trialObject.getTypeName().equals(ISWYTrialLockUnlockConstants.TRIAL_OBJECT_TYPE)) {
							preCondition = AttributeExpression.resolve(preCondition, trialObject, context_user);
							if (!QueryUtils.checkObjectConditionExpression(trialObject, preCondition, session))
								preConditionPass = false;
						} else {
							DfLogger.info(this,
									"[INFO] : Trial[" + trialObject.getString("clinical_trial_id") + "]--Object ID ["
											+ trialId.getId().toString() + "] is not of type "
											+ ISWYTrialLockUnlockConstants.TRIAL_OBJECT_TYPE + ". Cannot be processed",
									null, null);
						}

					}

					if (preConditionPass) {
						DfLogger.info(this, "[INFO] : Processing Trial[" + trialObject.getString("clinical_trial_id")
								+ "]--Object ID [" + trialId.getId().toString() + "]", null, null);
						
						if (actionType.equals(ISWYTrialLockUnlockConstants.ACTION_TYPE_LOCK)) {
							session.beginTrans();
								processTrialLock(trialObject, session, paramLocale);
							if(session.isTransactionActive())
							{
								session.commitTrans();
								return new D2methodBean(ISWYTrialLockUnlockConstants.D2METHODBEAN_SUCCESS);
							}
							else
							{
								session.abortTrans();
								return new D2methodBean(ISWYTrialLockUnlockConstants.D2METHODBEAN_FAILURE);
							}
						} else if (actionType.equals(ISWYTrialLockUnlockConstants.ACTION_TYPE_UNLOCK)) {
							session.beginTrans();
							processTrialUnLock(trialObject, session, paramLocale);
							
							if(session.isTransactionActive())
							{
								session.commitTrans();
								return new D2methodBean(ISWYTrialLockUnlockConstants.D2METHODBEAN_SUCCESS);
							}
							else
							{
								session.abortTrans();
								return new D2methodBean(ISWYTrialLockUnlockConstants.D2METHODBEAN_FAILURE);
							}
						}

					}

				} else {
					DfLogger.info(this, "[Invalid Argument] : -action_type argument is Invalid", null, null);

				}
			} else {
				throw new IllegalArgumentException("[Illegal Argument Exception] : -action_type parameter is null");
			}
		} else {
			throw new IllegalArgumentException("[Illegal Argument Exception] : -id argument is null or Invalid");
		}

		return null;
	}

	/**
	 * processTrialLock Method checks for "TMF Source File Link" relations of Cross
	 * Over Docs of the trial and creates a freezed relation with relation name "TMF
	 * Source File Link - Locked"
	 * 
	 * @param trialObj
	 *            Trial Object
	 * @param session
	 *            User Session
	 * @param locale
	 *            locale
	 * @throws DfException
	 */
	private void processTrialLock(IDfSysObject trialObj, IDfSession session, Locale locale) throws DfException {
		String[] parentIds = null;

		String parentObjectIDsQuery = "select distinct(parent_id) from dm_relation where relation_name='"
				+ relation_type_remove
				+ "' and parent_id in(select r_object_id from cd_clinical_tmf_doc where tmf_scope != 'Product' and clinical_trial_id='"
				+ trialObj.getString(ISWYTrialLockUnlockConstants.ATTR_NAME_CLIN_TRIAL_ID) + "')";
		DfLogger.debug(this, "[INFO] : parentObjectIDsQuery--" + parentObjectIDsQuery, null, null);
		parentIds = QueryUtils.getAllQueryResultsAsStrings(parentObjectIDsQuery, session);
		if (!StringUtils.isNullOrEmpty(parentIds)) {
			for (String parentId : parentIds) {
				IDfSysObject sysObj = (IDfSysObject) session.getObject(new DfId(parentId));

				String targetIds[] = QueryUtils.getAllQueryResultsAsStrings(
						"select child_id from dm_relation where parent_id='" + sysObj.getObjectId()
								+ "' and relation_name='" + relation_type_remove + "'",
						session);

				for (String targetId : targetIds) {
					IDfSysObject targetObj = (IDfSysObject) session.getObject(new DfId(targetId));
					if (!targetObj.getLatestFlag()) {

						targetObj = QueryUtils.getUniqueObjectByQuery(
								"select r_object_id from cd_controlled_doc where i_chronicle_id='"
										+ targetObj.getString("i_chronicle_id") + "'",
								session, true, false);

					}
					CreateRelation createRelation = new CreateRelation();
					Map<String, String> argMap = new HashMap<>();
					argMap.put("-id", parentId);
					argMap.put("-relation_type", relation_type_create);
					argMap.put("-target_object_id", targetId);
					argMap.put("-unique", "true");
					argMap.put("-permanent_link", "true");
					argMap.put("-child_version", "SYMBOLIC");
					argMap.put("-child_version_label", targetObj.getVersionLabel(0));
					argMap.put("-parent", "true");
					argMap.put("-audit", "true");
					argMap.put("-context_user", context_user);
					argMap.put("-reset_relations", reset_relation);

					ArgumentParser arg = new ArgumentParser(argMap);
					try {
						createRelation.execute(session, sysObj, locale, arg);
					} catch (Exception e) {
						DfLogger.error(this,
								"[CREATE RELATION ERROR] : COPY/Create Relation failed during Lock for TRIAL ID : "
										+ sysObj.getString("clinical_trial_id") + " for Parent ID : " + parentId
										+ " and Child ID :" + targetId + " " + e.getMessage(),
								null, null);
					}

				}
				Map<String, String> argMap = new HashMap<>();
				DeleteRelation delRelation = new DeleteRelation();
				argMap.put("-id", parentId);
				argMap.put("relation_type", relation_type_remove);
				argMap.put("-audit", "true");
				argMap.put("-parent", "true");
				ArgumentParser arg = new ArgumentParser(argMap);
				try {
					delRelation.execute(session, sysObj, locale, arg);
				} catch (Exception e) {
					DfLogger.error(this,
							"[DELETE RELATION ERROR] : Delete Relation failed during Lock for TRIAL ID : "
									+ sysObj.getString("clinical_trial_id") + " for Parent ID : " + parentId,
							null, null);
				}

			}
		}
	}

	/**
	 * processTrialUnLock Method checks for "TMF Source File Link - Locked"
	 * relations of Cross Over Docs of the trial and recreates relation with name
	 * "TMF Source File Link" with current Version of the document
	 * 
	 * @param trialObj
	 *            Trial Object
	 * @param session
	 *            User Session
	 * @param locale
	 *            locale
	 * @throws DfException
	 */
	private void processTrialUnLock(IDfSysObject trialObj, IDfSession session, Locale locale) throws DfException {
		String[] parentIds = null;

		String parentObjectIDsQuery = "select distinct(parent_id) from dm_relation where relation_name='"
				+ relation_type_remove
				+ "' and parent_id in(select r_object_id from cd_clinical_tmf_doc where tmf_scope != 'Product' and clinical_trial_id='"
				+ trialObj.getString(ISWYTrialLockUnlockConstants.ATTR_NAME_CLIN_TRIAL_ID) + "')";
		DfLogger.debug(this, "[INFO] : parentObjectIDsQuery--" + parentObjectIDsQuery, null, null);
		parentIds = QueryUtils.getAllQueryResultsAsStrings(parentObjectIDsQuery, session);
		if (!StringUtils.isNullOrEmpty(parentIds)) {
			for (String parentId : parentIds) {
				IDfSysObject sysObj = (IDfSysObject) session.getObject(new DfId(parentId));
				String targetIds[] = QueryUtils
						.getAllQueryResultsAsStrings("select child_id from dm_relation where parent_id='"
								+ sysObj.getObjectId() + "' and relation_name='"
								+ relation_type_remove + "'", session);

				for (String targetId : targetIds) {
					IDfSysObject targetObj = (IDfSysObject) session.getObject(new DfId(targetId));
					if (!targetObj.getLatestFlag()) {
						targetObj = QueryUtils.getUniqueObjectByQuery(
								"select r_object_id from cd_controlled_doc where i_chronicle_id='"
										+ targetObj.getString("i_chronicle_id") + "'",
								session, true, false);
					}
					CreateRelation createRelation = new CreateRelation();
					Map<String, String> argMap = new HashMap<>();					
					argMap.put("-id", parentId);
					argMap.put("-relation_type", relation_type_create);
					argMap.put("-target_object_id", targetId);
					argMap.put("-permanent_link", "true");
					argMap.put("-parent", "true");
					argMap.put("-audit", "true");
					argMap.put("-reset_relations", reset_relation);
					argMap.put("-context_user", context_user);
					ArgumentParser arg = new ArgumentParser(argMap);
					try {
						createRelation.execute(session, sysObj, locale, arg);
					} catch (Exception e) {
						DfLogger.error(this,
								"[CREATE RELATION ERROR] : COPY/Create Relation failed during Unlock for TRIAL ID : "
										+ sysObj.getString("clinical_trial_id") + e.getMessage(),
								null, null);
					}
				}
				Map<String, String> argMap = new HashMap<>();
				DeleteRelation delRelation = new DeleteRelation();
				argMap.put("-id", parentId);
				argMap.put("relation_type", relation_type_remove);
				argMap.put("-audit", "true");
				argMap.put("-parent", "true");
				ArgumentParser arg = new ArgumentParser(argMap);
				try {
					delRelation.execute(session, sysObj, locale, arg);
				} catch (Exception e) {
					DfLogger.error(this,
							"[DELETE RELATION ERROR] : Delete Relation failed during Unlock for TRIAL ID : "
									+ sysObj.getString("clinical_trial_id") + " for Parent ID : " + parentId,
							null, null);
				}

			}
		}
	}

}
