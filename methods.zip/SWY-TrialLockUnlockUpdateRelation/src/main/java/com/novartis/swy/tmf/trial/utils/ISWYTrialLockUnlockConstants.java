package com.novartis.swy.tmf.trial.utils;

public interface ISWYTrialLockUnlockConstants {
	
	final public static String PARAMETER_ID="-id";
	final public static String PARAMETER_ACTION="-action_type";
	final public static String PARAMETER_PRE_CONDITION="-if";
	final public static String PARAMETER_CONTEXT_USER = "-context_user";
	final public static String PARAMETER_RELATION_TYPE_CREATE = "-relation_type_create";
	final public static String PARAMETER_RELATION_TYPE_REMOVE = "-relation_type_remove";
	final public static String PARAMETER_RESET_RELATIONS ="-reset_relations";
	
	final public static String ACTION_TYPE_LOCK="Lock";
	final public static String ACTION_TYPE_UNLOCK="UnLock";
	
	final public static String CROSS_OVER_RELATION_NAME="TMF Source File Link";
	final public static String CROSS_OVER_RELATION_NAME_COPY="TMF Source File Link - Locked";
	
	
	final public static String TRIAL_OBJECT_TYPE = "cd_clinical_trial_info";
	
	final public static String ATTR_NAME_CLIN_TRIAL_ID = "clinical_trial_id";
	
	final public static String D2METHODBEAN_SUCCESS = "SUCCESS";
	final public static String D2METHODBEAN_FAILURE = "FAILED"; 
}
