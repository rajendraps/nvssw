// appKey attribute needs to be updated for different environments
//  --------------------------
// | DEV-MIG-INT environment  |
// | appKey = 'EC-AAB-FYX'    |
//  --------------------------
// 
//  -------------------------
// | QA environment  		 |
// | appKey = 'EC-AAB-KSW'   |
//  -------------------------
// 
//  ------------------------- 
// | PROD environment  		 |
// | appKey =''			     |
//  -------------------------
// Parameterizing this value so it can be replaced by Pipeline scripts

window['adrum-start-time'] = new Date().getTime();

(function(config){

   config.appKey = '###APP_KEY###';

   config.adrumExtUrlHttp = 'http://cdn.appdynamics.com';

   config.adrumExtUrlHttps = 'https://cdn.appdynamics.com';

   config.beaconUrlHttp = 'http://fra-col.eum-appdynamics.com';

   config.beaconUrlHttps = 'https://fra-col.eum-appdynamics.com';

   config.xd = {enable : false};

   config.spa = {"spa2": true};

   config.keepFullPageUrl = true;
   
   config.xhr = {

		payloadParams: [{method: 'POST'}]

	};
   
   config.userEventInfo =  {
		"Ajax" : function(context) {
			
			
		
			
			var payloadIndexes = {
				class: 7
				, method: 8
				, extended_username: [10,11]
			}
			
			function cleanupPayloadForRpcDialogService_getOptions(data) {
				for(var i=14;i<=40;i++) {
					//we do not hide property_config value
					if(i!=16 && i!= 17) data[i] = 'REDACTED';
				}
				return data.join("|");
			}
			function cleanupPayloadForRpcLoginService_initContext(data) {
				//removing password from the payload
				data[15] = "REDACTED";
				return data.join("|");
			}
			function cleanupPayloadForRpcDoclistService_getMenusForType(data) {
				for(var i=18;i<=59;i++) {
					data[i] = 'REDACTED';
				}
				return data.join("|");
			}
			
			function cleanupPayloadForRpcCreationService_isAFolderOrACabinet(data) {
				for(var i=14;i<=59;i++) {
					data[i] = 'REDACTED';
				}
				return data.join("|");
			}
			
			
			returnValue = {};
			var userData = {};
			if(typeof context != 'undefined') {
				
				if(typeof context.data != 'undefined') {
				
					if(typeof context.url != 'undefined') {
						if(typeof context.url.endsWith != 'undefined') {
							if(context.url.endsWith('CheckInWithLifeCycle')) {

								var username = context.data.get("_username");
								if(typeof username != 'undefined') {
									userData.username = username;

								}
								var requestpayload='';
								var keys = Object.keys(context.data);
								
								var keys = context.data.keys();
								for (var key of keys) {
									if(key != 'uploadFile' && key  != '_password') {
										requestpayload+=key+':'+ context.data.get(key)+';';
									}
									
								}

								userData.requestpayload = requestpayload;
							}
						}
					}
					
					
					if(typeof context.data.split != 'undefined') {
						var data = context.data.split("|");
						//extracting server side class and method name
						if (data[payloadIndexes.class] != 'undefined') 
							userData.class=data[payloadIndexes.class];
						if (data[payloadIndexes.method] != 'undefined') 
							userData.method=data[payloadIndexes.method];

						switch(userData.class) {
								case 'com.emc.x3.portal.client.components.dialog.RpcDialogService':
									switch(userData.method) {
										case 'getOptions':
											userData.requestpayload = cleanupPayloadForRpcDialogService_getOptions(data);
										break;
										default:
											userData.requestpayload = context.data;	
									}
								break;
								
								case 'com.emc.x3.portal.client.components.login.RpcLoginService':
									switch(userData.method) {
										case 'initContext':
											userData.requestpayload = cleanupPayloadForRpcLoginService_initContext(data);
										break;
										default:
											userData.requestpayload = context.data;
									}
								break;
								
								case 'com.emc.x3.client.services.RpcDoclistService':
									switch(userData.method) {
										case 'getMenusForType':
											userData.requestpayload = cleanupPayloadForRpcDoclistService_getMenusForType(data);
										break;
										default:
											userData.requestpayload = context.data;	
									}
								break;
								
								case 'com.emc.x3.portal.client.manager.create.RpcCreationService':
									switch(userData.method) {
										case 'isAFolderOrACabinet':
											userData.requestpayload = cleanupPayloadForRpcCreationService_isAFolderOrACabinet(data);
										break;
										default:
											userData.requestpayload = context.data;
									}
								break;
								
								default:
									userData.requestpayload = context.data;
							
						}
						
					
						//extracting username
						if(!userData.hasOwnProperty('username')) {
							for (var i=0;i<=payloadIndexes.extended_username.length;i++) {
								if(typeof data[payloadIndexes.extended_username[i]] != 'undefined') {
									var extended_username = data[payloadIndexes.extended_username[i]].split("-");
									if(typeof extended_username[2] != 'undefined') {
										userData.username = extended_username[2];
										break;
									} 
								} 
							}
						
						} 
						
					
					} 				
					
				} 
			} 


			returnValue.userData = userData;
			return returnValue;
		}
   }
})(window['adrum-config'] || (window['adrum-config'] = {}));


function loadjsfile(filename){
    var fileref=document.createElement('script')
    fileref.setAttribute("type","text/javascript")
    fileref.setAttribute("src", filename)
    if (typeof fileref!="undefined") {
		document.getElementsByTagName("head")[0].appendChild(fileref)
	}
}
loadjsfile('https://cdn.appdynamics.com/adrum/adrum-latest.js');
