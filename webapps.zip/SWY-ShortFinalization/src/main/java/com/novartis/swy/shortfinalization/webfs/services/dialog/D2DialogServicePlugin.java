package com.novartis.swy.shortfinalization.webfs.services.dialog;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.impl.util.StringUtil;
import com.documentum.utils.MethodHelper;
import com.documentum.utils.QueryUtils;
import com.emc.common.dctm.utils.DfSessionUtil;
import com.emc.common.java.utils.ArrayUtil;
import com.emc.common.java.utils.IVersion;
import com.emc.common.java.xml.XmlDocument;
import com.emc.common.java.xml.XmlNode;
import com.emc.common.java.xml.XmlNodeImpl;
import com.emc.common.java.xml.XmlUtil;
import com.emc.d2.api.methods.D2LifecycleChangeStateMethod;
import com.emc.d2.api.methods.D2Method;
import com.emc.d2fs.dctm.ui.XmlFactory;
import com.emc.d2fs.dctm.web.services.D2fsContext;
import com.emc.d2fs.dctm.web.services.ID2fsPlugin;
import com.emc.d2fs.dctm.web.services.dialog.D2DialogService;
import com.emc.d2fs.models.attribute.Attribute;
import com.emc.d2fs.models.context.Context;
import com.emc.d2fs.models.dialog.Dialog;
import com.novartis.swy.shortfinalization.SWYConstants;
import com.novartis.swy.shortfinalization.SWYShortFinalizationVersion;

public class D2DialogServicePlugin extends D2DialogService implements ID2fsPlugin {
	private static final IVersion VERSION = new SWYShortFinalizationVersion();

	public D2DialogServicePlugin() {
	}

	/**
	 * Override the default D2Dialog getDialog method for Short Finalization of Clinical TMF Documents
	 * 
	 * @param context   	The D2fsContext passed from user session.
	 * @param id 			The id holds the Object Ids of the objects selected
	 * @param dialogName	This parameter hold the dialog name that is being invoked
	 * @param paramters 	This holds all the parameters passed to the plugin like Date format, config name
	 * @return Dialog
	 * @throws IOException
	 */
	@Override
	public Dialog getDialog(Context context, String id, String dialogName, List<Attribute> parameters) throws Exception {
		LOG.debug("------------------Custom Dialog Plugin Service (Get Dialog Short Finalization)--------------");
		LOG.debug("Dialogue Name: " + dialogName);
		String[] inputIds = null;
		if (!StringUtil.isEmptyOrNull(id)) {
			inputIds = id.split("\254");
			LOG.debug("Selected IDs" + ArrayUtil.join(inputIds, "--"));
		}
		Dialog dialog = super.getDialog(context, id, dialogName, parameters);

		if (dialogName.equalsIgnoreCase(SWYConstants.D2_WORKFLOW_DIALOG)) {
			String processName = "";
			for (Attribute attr : parameters) {
				LOG.debug("Parms: " + attr.getName() + " - " + attr.getValue());
				if (attr.getName().equalsIgnoreCase("config")) {
					processName = attr.getValue();
					break;
				}
			}

			if (processName.equals(SWYConstants.SHORT_FINALIZATION_WORKFLOW)) {
				LOG.info("------------------Custom Dialog Plugin Service (Get Dialog Short Finalization)--------------");
				XmlDocument xmlDoc = XmlUtil.loadFromString(dialog.getXmlContent());

				XmlNode rootXmlNode = xmlDoc.getRootXmlNode();

				// Remove the Workflow Xml Content
				rootXmlNode.removeAllXmlNode();

					// Add Core Label Related Attributes Fields to XML

					/* LSS4.2 implementation
					 * 	XmlNode contentNode = new XmlNode("content");
						XmlNode fieldSetNode = new XmlNode("fieldset");
					
					*/
				
				/*LSS 16.6 implementation starts*/
					XmlNode contentNode = new XmlNodeImpl("content");
					XmlNode fieldSetNode = new XmlNodeImpl("fieldset");
					/*LSS 16.6 implementation ends*/	
					
					fieldSetNode.setAttribute("label_en", SWYConstants.PROPERTY_LABEL_REASON);
					
					/* LSS4.2 implementation
					XmlNode TextXmlNode = new XmlNode(SWYConstants.PROPERTY_COMPONENT_MEMO);
					*/
					/*LSS 16.6 implementation starts*/
					XmlNode TextXmlNode = new XmlNodeImpl(SWYConstants.PROPERTY_COMPONENT_MEMO);
					/*LSS 16.6 implementation ends*/
					TextXmlNode.setAttribute("id", SWYConstants.CLINICAL_SHORT_FINALIZATION_REASON_ATTR);
					TextXmlNode.setAttribute("label", SWYConstants.PROPERTY_LABEL_REASON);
					TextXmlNode.setAttribute("maxlength", SWYConstants.PROPERTY_COMPONENT_REASON_LENGTH);//
					TextXmlNode.setAttribute("required", SWYConstants.PROPERTY_COMPONENT_REASON_MANDATORY_TRUE);
					TextXmlNode.setAttribute("value","");
					
					fieldSetNode.appendXmlNode(TextXmlNode);
					
					contentNode.appendXmlNode(fieldSetNode);
					rootXmlNode.appendXmlNode(contentNode);

					/* LSS4.2 implementation
					 * XmlNode buttonNode = new XmlNode("buttons");

					XmlNode okButtonNode = new XmlNode("button");*/
					
					/*LSS 16.6 implementation starts*/
					XmlNode buttonNode = new XmlNodeImpl("buttons");
					XmlNode okButtonNode = new XmlNodeImpl("button");
					/*LSS 16.6 implementation ends*/
					
					okButtonNode.setAttribute("id", "buttonOk");
					okButtonNode.setAttribute("label", "Ok");
					okButtonNode.setAttribute("action", "validDialog()");
					buttonNode.appendXmlNode(okButtonNode);

					/*LSS4.2 implementation*/
					//XmlNode cancelButtonNode = new XmlNode("button");
					
					/*LSS 16.6 implementation starts*/
					XmlNode cancelButtonNode = new XmlNodeImpl("button");
					/*LSS 16.6 implementation ends*/
					
					cancelButtonNode.setAttribute("id", "buttonCancel");
					cancelButtonNode.setAttribute("label", "Cancel");
					cancelButtonNode.setAttribute("action", "cancelDialog()");
					buttonNode.appendXmlNode(cancelButtonNode);

					rootXmlNode.appendXmlNode(buttonNode);
					rootXmlNode.setAttribute(SWYConstants.PROPERTY_PAGE_ATTRIBUTE_WIDTH, SWYConstants.PROPERTY_PAGE_WIDTH);
					rootXmlNode.setAttribute(SWYConstants.PROPERTY_PAGE_ATTRIBUTE_HEIGHT, SWYConstants.PROPERTY_PAGE_HEIGHT);
					// Set new XML to dialog
					dialog.setXmlContent(rootXmlNode.toString(true));


			}else{
				LOG.debug("Process Name is incorrect (Building Dialog):"+processName);
			}
		}else{
			LOG.debug("Dialog Name is incorrect -i.e "+dialogName);
		}

		return dialog;

	}

	/*
	 * getToBeFinalizedType method will return the Short Finalized Type selected by
	 * user based on object Type attribute as there are type of multiple subtypes
	 */
	/**
	 * geToBeFinalizedType method will return the Short Finalization Type selected by
	 * user based on object Type attribute
	 * 
	 * @param selectedObjectId Object Ids selected
	 * @param session Admin session
	 * @return ToBeFinalizedType Returns the Clinical TMF Doc Type of the selected Document
	 * @throws DfException if Object doesnt exist
	 */
	public String getToBeFinalizedType(String[] selectedObjectId, IDfSession session) throws DfException {

		String ToBeFinalizedType = null;
		IDfSysObject sysObject = (IDfSysObject) session.getObject(new DfId(selectedObjectId[0]));

		ToBeFinalizedType = sysObject.getString(SWYConstants.OBJECT_TYPE);

		return ToBeFinalizedType;
	}


	/**
	 * validDialog Method is over ridden in the plugin. @param context User
	 * Context @param dialogName Name of the Dialog Invoked @param paramters
	 * This holds all the parameters passed to the plugin like Date format,
	 * config name, values selected on UI @return @throws
	 */

	@Override
	public Dialog validDialog(Context context, String id, String dialogName, List<Attribute> parameters) throws Exception {

		LOG.debug("------------------Dialog Plugin Service--------------");
		boolean isShortFinalized = false;
		Dialog dialog = null;
		long starttime = 0,endtime=0;
		String[] selectedIds = null;
		List<String[]> rejectedRecords = new ArrayList<String[]>();
		List<String[]> acceptedRecords = new ArrayList<String[]>();

		D2fsContext d2fsContext = (D2fsContext) context;
		
		if (!StringUtil.isEmptyOrNull(id)) {
			selectedIds = id.split("\254");
			LOG.debug("Selected IDs ->" + ArrayUtil.join(selectedIds, ";"));
		}
		

		if (dialogName.equalsIgnoreCase(SWYConstants.D2_WORKFLOW_DIALOG)) {
			String processName = "";
			for (Attribute attr : parameters) {
				LOG.debug("Parms: " + attr.getName() + " - " + attr.getValue());
				if (attr.getName().equalsIgnoreCase("config")) {
					processName = attr.getValue();
					break;
				}
			}
			if (processName.equals(SWYConstants.SHORT_FINALIZATION_WORKFLOW)) {
				IDfSession session = d2fsContext.getAdminSession();
				LOG.info("******************************* SWY Custom Dialog Plugin Service (Valid Dialog Short Finalization) *******************************");
				// Set if it's Short Finalization
				isShortFinalized = true;
				dialog = new Dialog();

				// Set the Success XML to dialog. So that it doesn't initate the
				// actual workflow.
				
				/*LSS4.2 implementation
				 * XmlNode result = XmlFactory.getRootSuccess();
				
				XmlDocument xmlDoc = new XmlDocument(result);
				dialog.setXmlContent(xmlDoc.toString());*/
				
				/*LSS 16.6 implementation starts*/
				XmlNode result = XmlFactory.getRootSuccess();
				dialog.setXmlContent(result.toString(true));
				/*LSS 16.6 implementation ends*/
				
					String short_finalization_reason = null;
					// Get Short Finalization from the parameter
					for (Attribute attr : parameters) {
						if (attr.getName().equalsIgnoreCase(SWYConstants.CLINICAL_SHORT_FINALIZATION_REASON_ATTR)) {
							short_finalization_reason = attr.getValue();
						}
					}

					// this is to truncate the information back to 200 as the maximum limit of storing the reason in the audit trails
					// short_finalization_reason=short_finalization_reason.substring(0,Math.min(short_finalization_reason.length(),200));
					
					for (int i = 0; i < selectedIds.length; i++) {

							IDfSysObject selectedObject = (IDfSysObject) session.getObject(new DfId(selectedIds[i]));
							
									String old_status_of_doc=selectedObject.getStatus();
									String product_code=selectedObject.getString(SWYConstants.PRODUCT_CODE);
									String object_name=selectedObject.getObjectName();
									LOG.debug("Document Name: "+ object_name +" A_Status "+ old_status_of_doc +" Product Code: "+product_code);
									try {

									LOG.debug("Applying Promotion to the Document : "+selectedObject.getStatus());
									starttime=System.currentTimeMillis();
									Map<String, Object> args = new HashMap<String, Object>();
									args.put(D2Method.ARG_ID, selectedObject.getObjectId());
									args.put(D2Method.ARG_CALLER_LOGIN, session.getLoginUserName());
									args.put(D2LifecycleChangeStateMethod.ARG_TARGET_STATE, SWYConstants.TO_BE_LIFECYCLE_STATE);
									args.put(D2LifecycleChangeStateMethod.ARG_TRANSITION_TYPE, SWYConstants.LIFECYCLE_TRANSITION_PROMOTE);
									args.put(D2Method.ARG_CLIENT_LOCALE, DfSessionUtil.getLocale(session).getLanguage());
									D2Method.start(session, D2LifecycleChangeStateMethod.class, args);
									endtime=System.currentTimeMillis();
									
									IDfSysObject newSelectedObject = (IDfSysObject) session.getObject(new DfId(getCurrentDocumentID(selectedObject,session)));
									
									LOG.debug("Applied Promotion to the Document new state : "+newSelectedObject.getStatus());

									
									if(old_status_of_doc.equals(newSelectedObject.getStatus()))//((selectedObject.getObjectId().toString().equals(newSelectedObject.getObjectId().toString())) && (selectedObject.getStatus().equals(newSelectedObject.getStatus()))) || ((selectedObject.getObjectId().toString().equals(newSelectedObject.getObjectId().toString())) && !(selectedObject.getStatus().equals(newSelectedObject.getStatus())))
									{
										String[] reasons= new String[3];
										reasons[0]=selectedObject.getObjectId().toString();
										reasons[1]=SWYConstants.PROMOTION_REJECTED_REASON_1;
										reasons[2]="process completed in "+String.valueOf(endtime-starttime)+" ms";
										rejectedRecords.add(reasons);
									} else {
										LOG.debug("Now Document Name: "+ newSelectedObject.getObjectName()+" A_Status "+ newSelectedObject.getStatus() +" Product Code: "+product_code+" Short Finalization Reason: "+short_finalization_reason);
										MethodHelper.auditEvent(newSelectedObject, SWYConstants.AUDIT_EVENT_SHORTFINALIZED_COMPLETED, d2fsContext.getSession().getLoginUserName(),new String[] {short_finalization_reason,object_name,product_code}, null);
										LOG.debug("Saved Finalization Reason: "+short_finalization_reason);								
										String[] reasons= new String[3];
										reasons[0]=selectedObject.getObjectId().toString();
										reasons[1]="";
										reasons[2]="process completed in "+String.valueOf(endtime-starttime)+" ms";
										acceptedRecords.add(reasons);

									}

								} catch (Throwable e) {
								String[] reasons= new String[3];
								reasons[0]=selectedObject.getObjectId().toString();
								reasons[1]=SWYConstants.PROMOTION_REJECTED_REASON_2 +"->"+ e.getMessage();
								reasons[2]="process completed in "+String.valueOf(endtime-starttime)+" ms";
								rejectedRecords.add(reasons);
								e.printStackTrace();
								LOG.debug("Error while promoting a Document : " + selectedObject.getObjectId()+ "Error: " + e.getMessage());
							}
									
						
							
					}
				
			}else{
				LOG.debug("Process Name is incorrect :"+processName);
			}
								
		}else{
			LOG.debug("Dialog Name is incorrect :"+dialogName);
		}
		
		// Printing the Information in Logs
		if (acceptedRecords.size() > 0) {
			LOG.debug("******************** Documents Fizalized during Short Finalization  **************************");
			for (int count = 0; count < acceptedRecords.size(); count++) {
				String[] strings = (String[]) acceptedRecords.get(count);
				LOG.debug("Document ID : " + strings[0] + "... " + strings[1] +" ("+strings[2]+")");
			}
		} 	
		if (rejectedRecords.size() > 0) {
		LOG.debug("**********************  Not Promoted records from selected documents during Short Finalization  **************************");
			for (int count = 0; count < rejectedRecords.size(); count++) {
				String[] strings = (String[]) rejectedRecords.get(count);
				LOG.debug("Document ID : " + strings[0] + " ... " + strings[1] +" ("+strings[2]+")");
			}
		} 
		LOG.debug("********************** Short Finalization processing ends here *****************************************");
		rejectedRecords.clear();
		acceptedRecords.clear();
		// If Its Short Finalization then returns the newly constructed Success dialog
		// else return Super.ValidDialog
		if (isShortFinalized) {
			return dialog;
		}
		return super.validDialog(d2fsContext, id, dialogName, parameters);

	}

	/**
	 * getCurrentDocumentID method will return the current version of the document from the given Document Version Tree
	 * 
	 * @param  selectedObject Selected Document 
	 * @param  session 		  Admin session
	 * @return String  		  Document ID of current version of the document
	 * @throws DfException 	  if Object doesnt exist
	 */

	private String getCurrentDocumentID(IDfSysObject selectedObject,IDfSession session) throws DfException
	{
		IDfId chronId = selectedObject.getChronicleId();
        String documentID=QueryUtils.execQuery("Select r_object_id from dm_document where i_chronicle_id='"+chronId+"' and any r_version_label='"+SWYConstants.DOCUMENT_CURRENT+"'", session);
		LOG.debug("GetCurrentDocumentID -> New Document ID :"+documentID);
		return documentID;
	}
	
	@Override
	public String getFullName() {
		return VERSION.getFullName();
	}

	@Override
	public String getProductName() {
		return VERSION.getProductName();
	}

}
