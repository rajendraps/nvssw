
package com.novartis.swy.shortfinalization;

import com.emc.common.java.utils.AbstractVersion;
import com.emc.common.java.utils.IVersion;



/**
 * Display the plugin version.
 *
 * @author : kumarr3y
 * @version : 1.0 
 */
public final class SWYShortFinalizationVersion extends AbstractVersion
{
       
    public static void main(String[] args)
    {
        IVersion version = new SWYShortFinalizationVersion();
       
    }
}
