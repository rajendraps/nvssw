package com.novartis.swy.shortfinalization;

public interface SWYConstants {

	// Dialog Names
	public static final String D2_WORKFLOW_DIALOG = "D2WorkflowLaunchDialog";
	public static final String SHORT_FINALIZATION_WORKFLOW = "CLN-WF-ShortFinalization";
	public static final String SHORT_FINALIZATION_CONFIG = "config";

	
	// Type Attribute Name
	public static final String OBJECT_TYPE = "r_object_type";
	public static final String PRODUCT_CODE = "product_code";
	public static final String CLINICAL_TRIAL_ID = "clinical_trial_id";
	public static final String DOCUMENT_CURRENT = "CURRENT";
	
	//Properties Attributes
	public static final String PROPERTY_PAGE_ATTRIBUTE_WIDTH = "width";
	public static final String PROPERTY_PAGE_WIDTH = "700";
	public static final String PROPERTY_PAGE_ATTRIBUTE_HEIGHT = "height";
	public static final String PROPERTY_PAGE_HEIGHT = "400";
	
	public static final String PROPERTY_LABEL_REASON = "Reason for Short Finalization";
	public static final String PROPERTY_COMPONENT_MEMO = "memo";
	public static final String PROPERTY_COMPONENT_REASON_LENGTH = "200";
	public static final String PROPERTY_COMPONENT_REASON_MANDATORY_TRUE = "true";


	
	// Attribute Name
	public static final String CLINICAL_SHORT_FINALIZATION_REASON_ATTR = "cst_string_s_01";
	public static final String CLINICAL_SHORT_FINALIZATION_STATUS_ATTR = "a_status";

	
	// Types
//	public static final String CLINICAL_TMF_DOCUMENT_OBJECT_TYPE = "cd_clinical_tmf_doc";


	// Method Names
	public static final String D2_CORE_METHOD_CLASS = "com.emc.d2.api.methods.D2CoreMethod";

	// Life Cycle State
	public static final String TO_BE_LIFECYCLE_STATE = "(Effective via ShortFinalization)";
	
	// Life Cycle Transition
	public static final String LIFECYCLE_TRANSITION_PROMOTE = "promote";

	//
	public static final String PROMOTION_ACCEPTED_REASON = "Saved Short Finalization Reason: ";

	
	// Error Reasons
	public static final String PROMOTION_REJECTED_REASON_1 = "Document cannot be promoted to the desired state";
	public static final String PROMOTION_REJECTED_REASON_2 = "Exception in promoting the document to desired state";

	
	// Audited events
	public static final String AUDIT_EVENT_SHORTFINALIZED_COMPLETED = "swy_short_finalize";

}
