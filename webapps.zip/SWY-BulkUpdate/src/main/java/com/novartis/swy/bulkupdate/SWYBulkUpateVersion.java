
package com.novartis.swy.bulkupdate;

import com.emc.common.java.utils.AbstractVersion;
import com.emc.common.java.utils.IVersion;



/**
 * Display the plugin version.
 *
 * @author : patilk
 * @version : 1.1 
 */
public final class SWYBulkUpateVersion extends AbstractVersion
{
       
    public static void main(String[] args)
    {
        IVersion version = new SWYBulkUpateVersion();
       
    }
}
