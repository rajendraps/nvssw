package com.novartis.swy.bulkupdate;

public interface SWYConstants {

	// Dialog Names
	public static final String D2_WORKFLOW_DIALOG = "D2WorkflowLaunchDialog";
	public static final String BULK_UPDATE_WORKFLOW = "CMN-WF-BulkUpdate";

	// TYPES
	public static final String CORE_LABELING_OBJECT_TYPE = "cd_core_reg_labeling_doc";
	public static final String NON_CORE_LABELING_OBJECT_TYPE = "cd_app_reg_labeling_doc";

	// Dictionary
	public static final String CORE_LABELING_STATUS_DICTIONARY = "REG-DIC-Core Labeling Status";
	public static final String CORE_DISPATCH_STATUS_DICTIONARY = "REG-DIC-Core Labeling Dispatch";

	public static final String HQ_LABELING_STATUS_DICTIONARY = "REG-DIC-Core Labeling Status";
	public static final String IPL_LABELING_STATUS_DICTIONARY = "REG-DIC-IPL Labeling Status";
	public static final String NATIONAL_LABELING_STATUS_DICTIONARY = "REG-DIC-National Labeling Status";
	public static final String NATIONAL_ROUND_DICTIONARY = "REG-DIC-National Labeling Round";

	// Labeling Doc Types

	public static final String CORE_LABELING = "Core Labeling";
	public static final String HQ_LABELING = "HQ Review-NPI Deviations";
	public static final String IPL_LABELING = "IPL Labeling";
	public static final String NATIONAL_LABELING = "National Labeling";

	// Mass Update Attributes
	public static final String MU_ATTR_LABELING_STATUS = "swy_labeling_status";
	public static final String MU_ATTR_DISPATCH_STATUS = "swy_dispatch_status";
	public static final String MU_ATTR_NAT_LABELING_ROUND = "swy_labeling_round";
	public static final String MU_ATTR_NAT_LABELING_STATUS = "swy_nat_labeling_status";
	public static final String MU_ATTR_IPL_LABELING_STATUS = "swy_ipl_labeling_status";
	public static final String MU_ATTR_LABELING_TYPE = "swy_labeling_type";

	// FORMATS
	public static final String MU_DISPATCH_DATE_VALUE_FORMAT = "value_format";

	// Method Names
	public static final String D2_CORE_METHOD_CLASS = "com.emc.d2.api.methods.D2CoreMethod";

}
