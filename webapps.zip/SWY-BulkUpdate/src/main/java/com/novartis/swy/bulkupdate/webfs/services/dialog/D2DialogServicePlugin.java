package com.novartis.swy.bulkupdate.webfs.services.dialog;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.impl.util.StringUtil;
import com.documentum.utils.QueryUtils;
import com.emc.common.dctm.utils.DfSessionUtil;
import com.emc.common.java.utils.ArrayUtil;
import com.emc.common.java.utils.IVersion;
import com.emc.common.java.xml.XmlDocument;
import com.emc.common.java.xml.XmlNode;
import com.emc.common.java.xml.XmlNodeImpl;
import com.emc.common.java.xml.XmlUtil;
import com.emc.d2.api.methods.D2LifecycleChangeStateMethod;
import com.emc.d2.api.methods.D2Method;
import com.emc.d2fs.dctm.ui.XmlFactory;
import com.emc.d2fs.dctm.web.services.D2fsContext;
import com.emc.d2fs.dctm.web.services.ID2fsPlugin;
import com.emc.d2fs.dctm.web.services.dialog.D2DialogService;
import com.emc.d2fs.models.attribute.Attribute;
import com.emc.d2fs.models.context.Context;
import com.emc.d2fs.models.dialog.Dialog;
import com.novartis.swy.bulkupdate.SWYBulkUpateVersion;
import com.novartis.swy.bulkupdate.SWYConstants;
/**
 * D2DialogServicePlugin extends D2DialogService. This class overrides behavior of D2DialogService,
 * for bulk update of Labeling's Dispatch and Labeling status. 
 * @author patilk
 *  
 * *************JIRA 2959*******************************************
 * Date : 21-Dec-2020 , Author : SHUBHKU1, SUKANRA1
 * Re-factored code, handled collection leak issue (JIRA# 2959)
 * *****************************************************************
 *
 */
public class D2DialogServicePlugin extends D2DialogService implements ID2fsPlugin {
	private static final IVersion VERSION = new SWYBulkUpateVersion();
	final String RECLASSIFY_TRANS_STATE = "(Bulk Update Security)";

	public D2DialogServicePlugin() {
	}

	/**
	 * Override the default D2Dialog getDialog method for Bulk Update
	 * 
	 * @param context
	 *            The D2fsContext passed from user session.
	 * @param context
	 *            The D2fsContext passed from user session.
	 * @param id
	 *            The id holds the Object Ids of the objects selected
	 * @param dialogName
	 *            This parameter hold the dialog name that is being invoked
	 * @param paramters
	 *            This holds all the parameters passed to the plugin like Date
	 *            format, config name
	 * @return Dialog
	 * @throws IOException
	 */
	@Override
	public Dialog getDialog(Context context, String id, String dialogName, List<Attribute> parameters)
			throws Exception {
		LOG.debug("------------------Custom Dialog Plugin Service (Get Dialog)--------------");
		LOG.debug("Dialogue Name: " + dialogName);
		String[] inputIds = null;
		if (!StringUtil.isEmptyOrNull(id)) {
			inputIds = id.split("\254");
			LOG.debug("Selected IDs" + ArrayUtil.join(inputIds, "--"));
		}
		Dialog dialog = super.getDialog(context, id, dialogName, parameters);
		D2fsContext d2fsContext = (D2fsContext) context;

		if (dialogName.equalsIgnoreCase(SWYConstants.D2_WORKFLOW_DIALOG)) {
			String processName = "";
			for (Attribute attr : parameters) {
				LOG.debug("Parms: " + attr.getName() + " - " + attr.getValue());
				if (attr.getName().equalsIgnoreCase("config")) {
					processName = attr.getValue();
					break;
				}
			}

			if (processName.equals(SWYConstants.BULK_UPDATE_WORKFLOW)) {
				LOG.info("------------------Custom Dialog Plugin Service (Get Dialog Bulk Update)--------------");
				// Get Admin Session for running D2 Core Job
				IDfSession session = d2fsContext.getAdminSession();
				XmlDocument xmlDoc = XmlUtil.loadFromString(dialog.getXmlContent());

				XmlNode rootXmlNode = xmlDoc.getRootXmlNode();

				// Remove the Workflow Xml Content
				rootXmlNode.removeAllXmlNode();

				// Get bulk update type:Core OR HQ OR IPL Labeling OR National
				// Labeling based on object Type and labelling type attribute
				String bulkUpdateType = getBulkUpdateType(inputIds, session);
				if (bulkUpdateType.equalsIgnoreCase(SWYConstants.CORE_LABELING)) {

					// Add Core Label Related Attributes Fields to XML

					/*LSS4.2 implementation
					XmlNode contentNode = new XmlNode("content");
					XmlNode fieldSetNode = new XmlNode("fieldset");
					XmlNode comboXmlNode = new XmlNode("combo");*/

					/*LSS 16.6 implementation starts*/
					XmlNode contentNode = new XmlNodeImpl("content");
					XmlNode fieldSetNode = new XmlNodeImpl("fieldset");
					XmlNode comboXmlNode = new XmlNodeImpl("combo");
					/*LSS 16.6 implementation ends*/
					fieldSetNode.setAttribute("label_en", "BulkUpdate");
					comboXmlNode.setAttribute("id", SWYConstants.MU_ATTR_LABELING_STATUS);
					comboXmlNode.setAttribute("label", "Labeling Status");
					comboXmlNode.setAttribute("advancedView_required", "false");
					comboXmlNode.setAttribute("assistance_dictionary", SWYConstants.CORE_LABELING_STATUS_DICTIONARY);
					comboXmlNode.setAttribute("value",
							getAttributeValue(inputIds, SWYConstants.MU_ATTR_LABELING_STATUS, "String", session));
					comboXmlNode.setAttribute("assistance_dictionary_alias", "en");
					comboXmlNode.setAttribute("assistance_type", "dictionary");
					comboXmlNode.setAttribute("condition_required_create", "false");
					comboXmlNode.setAttribute("condition_required_edit", "false");
					comboXmlNode.setAttribute("condition_required_import", "false");

					XmlNode commonNode = comboXmlNode.appendChildNode("o");
					commonNode.setAttribute("v", "#####");
					commonNode.setAttribute("l", "#####");

					// Fetch the values from the Dictionary
					String dictionaryVals = "select object_name from d2_dictionary_value where dictionary_name='"
							+ SWYConstants.CORE_LABELING_STATUS_DICTIONARY + "'";
					IDfQuery dictionaryValsQry = new DfQuery(dictionaryVals);
					IDfCollection dictionaryValsQryColl =null; 
					try
					{
						dictionaryValsQryColl = dictionaryValsQry.execute(session, DfQuery.DF_EXECREAD_QUERY);
						while (dictionaryValsQryColl.next()) {
							// Create List items
							XmlNode itemNode = comboXmlNode.appendChildNode("o");
							itemNode.setAttribute("v", dictionaryValsQryColl.getString("object_name"));
							itemNode.setAttribute("l", dictionaryValsQryColl.getString("object_name"));
						}
					}
					finally
					{
						if(dictionaryValsQryColl!=null)
						{
							dictionaryValsQryColl.close();
							LOG.debug( "bulkupdate ::: collection closed dictionaryValsQryColl");
						}
					}


					fieldSetNode.appendXmlNode(comboXmlNode);
					/*LSS4.2 implementation
					XmlNode comboXmlNode1 = new XmlNode("combo");
					 */
					/*LSS 16.6 implementation starts*/
					XmlNode comboXmlNode1 = new XmlNodeImpl("combo");
					/*LSS 16.6 implementation ends*/

					comboXmlNode1.setAttribute("id", SWYConstants.MU_ATTR_DISPATCH_STATUS);
					comboXmlNode1.setAttribute("label", "Dispatch Status");
					comboXmlNode1.setAttribute("advancedView_required", "false");
					comboXmlNode1.setAttribute("assistance_dictionary", SWYConstants.CORE_DISPATCH_STATUS_DICTIONARY);
					comboXmlNode1.setAttribute("value",
							getAttributeValue(inputIds, SWYConstants.MU_ATTR_DISPATCH_STATUS, "String", session));
					comboXmlNode1.setAttribute("assistance_dictionary_alias", "en");
					comboXmlNode1.setAttribute("assistance_type", "dictionary");
					comboXmlNode1.setAttribute("condition_required_create", "false");
					comboXmlNode1.setAttribute("condition_required_edit", "false");
					comboXmlNode1.setAttribute("condition_required_import", "false");

					XmlNode commonNode1 = comboXmlNode1.appendChildNode("o");
					commonNode1.setAttribute("v", "#####");
					commonNode1.setAttribute("l", "#####");

					// Fetch the values from the Dictionary
					String dictionaryVals1 = "select object_name from d2_dictionary_value where dictionary_name='"
							+ SWYConstants.CORE_DISPATCH_STATUS_DICTIONARY + "'";
					IDfQuery dictionaryValsQry1 = new DfQuery(dictionaryVals1);
					IDfCollection dictionaryValsQryColl1 = null;
					try
					{
						dictionaryValsQryColl1 = dictionaryValsQry1.execute(session, DfQuery.DF_EXECREAD_QUERY);
						while (dictionaryValsQryColl1.next()) {
							// Create List items
							XmlNode itemNode1 = comboXmlNode1.appendChildNode("o");
							itemNode1.setAttribute("v", dictionaryValsQryColl1.getString("object_name"));
							itemNode1.setAttribute("l", dictionaryValsQryColl1.getString("object_name"));
						}
					}
					finally
					{
						if(dictionaryValsQryColl1!=null)
						{
							dictionaryValsQryColl1.close();
							LOG.debug( "bulkupdate ::: collection closed dictionaryValsQryColl1");
						}
					}					

					fieldSetNode.appendXmlNode(comboXmlNode1);

					contentNode.appendXmlNode(fieldSetNode);
					rootXmlNode.appendXmlNode(contentNode);

					/* LSS4.2 implementation	
				 	XmlNode buttonNode = new XmlNode("buttons");

					XmlNode okButtonNode = new XmlNode("button");*/

					/*LSS 16.6 implementation starts*/
					XmlNode buttonNode = new XmlNodeImpl("buttons");
					XmlNode okButtonNode = new XmlNodeImpl("button");
					/*LSS 16.6 implementation ends*/
					okButtonNode.setAttribute("id", "buttonOk");
					okButtonNode.setAttribute("label", "Ok");
					okButtonNode.setAttribute("action", "validDialog()");
					buttonNode.appendXmlNode(okButtonNode);

					/* LSS4.2 implementation
					XmlNode cancelButtonNode = new XmlNode("button");
					 */
					/*LSS 16.6 implementation starts*/
					XmlNode cancelButtonNode = new XmlNodeImpl("button");
					/*LSS 16.6 implementation ends*/
					cancelButtonNode.setAttribute("id", "buttonCancel");
					cancelButtonNode.setAttribute("label", "Cancel");
					cancelButtonNode.setAttribute("action", "cancelDialog()");
					buttonNode.appendXmlNode(cancelButtonNode);

					rootXmlNode.appendXmlNode(buttonNode);
					// Set new XML to dialog
					dialog.setXmlContent(rootXmlNode.toString(true));

				} else if (bulkUpdateType.equalsIgnoreCase(SWYConstants.HQ_LABELING)) {
					// Add HQ-NPI Label Related Attributes Fields to XML
					/*LSS4.2 implementation
					XmlNode contentNode = new XmlNode("content");
					XmlNode fieldSetNode = new XmlNode("fieldset");
					XmlNode comboXmlNode = new XmlNode("combo");*/

					/*LSS 16.6 implementation starts*/
					XmlNode contentNode = new XmlNodeImpl("content");
					XmlNode fieldSetNode = new XmlNodeImpl("fieldset");
					XmlNode comboXmlNode = new XmlNodeImpl("combo");
					/*LSS 16.6 implementation ends*/
					fieldSetNode.setAttribute("label_en", "BulkUpdate");

					comboXmlNode.setAttribute("id", SWYConstants.MU_ATTR_LABELING_STATUS);
					comboXmlNode.setAttribute("label", "Labeling Status");
					comboXmlNode.setAttribute("advancedView_required", "false");
					comboXmlNode.setAttribute("assistance_dictionary", SWYConstants.HQ_LABELING_STATUS_DICTIONARY);
					comboXmlNode.setAttribute("value",
							getAttributeValue(inputIds, SWYConstants.MU_ATTR_LABELING_STATUS, "String", session));
					comboXmlNode.setAttribute("assistance_dictionary_alias", "en");
					comboXmlNode.setAttribute("assistance_type", "dictionary");
					comboXmlNode.setAttribute("condition_required_create", "false");
					comboXmlNode.setAttribute("condition_required_edit", "false");
					comboXmlNode.setAttribute("condition_required_import", "false");

					XmlNode commonNode = comboXmlNode.appendChildNode("o");
					commonNode.setAttribute("v", "#####");
					commonNode.setAttribute("l", "#####");

					// Fetch the values from the Dictionary
					String dictionaryVals = "select object_name from d2_dictionary_value where dictionary_name='"
							+ SWYConstants.HQ_LABELING_STATUS_DICTIONARY + "'";
					IDfQuery dictionaryValsQry = new DfQuery(dictionaryVals);
					IDfCollection dictionaryValsQryColl = null;
					try
					{
						dictionaryValsQryColl = dictionaryValsQry.execute(session, DfQuery.DF_EXECREAD_QUERY);
						while (dictionaryValsQryColl.next()) {
							// Create List items
							XmlNode itemNode = comboXmlNode.appendChildNode("o");
							itemNode.setAttribute("v", dictionaryValsQryColl.getString("object_name"));
							itemNode.setAttribute("l", dictionaryValsQryColl.getString("object_name"));
						}
					}
					finally
					{
						if(dictionaryValsQryColl!=null)
						{
							dictionaryValsQryColl.close();
							LOG.debug( "bulkupdate ::: collection closed elseif dictionaryValsQryColl");
						}
					}

					fieldSetNode.appendXmlNode(comboXmlNode);
					/* LSS4.2 implementation
					XmlNode comboXmlNode1 = new XmlNode("combo");
					 */
					/*LSS 16.6 implementation starts*/
					XmlNode comboXmlNode1 = new XmlNodeImpl("combo");
					/*LSS 16.6 implementation ends*/
					comboXmlNode1.setAttribute("id", SWYConstants.MU_ATTR_DISPATCH_STATUS);
					comboXmlNode1.setAttribute("label", "Dispatch Status");
					comboXmlNode1.setAttribute("advancedView_required", "false");
					comboXmlNode1.setAttribute("assistance_dictionary", SWYConstants.CORE_DISPATCH_STATUS_DICTIONARY);
					comboXmlNode1.setAttribute("value",
							getAttributeValue(inputIds, SWYConstants.MU_ATTR_DISPATCH_STATUS, "String", session));
					comboXmlNode1.setAttribute("assistance_dictionary_alias", "en");
					comboXmlNode1.setAttribute("assistance_type", "dictionary");
					comboXmlNode1.setAttribute("condition_required_create", "false");
					comboXmlNode1.setAttribute("condition_required_edit", "false");
					comboXmlNode1.setAttribute("condition_required_import", "false");

					XmlNode commonNode1 = comboXmlNode1.appendChildNode("o");
					commonNode1.setAttribute("v", "#####");
					commonNode1.setAttribute("l", "#####");

					// Fetch the values from the Dictionary
					String dictionaryVals1 = "select object_name from d2_dictionary_value where dictionary_name='"
							+ SWYConstants.CORE_DISPATCH_STATUS_DICTIONARY + "'";
					IDfQuery dictionaryValsQry1 = new DfQuery(dictionaryVals1);
					IDfCollection  dictionaryValsQryColl1 = null;
					try
					{
						dictionaryValsQryColl1 = dictionaryValsQry1.execute(session,
								DfQuery.DF_EXECREAD_QUERY);
						while (dictionaryValsQryColl1.next()) {
							// Create List items
							XmlNode itemNode1 = comboXmlNode1.appendChildNode("o");
							itemNode1.setAttribute("v", dictionaryValsQryColl1.getString("object_name"));
							itemNode1.setAttribute("l", dictionaryValsQryColl1.getString("object_name"));
						}
					}
					finally
					{
						if(dictionaryValsQryColl1!=null)
						{
							dictionaryValsQryColl1.close();
							LOG.debug("bulkupdate ::: collection closed elseif dictionaryValsQryColl1");
						}
					}

					fieldSetNode.appendXmlNode(comboXmlNode1);

					contentNode.appendXmlNode(fieldSetNode);
					rootXmlNode.appendXmlNode(contentNode);

					/* LSS4.2 implementation	
				 	XmlNode buttonNode = new XmlNode("buttons");

					XmlNode okButtonNode = new XmlNode("button");*/

					/*LSS 16.6 implementation starts*/
					XmlNode buttonNode = new XmlNodeImpl("buttons");
					XmlNode okButtonNode = new XmlNodeImpl("button");
					/*LSS 16.6 implementation ends*/
					okButtonNode.setAttribute("id", "buttonOk");
					okButtonNode.setAttribute("label", "Ok");
					okButtonNode.setAttribute("action", "validDialog()");
					buttonNode.appendXmlNode(okButtonNode);

					/* LSS4.2 implementation
					XmlNode cancelButtonNode = new XmlNode("button");
					 */
					/*LSS 16.6 implementation starts*/
					XmlNode cancelButtonNode = new XmlNodeImpl("button");
					/*LSS 16.6 implementation ends*/
					cancelButtonNode.setAttribute("id", "buttonCancel");
					cancelButtonNode.setAttribute("label", "Cancel");
					cancelButtonNode.setAttribute("action", "cancelDialog()");
					buttonNode.appendXmlNode(cancelButtonNode);

					rootXmlNode.appendXmlNode(buttonNode);
					// Set the xml to dialog
					dialog.setXmlContent(rootXmlNode.toString(true));

				} else if (bulkUpdateType.equalsIgnoreCase(SWYConstants.IPL_LABELING)) {

					// Add IPL Label Related Attributes Fields to XML

					/*LSS4.2 implementation
					XmlNode contentNode = new XmlNode("content");
					XmlNode fieldSetNode = new XmlNode("fieldset");
					XmlNode comboXmlNode = new XmlNode("combo");*/

					/*LSS 16.6 implementation starts*/
					XmlNode contentNode = new XmlNodeImpl("content");
					XmlNode fieldSetNode = new XmlNodeImpl("fieldset");
					XmlNode comboXmlNode = new XmlNodeImpl("combo");
					/*LSS 16.6 implementation ends*/
					fieldSetNode.setAttribute("label_en", "BulkUpdate");


					comboXmlNode.setAttribute("id", SWYConstants.MU_ATTR_IPL_LABELING_STATUS);
					comboXmlNode.setAttribute("label", "Labeling Status");
					comboXmlNode.setAttribute("advancedView_required", "false");
					comboXmlNode.setAttribute("assistance_dictionary", SWYConstants.IPL_LABELING_STATUS_DICTIONARY);
					comboXmlNode.setAttribute("value",
							getAttributeValue(inputIds, SWYConstants.MU_ATTR_IPL_LABELING_STATUS, "String", session));
					comboXmlNode.setAttribute("assistance_dictionary_alias", "en");
					comboXmlNode.setAttribute("assistance_type", "dictionary");
					comboXmlNode.setAttribute("condition_required_create", "false");
					comboXmlNode.setAttribute("condition_required_edit", "false");
					comboXmlNode.setAttribute("condition_required_import", "false");

					XmlNode commonNode = comboXmlNode.appendChildNode("o");
					commonNode.setAttribute("v", "#####");
					commonNode.setAttribute("l", "#####");

					// Fetch the values from the Dictionary
					String dictionaryVals = "select object_name from d2_dictionary_value where dictionary_name='"
							+ SWYConstants.IPL_LABELING_STATUS_DICTIONARY + "'";
					IDfQuery dictionaryValsQry = new DfQuery(dictionaryVals);
					IDfCollection dictionaryValsQryColl = null;
					try
					{
						dictionaryValsQryColl = dictionaryValsQry.execute(session, DfQuery.DF_EXECREAD_QUERY);
						while (dictionaryValsQryColl.next()) {
							// Create List items
							XmlNode itemNode = comboXmlNode.appendChildNode("o");
							itemNode.setAttribute("v", dictionaryValsQryColl.getString("object_name"));
							itemNode.setAttribute("l", dictionaryValsQryColl.getString("object_name"));
						}
					}
					finally
					{
						if(dictionaryValsQryColl!=null)
						{
							dictionaryValsQryColl.close();
							LOG.debug("bulkupdate ::: collection closed elseiff dictionaryValsQryColl");
						}
					}

					fieldSetNode.appendXmlNode(comboXmlNode);
					/*LSS4.2 implementation
					XmlNode comboXmlNode1 = new XmlNode("combo");
					 */
					/*LSS 16.6 implementation starts*/
					XmlNode comboXmlNode1 = new XmlNodeImpl("combo");
					/*LSS 16.6 implementation ends*/
					comboXmlNode1.setAttribute("id", SWYConstants.MU_ATTR_DISPATCH_STATUS);
					comboXmlNode1.setAttribute("label", "Dispatch Status");
					comboXmlNode1.setAttribute("advancedView_required", "false");
					comboXmlNode1.setAttribute("assistance_dictionary", SWYConstants.CORE_DISPATCH_STATUS_DICTIONARY);
					comboXmlNode1.setAttribute("value",
							getAttributeValue(inputIds, SWYConstants.MU_ATTR_DISPATCH_STATUS, "String", session));
					comboXmlNode1.setAttribute("assistance_dictionary_alias", "en");
					comboXmlNode1.setAttribute("assistance_type", "dictionary");
					comboXmlNode1.setAttribute("condition_required_create", "false");
					comboXmlNode1.setAttribute("condition_required_edit", "false");
					comboXmlNode1.setAttribute("condition_required_import", "false");

					XmlNode commonNode1 = comboXmlNode1.appendChildNode("o");
					commonNode1.setAttribute("v", "#####");
					commonNode1.setAttribute("l", "#####");

					// Fetch the values from the Dictionary
					String dictionaryVals1 = "select object_name from d2_dictionary_value where dictionary_name='"
							+ SWYConstants.CORE_DISPATCH_STATUS_DICTIONARY + "'";
					IDfQuery dictionaryValsQry1 = new DfQuery(dictionaryVals1);
					IDfCollection dictionaryValsQryColl1 = null;
					try
					{
						dictionaryValsQryColl1 = dictionaryValsQry1.execute(session,
								DfQuery.DF_EXECREAD_QUERY);
						while (dictionaryValsQryColl1.next()) {
							// Create List items
							XmlNode itemNode1 = comboXmlNode1.appendChildNode("o");
							itemNode1.setAttribute("v", dictionaryValsQryColl1.getString("object_name"));
							itemNode1.setAttribute("l", dictionaryValsQryColl1.getString("object_name"));
						}
					}
					finally
					{
						if(dictionaryValsQryColl1!=null)
						{
							dictionaryValsQryColl1.close();
							LOG.debug( "bulkupdate ::: collection closed elseiff dictionaryValsQryColl1");
						}
					}

					fieldSetNode.appendXmlNode(comboXmlNode1);
					contentNode.appendXmlNode(fieldSetNode);
					rootXmlNode.appendXmlNode(contentNode);

					/* LSS4.2 implementation	
				 	XmlNode buttonNode = new XmlNode("buttons");

					XmlNode okButtonNode = new XmlNode("button");*/

					/*LSS 16.6 implementation starts*/
					XmlNode buttonNode = new XmlNodeImpl("buttons");
					XmlNode okButtonNode = new XmlNodeImpl("button");
					/*LSS 16.6 implementation ends*/
					okButtonNode.setAttribute("id", "buttonOk");
					okButtonNode.setAttribute("label", "Ok");
					okButtonNode.setAttribute("action", "validDialog()");
					buttonNode.appendXmlNode(okButtonNode);

					/* LSS4.2 implementation
					XmlNode cancelButtonNode = new XmlNode("button");
					 */
					/*LSS 16.6 implementation starts*/
					XmlNode cancelButtonNode = new XmlNodeImpl("button");
					/*LSS 16.6 implementation ends*/
					cancelButtonNode.setAttribute("id", "buttonCancel");
					cancelButtonNode.setAttribute("label", "Cancel");
					cancelButtonNode.setAttribute("action", "cancelDialog()");
					buttonNode.appendXmlNode(cancelButtonNode);

					rootXmlNode.appendXmlNode(buttonNode);
					// set XML to dialog
					dialog.setXmlContent(rootXmlNode.toString(true));

				}

				else if (bulkUpdateType.equalsIgnoreCase(SWYConstants.NATIONAL_LABELING)) {
					// Add National Label Related Attributes Fields to XML

					/*LSS4.2 implementation
					XmlNode contentNode = new XmlNode("content");
					XmlNode fieldSetNode = new XmlNode("fieldset");
					XmlNode comboXmlNode = new XmlNode("combo");*/

					/*LSS 16.6 implementation starts*/
					XmlNode contentNode = new XmlNodeImpl("content");
					XmlNode fieldSetNode = new XmlNodeImpl("fieldset");
					XmlNode comboXmlNode = new XmlNodeImpl("combo");
					/*LSS 16.6 implementation ends*/

					fieldSetNode.setAttribute("label_en", "BulkUpdate");

					comboXmlNode.setAttribute("id", SWYConstants.MU_ATTR_NAT_LABELING_STATUS);
					comboXmlNode.setAttribute("label", "Labeling Status");
					comboXmlNode.setAttribute("advancedView_required", "false");
					comboXmlNode.setAttribute("assistance_dictionary",
							SWYConstants.NATIONAL_LABELING_STATUS_DICTIONARY);
					comboXmlNode.setAttribute("value",
							getAttributeValue(inputIds, SWYConstants.MU_ATTR_NAT_LABELING_STATUS, "String", session));
					comboXmlNode.setAttribute("assistance_dictionary_alias", "en");
					comboXmlNode.setAttribute("assistance_type", "dictionary");
					comboXmlNode.setAttribute("condition_required_create", "false");
					comboXmlNode.setAttribute("condition_required_edit", "false");
					comboXmlNode.setAttribute("condition_required_import", "false");

					XmlNode commonNode = comboXmlNode.appendChildNode("o");
					commonNode.setAttribute("v", "#####");
					commonNode.setAttribute("l", "#####");

					// Fetch the values from the Dictionary
					String dictionaryVals = "select object_name from d2_dictionary_value where dictionary_name='"
							+ SWYConstants.NATIONAL_LABELING_STATUS_DICTIONARY + "'";
					IDfQuery dictionaryValsQry = new DfQuery(dictionaryVals);
					IDfCollection dictionaryValsQryColl =null;
					try
					{
						dictionaryValsQryColl = dictionaryValsQry.execute(session, DfQuery.DF_EXECREAD_QUERY);
						while (dictionaryValsQryColl.next()) {
							// Create List items
							XmlNode itemNode = comboXmlNode.appendChildNode("o");
							itemNode.setAttribute("v", dictionaryValsQryColl.getString("object_name"));
							itemNode.setAttribute("l", dictionaryValsQryColl.getString("object_name"));
						}
					}
					finally
					{
						if(dictionaryValsQryColl!=null)
						{
							dictionaryValsQryColl.close();
							LOG.debug( "bulkupdate ::: collection closed elseifff dictionaryValsQryColl");
						}
					}
					fieldSetNode.appendXmlNode(comboXmlNode);
					/*LSS4.2 implementation
					XmlNode comboXmlNode1 = new XmlNode("combo-editable");
					 */
					/*LSS 16.6 implementation starts*/
					XmlNode comboXmlNode1 = new XmlNodeImpl("combo-editable");
					/*LSS 16.6 implementation ends*/
					comboXmlNode1.setAttribute("id", SWYConstants.MU_ATTR_NAT_LABELING_ROUND);
					comboXmlNode1.setAttribute("label", "Round");
					comboXmlNode1.setAttribute("advancedView_required", "false");
					comboXmlNode1.setAttribute("assistance_dictionary", SWYConstants.NATIONAL_ROUND_DICTIONARY);
					comboXmlNode1.setAttribute("value",
							getAttributeValue(inputIds, SWYConstants.MU_ATTR_NAT_LABELING_ROUND, "string", session));
					comboXmlNode1.setAttribute("assistance_dictionary_alias", "en");
					comboXmlNode1.setAttribute("assistance_type", "dictionary");
					comboXmlNode1.setAttribute("condition_required_create", "false");
					comboXmlNode1.setAttribute("condition_required_edit", "false");
					comboXmlNode1.setAttribute("condition_required_import", "false");

					XmlNode commonNode1 = comboXmlNode1.appendChildNode("o");
					commonNode1.setAttribute("v", "#####");
					commonNode1.setAttribute("l", "#####");

					// Fetch the values from the Dictionary
					String dictionaryVals1 = "select object_name from d2_dictionary_value where dictionary_name='"
							+ SWYConstants.NATIONAL_ROUND_DICTIONARY + "'";
					IDfQuery dictionaryValsQry1 = new DfQuery(dictionaryVals1);
					IDfCollection dictionaryValsQryColl1 = null;
					try
					{
						dictionaryValsQryColl1 = dictionaryValsQry1.execute(session,
								DfQuery.DF_EXECREAD_QUERY);
						while (dictionaryValsQryColl1.next()) {
							// Create List items
							XmlNode itemNode1 = comboXmlNode1.appendChildNode("o");
							itemNode1.setAttribute("v", dictionaryValsQryColl1.getString("object_name"));
							itemNode1.setAttribute("l", dictionaryValsQryColl1.getString("object_name"));
						}
					}
					finally
					{
						if(dictionaryValsQryColl1!=null)
						{
							dictionaryValsQryColl1.close();
							LOG.debug( "bulkupdate ::: collection closed elseifff dictionaryValsQryColl1");
						}
					}

					fieldSetNode.appendXmlNode(comboXmlNode1);

					contentNode.appendXmlNode(fieldSetNode);
					rootXmlNode.appendXmlNode(contentNode);

					/* LSS4.2 implementation	
				 	XmlNode buttonNode = new XmlNode("buttons");

					XmlNode okButtonNode = new XmlNode("button");*/

					/*LSS 16.6 implementation starts*/
					XmlNode buttonNode = new XmlNodeImpl("buttons");
					XmlNode okButtonNode = new XmlNodeImpl("button");
					/*LSS 16.6 implementation ends*/
					okButtonNode.setAttribute("id", "buttonOk");
					okButtonNode.setAttribute("label", "Ok");
					okButtonNode.setAttribute("action", "validDialog()");
					buttonNode.appendXmlNode(okButtonNode);
					/* LSS4.2 implementation
					XmlNode cancelButtonNode = new XmlNode("button");
					 */
					/*LSS 16.6 implementation starts*/
					XmlNode cancelButtonNode = new XmlNodeImpl("button");
					/*LSS 16.6 implementation ends*/
					cancelButtonNode.setAttribute("id", "buttonCancel");
					cancelButtonNode.setAttribute("label", "Cancel");
					cancelButtonNode.setAttribute("action", "cancelDialog()");
					buttonNode.appendXmlNode(cancelButtonNode);

					rootXmlNode.appendXmlNode(buttonNode);
					// Set Constructed xml to dialog
					dialog.setXmlContent(rootXmlNode.toString(true));

				}

			}
		}

		return dialog;

	}

	/*
	 * getBulkUpdateType method will return the Bulk Update Type selected by user
	 * based on object Type and labeling_type attribute
	 */
	/**
	 * getBulkUpdateType method will return the Bulk Update Type selected by user
	 * based on object Type and labeling_type attribute
	 * 
	 * @param selectedObjectId
	 *            Object Ids selected
	 * @param session
	 *            Admin session
	 * @return bulkUpdateType Returns the Labeling Type of the selected Document
	 * @throws DfException
	 *             if Object doesnt exist
	 */
	public String getBulkUpdateType(String[] selectedObjectId, IDfSession session) throws DfException {

		String bulkUpdateType = null;
		IDfSysObject sysObject = (IDfSysObject) session.getObject(new DfId(selectedObjectId[0]));

		bulkUpdateType = sysObject.getString(SWYConstants.MU_ATTR_LABELING_TYPE);

		return bulkUpdateType;
	}

	/**
	 * getAttributeValue method will check if attribute value of the object are same
	 * else sends '#####' as return value
	 * 
	 * @param selectedObjectId
	 *            Array of Selected Labeling Objects
	 * @param attrName
	 *            Attribute name of selected Object
	 * @param attrType
	 *            Holds the type of attribute. For Ex: String
	 * @return attrValue queries the attributes on the objects, If all the objects
	 *         are same sends the value else sends '#####'
	 */
	public String getAttributeValue(String[] selectedObjectId, String attrName, String attrType, IDfSession session)
			throws DfException {
		String attrValue = null;
		if (attrType.equalsIgnoreCase("string")) {
			for (int i = 0; i < selectedObjectId.length; i++) {
				IDfSysObject sysObj = (IDfSysObject) session.getObject(new DfId(selectedObjectId[i]));
				if (i == 0) {
					attrValue = sysObj.getString(attrName);
				} else {
					if (attrValue.equals(sysObj.getString(attrName))) {
						continue;
					} else {
						attrValue = "#####";
						break;
					}
				}
			}
		} else {
			for (int i = 0; i < selectedObjectId.length; i++) {
				IDfSysObject sysObj = (IDfSysObject) session.getObject(new DfId(selectedObjectId[i]));

				if (i == 0) {

					attrValue = sysObj.getTime(attrName).asString("MM/dd/yyyy");
				} else {
					if (attrValue.equals(sysObj.getTime(attrName).asString("MM/dd/yyyy"))) {
						continue;
					} else {
						attrValue = "#####";
						break;
					}
				}
			}

		}

		return attrValue;

	}

	/**
	 * validDialog Method is over ridden in the plugin. @param context User
	 * Context @param dialogName Name of the Dialog Invoked @param paramters This
	 * holds all the parameters passed to the plugin like Date format, config name,
	 * values selected on UI @return @throws
	 */
	@Override
	public Dialog validDialog(Context context, String id, String dialogName, List<Attribute> parameters)
			throws Exception {

		LOG.debug("------------------Custom Dialog Plugin Service--------------");

		boolean isBulkUpdate = false;
		boolean lcCallState = false;
		Dialog dialog = null;
		String[] selectedIds = null;
		D2fsContext d2fsContext = (D2fsContext) context;
		if (!StringUtil.isEmptyOrNull(id)) {
			selectedIds = id.split("\254");
			LOG.debug("Selected IDs----" + ArrayUtil.join(selectedIds, ";"));
		}

		if (dialogName.equalsIgnoreCase(SWYConstants.D2_WORKFLOW_DIALOG)) {
			String processName = "";
			for (Attribute attr : parameters) {
				LOG.debug("Parms: " + attr.getName() + " - " + attr.getValue());
				if (attr.getName().equalsIgnoreCase("config")) {
					processName = attr.getValue();
					break;
				}
			}
			if (processName.equals(SWYConstants.BULK_UPDATE_WORKFLOW)) {
				IDfSession session = d2fsContext.getAdminSession();
				LOG.info("------------------Custom Dialog Plugin Service (Valid Dialog Bulk Update)--------------");
				// Set if it's Bulk Update
				isBulkUpdate = true;
				dialog = new Dialog();

				// Set the Success XML to dialog. So that it doesn't initate the
				// actual workflow.
				/* LSS4.2 implementation
				XmlNode result = XmlFactory.getRootSuccess();
				XmlDocument xmlDoc = new XmlDocument(result);
				dialog.setXmlContent(xmlDoc.toString());*/

				/*LSS 16.6 implementation starts*/
				XmlNode result = XmlFactory.getRootSuccess();
				dialog.setXmlContent(result.toString(true));

				/*LSS 16.6 implementation ends*/
				// Check the Bulk Update Type
				String bulkUpdateType = getBulkUpdateType(selectedIds, session);

				if (bulkUpdateType.equalsIgnoreCase(SWYConstants.CORE_LABELING)) {
					String labelingStatus = null;
					String swyDispatchStatus = null;
					// Get Core labeling attributes from the parameter
					for (Attribute attr : parameters) {
						if (attr.getName().equalsIgnoreCase(SWYConstants.MU_ATTR_LABELING_STATUS)) {
							labelingStatus = attr.getValue();

						} else if (attr.getName().equalsIgnoreCase(SWYConstants.MU_ATTR_DISPATCH_STATUS)) {
							swyDispatchStatus = attr.getValue();

						}

					}
					// If Both labeling status and Dispatch Date is equals to
					// #####, No update of attributes

					if (!(labelingStatus.equals("#####") && swyDispatchStatus.equals("#####"))) {
						for (int i = 0; i < selectedIds.length; i++) {

							// Update the selected object attributes
							IDfSysObject selectedObject = (IDfSysObject) session.getObject(new DfId(selectedIds[i]));
							if (!labelingStatus.equals("#####"))
								selectedObject.setString(SWYConstants.MU_ATTR_LABELING_STATUS, labelingStatus);
							if (!swyDispatchStatus.equals("#####"))
								selectedObject.setString(SWYConstants.MU_ATTR_DISPATCH_STATUS, swyDispatchStatus);
							selectedObject.save();
							// Re-evaluate Secrf
							lcCallState = callLifecycleState(selectedIds[i], session, RECLASSIFY_TRANS_STATE);

							if (lcCallState) {
								LOG.error("Transient state::" + RECLASSIFY_TRANS_STATE
										+ " for Object id" + selectedIds[i] + " called successfully");
							} else {
								LOG.error("ERROR in calling transient state::" + RECLASSIFY_TRANS_STATE
										+ " for Object id" + selectedIds[i]);
							}

							if ((selectedObject.getTypeName())
									.equalsIgnoreCase(SWYConstants.CORE_LABELING_OBJECT_TYPE)) {

								// update When selectedObject is Parent Id, The
								// below code is to handle if any documents are
								// moved to Submission Package

								String relatedCoreDocsParentQuery = new StringBuilder("select r_object_id from ")
										.append(SWYConstants.CORE_LABELING_OBJECT_TYPE)
										.append(" where swy_is_labeling_pkg = true and  r_lock_owner is nullstring  ")
										.append("  and  r_object_id in (select child_id from dm_relation where parent_id ='")
										.append(selectedIds[i]).append("' and relation_name='Related Core Labeling')")
										.toString();
								StringBuilder UpdateRelatedCoreDocsParentQuery = new StringBuilder("update ")
										.append(SWYConstants.CORE_LABELING_OBJECT_TYPE).append(" objects ");
								StringBuilder UpdateRelatedCoreDocsChildQuery = new StringBuilder("update ")
										.append(SWYConstants.CORE_LABELING_OBJECT_TYPE).append(" objects ");
								// Append labeling status only when its value is
								// not #####
								if (!labelingStatus.equals("#####")) {
									UpdateRelatedCoreDocsParentQuery.append(" set ")
									.append(SWYConstants.MU_ATTR_LABELING_STATUS).append(" = '")
									.append(labelingStatus).append("'");
									UpdateRelatedCoreDocsChildQuery.append(" set ")
									.append(SWYConstants.MU_ATTR_LABELING_STATUS).append(" = '")
									.append(labelingStatus).append("'");
								}
								// Append dispatch status only when its value is
								// not #####
								if (!swyDispatchStatus.equals("#####")) {
									UpdateRelatedCoreDocsParentQuery.append(" set ")
									.append(SWYConstants.MU_ATTR_DISPATCH_STATUS).append(" = ").append("'")
									.append(swyDispatchStatus).append("' ");
									UpdateRelatedCoreDocsChildQuery.append(" set ")
									.append(SWYConstants.MU_ATTR_DISPATCH_STATUS).append(" = ").append(" '")
									.append(swyDispatchStatus).append("' ");
								}
								UpdateRelatedCoreDocsParentQuery
								.append(" where swy_is_labeling_pkg = true and  r_lock_owner is nullstring  ")
								.append("  and  r_object_id in (select child_id from dm_relation where parent_id ='")
								.append(selectedIds[i]).append("' and relation_name='Related Core Labeling')")
								.toString();
								LOG.debug("UpdateRelatedCoreDocsParentQuery" + UpdateRelatedCoreDocsParentQuery);
								QueryUtils.execQuery(UpdateRelatedCoreDocsParentQuery.toString(), session);

								// update When selectedObject is Child Id
								UpdateRelatedCoreDocsChildQuery
								.append(" where swy_is_labeling_pkg = true and  r_lock_owner is nullstring  ")
								.append("  and  r_object_id in (select parent_id from dm_relation where child_id='")
								.append(selectedIds[i]).append("' and relation_name='Related Core Labeling')")
								.toString();
								LOG.debug("UpdateRelatedCoreDocsChildQuery" + UpdateRelatedCoreDocsChildQuery);
								QueryUtils.execQuery(UpdateRelatedCoreDocsChildQuery.toString(), session);

								IDfCollection  parColl = null;
								try
								{
									parColl = new DfQuery(relatedCoreDocsParentQuery).execute(session,
											DfQuery.READ_QUERY);

									while (parColl.next()) {

										// Re-evaluate Secrf
										lcCallState = callLifecycleState(parColl.getString("r_object_id"), session,
												RECLASSIFY_TRANS_STATE);
										if (lcCallState) {
											LOG.error("Transient state::" + RECLASSIFY_TRANS_STATE
													+ " for Object id" +  parColl.getString("r_object_id") + " called successfully");
										} else {
											LOG.error("ERROR in calling transient state::" + RECLASSIFY_TRANS_STATE
													+ " for Object id" + parColl.getString("r_object_id"));
										}
									}
								}
								finally
								{
									if(parColl!=null)
									{
										parColl.close();
										LOG.debug("bulkupdate::: validDialog Parent Collection closed Core Labelling parColl");
									}
								}
								String relatedCoreDocsChildQuery = new StringBuilder("select r_object_id from ")
										.append(SWYConstants.CORE_LABELING_OBJECT_TYPE)
										.append(" where swy_is_labeling_pkg = true and  r_lock_owner is nullstring  ")
										.append("  and  r_object_id in (select parent_id from dm_relation where child_id ='")
										.append(selectedIds[i]).append("' and relation_name='Related Core Labeling')")
										.toString();

								IDfCollection childColl = null;
								try
								{
									childColl = new DfQuery(relatedCoreDocsChildQuery).execute(session,
											DfQuery.READ_QUERY);

									while (childColl.next()) {

										// Re-evaluate Secrf
										lcCallState = callLifecycleState(childColl.getString("r_object_id"), session,
												RECLASSIFY_TRANS_STATE);
										if (lcCallState) {
											LOG.error("Transient state::" + RECLASSIFY_TRANS_STATE
													+ " for Object id" +  childColl.getString("r_object_id") + " called successfully");
										} else {
											LOG.error("ERROR in calling transient state::" + RECLASSIFY_TRANS_STATE
													+ " for Object id" + childColl.getString("r_object_id"));
										}
									}
								}
								finally
								{
									if(childColl!=null)
									{
										childColl.close();
										LOG.debug( "bulkupdate::: validDialog Child Collection closed Core Labelling childColl");
									}
								}
							}

						}
					}

				} else if (bulkUpdateType.equalsIgnoreCase(SWYConstants.HQ_LABELING)) {
					String labelingStatus = null;
					String swyDispatchStatus = null;
					// Get labelingStatus and Dispatch date from parameters
					for (Attribute attr : parameters) {
						if (attr.getName().equalsIgnoreCase(SWYConstants.MU_ATTR_LABELING_STATUS)) {
							labelingStatus = attr.getValue();

						} else if (attr.getName().equalsIgnoreCase(SWYConstants.MU_ATTR_DISPATCH_STATUS)) {
							swyDispatchStatus = attr.getValue();

						}
					}
					// Attributes are update only when value of it selected on
					// UI is not #####
					if (!(labelingStatus.equals("#####") && swyDispatchStatus.equals("#####"))) {
						for (int i = 0; i < selectedIds.length; i++) {

							IDfSysObject selectedObject = (IDfSysObject) session.getObject(new DfId(selectedIds[i]));
							if (!labelingStatus.equals("#####"))
								selectedObject.setString(SWYConstants.MU_ATTR_LABELING_STATUS, labelingStatus);
							if (!swyDispatchStatus.equals("#####"))
								selectedObject.setString(SWYConstants.MU_ATTR_DISPATCH_STATUS, swyDispatchStatus);
							selectedObject.save();

							// Re-evaluate Secrf
							lcCallState = callLifecycleState(selectedIds[i], session, RECLASSIFY_TRANS_STATE);
							if (lcCallState) {
								LOG.error("Transient state::" + RECLASSIFY_TRANS_STATE
										+ " for Object id" +  selectedObject.getObjectId().getId() + " called successfully");
							} else {
								LOG.error("ERROR in calling transient state::" + RECLASSIFY_TRANS_STATE
										+ " for Object id" + selectedObject.getObjectId().getId());
							}

						}

					}

				} else if (bulkUpdateType.equalsIgnoreCase(SWYConstants.IPL_LABELING)) {
					String iplLabelingStatus = null;
					String swyDispatchStatus = null;
					// Get IPL Labeling Status and Dispatch date from parameters
					for (Attribute attr : parameters) {
						if (attr.getName().equalsIgnoreCase(SWYConstants.MU_ATTR_IPL_LABELING_STATUS)) {
							iplLabelingStatus = attr.getValue();

						} else if (attr.getName().equalsIgnoreCase(SWYConstants.MU_ATTR_DISPATCH_STATUS)) {
							swyDispatchStatus = attr.getValue();

						}

					}

					if (!(iplLabelingStatus.equals("#####") && swyDispatchStatus.equals("#####"))) {
						for (int i = 0; i < selectedIds.length; i++) {

							IDfSysObject selectedObject = (IDfSysObject) session.getObject(new DfId(selectedIds[i]));
							if (!iplLabelingStatus.equals("#####"))
								selectedObject.setString(SWYConstants.MU_ATTR_IPL_LABELING_STATUS, iplLabelingStatus);
							if (!swyDispatchStatus.equals("#####"))
								selectedObject.setString(SWYConstants.MU_ATTR_DISPATCH_STATUS, swyDispatchStatus);
							selectedObject.save();

							// Re-evaluate Secrf
							lcCallState = callLifecycleState(selectedIds[i], session, RECLASSIFY_TRANS_STATE);
							if (lcCallState) {
								LOG.error("Transient state::" + RECLASSIFY_TRANS_STATE
										+ " for Object id" +  selectedObject.getObjectId().getId() + " called successfully");
							} else {
								LOG.error("ERROR in calling transient state::" + RECLASSIFY_TRANS_STATE
										+ " for Object id" + selectedObject.getObjectId().getId());
							}

							LOG.debug("Object_Id--" + selectedIds[i] + "--Type" + selectedObject.getTypeName());
							if ((selectedObject.getTypeName())
									.equalsIgnoreCase(SWYConstants.NON_CORE_LABELING_OBJECT_TYPE)) {

								// update When selectedObject is Parent Id

								String relatedCoreDocsParentQuery = new StringBuilder("select r_object_id from ")
										.append(SWYConstants.NON_CORE_LABELING_OBJECT_TYPE)
										.append(" where swy_is_labeling_pkg = true and  r_lock_owner is nullstring  ")
										.append("  and  r_object_id in (select child_id from dm_relation where parent_id ='")
										.append(selectedIds[i])
										.append("' and relation_name='Related Application Labeling')").toString();
								StringBuilder UpdateRelatedCoreDocsParentQuery = new StringBuilder("update ")
										.append(SWYConstants.NON_CORE_LABELING_OBJECT_TYPE).append(" objects ");
								StringBuilder UpdateRelatedCoreDocsChildQuery = new StringBuilder("update ")
										.append(SWYConstants.NON_CORE_LABELING_OBJECT_TYPE).append(" objects ");
								if (!iplLabelingStatus.equals("#####")) {
									UpdateRelatedCoreDocsParentQuery.append(" set ")
									.append(SWYConstants.MU_ATTR_IPL_LABELING_STATUS).append(" = '")
									.append(iplLabelingStatus).append("'");
									UpdateRelatedCoreDocsChildQuery.append(" set ")
									.append(SWYConstants.MU_ATTR_IPL_LABELING_STATUS).append(" = '")
									.append(iplLabelingStatus).append("'");
								}
								if (!swyDispatchStatus.equals("#####")) {
									UpdateRelatedCoreDocsParentQuery.append(" set ")
									.append(SWYConstants.MU_ATTR_DISPATCH_STATUS).append(" = ").append(" '")
									.append(swyDispatchStatus).append("' ");
									UpdateRelatedCoreDocsChildQuery.append(" set ")
									.append(SWYConstants.MU_ATTR_DISPATCH_STATUS).append(" = ").append(" '")
									.append(swyDispatchStatus).append("' ");
								}
								UpdateRelatedCoreDocsParentQuery
								.append(" where swy_is_labeling_pkg = true and  r_lock_owner is nullstring  ")
								.append("  and  r_object_id in (select child_id from dm_relation where parent_id ='")
								.append(selectedIds[i])
								.append("' and relation_name='Related Application Labeling')").toString();
								LOG.debug("UpdateRelatedCoreDocsParentQuery" + UpdateRelatedCoreDocsParentQuery);
								QueryUtils.execQuery(UpdateRelatedCoreDocsParentQuery.toString(), session);

								// update When selectedObject is Child Id
								UpdateRelatedCoreDocsChildQuery
								.append(" where swy_is_labeling_pkg = true and  r_lock_owner is nullstring  ")
								.append("  and  r_object_id in (select parent_id from dm_relation where child_id='")
								.append(selectedIds[i])
								.append("' and relation_name='Related Application Labeling')").toString();
								LOG.debug("UpdateRelatedCoreDocsChildQuery" + UpdateRelatedCoreDocsChildQuery);
								QueryUtils.execQuery(UpdateRelatedCoreDocsChildQuery.toString(), session);

								IDfCollection parColl = null;
								try
								{
								parColl = new DfQuery(relatedCoreDocsParentQuery).execute(session,
										DfQuery.READ_QUERY);

								while (parColl.next()) {

									// Re-evaluate Secrf
									lcCallState = callLifecycleState(parColl.getString("r_object_id"), session,
											RECLASSIFY_TRANS_STATE);
									if (lcCallState) {
										LOG.error("Transient state::" + RECLASSIFY_TRANS_STATE
												+ " for Object id" +  parColl.getString("r_object_id") + " called successfully");
									} else {
										LOG.error("ERROR in calling transient state::" + RECLASSIFY_TRANS_STATE
												+ " for Object id" + parColl.getString("r_object_id"));
									}
								}
								}
								finally
								{
									if(parColl!=null)
									{
										parColl.close();
										LOG.debug("bulkupdate::: validDialog Parent Collection closed HQLabelling parColl");
									}
								}
								String relatedCoreDocsChildQuery = new StringBuilder("select r_object_id from ")
										.append(SWYConstants.NON_CORE_LABELING_OBJECT_TYPE)
										.append(" where swy_is_labeling_pkg = true and  r_lock_owner is nullstring  ")
										.append("  and  r_object_id in (select parent_id from dm_relation where child_id ='")
										.append(selectedIds[i])
										.append("' and relation_name='Related Application Labeling')").toString();

								IDfCollection childColl = null;
								try
								{
								childColl = new DfQuery(relatedCoreDocsChildQuery).execute(session,
										DfQuery.READ_QUERY);

								while (childColl.next()) {
									// Re-evaluate Secrf
									lcCallState = callLifecycleState(childColl.getString("r_object_id"), session,
											RECLASSIFY_TRANS_STATE);
									if (lcCallState) {
										LOG.error("Transient state::" + RECLASSIFY_TRANS_STATE
												+ " for Object id" +  childColl.getString("r_object_id") + " called successfully");
									} else {
										LOG.error("ERROR in calling transient state::" + RECLASSIFY_TRANS_STATE
												+ " for Object id" + childColl.getString("r_object_id"));
									}
								}
								}
								finally
								{
									if(childColl!=null)
									{
										childColl.close();
										LOG.debug("bulkupdate::: validDialog Child Collection closed HQLabelling childColl");
									}
								}

							}

						}
					}

				} else if (bulkUpdateType.equalsIgnoreCase(SWYConstants.NATIONAL_LABELING)) {
					String nationalLabelingStatus = null;
					String nationalLabelingRound = null;

					for (Attribute attr : parameters) {

						if (attr.getName().equalsIgnoreCase(SWYConstants.MU_ATTR_NAT_LABELING_STATUS)) {
							nationalLabelingStatus = attr.getValue();

						} else if (attr.getName().equalsIgnoreCase(SWYConstants.MU_ATTR_NAT_LABELING_ROUND)) {
							nationalLabelingRound = attr.getValue();

						}
					}

					if (!(nationalLabelingStatus.equals("#####") && nationalLabelingRound.equals("#####"))) {
						for (int i = 0; i < selectedIds.length; i++) {

							IDfSysObject selectedObject = (IDfSysObject) session.getObject(new DfId(selectedIds[i]));
							if (!nationalLabelingStatus.equals("#####"))
								selectedObject.setString(SWYConstants.MU_ATTR_NAT_LABELING_STATUS,
										nationalLabelingStatus);
							if (!nationalLabelingRound.equals("#####"))
								selectedObject.setString(SWYConstants.MU_ATTR_NAT_LABELING_ROUND,
										nationalLabelingRound);
							selectedObject.save();

							// Re-evaluate Secrf
							lcCallState = callLifecycleState(selectedIds[i], session, RECLASSIFY_TRANS_STATE);
							if (lcCallState) {
								LOG.error("Transient state::" + RECLASSIFY_TRANS_STATE
										+ " for Object id" +  selectedIds[i] + " called successfully");
							} else {
								LOG.error("ERROR in calling transient state::" + RECLASSIFY_TRANS_STATE
										+ " for Object id" + selectedIds[i]);
							}

							LOG.debug("Object_Id--" + selectedIds[i] + "--Type" + selectedObject.getTypeName());
							if ((selectedObject.getTypeName())
									.equalsIgnoreCase(SWYConstants.NON_CORE_LABELING_OBJECT_TYPE)) {

								// update When selectedObject is Parent Id

								String relatedCoreDocsParentQuery = new StringBuilder("select r_object_id from ")
										.append(SWYConstants.NON_CORE_LABELING_OBJECT_TYPE)
										.append(" where swy_is_labeling_pkg = true and  r_lock_owner is nullstring  ")
										.append("  and  r_object_id in (select child_id from dm_relation where parent_id ='")
										.append(selectedIds[i])
										.append("' and relation_name='Related Application Labeling')").toString();
								StringBuilder UpdateRelatedCoreDocsParentQuery = new StringBuilder("update ")
										.append(SWYConstants.NON_CORE_LABELING_OBJECT_TYPE).append(" objects ");
								StringBuilder UpdateRelatedCoreDocsChildQuery = new StringBuilder("update ")
										.append(SWYConstants.NON_CORE_LABELING_OBJECT_TYPE).append(" objects ");
								if (!nationalLabelingStatus.equals("#####")) {
									UpdateRelatedCoreDocsParentQuery.append(" set ")
									.append(SWYConstants.MU_ATTR_NAT_LABELING_STATUS).append(" = '")
									.append(nationalLabelingStatus).append("'");
									UpdateRelatedCoreDocsChildQuery.append(" set ")
									.append(SWYConstants.MU_ATTR_NAT_LABELING_STATUS).append(" = '")
									.append(nationalLabelingStatus).append("'");
								}
								if (!nationalLabelingRound.equals("#####")) {
									UpdateRelatedCoreDocsParentQuery.append(" set ")
									.append(SWYConstants.MU_ATTR_NAT_LABELING_ROUND).append(" = '")
									.append(nationalLabelingRound).append("'");
									UpdateRelatedCoreDocsChildQuery.append(" set ")
									.append(SWYConstants.MU_ATTR_NAT_LABELING_ROUND).append(" = '")
									.append(nationalLabelingRound).append("'");
								}
								UpdateRelatedCoreDocsParentQuery
								.append(" where swy_is_labeling_pkg = true and  r_lock_owner is nullstring  ")
								.append("  and  r_object_id in (select child_id from dm_relation where parent_id ='")
								.append(selectedIds[i])
								.append("' and relation_name='Related Application Labeling')").toString();
								LOG.debug("UpdateRelatedCoreDocsParentQuery" + UpdateRelatedCoreDocsParentQuery);
								QueryUtils.execQuery(UpdateRelatedCoreDocsParentQuery.toString(), session);

								// update When selectedObject is Child Id
								UpdateRelatedCoreDocsChildQuery
								.append(" where swy_is_labeling_pkg = true and  r_lock_owner is nullstring  ")
								.append("  and  r_object_id in (select parent_id from dm_relation where child_id='")
								.append(selectedIds[i])
								.append("' and relation_name='Related Application Labeling')").toString();
								LOG.debug("UpdateRelatedCoreDocsChildQuery" + UpdateRelatedCoreDocsChildQuery);
								QueryUtils.execQuery(UpdateRelatedCoreDocsChildQuery.toString(), session);

								IDfCollection parColl =null;
								try
								{
								parColl = new DfQuery(relatedCoreDocsParentQuery).execute(session,
										DfQuery.READ_QUERY);

								while (parColl.next()) {

									// Re-evaluate Secrf
									lcCallState = callLifecycleState(parColl.getString("r_object_id"), session,
											RECLASSIFY_TRANS_STATE);
									if (lcCallState) {
										LOG.error("Transient state::" + RECLASSIFY_TRANS_STATE
												+ " for Object id" +  selectedIds[i] + " called successfully");
									} else {
										LOG.error("ERROR in calling transient state::" + RECLASSIFY_TRANS_STATE
												+ " for Object id" + selectedIds[i]);
									}
								}
								}
								finally
								{
									if(parColl!=null)
									{
										parColl.close();
										LOG.debug("bulkupdate::: validDialog Parent Collection closed National Labelling parColl");
									}
								}
								String relatedCoreDocsChildQuery = new StringBuilder("select r_object_id from ")
										.append(SWYConstants.NON_CORE_LABELING_OBJECT_TYPE)
										.append(" where swy_is_labeling_pkg = true and  r_lock_owner is nullstring  ")
										.append("  and  r_object_id in (select parent_id from dm_relation where child_id ='")
										.append(selectedIds[i])
										.append("' and relation_name='Related Application Labeling')").toString();

								IDfCollection childColl =null;
								try
								{
								childColl = new DfQuery(relatedCoreDocsChildQuery).execute(session,
										DfQuery.READ_QUERY);

								while (childColl.next()) {

									// Re-evaluate Secrf
									lcCallState = callLifecycleState(childColl.getString("r_object_id"), session,
											RECLASSIFY_TRANS_STATE);
									if (lcCallState) {
										LOG.error("Transient state::" + RECLASSIFY_TRANS_STATE
												+ " for Object id" +  selectedIds[i] + " called successfully");
									} else {
										LOG.error("ERROR in calling transient state::" + RECLASSIFY_TRANS_STATE
												+ " for Object id" + selectedIds[i]);
									}
								}
								}
								finally
								{
									if(childColl!=null)
									{
										childColl.close();
										LOG.debug( "bulkupdate::: validDialog Child Collection closed National Labelling childColl");
									}
								}

							}

						}
					}

				}

			}
		}
		// If Its bulk Update then retruns the newly constructed Success dialog
		// else return Super.ValidDialog
		if (isBulkUpdate)
			return dialog;
		return super.validDialog(d2fsContext, id, dialogName, parameters);

	}

	public boolean callLifecycleState(String documentId, IDfSession session, String lcState) {
		boolean bool = false;
		try {
			LOG.info( "Object Ids [" + documentId + "] Calling LC state [" + lcState
					+ "] to complete the task :::  start ");
			IDfId docId = new DfId(documentId);
			String lcTransitionState = lcState;
			Map<String, Object> arguments = new HashMap<String, Object>();
			arguments.put(D2Method.ARG_ID, docId);
			arguments.put(D2Method.ARG_CALLER_LOGIN, session.getLoginUserName());
			arguments.put(D2LifecycleChangeStateMethod.ARG_TARGET_STATE, lcTransitionState);
			arguments.put(D2LifecycleChangeStateMethod.ARG_TRANSITION_TYPE, "promote");
			arguments.put(D2Method.ARG_CLIENT_LOCALE, DfSessionUtil.getLocale(session).getLanguage());

			D2Method.start(session, D2LifecycleChangeStateMethod.class, arguments);
			bool = true;
			LOG.debug("====> Promoting to transition state -> " + lcTransitionState);
		} catch (Exception ex) {
			bool = false;
			LOG.error("ERROR in calling transient state for object id :- " + documentId + "\n[ERROR] : ");
		}
		LOG.info("Object Ids [" + documentId + "] Calling LC state [" + lcState+ "] to complete the task :::  done with status [" + bool + "]");
		return bool;
	}

	@Override
	public String getFullName() {
		// TODO Auto-generated method stub
		return VERSION.getFullName();
	}

	@Override
	public String getProductName() {
		// TODO Auto-generated method stub
		return VERSION.getProductName();
	}

}
