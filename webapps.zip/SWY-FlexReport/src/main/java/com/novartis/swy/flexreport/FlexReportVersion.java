
package com.novartis.swy.flexreport;

import com.emc.common.java.utils.AbstractVersion;
import com.emc.common.java.utils.IVersion;



/**
 * Display the plugin version.
 *
 * @author patilk
 * @version revising1.0
 */
public final class FlexReportVersion extends AbstractVersion
{
    //~ Methods ------------------------------------------------------------------------------------

    /**
     * DOCUMENT ME!
     *
     * @param args DOCUMENT ME!
     **/
    public static void main(String[] args)
    {
        IVersion version = new FlexReportVersion();
    }
}
