package com.novartis.swy.flexreport.webfs.services.x3configservice;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfPersistentObject;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.utils.QueryUtils;
import com.emc.common.java.utils.IVersion;
import com.emc.d2fs.dctm.web.services.D2fsContext;
import com.emc.d2fs.dctm.web.services.ID2fsPlugin;
import com.emc.d2fs.dctm.web.services.config.D2X3ConfigService;
import com.emc.d2fs.models.context.Context;
import com.emc.d2fs.models.x3_space.X3Space;

import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * D2X3ConfigServicePlugin extends D2X3ConfigService. This class overrides behavior of D2X3ConfigService
 * @author patilk
 *  
 * *************JIRA 2959*******************************************
 * Date : 21-Dec-2020 , Author : SHUBHKU1, SUKANRA1
 * Re-factored code, handled collection leak issue (JIRA# 2959)
 * *****************************************************************
 */
public class D2X3ConfigServicePlugin extends D2X3ConfigService implements ID2fsPlugin {

	private static final IVersion VERSION = new com.novartis.swy.flexreport.FlexReportVersion();
	private static final Logger LOGGER = LoggerFactory.getLogger(D2X3ConfigService.class);
	private static final String MULTI_WS_GROUPS = "CMN-DIC-Multi WS Groups";
	

	public List<X3Space> getAvailableSpaces(Context context) throws Exception {

		LOGGER.debug("-----------D2X3ConfigServicePlugin custom plugin Invoked-----------");

		// Get Context, Current User Session
		D2fsContext d2fsContext = (D2fsContext) context;
		IDfSession curSess = d2fsContext.getSession();
		String curUser = curSess.getLoginUserName();
		IDfSession adminSess = d2fsContext.getAdminSession();
		if (isWsRestrictedUser(curUser, adminSess)) {

			// Get Admin session to execute queries against D2 Config objects

			// Get D2 Contexts applicable to the logged in user
			List<String> contextList = new ArrayList<String>();
			String d2_documentsetDQL = "select object_name from d2_documentset where any group_names in (select group_name from dm_group where any i_all_users_names ='"
					+ curUser + "' "
					+ "	and group_name in (select object_name from  d2_dictionary_value where is_enabled= true and dictionary_name = '"
					+ MULTI_WS_GROUPS + "'))";
		
			IDfQuery d2_documentsetDQLQry = new DfQuery(d2_documentsetDQL);

			IDfCollection d2_documentsetColl =null; 
			
			try
			{
			d2_documentsetColl = d2_documentsetDQLQry.execute(adminSess, DfQuery.READ_QUERY);
			while (d2_documentsetColl.next()) {
				contextList.add(d2_documentsetColl.getString("object_name"));
			}
			
			}
			finally
			{
				if(d2_documentsetColl!=null)
				{
					d2_documentsetColl.close();
					LOGGER.debug("::: Flex Report - getAvailableSpaces() ::: Collection Closed");

				}
			}

			// Print the list of D2 Contexts applicable to the logged in user
			for (String usrContext : contextList) {
				LOGGER.debug("context available to " + curUser + " : " + usrContext);
			}

			// Get X3 Space Config mapped to the fetched D2 Contexts
			List<String> spaceList = new ArrayList<String>();
			IDfPersistentObject d2_documentset_switch = (IDfPersistentObject) adminSess
					.getObjectByQualification("d2_documentset_switch where object_name='x3_space_config'");

			for (int x = 0; x < d2_documentset_switch.getValueCount("documentset_name"); x++) {
				String curContext = d2_documentset_switch.getRepeatingString("documentset_name", x);
				String[] allCurContext = curContext.split("¬");
				String latestContext = allCurContext[allCurContext.length - 1];
				String spaceConfigName = d2_documentset_switch.getRepeatingString("config_name", x);

				if (contextList.contains(latestContext)) {
					if (!spaceList.contains(spaceConfigName)) {
						spaceList.add(spaceConfigName);
						LOGGER.debug("Not a duplicate: " + spaceConfigName);
						
					} else {
						LOGGER.debug("Found duplicate: " + spaceConfigName);

					}
				}
			}

			// Print the list of X3 Worspaces applicable to the fetched D2
			// Contexts
			for (String usrSpace : spaceList) {
				LOGGER.debug("Workspace available to " + curUser + " : " + usrSpace);
			}

			List<X3Space> curSpaces = super.getAvailableSpaces(context);

			// Add spaces identified
			for (String space : spaceList) {
				// Add workspace to X3 Config
				X3Space newSpace = getSpace(context, space, true);
				// Check if newSpace already exist in currSpaces.
				if (!isRepeatedContext(curSpaces, newSpace))
				{
					curSpaces.add(newSpace);
					LOGGER.debug("Adding this identified workspace : " + space);
				}
			}

			// Print added spaces
			for (X3Space space : curSpaces) {

				LOGGER.debug("Added space " + space.getSpaceConfigName());
			}

			LOGGER.debug("-----------D2X3ConfigServicePlugin custom plugin End-----------");
			return curSpaces;
		} else {
			return super.getAvailableSpaces(d2fsContext);
		}
	}

	/**
	 * @param
	 * @return Version Number of Plugin
	 * @throws
	 */
	@Override
	public String getFullName() {
		return VERSION.getFullName();
	}

	/**
	 * @param
	 * @return Product Name
	 * @throws
	 */
	@Override
	public String getProductName() {
		return VERSION.getProductName();
	}

	/**
	 * isRepeatedContext checks for if a context already exist in CurrentContext
	 * @param currSpaces List of spaces for a user
	 * @param context Context that is being added to currSpaces
	 * @return isRepeatedContext return if context already exists in curSpaces
	 * @throws
	 */
	public boolean isRepeatedContext(List<X3Space> curSpaces, X3Space context) {
		boolean isRepeatedContext = false;
		for (X3Space space : curSpaces) {
			if (space.getSpaceConfigName().equalsIgnoreCase(context.getSpaceConfigName())) {
				isRepeatedContext = true;
				break;
			}
		}

		return isRepeatedContext;

	}

	/**
	 * isWsRestrictedUser Checks if users is part of any group which corresponds to Multi Workspace Display
	 * @param user UserName of Logged In user
	 * @return isUserIngroup Returns true if user is part of any multi Workspace group
	 */
	public boolean isWsRestrictedUser(String user, IDfSession session) throws Exception{
		boolean isUserIngroup = false;
		String checkUserGroupQuery = new StringBuilder(
				"select count(r_object_id) as group_count from dm_group where group_name in (")
						.append("select object_name from  d2_dictionary_value where is_enabled= true and  dictionary_name = '")
						.append(MULTI_WS_GROUPS).append("') and any i_all_users_names = '").append(user).append("'")
						.toString();
		IDfQuery dfQuery = new DfQuery(checkUserGroupQuery);
		IDfCollection coll =null;
		try {
			 coll = dfQuery.execute(session, DfQuery.READ_QUERY);
			while (coll.next()) {
				if (coll.getInt("group_count") > 0)
					isUserIngroup = true;
			}
		} catch (DfException e) {
			LOGGER.error(e.getMessage());
		}
		finally
		{
			if(coll!=null)
			{
				coll.close();
				LOGGER.debug( "::: Flex Report isWsRestrictedUser() ::: Collection Closed" );

			}
		}

		return isUserIngroup;

	}

}
