package com.novartis.swy.bulkexportrendition;

import org.apache.commons.lang.StringUtils;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.client.IDfType;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.utils.QueryUtils;
/**
 * Utiltiy Class for Bulk Export of Native PDF
 * renditions
 * 
 * @author SUKANRA1
 *
 * *************JIRA 2959**************************************************************************
 * Date : 21-Dec-2020 , Author : SHUBHKU1, SUKANRA1
 * Re-factored code, merged method "runDQLQuery1()" with "runSelectQuery()"  , JIRA# 2959 
 * ************************************************************************************************
 *
 */
public class SWYDCTMUtils {

	public static IDfCollection runSelectQuery(String query, IDfSession session) throws DfException {
		IDfCollection col = null;
		if (!query.toLowerCase().startsWith("select")) {
			throw new DfException("Select query must start with 'SELECT'");
		}
		
		if ((query == null) || (query.trim().isEmpty())) {
			throw new DfException("Query string is null or blank.");
		}
		if (session == null) {
			throw new DfException("Session is null.");
		}
		DfLogger.debug("SWYDCTMUtils.runDQLQuery", "query=" + query, null, null);

		IDfQuery q = new DfQuery();
		q.setDQL(query);
		col = q.execute(session, 0);
		
		return col;
	}

	/*private static IDfCollection runDQLQuery1(String query, IDfSession session, int queryType) throws DfException {
		IDfCollection col = null;
		if ((query == null) || (query.trim().isEmpty())) {
			throw new DfException("Query string is null or blank.");
		}
		if (session == null) {
			throw new DfException("Session is null.");
		}
		DfLogger.debug("SWYDCTMUtils.runDQLQuery", "query=" + query, null, null);

		IDfQuery q = new DfQuery();
		q.setDQL(query);
		col = q.execute(session, queryType);

		return col;
	}*/

	/**
	 * Method to validate if the sysobject has rendition.
	 * 
	 * @param sysObject
	 * @param session
	 * @return
	 * @throws DfException
	 */
	public static boolean hasPDFRendition(IDfSysObject sysObject, IDfSession session) throws DfException {

		String objectID = sysObject.getObjectId().getId();
		String query = "select doc.r_object_id from dm_document doc, dmr_content cnt where  any cnt.parent_id=doc.r_object_id and cnt.full_format ='"
				+ SWYConstants.RENDITION_FORMAT + "' and any cnt.parent_id='" + objectID + "'";
		String[] result = QueryUtils.getAllQueryResultsAsStrings(query, session);

		return (result.length > 0) ? true : false;

	}

	/**
	 * Method to get the object type of the source document.
	 * 
	 * @param selectedObjectId
	 * @param session
	 * @return
	 * @throws DfException
	 */
	public static String getSourceObjectType(String[] selectedObjectId, IDfSession session) throws DfException {

		IDfSysObject sysObject = null;
		IDfType objectType = null;
		String sourceObjectType = null;
		for (int i = 0; i < selectedObjectId.length; i++) {
			sysObject = (IDfSysObject) session.getObject(new DfId(selectedObjectId[i]));
			objectType = session.getType(sysObject.getString(SWYConstants.ATTR_R_OBJECT_TYPE));

			if (objectType.isSubTypeOf(SWYConstants.OBJ_TYPE_DM_FOLDER)
					|| StringUtils.equalsIgnoreCase(objectType.getName(), SWYConstants.OBJ_TYPE_DM_FOLDER)) {
				sourceObjectType = SWYConstants.OBJ_TYPE_DM_FOLDER;
				break;
			} else if (objectType.isSubTypeOf(SWYConstants.OBJ_TYPE_DM_DOCUMENT)
					|| StringUtils.equalsIgnoreCase(objectType.getName(), SWYConstants.OBJ_TYPE_DM_DOCUMENT)) {
				sourceObjectType = SWYConstants.OBJ_TYPE_DM_DOCUMENT;
				break;
			} else {
				DfLogger.info(null, "Source object undidentified", null, null);
			}
		}
		return sourceObjectType;
	}

}
