package com.novartis.swy.bulkexportrendition;

import com.emc.common.java.utils.AbstractVersion;
import com.emc.common.java.utils.IVersion;

/**
 * Displays the BulkExportRendtion plugin version.
 * 
 * @author SUKANRA1
 * @version 2.2
 */

public class SWYBulkExportRendtionVersion extends AbstractVersion {
	 public static void main(String[] args)
	    {
			@SuppressWarnings("unused")
			IVersion version = new SWYBulkExportRendtionVersion();
	       
	    }
}
