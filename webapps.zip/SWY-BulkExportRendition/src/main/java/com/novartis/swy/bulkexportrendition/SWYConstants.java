package com.novartis.swy.bulkexportrendition;

public abstract class SWYConstants {

	// Dialog Names
	public static final String D2_WORKFLOW_DIALOG = "D2WorkflowLaunchDialog";
	public static final String BULK_EXPORT_RENDITION_WORKFLOW = "CMN-WF-BulkExportRendtion";

	public static final String OBJ_TYPE_DM_FOLDER = "dm_folder";
	public static final String OBJ_TYPE_DM_DOCUMENT = "dm_document";
	public static final String OBJ_TYPE_DM_ACL = "dm_acl";
	public static final String OBJ_BULK_PDF_EXPORT_ACL = "Bulk PDF Export ACL";
	
	public static final String OBJ_ACL_WORLD_PERMIT = "dm_world";
	public static final String OBJ_ACL_OWNER_PERMIT = "dm_owner";
	
	public static final String OBJ_ACL_DOMAIN_USER = "dm_dbo";

	public static final String ATTR_R_OBJECT_ID = "r_object_id";
	public static final String ATTR_R_OBJECT_TYPE = "r_object_type";
	public static final String ATTR_PARENT_ID = "parent_id";
	public static final String ATTR_CONFIG = "config";
	public static final String ATTR_LOG_ENTRY = "log_entry";
	public static final String ATTR_LOG_ENTRY_VALUE = "Bulk Export Rendition";
	public static final String ATTR_D2_URL_PARAM = "d2_url_param";
	public static final String ATTR_A_STATUS = "a_status";
	public static final String EFFECTIVE_STATUS = "Effective";
	
	public static final String STR_DOCUMENT ="Document";
	public static final String STR_ELCTRONICALLY="electronically";
	public static final String STR_SIGNED ="signed";	
	
	public static final String CABINET_GENERAL ="General";
	public static final String FOLDER_BULK_PDF_EXPORT="Bulk PDF Export";
	
	public static final String SYSTEM_PROP_USER_HOME = "user.home";
	public static final String SYSTEM_PROP_JAVA_IO_TMP_DIR = "java.io.tmpdir";

	public static final String RENDITION_FORMAT = "pdf";
	public static final String FOLDER_ID_PREFIX = "0b";
	public static final String DOCUMENT_ID_PREFIX = "09";
	public static final String ZIP_FORMAT = ".zip";
	public static final String DOT = ".";
	public static final String NULL = null;

	public static final String ARG_ID = "-id";
	public static final String ARG_EVENT = "-event";
	public static final String ARG_CONTEXT_USER = "-context_user";
	public static final String ARG_AUDIT_FIELD = "-string_1";
	public static final String EVENT_D2_EXPORT = "d2_export";
	public static final String AUDIT_EVENT_DESCRIPTION = "Bulk PDF Rendition Exported";
	public static final String CDF_AUDIT_METHOD = "CDFAuditMethod";
	public static final String CDF_NOTIFY_USERS_METHOD = "CDFNotifyUsersAsynchMethod";

	
	public final static String ARG_CONTEXT_OBJECT_ID = "-id";
	public final static String ARG_PRECONDITION = "-if";
	public final static String ARG_MESSAGE = "-message";
	public final static String ARG_MIN_PERMIT = "-min_permit";
	public final static String ARG_USER_ROLES = "-user_roles";
	public final static String ARG_OTHER_USERS = "-other_users";
	
	// Method-specific argument values
	public static final String NOTIFY_USERS_TITLE = "notifyUsers.title";
	public static final String NOTIFY_USERS_CONDITION = "notifyUsers.ifCondition";
	public static final String NOTIFY_USERS_EVENT = "notifyUsers.event";
	public static final String NOTIFY_USERS_MESSAGE = "notifyUsers.message";
	public static final String NOTIFY_USERS_USER_ROLE = "notifyUsers.userRole";
	public static final String NOTIFY_USERS_OTH_USERS = "notifyUsers.otherUsers";
	public static final String NOTIFY_USERS_MIN_PERMIT = "notifyUsers.minPermit";

}
