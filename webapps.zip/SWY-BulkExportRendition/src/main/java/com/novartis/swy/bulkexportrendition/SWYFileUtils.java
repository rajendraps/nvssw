package com.novartis.swy.bulkexportrendition;

import java.io.File;

public class SWYFileUtils {


	public static long getTimeInMilliSeconds() {
		long timeInMilliSeconds = System.currentTimeMillis();
		return timeInMilliSeconds;
	}

	public static String getFileExtension(String filename) {
		int i = (filename == null ? -1 : filename.lastIndexOf('.'));
		if (i == -1) {
			return "";
		} else {
			return filename.substring(i + 1);
		}
	}

	public static String returnFileNameFromPath(String filePath) {
		File file = new File(filePath);
		return file.getAbsolutePath().substring(file.getAbsolutePath().lastIndexOf("\\") + 1);

	}

}
