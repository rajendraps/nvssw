package com.novartis.swy.bulkexportrendition.webfs.services.dialog;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.mail.internet.InternetAddress;

import com.documentum.com.DfClientX;
import com.documentum.fc.client.IDfACL;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.client.IDfUser;
import com.documentum.fc.common.DfException;
import com.documentum.utils.StringUtils;
import com.emc.common.java.javamail.MailMessage;
import com.emc.common.java.javamail.MailSender;
import com.emc.common.java.utils.ArrayUtil;
import com.emc.common.java.utils.IVersion;
import com.emc.common.java.xml.XmlDocument;
import com.emc.common.java.xml.XmlNode;
import com.emc.common.java.xml.XmlNodeImpl;
import com.emc.common.java.xml.XmlUtil;
import com.emc.d2.api.config.mail.D2MailConfig;
import com.emc.d2.api.config.mail.ID2MailConfig;
import com.emc.d2.api.methods.D2Method;
//import com.emc.d2.web.servlets.XmlFactory;
import com.emc.d2fs.dctm.ui.XmlFactory;
import com.emc.d2fs.dctm.web.services.D2fsContext;
import com.emc.d2fs.dctm.web.services.ID2fsPlugin;
import com.emc.d2fs.dctm.web.services.dialog.D2DialogService;
import com.emc.d2fs.models.attribute.Attribute;
import com.emc.d2fs.models.context.Context;
import com.emc.d2fs.models.dialog.Dialog;
import com.lowagie.text.DocumentException;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfStamper;
import com.lowagie.text.pdf.parser.PdfTextExtractor;
import com.novartis.swy.bulkexportrendition.SWYBulkExportRendtionVersion;
import com.novartis.swy.bulkexportrendition.SWYConstants;
import com.novartis.swy.bulkexportrendition.SWYDCTMUtils;
import com.novartis.swy.bulkexportrendition.SWYFileUtils;

/**
 * Custom D2DialogServicePlugin for overriding the Bulk Export of Native PDF
 * renditions
 * 
 * @author SUKANRA1
 *
 * *************JIRA 2959*******************************************
 * Date : 21-Dec-2020 , Author : SHUBHKU1, SUKANRA1
 * Re-factored code, handled collection leak issue (JIRA# 2959)
 * *****************************************************************
 *
 */

public class D2DialogServicePlugin extends D2DialogService implements ID2fsPlugin {
	private static final IVersion VERSION = new SWYBulkExportRendtionVersion();

	public D2DialogServicePlugin() {

	}

	/**
	 * Override the default D2Dialog getDialog method for Bulk Update
	 * 
	 * @param context
	 *            The D2fsContext passed from user session.
	 * @param context
	 *            The D2fsContext passed from user session.
	 * @param id
	 *            The id holds the Object Ids of the objects selected
	 * @param dialogName
	 *            This parameter hold the dialog name that is being invoked
	 * @param paramters
	 *            This holds all the parameters passed to the plugin like Date
	 *            format, config name
	 * @return Dialog
	 * @throws IOException
	 */
	@Override
	public Dialog getDialog(Context context, String id, String dialogName, List<Attribute> parameters)
			throws Exception {
		LOG.debug("------------------Custom Dialog Plugin Service (Get Dialog)--------------");
		LOG.debug("Dialogue Name: " + dialogName);
		String[] inputIds = null;
		if (!StringUtils.isNullOrEmpty(id)) {
			inputIds = id.split("\254");
			LOG.debug("Selected IDs" + ArrayUtil.join(inputIds, "--"));
		}
		Dialog dialog = super.getDialog(context, id, dialogName, parameters);
		// D2fsContext d2fsContext = (D2fsContext) context;

		if (dialogName.equalsIgnoreCase(SWYConstants.D2_WORKFLOW_DIALOG)) {
			String processName = "";
			for (Attribute attr : parameters) {
				LOG.debug("Parms: " + attr.getName() + " - " + attr.getValue());
				if (attr.getName().equalsIgnoreCase("config")) {
					processName = attr.getValue();
					break;
				}
			}
			if (processName.equals(SWYConstants.BULK_EXPORT_RENDITION_WORKFLOW)) {

				LOG.info("------------------Custom Dialog Plugin Service (Get Dialog Bulk Update)--------------");
				// Get Admin Session for running D2 Core Job
				// IDfSession session = d2fsContext.getAdminSession();
				XmlDocument xmlDoc = XmlUtil.loadFromString(dialog.getXmlContent());

				XmlNode rootXmlNode = xmlDoc.getRootXmlNode();
				// Remove the Workflow Xml Content
				rootXmlNode.removeAllXmlNode();
				rootXmlNode.clean();

				LOG.info( "Root XML Node.");

				/*LSS4.2 implementation
				XmlNode contentNode = new XmlNode("content");
				XmlNode fieldSetNode = new XmlNode("fieldset");
				XmlNode label = new XmlNode("comment");*/

				/*LSS 16.6 implementation starts*/
				XmlNode contentNode = new XmlNodeImpl("content");
				XmlNode fieldSetNode = new XmlNodeImpl("fieldset");
				XmlNode label = new XmlNodeImpl("comment");
				/*LSS 16.6 implementation ends*/

				label.setValue(
						"The native PDF renditions of documents are being zipped and an email will be sent to the requestor with a link to download the files.");
				fieldSetNode.appendXmlNode(label);
				contentNode.appendXmlNode(fieldSetNode);
				rootXmlNode.appendXmlNode(contentNode);

				/* LSS4.2 implementation	
			 	XmlNode buttonNode = new XmlNode("buttons");

				XmlNode okButtonNode = new XmlNode("button");*/

				/*LSS 16.6 implementation starts*/
				XmlNode buttonNode = new XmlNodeImpl("buttons");
				XmlNode okButtonNode = new XmlNodeImpl("button");
				/*LSS 16.6 implementation ends*/

				okButtonNode.setAttribute("id", "buttonOk");
				okButtonNode.setAttribute("label", "Ok");
				okButtonNode.setAttribute("action", "validDialog()");
				buttonNode.appendXmlNode(okButtonNode);

				/* LSS4.2 implementation
				XmlNode cancelButtonNode = new XmlNode("button");
				 */
				/*LSS 16.6 implementation starts*/
				XmlNode cancelButtonNode = new XmlNodeImpl("button");
				/*LSS 16.6 implementation ends*/
				cancelButtonNode.setAttribute("id", "buttonCancel");
				cancelButtonNode.setAttribute("label", "Cancel");
				cancelButtonNode.setAttribute("action", "cancelDialog()");
				buttonNode.appendXmlNode(cancelButtonNode);

				rootXmlNode.appendXmlNode(buttonNode);
				// Set new XML to dialog
				dialog.setXmlContent(rootXmlNode.toString(true));
			}
		}
		return dialog;
	}

	/**
	 * validDialog Method is over ridden in the plugin. @param context User
	 * Context @param dialogName Name of the Dialog Invoked @param paramters This
	 * holds all the parameters passed to the plugin like Date format, config name,
	 * values selected on UI @return @throws
	 */
	@Override
	public Dialog validDialog(Context context, String id, String dialogName, List<Attribute> parameters)
			throws Exception {

		LOG.debug("------------------Bulk Export PDF Dialog Plugin Service--------------");
		boolean isBulkExportRendtion = false;
		String[] selectedIds = null;
		if (!StringUtils.isNullOrEmpty(id)) {
			selectedIds = id.split("\254");
			LOG.debug("Selected IDs----" + ArrayUtil.join(selectedIds, ";"));
		}

		Dialog dialog = null;

		D2fsContext d2fsContext = (D2fsContext) context;
		String contextUser = d2fsContext.getSession().getLoginUserName();
		LOG.info("Bulk Export PDF Rendition Context User = " + contextUser);
		IDfSession session = d2fsContext.getAdminSession();
		IDfSession userSession = d2fsContext.getSession();

		String webAppUrl = d2fsContext.getWebAppURL();

		if (dialogName.equalsIgnoreCase(SWYConstants.D2_WORKFLOW_DIALOG)) {
			String processName = "";
			for (Attribute attr : parameters) {
				LOG.debug("Parms: " + attr.getName() + " - " + attr.getValue());
				if (attr.getName().equalsIgnoreCase(SWYConstants.ATTR_CONFIG)) {
					processName = attr.getValue();
					break;
				}
			}
			if (processName.equals(SWYConstants.BULK_EXPORT_RENDITION_WORKFLOW)) {
				LOG.info(
						"------------------Bulk Export PDF Dialog Plugin Service (Valid Dialog Bulk Export)--------------");
				// Set if it's Bulk Update
				isBulkExportRendtion = true;
				dialog = new Dialog();
				// Set the Success XML to dialog. So that it doesn't initate the
				// actual workflow.

				/*LSS4.2 implementation
				XmlNode result = XmlFactory.getRootSuccess();
				XmlDocument xmlDoc = new XmlDocument(result);
				dialog.setXmlContent(xmlDoc.toString());*/

				/*LSS 16.6 implementation starts*/
				XmlNode result = XmlFactory.getRootSuccess();
				dialog.setXmlContent(result.toString(true));
				/*LSS 16.6 implementation ends*/

				LOG.info("WebApp URL = " + webAppUrl);
				// Check the Bulk Update Type
				String sourceObjectType = SWYDCTMUtils.getSourceObjectType(selectedIds, session);
				if (sourceObjectType.equalsIgnoreCase(SWYConstants.OBJ_TYPE_DM_FOLDER)) {
					LOG.info("------------- Exporting Bulk PDF Folder Obejcts-----------------------");
					exportBulkRendtionFolderObjects(selectedIds, session, contextUser, userSession, webAppUrl);
				} else if (sourceObjectType.equalsIgnoreCase(SWYConstants.OBJ_TYPE_DM_DOCUMENT)) {
					LOG.info("------------- Exporting Bulk PDF Multiple Obejcts---------------------");
					exportBulkRenditionObjects(selectedIds, session, contextUser, userSession, webAppUrl);
				}
			}
		}
		if (isBulkExportRendtion)
			return dialog;
		return super.validDialog(d2fsContext, id, dialogName, parameters);
	}

	public void exportBulkRendtionFolderObjects(String[] objectIds, IDfSession session, String contextUser,
			IDfSession userSession, String webAppUrl) throws Exception {

		int fileCount = 0;
		String fullFileName = null;
		String zFileName = null;
		String zipFilePath = null;
		String userLoginName = null;
		File tempDir = null;
		File zipFileName = null;
		String newZipFilePath = null;
		// Charset charset = StandardCharsets.UTF_8;
		IDfUser dfUser;
		dfUser = session.getUser(contextUser);
		userLoginName = dfUser.getUserLoginName();
		IDfCollection collection =null;
		LOG.debug("---- Folder Objects for Bulk Export are : -------");
		for (int i = 0; i < objectIds.length; i++) {
			String query = "select r_object_id from dm_sysobject where folder(id('"
					+ (new DfClientX().getId(objectIds[i])).toString()
					+ "')) and r_object_id in (select parent_id from dmr_content where full_format ='"
					+ SWYConstants.RENDITION_FORMAT + "')";

			 collection =null;
			try
			{
				collection = SWYDCTMUtils.runSelectQuery(query, session);
				if(collection!=null)
				{
					String weblogiTempPath = System.getProperty(SWYConstants.SYSTEM_PROP_JAVA_IO_TMP_DIR);
					LOG.info("Weblogic Temp Path = " + weblogiTempPath);

					tempDir = new File(weblogiTempPath + File.separator + SWYFileUtils.getTimeInMilliSeconds());

					if (!tempDir.exists()) {
						tempDir.mkdir();
						if (tempDir.exists()) {
							while (collection.next()) {
								IDfSysObject parentObject = (IDfSysObject) session
										.getObject(collection.getId(SWYConstants.ATTR_R_OBJECT_ID));
								LOG.info("Object ID from folder is = " + parentObject.getObjectId());
								if (parentObject.getString(SWYConstants.ATTR_A_STATUS)
										.equalsIgnoreCase(SWYConstants.EFFECTIVE_STATUS)
										&& parentObject.hasPermission(IDfACL.DF_PERMIT_READ_STR, contextUser)) {
									if (SWYDCTMUtils.hasPDFRendition(parentObject, session)) {
										fullFileName = tempDir.getAbsolutePath() + File.separator + parentObject.getObjectName()
										+ "." + SWYConstants.RENDITION_FORMAT;

										String pdfFileName = parentObject.getFileEx2(fullFileName,
												SWYConstants.RENDITION_FORMAT, 0, "", false);
										File pdfFile = new File(pdfFileName);
										System.out.println("Target Content File Path = " + pdfFile.getAbsolutePath());
										//removeSignaturePage(pdfFile);
									}
								}
								fileCount++;
								if (fileCount > 100) {
									break;
								}
								addEventToAudit(parentObject.getObjectId().toString(), session, contextUser);
							}							
							LOG.info("Number of Native content files exported  = " + fileCount +" Collection Closed");
						}
					}

				}
			}
			finally
			{
				if (collection!=null)
				{					
					collection.close();

					LOG.debug( "exportBulkRendtionFolderObjects::: Closing the collection");
				}
			}

		}
		zFileName = userLoginName + "-" + SWYFileUtils.getTimeInMilliSeconds();
		zipFilePath = tempDir.getAbsolutePath() + File.separator + zFileName + SWYConstants.ZIP_FORMAT;
		zipFileName = createZipFromDirectory(tempDir, zipFilePath);
		newZipFilePath = zipFileName.getAbsoluteFile().toString();
		LOG.info("Zip file Path = " + newZipFilePath);
		IDfSysObject zipObject = createDocument(session, userSession, newZipFilePath, zFileName,
				SWYConstants.ZIP_FORMAT, contextUser);
		LOG.info("Bulk Exported ZIP has been created with Object ID = " + zipObject.getObjectId());
		zipFileName = new File(zipFilePath);
		LOG.info("WebApp URL = " + webAppUrl);
		sendMailNotification(zipObject, userSession, contextUser, webAppUrl);

	}

	public void exportBulkRenditionObjects(String[] objectIds, IDfSession session, String contextUser,
			IDfSession userSession, String webAppUrl) throws Exception {

		int fileCount = 0;
		String fullFileName = null;
		String zFileName = null;
		String zipFilePath = null;
		String userLoginName = null;
		File tempDir = null;
		File zipFileName = null;
		String newZipFilePath = null;
		IDfUser dfUser;
		dfUser = session.getUser(contextUser);
		userLoginName = dfUser.getUserLoginName();
		// Charset charset = StandardCharsets.UTF_8;

		LOG.debug("Objects for Bulk Export are : ");

		String weblogiTempPath = System.getProperty(SWYConstants.SYSTEM_PROP_JAVA_IO_TMP_DIR);
		LOG.info("Weblogic Temp Path = " + weblogiTempPath);

		tempDir = new File(weblogiTempPath + File.separator + SWYFileUtils.getTimeInMilliSeconds());

		if (!tempDir.exists()) {
			tempDir.mkdir();
			if (tempDir.exists()) {
				System.out.println("No of Objects = " + objectIds.length);
				for (int i = 0; i < objectIds.length; i++) {

					IDfSysObject parentObject = (IDfSysObject) session.getObject(new DfClientX().getId(objectIds[i]));
					LOG.info("Object ID from folder is = " + parentObject.getObjectId());
					if (parentObject.getString(SWYConstants.ATTR_A_STATUS)
							.equalsIgnoreCase(SWYConstants.EFFECTIVE_STATUS)
							&& parentObject.hasPermission(IDfACL.DF_PERMIT_READ_STR, contextUser)) {
						if (SWYDCTMUtils.hasPDFRendition(parentObject, session)) {
							fullFileName = tempDir.getAbsolutePath() + File.separator + parentObject.getObjectName()
							+ "." + SWYConstants.RENDITION_FORMAT;

							String pdfFileName = parentObject.getFileEx2(fullFileName, SWYConstants.RENDITION_FORMAT, 0,
									"", false);
							File pdfFile = new File(pdfFileName);
							System.out.println("Target Content File Path = " + pdfFile.getAbsolutePath());
							//removeSignaturePage(pdfFile);
						}
					}
					fileCount++;
					if (fileCount > 100) {
						break;
					}
					addEventToAudit(parentObject.getObjectId().toString(), session, contextUser);
				}
				LOG.info("Number of Objects  = " + fileCount);
			}
		}
		zFileName = userLoginName + "-" + SWYFileUtils.getTimeInMilliSeconds();
		zipFilePath = tempDir.getAbsolutePath() + File.separator + zFileName + SWYConstants.ZIP_FORMAT;
		zipFileName = createZipFromDirectory(tempDir, zipFilePath);
		newZipFilePath = zipFileName.getAbsoluteFile().toString();
		LOG.info("Zip file Path = " + newZipFilePath);
		IDfSysObject zipObject = createDocument(session, userSession, newZipFilePath, zFileName,
				SWYConstants.ZIP_FORMAT, contextUser);
		LOG.info("Bulk Exported ZIP has been created with Object ID = " + zipObject.getObjectId());
		LOG.info("WebApp URL = " + webAppUrl);
		sendMailNotification(zipObject, userSession, contextUser, webAppUrl);

	}

	/**
	 * Method which calls audit method and audits an "d2_export" audit event.
	 * 
	 * @param objId
	 * @param adminSession
	 * @param userName
	 * @throws DfException
	 */

	public void addEventToAudit(String objId, IDfSession adminSession, String userName) throws DfException {
		Map<String, String> arguments = new HashMap<String, String>();
		arguments.put(SWYConstants.ARG_ID, objId);
		arguments.put(SWYConstants.ARG_EVENT, SWYConstants.EVENT_D2_EXPORT);
		arguments.put(SWYConstants.ARG_CONTEXT_USER, userName);
		arguments.put(SWYConstants.ARG_AUDIT_FIELD, SWYConstants.AUDIT_EVENT_DESCRIPTION);

		/*LSS4.2 implementation
		D2Method.start(adminSession, SWYConstants.CDF_AUDIT_METHOD, Boolean.valueOf(false), arguments);
		 */

		/* LSS 16.6 implementation starts*/
		//start(session, adminSession, methodName, isLaunchAsync, arguments, "", runLocally);
		D2Method.start(adminSession, adminSession,SWYConstants.CDF_AUDIT_METHOD, Boolean.valueOf(false), arguments,"", false);

		/*LSS 16.6 implementation ends*/
	}

	/**
	 * Method to send mail notification to the user exporting the Bulk Rendition
	 * with the URL of the Zip Object.
	 * 
	 * @param sysObject
	 * @param session
	 * @param contextUser
	 * @throws DfException
	 */

	public void sendMailNotification(IDfSysObject sysObject, IDfSession session, String contextUser, String webAppUrl)
			throws DfException {

		IDfUser dfUser;
		dfUser = session.getUser(contextUser);
		String emailList = dfUser.getUserAddress();
		LOG.info("-------------- Sending Bulk PDF Export attachment to mail ----------------");
		String mailSubject = "Link to native bulk Renditions from selected Folder or Objects.";
		String mailBody = null;
		IDfSysObject docObject = (IDfSysObject) session.getObject(sysObject.getObjectId());
		webAppUrl = webAppUrl + "?docbase=" + session.getDocbaseName() + "&locateId="
				+ docObject.getObjectId().toString();
		LOG.info("Exported URL = " + webAppUrl);
		mailBody = webAppUrl;
		LOG.info(" Mail Body = " + mailBody.toString());

		ID2MailConfig mailConfig = D2MailConfig.getInstance(session);
		MailSender mailSender = mailConfig.getMailSender();
		LOG.debug("[Bulk Export Notification] : Invoking send email for Doc Id--" + docObject.getObjectId() + "");
		LOG.debug( "[Bulk Export Notification] : Mail Subject" + mailSubject);
		LOG.debug( "[Bulk Export Notification] : Mail Body" + mailBody);
		sendMessage(mailSender, mailSubject, mailBody, emailList, mailConfig.getFromInternetAddress(), session);
	}

	/**
	 * 
	 * @param mailSender
	 * @param mailSubject
	 * @param mailBody
	 * @param addressTo
	 * @param addressFrom
	 * @param session
	 * @throws DfException
	 */
	private void sendMessage(MailSender mailSender, String mailSubject, String mailBody, String addressTo,
			InternetAddress addressFrom, IDfSession session) throws DfException {
		// Send message
		LOG.debug("-------Sending Email With Details:------");
		LOG.debug( "Email Sent To User Names" + addressTo);
		MailMessage msg = new MailMessage();
		msg.setFrom(addressFrom);
		try {
			msg.setTo(addressTo);
			LOG.debug( "Email Sent with Subject : " + mailSubject);
			LOG.debug( "Email Sent with Body : " + mailBody);
			msg.setSubject(mailSubject);
			msg.setContent(mailBody, true);
			mailSender.sendMessage(msg);
		} catch (Exception e) {
			LOG.error( "-----Error sending Email------" + getClass() + ":sendMessage");
		}
	}

	public IDfSysObject createDocument(IDfSession session, IDfSession userSession, String filePath, String fileName,
			String contentType, String contextUser) throws Exception {
		String qualification = "dm_folder where object_name ='" + SWYConstants.FOLDER_BULK_PDF_EXPORT + "'";
		contextUser = userSession.getLoginUserName();

		IDfFolder bulkExportFolder = (IDfFolder) session.getObjectByQualification(qualification);
		if (bulkExportFolder == null) {
			bulkExportFolder = (IDfFolder) session.newObject(SWYConstants.OBJ_TYPE_DM_FOLDER);
			bulkExportFolder.setObjectName(SWYConstants.FOLDER_BULK_PDF_EXPORT);
			bulkExportFolder.link("/" + SWYConstants.CABINET_GENERAL);
			bulkExportFolder.setWorldPermit(IDfACL.DF_PERMIT_WRITE);
			bulkExportFolder.save();
		}

		IDfDocument document = (IDfDocument) userSession.newObject(SWYConstants.OBJ_TYPE_DM_DOCUMENT);

		if (document != null) {
			document.setObjectName(fileName);
			document.setContentType(contentType);
			document.setFile(filePath);
			document.link(bulkExportFolder.getFolderPath(0));
			document.setString(SWYConstants.ATTR_LOG_ENTRY, SWYConstants.ATTR_LOG_ENTRY_VALUE);
			IDfACL bulkExportACL = (IDfACL) session.getObjectByQualification(
					"dm_acl where object_name='" + SWYConstants.OBJ_BULK_PDF_EXPORT_ACL + "' ");
			if (bulkExportACL != null) {
				document.setACL(bulkExportACL);
				document.setACLDomain(SWYConstants.OBJ_ACL_DOMAIN_USER);
			} else {
				bulkExportACL = (IDfACL) session.newObject(SWYConstants.OBJ_TYPE_DM_ACL);
				bulkExportACL.setObjectName(SWYConstants.OBJ_BULK_PDF_EXPORT_ACL);
				bulkExportACL.setDomain(SWYConstants.OBJ_ACL_DOMAIN_USER);
				bulkExportACL.grant(SWYConstants.OBJ_ACL_WORLD_PERMIT, 1, null);
				bulkExportACL.grant(SWYConstants.OBJ_ACL_OWNER_PERMIT, 7, null);
				bulkExportACL.save();
				document.setACL(bulkExportACL);
				document.setACLDomain(SWYConstants.OBJ_ACL_DOMAIN_USER);
			}

			document.save();
		}
		return document;
	}

	public File createZipFromDirectory(File tempDir, String zipFileName) throws IOException {
		FileOutputStream fos = null;
		ZipOutputStream zos = null;
		FileInputStream fis = null;
		File[] files = null;
		ZipEntry zipEntry = null;
		File zipFile = null;
		try {
			byte[] buffer = new byte[1024];
			String tempFileName = null;
			int length = 0;
			zipFile = new File(zipFileName);
			fos = new FileOutputStream(zipFileName);
			zos = new ZipOutputStream(fos);

			files = tempDir.listFiles();

			for (int i = 0; i < files.length; i++) {
				tempFileName = files[i].getName();
				if (SWYFileUtils.getFileExtension(tempFileName).equalsIgnoreCase(SWYConstants.RENDITION_FORMAT)) {
					System.out.println("Adding file: " + tempFileName);
					fis = new FileInputStream(files[i]);
					zipEntry = new ZipEntry(files[i].getName());
					zos.putNextEntry(zipEntry);
					while ((length = fis.read(buffer)) > 0) {
						zos.write(buffer, 0, length);
					}
				}
				zos.closeEntry();
			}
			zos.close();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {

			if (fis != null) {
				fis.close();
			}
			if (fos != null) {
				fos.close();
			}
		}
		return zipFile;
	}

	private static void removeSignaturePage(File inputFile) throws IOException, DocumentException {
		int count = 0;
		String[] searchArrayText = { SWYConstants.STR_DOCUMENT, SWYConstants.STR_ELCTRONICALLY,
				SWYConstants.STR_SIGNED };

		String inputFilePath = null;
		inputFilePath = inputFile.getAbsolutePath();

		String inputFileName = null;
		inputFileName = inputFile.getName();

		LOG.info("Repostiry Content file path = " + inputFilePath);
		LOG.info("Repostiry Content file name = " + inputFileName);

		int lastDot = inputFileName.lastIndexOf('.');
		String outputFileName = inputFileName.substring(0, lastDot) + "_updated" + inputFileName.substring(lastDot);
		LOG.info("Repostory Content file without signature page = " + outputFileName);

		String outputFilePath = null;
		outputFilePath = inputFile.getParent() + File.separator + outputFileName;
		LOG.info("Output File Absolute Path = " + outputFilePath);
		PdfReader reader = new PdfReader(inputFilePath);

		int numberOfPages = reader.getNumberOfPages();
		PdfTextExtractor pde = new PdfTextExtractor(reader);
		LOG.info("Repository Content file has pages = " + numberOfPages);
		List<Integer> allPages = new ArrayList<>(numberOfPages);
		int searchArrayLength = searchArrayText.length;
		System.out.println("--------------------------------------------");
		for (int i = 1; i <= numberOfPages; i++) {
			LOG.info("Current Page Number is " + i);
			LOG.info("--------------------------------------------");
			String pageContent = pde.getTextFromPage(i);
			allPages.add(i);
			for (int j = 0; j < searchArrayLength; j++) {
				if (pageContent.contains(searchArrayText[j])) {
					count++;
					if (searchArrayLength == count) {
						LOG.info("Current page " + i + " has " + count + " occurences.");
						allPages.remove(new Integer(count));
					}
				}
			}

		}
		FileOutputStream outputFileStream = new FileOutputStream(outputFilePath);
		reader.selectPages(allPages);
		PdfStamper pdfStamper = new PdfStamper(reader, outputFileStream);
		File outputFile = new File(outputFilePath);
		pdfStamper.close();
		reader.close();

		if (inputFile.exists()) {
			inputFile.delete();
			LOG.info("Deleted inputfile.");
			inputFile = new File(inputFilePath);
			LOG.info("Input file exists.");
			if (outputFile.renameTo(inputFile)) {
				LOG.info("Rename success");
				LOG.info("Final Output file Path = " + outputFile.getAbsolutePath());
			}

		}
	}

	public String getFullName() {
		// TODO Auto-generated method stub
		return VERSION.getFullName();
	}

	public String getProductName() {
		// TODO Auto-generated method stub
		return VERSION.getProductName();
	}

}
