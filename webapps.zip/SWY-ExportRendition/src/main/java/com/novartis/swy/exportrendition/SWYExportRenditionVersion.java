
package com.novartis.swy.exportrendition;

import com.emc.common.java.utils.AbstractVersion;
import com.emc.common.java.utils.IVersion;



/**
 * Display the plugin version.
 *
 * @author : shubhku1
 * @version : 1.0 
 */
public final class SWYExportRenditionVersion extends AbstractVersion
{
       
    public static void main(String[] args)
    {
        IVersion version = new SWYExportRenditionVersion();
       
    }
}
