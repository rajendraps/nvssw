package com.novartis.swy.exportrendition.webfs.services.custom;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.emc.d2.api.methods.D2Method;
import com.emc.d2fs.dctm.plugin.IPluginAction;
import com.emc.d2fs.dctm.web.services.D2fsContext;
import com.emc.d2fs.models.attribute.Attribute;

public class D2CustomServicePlugin implements IPluginAction
{
	private static final Logger LOGGER = LoggerFactory.getLogger(D2CustomServicePlugin.class);

	/**
	 * Calling method for the framework, which will be configure with D2 menu item
	 * @param d2fsContext : Context object provided by the framework
	 * @return : returns URL as List
	 * @throws Exception
	 */

	public List<Attribute> getCustomDownloadURL(D2fsContext d2fsContext) throws Exception
	{
		String webAppUrl=d2fsContext.getWebAppURL();

		String context_user=d2fsContext.getSession().getLoginUserName();
		IDfSession session = d2fsContext.getAdminSession();
		List<Attribute> result = new ArrayList<Attribute>();
		Attribute returnValue = new Attribute();
		returnValue.setName("RETURNED");

		String exportPdfDwnldUrl = "";

		String expObjId=d2fsContext.getParameterParser().getStringParameter("id");
		IDfSysObject objToExport = (IDfSysObject)session.getObject(new DfId(expObjId));
		LOGGER.info("User - " + session.getLoginUserName() + " has requested the PDF rendition of the Document:" + objToExport.getObjectName());

		exportPdfDwnldUrl = generateD2DownloadUrl(session,expObjId,webAppUrl);

		LOGGER.info("D2 Download URL to export PDF rendition of the document : " + objToExport.getObjectName() + "-->" + exportPdfDwnldUrl);
		System.out.println("D2 Download URL to export PDF rendition of the document : " + objToExport.getObjectName() + "-->" + exportPdfDwnldUrl);
		returnValue.setValue(exportPdfDwnldUrl);
		result.add(returnValue);
		LOGGER.info("Adding event to the Audit Trail of the object ["+expObjId+"] for exporting pdf rendition");
		addEventToAudit(objToExport.getObjectId().toString(), d2fsContext.getAdminSession(), context_user);

		return result;
	}
	
	/**
	 * This method create an entry in dm_audittrail table with respect to each download request
	 * @param objId : r_object_id of the document
	 * @param adminSess : Session object
	 * @param userName : Context user who tries to download the rendition
	 * @throws DfException
	 */
	
	private void addEventToAudit(String objId, IDfSession adminSess, String userName)
			throws DfException
	{
		Map arguments = new HashMap();
		arguments.put("-id", objId);
		arguments.put("-event", "d2_export");
		arguments.put("-context_user", userName);
		arguments.put("-string_1", "PDF Rendition Exported");
		
		/*LSS4.2 implementation
		D2Method.start(adminSess, "CDFAuditMethod", Boolean.valueOf(false), arguments);
		*/
		
		/* LSS 16.6 implementation starts*/
		//start(session, adminSession, methodName, isLaunchAsync, arguments, "", runLocally);
		D2Method.start(adminSess, adminSess,"CDFAuditMethod", Boolean.valueOf(false), arguments,"", false);
		
		/*LSS 16.6 implementation ends*/
	}

	/**
	 * This method generate D2 Servlet download URL, through which PDF rendition can be downloaded.
	 * @param admSession : Admin Session , since context user session would not be able to download the rendition without watermark or signature page
	 * @param exportedObjId : r_bject_id of the document
	 * @param webContextUrl : URL of the D2 (Client) application 
	 * @return : Complete URL along with admin login ticket to download the PDF rendition .
	 * @throws DfException
	 */

	private String generateD2DownloadUrl(IDfSession admSession,String exportedObjId, String webContextUrl) throws DfException
	{
		String d2DwnldUrl="";
		int timeout = admSession.getServerConfig().getInt("login_ticket_timeout"); 
		String docbaseName=admSession.getDocbaseName();

		/* 	userName- the user for which the login ticket is desired.Here it is null since we want a login ticket for same user from whose session we are trying to get login ticket.
			scope- - the scope od the acquired login ticket. It can be "server", "docbase", or "global".
			timeout- - How long will acquired loigin ticket remain valid since generation.
			singleUse- - if the login ticket can be used once only
			serverName- - When single_use is true, the acquired one-time login ticket will be valid in the specified server only. 
		 */
		String login_ticket=admSession.getLoginTicketEx(null, "docbase", timeout, false, docbaseName);

		d2DwnldUrl =  webContextUrl + "servlet/Download?_docbase=" 
				+ docbaseName + "&_locale=" + "en" + "&_username=" + admSession.getUser(null).getUserLoginName() 
				+ "&_password=" + login_ticket + "&id=" + exportedObjId + "&format=pdf" 
				+ "&event_name=d2_export&content_disposition=attachment";

		return d2DwnldUrl;
	}

}
